<?php
/**
 * Plugin Name: سنسور | تخفیف براساس بازدید
 * Description: ارائه خودکار تخفیف بر اساس دفعات یا مدت زمان بازدید کاربر، همراه با بنر، پیامک و نوار یادآور.
 * Version: 1.0.0
 * Author: kianAfraz | کیان‌افراز
 * Text Domain: sekianafraz-visit-discount
 * Requires at least: 6.0
 * Tested up to: 7.1.1
 * Requires PHP: 7.4
 * Requires Plugins: woocommerce
 * WC requires at least: 7.2
 * WC tested up to: 11.1.1
 */
if (!defined('ABSPATH')) { exit; }
define('SEKIANAFRAZ_VERSION', '1.0.0');
define('SEKIANAFRAZ_FILE', __FILE__);
define('SEKIANAFRAZ_PATH', plugin_dir_path(__FILE__));
define('SEKIANAFRAZ_URL', plugin_dir_url(__FILE__));
add_action('before_woocommerce_init', static function (): void {
    if (!class_exists(\Automattic\WooCommerce\Utilities\FeaturesUtil::class)) {
        return;
    }
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
        'custom_order_tables',
        __FILE__,
        true
    );
    \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
        'cart_checkout_blocks',
        __FILE__,
        true
    );
});
spl_autoload_register(function($class) {
    $prefix = 'SeKianAfraz\VisitDiscount\\';
    $baseDir = SEKIANAFRAZ_PATH . 'includes/';
    if (strpos($class, $prefix) !== 0) {
        return;
    }
    $relative = substr($class, strlen($prefix));
    $file = $baseDir . str_replace('\\', '/', $relative) . '.php';
    if (is_readable($file)) {
        require_once $file;
    }
});
register_activation_hook(__FILE__, function($networkWide = false) {
    if (class_exists('SeKianAfraz\VisitDiscount\\Installer\\Activator')) {
        \SeKianAfraz\VisitDiscount\Installer\Activator::activate((bool)$networkWide);
    }
});
register_deactivation_hook(__FILE__, function() {
    if (class_exists('SeKianAfraz\VisitDiscount\\Installer\\Deactivator')) {
        \SeKianAfraz\VisitDiscount\Installer\Deactivator::deactivate();
    }
});
function sekianafraz_license_php_supported(): bool
{
    return version_compare(PHP_VERSION, '7.4', '>=');
}
function sekianafraz_license_php_notice(): void
{
    echo '<div class="notice notice-error"><p>' . esc_html__('افزونه سنسور به PHP نسخه 7.4 یا بالاتر نیاز دارد. لطفاً نسخه PHP سرور را ارتقا دهید.', 'sekianafraz-visit-discount') . '</p></div>';
}
add_action('plugins_loaded', static function (): void {
    if (!sekianafraz_license_php_supported()) {
        add_action('admin_notices', 'sekianafraz_license_php_notice');
        return;
    }
    $gate = SEKIANAFRAZ_PATH . 'includes/License/Boot.php';
    if (is_readable($gate)) {
        require_once $gate;
    }
}, 10);
