(function () {
  const {
    $, $all, api, currencyLabel, escAttr, toast,
    withBtnLoader, renderVarsTable, renderColorFields, updateVarsTables, filterVarsByCoupon
  } = window.SEKIANAFRAZ_ADMIN_CORE;
  const {
    normalizeDigits, sanitizeAffix, mountCustomSelects, applyNumberGuards,
    enhanceTooltips, applyModalCheckboxSkin, mountColorFields, setFieldVisible, makeFormRow, beginFormLayout, refreshFormRow, animateFormContent, moveFormField
  } = window.SEKIANAFRAZ_ADMIN_CONTROLS;
  const sections = () => window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS;
  const renderActionFields = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.renderActionFields(...args);
  const collectBannerRadiusState = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.collectBannerRadiusState(...args);
  const collectBannerPaddingState = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.collectBannerPaddingState(...args);
  const previewSensor = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW.previewSensor(...args);
  const togglePreviewVisibility = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW.togglePreviewVisibility(...args);
  const updatePreview = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW.updatePreview(...args);
  function renderSensorHeaderWordmark() {
    return `<div class="sekianafraz-modal-wordmark" aria-label="Sensor">
      <svg xmlns="http://www.w3.org/2000/svg" width="1422.83px" height="280.7px" viewBox="536.16 86.89 1422.83 280.7" role="img">
        <g>
          <path class="sekianafraz-modal-wordmark-letter" style="--letter-index:0;--letter-exit-index:4" fill="#111111" d="M740.52,351.96h-0.02c-0.04,0.02-0.06,0.04-0.1,0.06l-0.12,0.08c-18.94,10.92-42.48,15.48-64.49,15.48c-15.57,0-30.37-2.28-42.22-6.23c-52.15-17.4-77.26-55.95-89.14-85.24l-0.84-2.1l48.9-14.87l0.72,1.69c0.12,0.29,12.5,28.32,36.64,52.95c21.89,22.32,45.85,34.82,71.6,37.38c37.57,3.74,72.49-21.79,77.64-59.19c0.15-1.07,0.27-2.16,0.38-3.25h-0.02c-0.49-14.64-4.28-34.79-19.49-47.54c-18.08-15.2-41.72-9.52-71.66-2.34c-20.95,5.02-44.68,10.69-72.03,10.82h-0.62c-33.7,0-52.99-12.52-63.85-25.09c-10.88-12.56-13.33-25.21-13.37-25.46c-5.37-17.87-1.28-41.35,13.49-59.33c22.7-30.74,50.52-48.26,82.75-52.09c65.68-7.83,127.93,44.79,128.54,45.32l1.62,1.38l-35.84,39.15l-1.52-1.65c-0.78-0.84-79.05-84.27-153.53-45.24c-7.44,4.15-13.59,9.4-18.53,15.3c-0.45,0.62-0.9,1.21-1.34,1.83l-0.1-0.06c-13.9,17.87-16.99,40.98-10.45,57.56c8.76,22.29,31.98,30.62,63.71,22.85c55.13-13.51,117.62-28.81,151.39-4.11c15.18,11.13,23.38,29.02,25.11,54.7C786.52,316.24,761.76,339.62,740.52,351.96z"/>
          <path class="sekianafraz-modal-wordmark-letter" style="--letter-index:0.8;--letter-exit-index:3.2" fill="#111111" d="M1006.22,262.66l39.46,21.49l-0.58,1.64c-16.45,47.61-63.97,79.6-118.2,79.6c-68.42,0-124.08-51.31-124.08-114.4c0-63.09,55.67-114.4,124.08-114.4c31.09,0,60.85,10.65,83.76,30c22.83,19.27,36.93,45.47,39.75,73.76l0.23,2.26H867.49v-4.11h138.6c-4.48-55.03-38.95-97.8-79.19-97.8c-43.97,0-79.75,49.48-79.75,110.28c0,60.81,35.78,110.28,79.75,110.28c39.77,0,73.74-41.07,79-95.54L1006.22,262.66z"/>
          <path class="sekianafraz-modal-wordmark-letter" style="--letter-index:1.6;--letter-exit-index:2.4" fill="#111111" d="M1266.73,216.33v149.07h-42.5V201.83c0-15.55-6.17-30.19-16.94-40.16c-13.26-12.28-29.22-14.65-47.62-7.12c-13.02,5.33-23.99,14.75-31.87,26.41c-4.17,6.16-7.38,12.13-9.74,17.1v167.33h-38.23V137.67h38.23v51.41c4.52-8.25,10.88-17.79,19.35-26.42l-0.06-0.08c0.17-0.12,0.33-0.25,0.51-0.37c13.39-13.47,32.02-24.53,57.04-24.53C1265.91,137.67,1266.73,215.55,1266.73,216.33z"/>
          <path class="sekianafraz-modal-wordmark-letter" style="--letter-index:2.4;--letter-exit-index:1.6" fill="#111111" d="M1508.93,287.97c2.42,32.77-19.04,51.23-37.45,60.97h-0.02c-0.04,0.02-0.05,0.03-0.09,0.05l-0.11,0.07c-16.42,8.62-36.83,12.22-55.9,12.22c-13.49,0-26.33-1.8-36.59-4.92c-45.2-13.73-66.97-44.17-77.27-67.28l-0.73-1.66l42.39-11.74l0.62,1.33c0.11,0.23,10.84,22.35,31.76,41.8c21.62,20.08,45.59,30.09,71.52,29.89c17.27-0.13,34.06-7.02,45.31-20.12c6.6-7.68,11.59-17.39,12.86-29.56h-0.02c-0.43-11.56-3.71-27.46-16.9-37.53c-15.67-12-36.17-7.52-62.12-1.85c-18.16,3.96-38.73,8.44-62.44,8.54h-0.53c-29.21,0-45.93-9.88-55.34-19.8c-9.43-9.92-11.55-19.9-11.59-20.09c-4.65-14.11-1.1-32.64,11.69-46.83c19.68-24.27,43.79-38.1,71.72-41.12c56.93-6.19,110.89,35.35,111.42,35.77l1.41,1.09l-31.07,30.91l-1.32-1.3c-0.68-0.67-68.52-66.52-133.08-35.71c-6.45,3.28-11.78,7.42-16.06,12.08c-0.39,0.49-0.78,0.96-1.16,1.45l-0.09-0.05c-12.05,14.1-14.72,32.35-9.05,45.43c7.59,17.6,25.45,19.01,52.95,12.88c47.79-10.66,101.96-22.74,131.22-3.25C1498.06,248.42,1507.44,267.7,1508.93,287.97L1508.93,287.97z"/>
          <path class="sekianafraz-modal-wordmark-letter" style="--letter-index:3.2;--letter-exit-index:0.8" fill="#111111" d="M1772.54,251.53c0,62.16-53.69,112.85-120.09,113.84c-0.66,0-1.32,0.02-1.99,0.02s-1.34-0.02-2-0.02c-66.4-0.99-120.09-51.66-120.09-113.84s53.69-112.85,120.09-113.84c0.66,0,1.32-0.02,2-0.02s1.34,0.02,1.99,0.02C1718.85,138.68,1772.54,189.37,1772.54,251.53z M1727.61,251.53c0-59.57-33.54-108.21-75.16-109.71c-0.66-0.02-1.34-0.04-1.99-0.04c-0.66,0-1.34,0.02-2,0.04c-41.6,1.5-75.16,50.15-75.16,109.71c0,59.55,33.56,108.21,75.16,109.71c0.66,0.02,1.34,0.04,2,0.04c0.66,0,1.34,0,1.99-0.04C1694.07,359.74,1727.61,311.11,1727.61,251.53z"/>
          <path class="sekianafraz-modal-wordmark-letter" style="--letter-index:4;--letter-exit-index:0" fill="#111111" d="M1958.98,152.54l-14.54,38.78l-2.26-2.34c-1.15-1.19-18.53-18.88-42.33-23.79c-23.71-4.89-47.75,7.23-58.61,28.87l-0.03,0.06v171.28h-38.23V137.67h38.23v47.87c7.3-12.28,24.78-36.58,52.31-44.95c20.13-6.13,41.66-2.39,63.97,11.08L1958.98,152.54z"/>
        </g>
      </svg>
    </div>`;
  }
  function mountModalRows() {
    const fieldOf = id => $('#' + id)?.closest('.sekianafraz-field');
    const visitRow = makeFormRow('sekianafraz-visit-row', [fieldOf('sekianafraz-visit-metric'), $('#sekianafraz-min-views-wrap'), $('#sekianafraz-min-duration-wrap')]);
    ensureVisitConditionControl(visitRow);
    const individual = $('#sekianafraz-individual-wrap');
    const custom = $('#sekianafraz-custom-coupon-template-wrap');
    if (custom?.parentElement === individual) individual.after(custom);
    makeFormRow('sekianafraz-coupon-type-row', [fieldOf('sekianafraz-coupon-strategy'), individual]);
    custom?.classList.add('sekianafraz-form-row');
    refreshFormRow(custom);
    makeFormRow('sekianafraz-discount-row', [fieldOf('sekianafraz-cmode'), fieldOf('sekianafraz-coupon-amount')]);
    $('#sekianafraz-expiry-wrap')?.classList.add('sekianafraz-form-row');
    refreshFormRow($('#sekianafraz-expiry-wrap'));
    makeFormRow('sekianafraz-action-row', [fieldOf('sekianafraz-action'), $('#sekianafraz-banner-type-slot')]);
  }
  function layoutReminder() {
    const reminder = $('#sekianafraz-reminder-wrap');
    const row = $('#sekianafraz-banner-options-row');
    const home = $('#sekianafraz-reminder-home');
    if (!reminder || !row || !home) return;
    const expanded = !!$('#sekianafraz-reminder-enabled')?.checked && reminder._sekianafrazVisible !== false;
    const destination = expanded ? home : row;
    if (reminder.parentElement !== destination) {
      moveFormField(reminder, destination, true);
    }
    reminder.classList.toggle('is-full-row', expanded);
    refreshFormRow(row);
  }
  function renderModal(mode) {
    return '<div class="content">' +
      '<div class="header">' +
      '<div class="sekianafraz-modal-header-save">' +
      '<button class="sekianafraz-btn primary" id="sekianafraz-save-sensor">ذخیره سنسور</button>' +
      '</div>' +
      renderSensorHeaderWordmark() +
      '<div class="sekianafraz-modal-header-actions">' +
      '<button class="close" id="sekianafraz-close-modal">\n' +
      '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>\n' +
      '</button>' +
      '<button class="sekianafraz-btn secondary" id="sekianafraz-preview-sensor" style="display:none"><span class="sekianafraz-preview-label">پیش‌نمایش بنر</span></button>' +
      renderDeviceToggle() +
      '</div>' +
      '</div>' +
      '<div class="sensor-modal-body">' +
      '<div class="sensor-modal-fields">' +
      field('نام سنسور', 'text', 'sekianafraz-name', '', 'مثلاً: سنسور بازدید پسته احمدآقایی') +
      sections().start('location', 'کجارو تحت نظر بگیرم؟') +
      placementList() +
      '<div id="sekianafraz-dynamic"></div>' +
      '<div id="sekianafraz-exclusions-wrap" hidden></div>' +
      '<div id="sekianafraz-visit-calculation-wrap" style="display:none">' +
      list('نحوه محاسبه بازدید', 'sekianafraz-visit-calculation', [['individual', 'محاسبه تکی'], ['aggregate', 'محاسبه تجمیعی']]) +
      '</div>' +
      sections().end() +
      sections().start('conditions', 'شرط تخفیف دادن چی باشه؟') +
      list('نوع محاسبه بازدید کاربر', 'sekianafraz-visit-metric', [['views', 'براساس دفعات بازدید'], ['duration', 'براساس مدت زمان بازدید'], ['both', 'براساس دفعات و مدت زمان بازدید']]) +
      '<div id="sekianafraz-min-views-wrap">' +
      field('حداقل دفعات بازدید', 'number', 'sekianafraz-min', '', 'مثلاً: 3') +
      '</div>' +
      '<div id="sekianafraz-min-duration-wrap" style="display:none">' +
      field('حداقل مدت زمان بازدید (ثانیه)', 'number', 'sekianafraz-min-duration', '', 'پیش‌فرض: 120 ثانیه') +
      '</div>' +
      list('در بازه زمانی', 'sekianafraz-window', [['24h', '24 ساعته'], ['72h', '72 ساعته'], ['1w', '1 هفته‌ای']]) +
      sections().end() +
      sections().start('coupon', 'به کاربر چه تخفیفی بدم؟') +
      couponStrategyList() +
      '<div id="sekianafraz-fixed-code-wrap" style="display:none">' +
      field('کد تخفیف', 'text', 'sekianafraz-fixed-code', '', '') +
      '</div>' +
      '<div id="sekianafraz-individual-wrap">' +
      list('الگوی کوپن', 'sekianafraz-ctype', [['numbers', 'ترکیب اعداد'], ['letters', 'ترکیب حروف'], ['mixed', 'هر دو'], ['custom', 'الگوی اختصاصی شما', 'coupon_custom_template']]) +
      '<div id="sekianafraz-custom-coupon-template-wrap" style="display:none">' +
        '<div class="sekianafraz-field">' +
          '<label>پیشوند</label>' +
          '<input type="text" id="sekianafraz-coupon-prefix" maxlength="32" placeholder="SNSR_" inputmode="latin" autocomplete="off">' +
        '</div>' +
        '<div class="sekianafraz-field">' +
          '<label>پسوند</label>' +
          '<input type="text" id="sekianafraz-coupon-suffix" maxlength="32" placeholder="_SNSR" inputmode="latin" autocomplete="off">' +
        '</div>' +
                list('الگوی رشته کاراکتر میانی', 'sekianafraz-coupon-mid-pattern', [['numbers','ترکیب اعداد'], ['letters','ترکیب حروف'], ['mixed','هر دو']]) +
        '<div class="sekianafraz-field">' +
          '<label>طول رشته‌کارکتر میانی</label>' +
          '<input type="number" id="sekianafraz-coupon-length" min="3" max="64" value="" placeholder="4">' +
        '</div>' +
      '</div>' +
      '</div>' +
      list('نوع مبلغ تخفیف', 'sekianafraz-cmode', [['fixed', 'مقدار ثابت'], ['percent', 'درصدی']]) +
      '<div class="sekianafraz-field">' +
      '<label>مبلغ تخفیف <span id="sekianafraz-coupon-amount-unit">(' + escAttr(currencyLabel) + ')</span></label>' +
      '<input required type="text" inputmode="decimal" autocomplete="off" dir="ltr" id="sekianafraz-coupon-amount" value="" placeholder="مثلاً: 200,000 ' + escAttr(currencyLabel) + '">' +
      '</div>' +
      '<div id="sekianafraz-expiry-wrap">' +
      field('مهلت استفاده (ساعت)', 'number', 'sekianafraz-coupon-valid-hours', '', 'مثلاً: 24 ساعت') +
      field('حداکثر دفعات استفاده از کد تخفیف', 'number', 'sekianafraz-coupon-usage-limit', '', 'پیش‌فرض: 3 بار') +
      '</div>' +
      '<div id="sekianafraz-coupon-options-stack">' +
      renderCouponOwnershipSection() +
      renderCouponLimitSection() +
      '</div>' +
      sections().end() +
      sections().start('reaction', 'اگه کاربر شرط بازدید رو انجام داد، چیکار کنم؟') +
      list('عکس‌العمل', 'sekianafraz-action', [["both", "نمایش بنر + ارسال پیامک"], ["sms", "ارسال پیامک (مخصوص کاربران وارد شده)"], ["banner", "نمایش بنر"]]) +
      '<div id="sekianafraz-banner-type-slot" style="display:none"></div>' +
      '<div id="sekianafraz-reaction-options"></div><div id="sekianafraz-logged-behavior-slot"></div>' +
      sections().end() +
      renderAudienceToggle() +
      '<div id="sekianafraz-banner-controls-home" hidden>' +
      '<div id="sekianafraz-banner-options-row" class="sekianafraz-form-row is-empty"></div>' +
      '<div id="sekianafraz-close-position-slot"></div>' +
      '<div id="sekianafraz-reminder-home">' + renderReminderSection() + '</div>' +
      '</div>' +
      '<div id="sekianafraz-action-fields"></div>' +
      '</div>' +
      '</div>' +
      '<div class="sensor-preview-column" style="display:flex;flex-direction:column;align-items:center;justify-content:center">' +
      '<div id="sekianafraz-preview-column" style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;overflow-y:auto;padding-bottom:100px;box-sizing:border-box"></div>' +
      '<div id="sekianafraz-reminder-preview-wrap" style="position:absolute;bottom:0;left:0;right:0;z-index:100;display:none"></div>' +
      '</div>' +
      '</div>' +
      '<footer class="sekianafraz-sensor-modal-footer">طراحی و توسعه توسط <strong>تیم برنامه‌نویسی کیان‌افراز</strong></footer>'
  }
  function renderAudienceToggle() {
    return '<div id="sekianafraz-audience-toggle" class="sekianafraz-body-audience-slot" data-active="0" aria-hidden="true" inert>' +
      '<div class="sekianafraz-audience-viewport"><div class="sekianafraz-audience-control" role="group" aria-label="اکشن کاربران"><span class="slider" aria-hidden="true"></span>' +
      '<button type="button" class="nav-item active" data-audience="guest" aria-label="اکشن کاربران وارد نشده" title="اکشن کاربران وارد نشده" aria-pressed="true">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="7" r="4"/><path d="M2 21v-2a7 7 0 0 1 12-5M16 16l6 6M22 16l-6 6"/></svg><span>کاربران مهمان</span></button>' +
      '<button type="button" class="nav-item" data-audience="logged" aria-label="اکشن کاربران وارد شده" title="اکشن کاربران وارد شده" aria-pressed="false">' +
      '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="7" r="4"/><path d="M2 21v-2a7 7 0 0 1 12-5M15 19l3 3 5-6"/></svg><span>کاربران واردشده</span></button></div></div></div>';
  }
  function renderDeviceToggle() {
    return `
    <div class="sekianafraz-device-toggle" id="sekianafraz-device-toggle" data-active="1" style="display:none">
        <div class="slider"></div>
        <div class="nav-item" onclick="SEKIANAFRAZ_ADMIN_FUNCS.setDevice(0)">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <rect x="5" y="2" width="14" height="20" rx="2" ry="2"></rect>
                <line x1="12" y1="18" x2="12.01" y2="18"></line>
            </svg>
        </div>
        <div class="nav-item active" onclick="SEKIANAFRAZ_ADMIN_FUNCS.setDevice(1)">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect>
                <line x1="12" y1="18" x2="12.01" y2="18"></line>
            </svg>
        </div>
        <div class="nav-item" onclick="SEKIANAFRAZ_ADMIN_FUNCS.setDevice(2)">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect>
                <line x1="8" y1="21" x2="16" y2="21"></line>
                <line x1="12" y1="17" x2="12" y2="21"></line>
            </svg>
        </div>
    </div>`;
  }
  window.SEKIANAFRAZ_ADMIN_FUNCS = window.SEKIANAFRAZ_ADMIN_FUNCS || {};
  window.SEKIANAFRAZ_ADMIN_FUNCS.setDevice = function (index) {
    const group = document.getElementById('sekianafraz-device-toggle');
    const modal = document.getElementById('sekianafraz-sensor-modal');
    if (!group) return;
    const items = group.querySelectorAll('.nav-item');
    group.setAttribute('data-active', index);
    if (modal) modal.setAttribute('data-device', String(index));
    items.forEach((item, i) => {
      if (i === index) item.classList.add('active');
      else item.classList.remove('active');
    });
  };
function renderCouponOwnershipSection() {
  return '<div id="sekianafraz-coupon-ownership-section" class="sekianafraz-field" style="display:none">' +
    '<div id="sekianafraz-coupon-ownership-row" class="sekianafraz-form-row">' +
    ['user', 'guest'].map(type => '<div class="sekianafraz-field" id="sekianafraz-coupon-restrict-' + type + '-wrap">' +
      '<label class="sekianafraz-coupon-ownership-label">' +
      '<input type="checkbox" class="ui-checkbox" id="sekianafraz-coupon-restrict-' + type + '">' +
      '<span>محدودسازی اعمال کوپن فقط برای همان ' + (type === 'user' ? 'حساب کاربری' : 'کاربر مهمان') + '</span>' +
      '</label></div>').join('') +
    '</div></div>';
}
  function refreshCouponOwnership() {
    const strategy = $('#sekianafraz-coupon-strategy')?.value || 'individual';
    setFieldVisible($('#sekianafraz-coupon-ownership-section'), ['individual', 'virtual'].includes(strategy));
    refreshFormRow($('#sekianafraz-coupon-ownership-row'));
  }
  function renderCouponLimitSection() {
    const titleHtml = 'کد تخفیف ساخته‌شده فقط روی محصول/دسته‌بندی خاص اعمال شود.';
    return '<div id="sekianafraz-coupon-limit-section" class="sekianafraz-coupon-option-group">' +
      '<div class="sekianafraz-coupon-option-block" id="sekianafraz-coupon-limit-option">' +
      '<div class="sekianafraz-field sekianafraz-coupon-checkbox-row" id="sekianafraz-coupon-limit-toggle-wrap">' +
      '<label class="sekianafraz-conditional-label sekianafraz-coupon-ownership-label">' +
      '<input type="checkbox" class="ui-checkbox" id="sekianafraz-coupon-limit-enabled"> ' +
      '<span id="sekianafraz-coupon-limit-title">' + titleHtml + '</span>' +
      '</label>' +
      '</div>' +
      '<div id="sekianafraz-coupon-limit-settings" class="sekianafraz-conditional-content" data-conditional-checkbox="sekianafraz-coupon-limit-enabled" style="display:none">' +
      '<div class="sekianafraz-field" style="margin:0 0 30px 0">' +
      '<label>نوع محدودسازی</label>' +
      '<div style="display:flex;gap:12px;flex-wrap:wrap">' +
      '<label style="display:flex;align-items:center;gap:6px"><input type="checkbox" class="ui-checkbox" name="sekianafraz-limit-type" id="sekianafraz-limit-type-product" value="product" checked> شامل محصول خاص</label>' +
      '<label style="display:flex;align-items:center;gap:6px"><input type="checkbox" class="ui-checkbox" name="sekianafraz-limit-type" id="sekianafraz-limit-type-category" value="category"> شامل دسته‌بندی محصولات خاص</label>' +
      '</div>' +
      '</div>' +
      '<div id="sekianafraz-limit-dynamic"></div>' +
      '</div>' +
      '</div>' +
      '<div class="sekianafraz-coupon-option-block" id="sekianafraz-coupon-free-shipping-option">' +
      '<div class="sekianafraz-field sekianafraz-coupon-checkbox-row" id="sekianafraz-coupon-free-shipping-wrap">' +
      '<label class="sekianafraz-coupon-ownership-label">' +
      '<input type="checkbox" class="ui-checkbox" id="sekianafraz-coupon-free-shipping">' +
      '<span>کد تخفیف شامل ارسال رایگان شود</span>' +
      '</label>' +
      '</div>' +
      '</div>' +
      '</div>';
  }
  function renderReminderSection() {
    const titleHtml = 'افزودن نوار یادآور';
    return '<div id="sekianafraz-reminder-wrap" style="display:none">' +
      '<div class="sekianafraz-field sekianafraz-reminder-checkbox-field">' +
      '<label style="display:flex;align-items:center;gap:6px;width:100%;font-weight:500" class="sekianafraz-conditional-label">' +
      '<input type="checkbox" class="ui-checkbox" id="sekianafraz-reminder-enabled"> ' +
      '<span id="sekianafraz-reminder-title">' + titleHtml + '</span>' +
      '</label>' +
      '</div>' +
      '</div>' +
      '<div id="sekianafraz-reminder-settings" class="sekianafraz-conditional-content" data-conditional-checkbox="sekianafraz-reminder-enabled" style="display:none">' +
      '<div class="sekianafraz-field">' +
      '<label>کد کوتاه</label>' +
      '<div style="position:relative">' +
      '<input type="text" value="[sensor_reminder_bar]" readonly style="width:100%; background: var(--gray-40); padding-left:70px; box-sizing:border-box">' +
      '<button type="button" class="sekianafraz-btn" style="position:absolute; left:9px; top:50%; transform:translateY(-50%); background:#000; color:#fff; border-radius:0; height:32px; padding:0 15px; border:none; cursor:pointer" onclick="document.querySelector(\'#sekianafraz-reminder-settings input\').select();document.execCommand(\'copy\');SEKIANAFRAZ_ADMIN_FUNCS.toast(\'کپی شد!\')">کپی</button>' +
      '</div>' +
      '</div>' +
      '<div class="sekianafraz-field">' +
      '<label>متن یادآور</label>' +
      '<textarea id="sekianafraz-reminder-message" rows="2" placeholder="فقط {Timer} ساعت برای استفاده از کد تخفیف {coupon_code} باقی مونده!"></textarea>' +
      renderVarsTable([
        { label: 'کد تخفیف', key: 'coupon_code', token: '{coupon_code}' },
        { label: 'تایمر معکوس', key: 'Timer', token: '{Timer}' }
      ]) +
      '</div>' +
      '<div class="sekianafraz-field sekianafraz-reminder-timer-panel-field">' +
      '<label style="display:flex;align-items:center;gap:6px"><input type="checkbox" class="ui-checkbox" id="sekianafraz-reminder-timer-panel"> <span>نمایش پنل تایمر</span></label>' +
      '</div>' +
      '<div class="sekianafraz-field sekianafraz-color-section">' +
      renderColorFields([
        ['sekianafraz-reminder-color-bg', 'پس‌زمینه', '#ffffff'],
        ['sekianafraz-reminder-color-text', 'متن', '#4b5563'],
        ['sekianafraz-reminder-color-timer-value', 'عدد تایمر', '#5F0027'],
        ['sekianafraz-reminder-color-timer-bg', 'باکس تایمر', '#000000'],
        ['sekianafraz-reminder-color-timer-text', 'متن تایمر', '#ffffff'],
        ['sekianafraz-reminder-color-close-btn', 'دکمه بستن', '#4b5563'],
        ['sekianafraz-reminder-color-coupon-highlight', 'هایلایت کد', '#5F0027']
      ], 'sekianafraz-reminder-color-fields') +
      window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.renderReminderStyleControls() +
      '</div>' +
      '</div>';
  }
  function mountCouponLimit() {
    const enabled = $('#sekianafraz-coupon-limit-enabled');
    const settings = $('#sekianafraz-coupon-limit-settings');
    const rProd = $('#sekianafraz-limit-type-product');
    const rCat = $('#sekianafraz-limit-type-category');
    const strategy = $('#sekianafraz-coupon-strategy');
    const section = $('#sekianafraz-coupon-limit-section');
    function refresh() {
      if (!settings) return;
      const available = !strategy || !['fixed', 'none'].includes(strategy.value);
      setFieldVisible(section, available);
      if (!available && enabled) enabled.checked = false;
      const show = available && !!(enabled && enabled.checked);
      setFieldVisible(settings, show);
      if (!show) return;
      const t = (rCat && rCat.checked) ? 'category' : 'product';
      if ($('#sekianafraz-limit-dynamic')?.dataset.limitType !== t) loadCouponLimitFields(t);
    }
    if (enabled) enabled.addEventListener('change', refresh);
    if (strategy) strategy.addEventListener('change', refresh);
    if (rProd) rProd.addEventListener('change', refresh);
    if (rCat) rCat.addEventListener('change', refresh);
    refresh();
  }
  function mountCustomCouponTemplate() {
    const sel = $('#sekianafraz-ctype');
    const wrap = $('#sekianafraz-custom-coupon-template-wrap');
    const prefix = $('#sekianafraz-coupon-prefix');
    const suffix = $('#sekianafraz-coupon-suffix');
    const mid = $('#sekianafraz-coupon-mid-pattern');
    const len = $('#sekianafraz-coupon-length');
    if (!sel || !wrap) return;
    function bindSanitizers() {
      if (wrap.dataset.sekianafrazBoundCustomTplInputs) return;
      wrap.dataset.sekianafrazBoundCustomTplInputs = '1';
      if (prefix) prefix.addEventListener('input', () => { const v = sanitizeAffix(prefix.value); if (v !== prefix.value) prefix.value = v; });
      if (suffix) suffix.addEventListener('input', () => { const v = sanitizeAffix(suffix.value); if (v !== suffix.value) suffix.value = v; });
      if (len) {
        len.addEventListener('input', () => { const nv = normalizeDigits(len.value); if (nv !== len.value) len.value = nv; });
        len.addEventListener('blur', () => { const raw = normalizeDigits(len.value || ''); let n = parseInt(raw || '4', 10); if (isNaN(n)) n = 4; if (n < 3) n = 3; if (n > 64) n = 64; len.value = String(n); });
      }
    }
    function refresh() {
      const show = sel.value === 'custom' && !['fixed', 'none'].includes($('#sekianafraz-coupon-strategy')?.value);
      setFieldVisible(wrap, show, 'grid');
      if (!show) return;
      bindSanitizers();
    }
    if (!sel.dataset.sekianafrazBoundCustomTpl) {
      sel.dataset.sekianafrazBoundCustomTpl = '1';
      sel.addEventListener('change', refresh);
    }
    refresh();
  }
  function mountReminder() {
    const wrap = $('#sekianafraz-reminder-wrap');
    const enabled = $('#sekianafraz-reminder-enabled');
    const settings = $('#sekianafraz-reminder-settings');
    const strategy = $('#sekianafraz-coupon-strategy');
    const action = $('#sekianafraz-action');
    function refreshVisibility() {
      const act = action ? action.value : '';
      const allowAct = (act === 'banner' || act === 'both');
      const allowStrategy = strategy ? !['fixed', 'none'].includes(strategy.value) : true;
      const multi = $('#sekianafraz-banner-type')?.value === 'multi';
      const loggedBanner = ['single', 'single_sms'].includes($('#sekianafraz-logged-behavior')?.value);
      const available = allowAct && allowStrategy && (!multi || loggedBanner);
      const allow = available && (!multi || $('#sekianafraz-action-fields')?.dataset.previewAudience === 'logged');
      setFieldVisible(wrap, allow);
      if (settings) {
        const show = allow && !!(enabled && enabled.checked);
        setFieldVisible(settings, show);
        const timerOn = show && !!$('#sekianafraz-reminder-timer-panel')?.checked;
        $('#sekianafraz-reminder-styles')?.querySelectorAll('[data-radius-target="reminder_timer"], [data-padding-target="reminder_timer"], [data-margin-target="reminder_timer"]').forEach(el => setFieldVisible(el, timerOn));
        ['timer-value', 'timer-bg', 'timer-text'].forEach((part) => {
          const el = $('#sekianafraz-reminder-color-' + part)?.closest('.sekianafraz-color-field');
          setFieldVisible(el, timerOn);
        });
      }
      layoutReminder();
      if (typeof updatePreview === 'function') updatePreview();
    }
    function bindOnce(el, evt, fn) {
      if (!el) return;
      const k = 'sekianafrazBound' + evt;
      if (el.dataset && el.dataset[k]) return;
      if (el.dataset) el.dataset[k] = '1';
      el.addEventListener(evt, fn);
    }
    bindOnce(enabled, 'change', refreshVisibility);
    bindOnce($('#sekianafraz-reminder-timer-panel'), 'change', refreshVisibility);
    bindOnce(strategy, 'change', refreshVisibility);
    bindOnce(action, 'change', refreshVisibility);
    wrap._refreshVisibility = refreshVisibility;
    mountColorFields(wrap || document);
    window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.mountReminderStyleControls();
    refreshVisibility();
  }
  const searchEmptyIcon = '<svg class="sensors-empty-icon" viewBox="0 0 126.086 120.359" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">' +
    '<path d="M125.95,42.66a2.983,2.983,0,0,0-3.8-1.9l-2.2.7a60.491,60.491,0,0,1-54.1-39.5,3.037,3.037,0,0,0-5.7,2.1,66.706,66.706,0,0,0,46.9,41.6l-18.5,6.1a78.564,78.564,0,0,1-22.5-16.3v-8.2a3,3,0,0,0-6,0v8.2a81.674,81.674,0,0,1-10.4,9.1,3.011,3.011,0,0,0,3.5,4.9,73.4,73.4,0,0,0,6.9-5.6v15.3l-41.1-13.5a65.685,65.685,0,0,0,19-7.8,2.984,2.984,0,1,0-3.1-5.1,59.791,59.791,0,0,1-28.7,8.7l-2.2-.7a3,3,0,0,0-1.9,5.7l2.7.8a57.54,57.54,0,0,1,11.2,11.9,61.222,61.222,0,0,1,7.7,14.8,59.208,59.208,0,0,1,3.4,16.2,2.971,2.971,0,0,0,3,2.8h.2a3.012,3.012,0,0,0,2.8-3.2,68,68,0,0,0-3.7-17.8,66.584,66.584,0,0,0-8.5-16.3c-1-1.4-2.1-2.8-3.2-4.2l18.4,6.1a75.9,75.9,0,0,1,8.4,26.2l-23,31.7a2.953,2.953,0,0,0,.7,4.2,2.792,2.792,0,0,0,1.8.6,2.982,2.982,0,0,0,2.4-1.2l4.1-5.7h0a60.379,60.379,0,0,1,65.1.1v.1l4,5.6a2.982,2.982,0,0,0,2.4,1.2,3.226,3.226,0,0,0,1.8-.6,3.122,3.122,0,0,0,.7-4.2l-3.3-4.6v-.2a60.121,60.121,0,0,1,20.2-63.4l2.6-.8A3.235,3.235,0,0,0,125.95,42.66Zm-58.1,22.2,14.2-4.7a82.3,82.3,0,0,0-5.4,16.8Zm12.7-10.5-14.5,4.8V43.76A82.892,82.892,0,0,0,80.55,54.36Zm-36.6,5.8,17.2,5.6,10.5,14.5a83.36,83.36,0,0,0-17.3,0l4.1-5.6a3.011,3.011,0,1,0-4.9-3.5l-4.2,5.8A82.3,82.3,0,0,0,43.95,60.16Zm49.9,45.2a66.77,66.77,0,0,0-55.6-2.8l11.3-15.6a81.563,81.563,0,0,1,27,0l5.5,7.6a2.982,2.982,0,0,0,2.4,1.2,3.226,3.226,0,0,0,1.8-.6,3.122,3.122,0,0,0,.7-4.2l-5.3-7.3a78.078,78.078,0,0,1,8.4-26.2l18.5-6.1A66.829,66.829,0,0,0,93.85,105.36Z" transform="translate(-0.002 -0.001)"></path>' +
    '<path d="M47.05,24.26a3,3,0,1,0,3,3A3,3,0,0,0,47.05,24.26Z" transform="translate(-0.002 -0.001)"></path></svg>';
  function searchStateMarkup(state) {
    if (state === 'loading') {
      return '<div class="sekianafraz-search-status" role="status"><span class="sekianafraz-search-spinner" aria-hidden="true"></span><span>درحال جستجو...</span></div>';
    }
    return '<div class="sensors-empty-state sekianafraz-search-empty-state">' + searchEmptyIcon +
      '<div class="sensors-empty-title">چیزی یافت نشد!</div>' +
      '<div class="sensors-empty-desc">لطفا عبارت دیگری را وارد کنید.</div></div>';
  }
  function ensureSearchResults(input, resultsId) {
    let list = document.getElementById(resultsId);
    if (!list) {
      list = document.createElement('div');
      list.id = resultsId;
      list.className = 'sekianafraz-results';
      list.setAttribute('aria-live', 'polite');
      list.innerHTML = '<div class="sekianafraz-results-inner"></div>';
      const fieldWrap = input.closest('.sekianafraz-field');
      if (!fieldWrap) return null;
      fieldWrap.appendChild(list);
    }
    clearTimeout(list._sekianafrazCloseTimer);
    clearTimeout(list._sekianafrazSettleTimer);
    return list;
  }
  function showSearchLoader(input, resultsId) {
    const list = ensureSearchResults(input, resultsId);
    if (!list) return null;
    const inner = list.querySelector('.sekianafraz-results-inner');
    if (inner) inner.innerHTML = searchStateMarkup('loading');
    list.setAttribute('aria-busy', 'true');
    list.classList.remove('is-results', 'is-closing', 'is-visible', 'is-loading', 'is-settled');
    void list.offsetWidth;
    list.classList.add('is-loading', 'is-visible');
    return list;
  }
  function closeSearchResults(resultsId) {
    const list = document.getElementById(resultsId);
    if (!list) return;
    clearTimeout(list._sekianafrazCloseTimer);
    clearTimeout(list._sekianafrazSettleTimer);
    list.classList.remove('is-visible');
    list.classList.add('is-closing');
    const reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const duration = list.classList.contains('is-loading') ? 240 : 480;
    list._sekianafrazCloseTimer = setTimeout(() => list.remove(), reduceMotion ? 0 : duration);
  }
  function renderSearchItems(list, items, chipsId, onSelect, options) {
    const opts = options || {};
    const inner = list && list.querySelector('.sekianafraz-results-inner');
    if (!inner) return;
    const append = !!opts.append;
    if (!append) inner.innerHTML = '';
    inner.querySelector('.sekianafraz-search-more-wrap')?.remove();
    if (!items.length && !append) {
      inner.innerHTML = searchStateMarkup('empty');
    } else if (items.length) {
      const chips = document.getElementById(chipsId);
      const html = items.map((item, index) => {
        const selected = !!(chips && chips.querySelector('.sekianafraz-chip[data-id="' + item.id + '"]'));
        const classes = 'item is-entering' + (item.disabled ? ' disabled' : '') + (selected ? ' is-selected' : '');
        const message = item.disabled ? '<small>(قبلا در سنسور ' + escAttr(item.conflict_sensor || '') + ' فراخوانی شده!)</small>' : '';
        const animationIndex = Math.min(index, 20);
        return '<div class="' + classes + '" style="--sekianafraz-result-index:' + animationIndex + '" data-sekianafraz-new="1" data-id="' + escAttr(item.id) + '" data-disabled="' + (item.disabled ? '1' : '0') + '">' +
          '<span class="sekianafraz-result-label">' + escAttr(item.label || '') + '</span>' + message + '</div>';
      }).join('');
      inner.insertAdjacentHTML('beforeend', html);
      const newItems = Array.from(inner.querySelectorAll('[data-sekianafraz-new="1"]'));
      newItems.forEach((el) => {
        el.removeAttribute('data-sekianafraz-new');
        if (el.dataset.disabled === '1') return;
        el.addEventListener('click', () => {
          const label = el.querySelector('.sekianafraz-result-label');
          onSelect(el.getAttribute('data-id'), label ? label.textContent : el.textContent);
          el.classList.add('is-selected');
        });
      });
      requestAnimationFrame(() => requestAnimationFrame(() => newItems.forEach((el) => el.classList.remove('is-entering'))));
    }
    if (opts.hasMore && typeof opts.onMore === 'function') {
      const moreWrap = document.createElement('div');
      moreWrap.className = 'sekianafraz-search-more-wrap';
      moreWrap.innerHTML = '<button type="button" class="sekianafraz-search-more">نمایش بیشتر</button>';
      moreWrap.querySelector('button').addEventListener('click', opts.onMore);
      inner.appendChild(moreWrap);
    }
    list.classList.remove('is-loading', 'is-closing', 'is-settled');
    list.classList.add('is-results', 'is-visible');
    list.setAttribute('aria-busy', 'false');
    list._sekianafrazSettleTimer = setTimeout(() => list.classList.add('is-settled'), 720);
    const emptyState = inner.querySelector('.sekianafraz-search-empty-state');
    if (emptyState) requestAnimationFrame(() => emptyState.classList.add('is-visible'));
  }
  function bindRemoteSearch(p, input, chipsId, resultsId, onSelect) {
    let requestId = 0;
    let timer = null;
    let loadedItems = [];
    const loadPage = async (q, page, append, token) => {
      if (input.readOnly) return;
      let list = ensureSearchResults(input, resultsId);
      let done = () => {};
      if (!append) {
        list = showSearchLoader(input, resultsId);
      } else {
        if (list) list.setAttribute('aria-busy', 'true');
        const moreButton = list && list.querySelector('.sekianafraz-search-more');
        if (moreButton) {
          done = window.SEKIANAFRAZ_ADMIN_CORE.startButtonLoading(moreButton, 'بارگذاری');
        }
      }
      try {
        const exclude = (window.SEKIANAFRAZ_CURRENT_EDIT_ID || 0);
        const j = await api('search?placement=' + encodeURIComponent(p) + '&q=' + encodeURIComponent(q) + '&exclude_sensor_id=' + exclude + '&page=' + page);
        if (token !== requestId || input.value.trim() !== q) return;
        const items = Array.isArray(j.items) ? j.items : [];
        loadedItems = append ? loadedItems.concat(items) : items;
        input._sekianafrazLastItems = loadedItems;
        input._sekianafrazLastQuery = q;
        renderSearchItems(list, items, chipsId, onSelect, {
          append,
          hasMore: !!j.has_more,
          onMore: () => loadPage(q, page + 1, true, token)
        });
      } catch (e) {
        if (token !== requestId) return;
        if (input._sekianafrazLastQuery === q && Array.isArray(input._sekianafrazLastItems)) {
          renderSearchItems(list, input._sekianafrazLastItems, chipsId, onSelect, { append: false });
        } else closeSearchResults(resultsId);
      } finally { done(); }
    };
    input.addEventListener('input', () => {
      if (input.readOnly) {
        closeSearchResults(resultsId);
        return;
      }
      clearTimeout(timer);
      const q = input.value.trim();
      const token = ++requestId;
      if (!q) {
        loadedItems = [];
        input._sekianafrazLastItems = null;
        input._sekianafrazLastQuery = '';
        closeSearchResults(resultsId);
        return;
      }
      if (q.length < 3) {
        closeSearchResults(resultsId);
        return;
      }
      timer = setTimeout(() => loadPage(q, 1, false, token), 180);
    });
  }
  function loadCouponLimitFields(t) {
    const box = $('#sekianafraz-limit-dynamic');
    const place = (t === 'product') ? 'product_single' : 'product_cat';
    box.dataset.limitType = t;
    beginFormLayout(box);
    box.innerHTML = '<div class="sekianafraz-field"><label>' + (t === 'product' ? 'انتخاب محصولات' : 'انتخاب دسته‌بندی محصولات') + '</label><div class="sekianafraz-search-box"><div id="sekianafraz-limit-chips"></div><input type="text" id="sekianafraz-limit-search" placeholder="برای جستجو حداقل 3 کاراکتر بنویسید…"></div></div>';
    animateFormContent(box);
    bindSearchScoped(place, 'sekianafraz-limit-search', 'sekianafraz-limit-chips', 'sekianafraz-limit-results');
  }
  function bindSearchScoped(p, inputId, chipsId, resultsId) {
    const input = document.getElementById(inputId); if (!input) return;
    bindRemoteSearch(p, input, chipsId, resultsId, (id, label) => {
      addChipScoped(chipsId, p, id, label);
      input.focus();
    });
  }
  function addChipScoped(chipsId, p, id, label) {
    const chips = document.getElementById(chipsId); if (!chips) return;
    if (chips.querySelector('.sekianafraz-chip[data-id="' + id + '"]')) return;
    const chip = document.createElement('span'); chip.className = 'sekianafraz-chip'; chip.dataset.id = id; chip.innerHTML = '<span>' + escAttr(label) + '</span><button class="close"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff6b6b" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>';
    chip.querySelector('.close').addEventListener('click', () => { chip.remove(); });
    chips.appendChild(chip);
  }
  function field(label, type, id, val, placeholder = '') {
    const cleanLabel = String(label || '');
    const value = (val || '')
    const ph = (placeholder || '')
    return '<div class="sekianafraz-field"><label>' + cleanLabel + '</label><input required type="' + type + '" id="' + id + '" autocomplete="off"' + (id === 'sekianafraz-coupon-usage-limit' ? ' min="0" max="65535"' : '') + ' value="' + value + '" placeholder="' + ph + '"></div>';
  }
  function list(label, id, items) {
    const emptyState = id === 'sekianafraz-action' ? ' data-empty-default="1" data-placeholder="انتخاب نشده"' : '';
    return '<div class="sekianafraz-field"><label>' + label + '</label><select required id="' + id + '"' + emptyState + '>' + items.map(i => {
      const value = i[0];
      const text = i[1];
      return '<option value="' + value + '">' + text + '</option>';
    }).join('') + '</select></div>';
  }
function placementList() {
    const items = [
      ['product_single', 'صفحه تک محصول'],
      ['product_single_all', 'همه محصولات'],
      ['product_cat', 'دسته‌بندی محصول'],
      ['product_cat_all', 'همه دسته‌بندی‌های محصولات'],
      ['product_in_cat', 'همه محصولات یک دسته‌بندی خاص'],
      ['product_tag', 'برچسب‌های محصول'],
      ['product_tag_all', 'همه برچسب‌های محصولات'],
      ['product_in_tag', 'همه محصولات یک برچسب خاص'],
      ['post_single', 'صفحه تک مطلب'],
      ['post_single_all', 'همه مطالب'],
      ['post_cat', 'دسته‌بندی مطالب'],
      ['post_cat_all', 'همه دسته‌بندی‌های مطالب'],
      ['post_in_cat', 'همه مطالب یک دسته‌بندی خاص'],
      ['post_tag', 'برچسب مطالب'],
      ['post_tag_all', 'همه برچسب‌های مطالب'],
      ['post_in_tag', 'همه مطالب یک برچسب خاص'],
      ['page', 'برگه‌ها'],
      ['page_all', 'همه برگه‌ها']
    ];
    return '<div class="sekianafraz-field"><label>مکان سنسور</label><select required id="sekianafraz-placement">' +
      items.map(i => '<option value="' + i[0] + '">' + i[1] + '</option>').join('') +
      '</select></div>';
  }
  function basePlacementOf(placement) {
    return String(placement || '').replace(/_all$/, '');
  }
  function isAllPlacement(placement) {
    return /_all$/.test(String(placement || ''));
  }
  function isGroupedContentPlacement(placement) {
    return ['product_in_cat', 'product_in_tag', 'post_in_cat', 'post_in_tag'].includes(basePlacementOf(placement));
  }
  function uiPlacementOf(placement, items) {
    const base = basePlacementOf(placement || 'product_single');
    return Array.isArray(items) && items.indexOf('*') !== -1 ? base + '_all' : base;
  }
  function couponStrategyList() {
    const items = [
      ['individual', 'کوپن اختصاصی برای هر کاربر (کوپن عادی ووکامرس)'],
      ['virtual', 'کوپن‌ساز اختصاصی سنسور (بسیار بهینه‌تر)'],
      ['fixed', 'استفاده از یک کوپن ثابت برای همه کاربران']
    ];
    return '<div class="sekianafraz-field"><label>نوع کوپن</label><select required id="sekianafraz-coupon-strategy">' +
      items.map(i => '<option value="' + i[0] + '">' + i[1] + '</option>').join('') +
      '</select></div>';
  }
function conditionTitleOf(p) {
    p = basePlacementOf(p);
    const map = {
      product_single: 'محصولات شامل سنسور',
      product_cat: 'دسته‌بندی‌های محصول شامل سنسور',
      product_tag: 'برچسب‌های محصول شامل سنسور',
      product_in_cat: 'دسته‌بندی محصولات شامل سنسور',
      product_in_tag: 'برچسب محصولات شامل سنسور',
      post_single: 'مطالب شامل سنسور',
      post_cat: 'دسته‌بندی‌های مطلب شامل سنسور',
      post_tag: 'برچسب‌های مطلب شامل سنسور',
      post_in_cat: 'دسته‌بندی مطالب شامل سنسور',
      post_in_tag: 'برچسب مطالب شامل سنسور',
      page: 'برگه‌های شامل سنسور',
      custom_url: 'آدرس شامل سنسور',
      search_terms: 'عبارت‌های جستجو شامل سنسور'
    };
    return map[p] || 'آیتم‌های شامل سنسور';
  }
  function loadPlacementFields(p) {
    const d = $('#sekianafraz-dynamic');
    beginFormLayout(d);
    animateFormContent(d, true);
    const basePlacement = basePlacementOf(p);
    const title = conditionTitleOf(basePlacement);
    const calculation = $('#sekianafraz-visit-calculation');
    if (calculation) {
      const previousPlacement = calculation.dataset.sekianafrazScopePlacement || '';
      if (previousPlacement && previousPlacement !== String(p)) calculation.value = isGroupedContentPlacement(p) ? 'aggregate' : 'individual';
      if (!previousPlacement && isGroupedContentPlacement(p)) calculation.value = 'aggregate';
      calculation.dataset.sekianafrazScopePlacement = String(p);
    }
    if (!p || isAllPlacement(p)) d.innerHTML = '';
    else if (basePlacement === 'custom_url') d.innerHTML = field(title, 'text', 'sekianafraz-items', '', 'آدرس صفحه مورد نظر را وارد کنید…');
    else if (basePlacement === 'search_terms') d.innerHTML = field(title, 'text', 'sekianafraz-key', '', 'کلمه کلیدی خود را وارد کنید و اینتر بزنید…');
    else d.innerHTML = field(title, 'text', 'sekianafraz-search', '', 'نام ' + labelOf(basePlacement) + ' خود را وارد کنید…');
    if (p && !isAllPlacement(p) && basePlacement !== 'custom_url' && basePlacement !== 'search_terms') bindSearch(basePlacement);
    if (p && basePlacement === 'search_terms') bindKeywords();
    updateVisitCalculationVisibility();
    bindVisitMetric();
    const act = $('#sekianafraz-action');
    if (act?.dataset.emptyDefault === '1' && act.dataset.emptyDefaultApplied !== '1') {
      act.selectedIndex = -1;
      act.dataset.emptyDefaultApplied = '1';
      act._sekianafrazSelectSync?.();
    }
    const previewBtn = $('#sekianafraz-preview-sensor');
    const togglePreview = () => {
      window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW.refreshPreviewAvailability();
      if (previewBtn) {
        if (!previewBtn.onclick) previewBtn.onclick = previewSensor;
      }
    };
    if (act && !act.dataset.actionBound) {
      act.dataset.actionBound = '1';
      act.addEventListener('change', () => {
        renderActionFields(act.value);
        togglePreview();
        if (act.value === 'sms') {
          const m = $('#sekianafraz-sensor-modal');
          if (m && m.classList.contains('has-preview')) togglePreviewVisibility();
        }
      });
    }
    const actionWrap = $('#sekianafraz-action-fields');
    if (!actionWrap.dataset.action) renderActionFields(act ? act.value : '');
    else {
      window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.refreshActionVariableTables(actionWrap, basePlacement);
      window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.refreshBannerConditionalControls(actionWrap);
    }
    animateFormContent(d);
    togglePreview();
    mountCustomSelects($('#sekianafraz-sensor-modal'));
    applyNumberGuards();
    enhanceTooltips($('#sekianafraz-sensor-modal'));
    updateVarsTables(document.getElementById('sekianafraz-sensor-modal'));
  }
  function updateVisitCalculationVisibility() {
    const placementEl = $('#sekianafraz-placement');
    const wrap = $('#sekianafraz-visit-calculation-wrap');
    const select = $('#sekianafraz-visit-calculation');
    if (!placementEl || !wrap || !select) return;
    const chipCount = $all('#sekianafraz-chips [data-id]').length;
    const pendingTerms = basePlacementOf(placementEl.value) === 'search_terms' && $('#sekianafraz-key')
      ? $('#sekianafraz-key').value.split(',').map(value => value.trim()).filter(Boolean).length
      : 0;
    const groupedContent = isGroupedContentPlacement(placementEl.value);
    const shouldShow = groupedContent || isAllPlacement(placementEl.value) || Math.max(chipCount, pendingTerms) > 1;
    setFieldVisible(wrap, shouldShow);
    if (!shouldShow) select.value = 'individual';
    if (groupedContent && !select.dataset.sekianafrazUserChanged) select.value = 'aggregate';
    if (!select.dataset.sekianafrazVisitBound) {
      select.dataset.sekianafrazVisitBound = '1';
      select.addEventListener('change', () => {
        select.dataset.sekianafrazUserChanged = '1';
        updateVarsTables(document.getElementById('sekianafraz-sensor-modal'));
      });
    }
    updateVarsTables(document.getElementById('sekianafraz-sensor-modal'));
  }
  function refreshCouponStrategyRestriction() {
    const strategy = $('#sekianafraz-coupon-strategy');
    if (!strategy) return;
    const metric = $('#sekianafraz-visit-metric')?.value || 'views';
    const condition = $('#sekianafraz-visit-condition')?.value === 'and' ? 'and' : 'or';
    const read = (id, fallback) => {
      const value = normalizeDigits($('#' + id)?.value || '').trim();
      return value === '' ? fallback : parseInt(value, 10);
    };
    const views = read('sekianafraz-min', 3);
    const duration = read('sekianafraz-min-duration', 120);
    const shortVisit = Number.isFinite(duration) && duration < 10;
    const fixedOnly = metric === 'views' ? views === 1 :
      metric === 'duration' ? shortVisit : condition === 'or' ? views === 1 || shortVisit : views === 1 && shortVisit;
    Array.from(strategy.options).forEach(option => {
      option.disabled = fixedOnly && option.value !== 'fixed';
    });
    if (fixedOnly && strategy.value !== 'fixed') {
      strategy.value = 'fixed';
      strategy.dispatchEvent(new Event('change', { bubbles: true }));
    }
    strategy._sekianafrazSelectSync?.();
  }
  function bindCouponStrategyRestriction() {
    applyNumberGuards();
    ['sekianafraz-min', 'sekianafraz-min-duration', 'sekianafraz-visit-metric', 'sekianafraz-visit-condition', 'sekianafraz-coupon-strategy'].forEach(id => {
      const el = $('#' + id);
      if (!el || el.dataset.sekianafrazCouponRestrictionBound) return;
      el.dataset.sekianafrazCouponRestrictionBound = '1';
      el.addEventListener('change', refreshCouponStrategyRestriction);
      if (el.tagName === 'INPUT') el.addEventListener('input', refreshCouponStrategyRestriction);
    });
    refreshCouponStrategyRestriction();
  }
  function visitConditionLabel(value) {
    return value === 'and' ? 'برای تغییر منطق محاسباتی به «یا» کلیک کنید.' : 'برای تغییر منطق محاسباتی به «و» کلیک کنید.';
  }
  function animateVisitConditionText(button, text) {
    const target = button?.querySelector('.sekianafraz-visit-condition-text');
    if (!target) return;
    target._sekianafrazTextMotion?.cancel();
    target._sekianafrazTextMotion = null;
    target.textContent = text;
    if (!target.animate || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
    const motion = target.animate([
      { opacity: .2, transform: 'translateY(4px) scale(.78)', filter: 'blur(1.5px)' },
      { opacity: 1, transform: 'translateY(0) scale(1)', filter: 'blur(0)' }
    ], { duration: 220, easing: 'cubic-bezier(.16,1,.3,1)' });
    target._sekianafrazTextMotion = motion;
    motion.finished.then(() => {
      if (target._sekianafrazTextMotion === motion) target._sekianafrazTextMotion = null;
    }).catch(() => {});
  }
  function syncVisitConditionControl(animateText = false) {
    const row = $('#sekianafraz-visit-row');
    const control = $('#sekianafraz-visit-condition-control');
    const input = $('#sekianafraz-visit-condition');
    const button = $('#sekianafraz-visit-condition-toggle');
    const metric = $('#sekianafraz-visit-metric');
    if (!row || !control || !input || !button || !metric) return;
    const value = input.value === 'and' ? 'and' : 'or';
    const active = metric.value === 'both';
    const text = value === 'and' ? 'و' : 'یا';
    const label = visitConditionLabel(value);
    input.value = value;
    row.classList.toggle('has-visit-condition', active);
    control.inert = !active;
    control.setAttribute('aria-hidden', String(!active));
    button.tabIndex = active ? 0 : -1;
    button.setAttribute('aria-label', label);
    button.dataset.condition = value;
    if (animateText) animateVisitConditionText(button, text);
    else {
      const target = button.querySelector('.sekianafraz-visit-condition-text');
      if (target) {
        target._sekianafrazTextMotion?.cancel();
        target._sekianafrazTextMotion = null;
        target.textContent = text;
      }
    }
  }
  function ensureVisitConditionControl(row) {
    if (!row) return null;
    let control = $('#sekianafraz-visit-condition-control');
    if (!control) {
      control = document.createElement('div');
      control.id = 'sekianafraz-visit-condition-control';
      control.className = 'sekianafraz-visit-condition-control';
      control.dataset.formOverlay = '1';
      control.innerHTML = '<input type="hidden" id="sekianafraz-visit-condition" value="or"><button type="button" id="sekianafraz-visit-condition-toggle" class="sekianafraz-visit-condition-toggle"><span class="sekianafraz-visit-condition-text">یا</span></button>';
      row.appendChild(control);
    } else if (control.parentElement !== row) {
      row.appendChild(control);
    }
    const input = $('#sekianafraz-visit-condition');
    const button = $('#sekianafraz-visit-condition-toggle');
    if (input && !input.dataset.sekianafrazConditionBound) {
      input.dataset.sekianafrazConditionBound = '1';
      input.addEventListener('change', () => {
        const animateText = input.dataset.sekianafrazAnimate === '1';
        delete input.dataset.sekianafrazAnimate;
        syncVisitConditionControl(animateText);
      });
    }
    if (button && !button.dataset.sekianafrazConditionBound) {
      button.dataset.sekianafrazConditionBound = '1';
      button.addEventListener('click', () => {
        if (!input || $('#sekianafraz-visit-metric')?.value !== 'both') return;
        input.value = input.value === 'and' ? 'or' : 'and';
        input.dataset.sekianafrazAnimate = '1';
        input.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }
    syncVisitConditionControl(false);
    return control;
  }
  function bindVisitMetric() {
    const metric = $('#sekianafraz-visit-metric');
    const viewsWrap = $('#sekianafraz-min-views-wrap');
    const durationWrap = $('#sekianafraz-min-duration-wrap');
    if (!metric || !viewsWrap || !durationWrap) return;
    const refresh = () => {
      const value = metric.value || 'views';
      setFieldVisible(viewsWrap, value !== 'duration');
      setFieldVisible(durationWrap, value !== 'views');
      syncVisitConditionControl(false);
    };
    if (!metric.dataset.sekianafrazMetricBound) {
      metric.dataset.sekianafrazMetricBound = '1';
      metric.addEventListener('change', refresh);
    }
    refresh();
  }
  function refreshCouponAmountUnit() {
    const cmodeEl = document.getElementById('sekianafraz-cmode');
    const unitEl = document.getElementById('sekianafraz-coupon-amount-unit');
    const amountEl = document.getElementById('sekianafraz-coupon-amount');
    if (!unitEl || !amountEl) return;
    const isPercent = !!(cmodeEl && cmodeEl.value === 'percent');
    unitEl.textContent = '(' + (isPercent ? 'درصد' : currencyLabel) + ')';
    amountEl.placeholder = isPercent ? 'مثلاً: 15 درصد' : 'مثلاً: 200,000 ' + currencyLabel;
    const raw = normalizeDigits(amountEl.value || '').replace(/[,٬،\s]/g, '').replace(/[^0-9.]/g, '');
    amountEl.value = isPercent ? raw : raw.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  function bindCouponAmountUnit() {
    const cmodeEl = document.getElementById('sekianafraz-cmode');
    if (!cmodeEl) return;
    refreshCouponAmountUnit();
    if (!cmodeEl.dataset.sekianafrazUnitBound) {
      cmodeEl.dataset.sekianafrazUnitBound = '1';
      cmodeEl.addEventListener('change', refreshCouponAmountUnit);
    }
    const amountEl = document.getElementById('sekianafraz-coupon-amount');
    if (amountEl && !amountEl.dataset.sekianafrazGroupingBound) {
      amountEl.dataset.sekianafrazGroupingBound = '1';
      amountEl.addEventListener('input', refreshCouponAmountUnit);
    }
  }
  function labelOf(p) {
    p = basePlacementOf(p);
    const map = {
      product_single: 'تک محصول', product_cat: 'دسته', product_tag: 'برچسب محصول',
      product_in_cat: 'دسته‌بندی محصول', product_in_tag: 'برچسب محصول',
      post_single: 'مطلب', post_cat: 'دسته مطلب', post_tag: 'برچسب مطلب',
      post_in_cat: 'دسته‌بندی مطلب', post_in_tag: 'برچسب مطلب', page: 'برگه'
    }; return map[p] || ''
  }
  function bindSearch(p) {
    const input = $('#sekianafraz-search'); if (!input) return;
    const fieldWrap = input.closest('.sekianafraz-field'); if (!fieldWrap) return;
    const sb = document.createElement('div'); sb.className = 'sekianafraz-search-box'; sb.id = 'sekianafraz-search-box';
    const chips = document.createElement('div'); chips.id = 'sekianafraz-chips';
    fieldWrap.insertBefore(sb, input); sb.appendChild(chips); sb.appendChild(input);
    input.placeholder = 'نام ' + labelOf(p) + ' خود را وارد کنید…';
    bindRemoteSearch(p, input, 'sekianafraz-chips', 'sekianafraz-results', (id, label) => {
      addChip(p, id, label);
      if (!isGroupedContentPlacement(p)) input.focus();
    });
  }
  function setGroupedSearchLocked(p, locked) {
    if (!isGroupedContentPlacement(p)) return;
    const input = $('#sekianafraz-search');
    const box = $('#sekianafraz-search-box');
    if (!input) return;
    input.readOnly = !!locked;
    input.setAttribute('aria-disabled', locked ? 'true' : 'false');
    input.tabIndex = locked ? -1 : 0;
    if (box) box.classList.toggle('is-selection-locked', !!locked);
    if (locked) {
      input.value = '';
      input.blur();
      closeSearchResults('sekianafraz-results');
    }
  }
  function addChip(p, id, label) {
    const chips = $('#sekianafraz-chips');
    if (!chips) return;
    if (isGroupedContentPlacement(p) && chips.querySelector('.sekianafraz-chip[data-id]')) return;
    if (chips.querySelector('.sekianafraz-chip[data-id="' + id + '"]')) return;
    const chip = document.createElement('span'); chip.className = 'sekianafraz-chip'; chip.dataset.id = id; chip.innerHTML = '<span>' + escAttr(label) + '</span><button class="close"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#ff6b6b" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>';
    chip.querySelector('.close').addEventListener('click', () => {
      chip.remove();
      setGroupedSearchLocked(p, false);
      updateVisitCalculationVisibility();
      const input = $('#sekianafraz-search');
      if (input && isGroupedContentPlacement(p)) requestAnimationFrame(() => input.focus());
    });
    chips.appendChild(chip);
    setGroupedSearchLocked(p, true);
    updateVisitCalculationVisibility();
  }
  function renderExclusions(data, sensorId) {
    const wrap = $('#sekianafraz-exclusions-wrap');
    if (!wrap) return;
    const state = data && typeof data === 'object' ? data : {};
    const items = Array.isArray(state.items) ? state.items : [];
    const total = Math.max(0, parseInt(state.total || '0', 10) || 0);
    if (!total) {
      setFieldVisible(wrap, false);
      wrap.innerHTML = '';
      return;
    }
    const rowHtml = (item) => {
      const owner = item.owner_sensor_name || ('سنسور #' + String(item.owner_sensor_id || ''));
      return '<li class="sekianafraz-exclusion-item" data-object-id="' + escAttr(item.id || '') + '">' +
        '<span class="sekianafraz-exclusion-item__name">' + escAttr(item.label || '') + '</span>' +
        '<span class="sekianafraz-exclusion-item__owner">در اختیار «' + escAttr(owner) + '»</span>' +
        '</li>';
    };
    setFieldVisible(wrap, true);
    wrap.innerHTML = '<div class="sekianafraz-exclusions-box">' +
      '<div class="sekianafraz-exclusions-box__head"><strong>' + escAttr(state.title || 'مکان‌های استثناشده') + '</strong><span>' + total + ' مورد</span></div>' +
      '<ul class="sekianafraz-exclusions-list">' + items.map(rowHtml).join('') + '</ul>' +
      (state.has_more ? '<button type="button" class="sekianafraz-exclusions-more">مشاهده همه</button>' : '') +
      '</div>';
    const more = wrap.querySelector('.sekianafraz-exclusions-more');
    if (!more || !sensorId) return;
    let page = 0;
    more.addEventListener('click', async () => {
      if (more.dataset.loading === '1') return;
      const done = window.SEKIANAFRAZ_ADMIN_CORE.startButtonLoading(more, 'بارگذاری');
      try {
        const result = await api('sensors/exclusions?id=' + encodeURIComponent(sensorId) + '&page=' + (page + 1) + '&per_page=20');
        const listEl = wrap.querySelector('.sekianafraz-exclusions-list');
        if (listEl) {
          if (page === 0) listEl.innerHTML = '';
          listEl.insertAdjacentHTML('beforeend', (result.items || []).map(rowHtml).join(''));
        }
        page = parseInt(result.page || String(page + 1), 10) || (page + 1);
        if (!result.has_more) more.remove();
      } catch (e) {
        toast((e && e.message) || 'خطا در بارگذاری مکان‌های استثناشده');
      } finally { done(); }
    });
  }
  function bindKeywords() {
    const input = $('#sekianafraz-key'); if (!input) return;
    const fieldWrap = input.closest('.sekianafraz-field'); if (!fieldWrap) return;
    const sb = document.createElement('div'); sb.className = 'sekianafraz-search-box'; sb.id = 'sekianafraz-key-box';
    const chips = document.createElement('div'); chips.id = 'sekianafraz-chips';
    fieldWrap.insertBefore(sb, input); sb.appendChild(chips); sb.appendChild(input);
    input.addEventListener('input', updateVisitCalculationVisibility);
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        const values = input.value.split(',').map(value => value.trim()).filter(Boolean);
        if (!values.length) return;
        values.forEach(value => addChip('search_terms', value, value));
        input.value = '';
        updateVisitCalculationVisibility();
      }
    });
  }
  function getSensorData(options = {}) {
    const preview = options.preview === true;
    const placement = $('#sekianafraz-placement')?.value || (preview ? 'product_single' : '');
    if (!placement) return null;
    const basePlacement = basePlacementOf(placement);
    let items = [];
    if (isAllPlacement(placement)) {
      items = ['*'];
    }
    else if (basePlacement === 'custom_url') {
      const v = ($('#sekianafraz-items') && $('#sekianafraz-items').value || '').trim();
      if (!v && !preview) return null;
      if (!v) items = [];
      else try { const u = new URL(v, location.origin); let path = u.pathname + u.search; const base = (window.SEKIANAFRAZ_ADMIN && SEKIANAFRAZ_ADMIN.base_path) || '/'; if (base !== '/' && path.indexOf(base) === 0) { path = path.slice(base.length - 1); if (path === '') path = '/'; } items = [path]; }
      catch (e) { let path = v; const base = (window.SEKIANAFRAZ_ADMIN && SEKIANAFRAZ_ADMIN.base_path) || '/'; if (base !== '/' && path.indexOf(base) === 0) { path = path.slice(base.length - 1); } items = [path]; }
    }
    else if (basePlacement === 'search_terms') {
      const chipVals = $all('#sekianafraz-chips [data-id]').map(el => el.dataset.id).filter(Boolean);
      if (chipVals.length) { items = chipVals; }
      else {
        const v = ($('#sekianafraz-key') && $('#sekianafraz-key').value || '').trim();
        if (v) items = v.split(',').map(s => s.trim()).filter(Boolean);
      }
    }
    else {
      items = $all('#sekianafraz-chips [data-id]').map(el => el.dataset.id);
    }
    const data = {
      name: ($('#sekianafraz-name') && $('#sekianafraz-name').value || '').trim(),
      placement: basePlacement, items,
      visit_metric: ($('#sekianafraz-visit-metric') && $('#sekianafraz-visit-metric').value) || 'views',
      visit_calculation: ($('#sekianafraz-visit-calculation') && $('#sekianafraz-visit-calculation').value) || 'individual',
      visit_condition: ($('#sekianafraz-visit-condition') && $('#sekianafraz-visit-condition').value) === 'and' ? 'and' : 'or',
      min_views: parseInt((($('#sekianafraz-min') && $('#sekianafraz-min').value) || '3'), 10),
      min_duration: parseInt((($('#sekianafraz-min-duration') && $('#sekianafraz-min-duration').value) || '120'), 10),
      window: ($('#sekianafraz-window') && $('#sekianafraz-window').value) || '',
      coupon_type: ($('#sekianafraz-ctype') && $('#sekianafraz-ctype').value) || '',
      coupon_custom_prefix: ($('#sekianafraz-coupon-prefix') && $('#sekianafraz-coupon-prefix').value || '').trim(),
      coupon_custom_suffix: ($('#sekianafraz-coupon-suffix') && $('#sekianafraz-coupon-suffix').value || '').trim(),
      coupon_custom_length: parseInt(normalizeDigits((($('#sekianafraz-coupon-length') && $('#sekianafraz-coupon-length').value) || '4')), 10) || 4,
      coupon_custom_mid_pattern: ($('#sekianafraz-coupon-mid-pattern') && $('#sekianafraz-coupon-mid-pattern').value) || 'mixed',
      coupon_amount: parseFloat(normalizeDigits((($('#sekianafraz-coupon-amount') && $('#sekianafraz-coupon-amount').value) || '1')).replace(/[,٬،\s]/g, '')) || 1,
      coupon_mode: ($('#sekianafraz-cmode') && $('#sekianafraz-cmode').value) || '',
      coupon_valid_hours: parseInt(($('#sekianafraz-coupon-valid-hours') && $('#sekianafraz-coupon-valid-hours').value) || '0', 10),
      coupon_usage_limit: Math.max(0, parseInt(normalizeDigits($('#sekianafraz-coupon-usage-limit')?.value || '3'), 10) || 0),
      coupon_free_shipping: !['fixed', 'none'].includes($('#sekianafraz-coupon-strategy')?.value) && !!($('#sekianafraz-coupon-free-shipping') && $('#sekianafraz-coupon-free-shipping').checked),
      banner_target_url: ($('#sekianafraz-banner-target-url')?.value || '').trim(),
      banner_button_closes: !!$('#sekianafraz-banner-button-closes')?.checked,
      sms_target_url: ($('#sekianafraz-sms-target-url')?.value || '').trim(),
      coupon_strategy: ($('#sekianafraz-coupon-strategy') && $('#sekianafraz-coupon-strategy').value) || 'individual',
      fixed_code: ($('#sekianafraz-fixed-code') && $('#sekianafraz-fixed-code').value || '').trim(),
      action: ($('#sekianafraz-action') && $('#sekianafraz-action').value) || '',
      hide_banner_for_logged_in: !!($('#sekianafraz-hide-banner-logged-in') && $('#sekianafraz-hide-banner-logged-in').checked),
    };
    const act = data.action;
    const isMulti = (act === 'banner' || act === 'both') && $('#sekianafraz-banner-type')?.value === 'multi';
    if (act === 'sms' || act === 'both' || isMulti) {
      data.sms_mode = ($('#sekianafraz-sms-mode') && $('#sekianafraz-sms-mode').value) || '';
      data.sms_delay_type = isMulti ? 'immediate' : ($('#sekianafraz-sms-delay-type')?.value || 'immediate');
      data.sms_delay_minutes = data.sms_delay_type === 'delayed' ? (parseInt($('#sekianafraz-sms-delay-minutes')?.value || '60', 10) || 60) : 0;
      if (data.sms_mode === 'promo') data.sms_text = $('#sekianafraz-sms-text') ? $('#sekianafraz-sms-text').value.trim() : '';
      if (data.sms_mode === 'pattern') data.sms_pattern = $('#sekianafraz-sms-pattern') ? $('#sekianafraz-sms-pattern').value.trim() : '';
    }
    if (act === 'banner' || act === 'both') {
      data.banner_type = isMulti ? 'multi' : 'single';
      data.logged_behavior = isMulti ? ($('#sekianafraz-logged-behavior')?.value || 'single_sms') : 'none';
      data.banner_title = ($('#sekianafraz-banner-title') && $('#sekianafraz-banner-title').value || '').trim();
      data.banner_button_text = ($('#sekianafraz-banner-button-text') && $('#sekianafraz-banner-button-text').value || '').trim();
      data.banner_text = ($('#sekianafraz-banner-text') && $('#sekianafraz-banner-text').value || '').trim();
      data.banner_button_color = ($('#sekianafraz-button-color') && $('#sekianafraz-button-color').value || '').trim();
      data.banner_image = ($('#sekianafraz-banner-image') && $('#sekianafraz-banner-image').value || '').trim();
      data.banner_hide_image = window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.getBannerImageMode($('#sekianafraz-action-fields')) === 'none';
      data.banner_svg_color = ($('#sekianafraz-banner-svg-color') && $('#sekianafraz-banner-svg-color').value || '#000000');
      const radiusState = collectBannerRadiusState();
      data.banner_border_radius = radiusState.simple;
      data.banner_radius_mode = radiusState.mode;
      data.banner_border_radii = radiusState.values;
      data.banner_paddings = collectBannerPaddingState();
      data.banner_margins = window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.collectBannerMarginState();
      data.display_name_fallback = (((($('#sekianafraz-display-name-fallback') && $('#sekianafraz-display-name-fallback').value) || 'کاربر').trim()) || 'کاربر');
      data.banner_bg_color = ($('#sekianafraz-banner-bg-color') && $('#sekianafraz-banner-bg-color').value) || '#ffffff';
      data.banner_title_color = ($('#sekianafraz-banner-title-color') && $('#sekianafraz-banner-title-color').value) || '#0d0d0d';
      data.banner_text_color = ($('#sekianafraz-banner-text-color') && $('#sekianafraz-banner-text-color').value) || '#4b5563';
      data.banner_coupon_color = ($('#sekianafraz-banner-coupon-color') && $('#sekianafraz-banner-coupon-color').value) || '#5c5c5c';
      data.banner_font_type = ($('#sekianafraz-banner-font-type') && $('#sekianafraz-banner-font-type').value) || 'arad';
      const variants = window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.collectBannerVariants();
      Object.assign(data, variants.guest);
      data.logged_banner = variants.logged;
      const actions = window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS;
      Object.keys(actions.multiFields).forEach((key) => {
        data[key] = ($('#' + actions.multiFields[key])?.value || '').trim();
      });
      data.multi_colors = {};
      actions.multiColors.forEach((key) => {
        data.multi_colors['multi_' + key.replace(/-/g, '_') + '_color'] = $('#sekianafraz-' + key + '-color')?.value || '';
      });
      if (isMulti && (data.logged_behavior === 'sms' || data.logged_behavior === 'single_sms')) {
        data.logged_sms_mode = $('#sekianafraz-logged-sms-mode')?.value || 'promo';
        data.logged_sms_target_url = ($('#sekianafraz-logged-sms-target-url')?.value || '').trim();
        data.logged_sms_text = $('#sekianafraz-logged-sms-text')?.value.trim() || '';
        data.logged_sms_pattern = $('#sekianafraz-logged-sms-pattern')?.value.trim() || '';
        data.logged_sms_delay_type = $('#sekianafraz-logged-sms-delay-type')?.value || 'immediate';
        data.logged_sms_delay_minutes = data.logged_sms_delay_type === 'delayed' ? (parseInt($('#sekianafraz-logged-sms-delay-minutes')?.value || '60', 10) || 60) : 0;
      }
    }
    const couponLimitAvailable = !['fixed', 'none'].includes(data.coupon_strategy);
    const couponLimitEnabled = couponLimitAvailable && !!$('#sekianafraz-coupon-limit-enabled')?.checked;
    data.coupon_limit_enabled = couponLimitEnabled;
    data.coupon_limit_type = couponLimitEnabled
      ? ((document.querySelector('input[name="sekianafraz-limit-type"]:checked') || {}).value || 'product')
      : '';
    data.coupon_limit_ids = couponLimitEnabled
      ? $all('#sekianafraz-limit-chips [data-id]').map(el => el.dataset.id)
      : [];
    data.reminder_enabled = (!isMulti || ['single', 'single_sms'].includes(data.logged_behavior)) && (act === 'banner' || act === 'both') && !['fixed', 'none'].includes(data.coupon_strategy) && !!$('#sekianafraz-reminder-enabled')?.checked;
    data.reminder_message_template = ($('#sekianafraz-reminder-message') && $('#sekianafraz-reminder-message').value || '').trim() || 'فقط {Timer} ساعت برای استفاده از کد تخفیف {coupon_code} باقی مونده!';
    data.reminder_show_timer_panel = $('#sekianafraz-reminder-timer-panel') && $('#sekianafraz-reminder-timer-panel').checked;
    data.reminder_styles = window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.collectReminderStyles();
    data.reminder_colors = {
      bg: ($('#sekianafraz-reminder-color-bg') && $('#sekianafraz-reminder-color-bg').value) || '#ffffff',
      text: ($('#sekianafraz-reminder-color-text') && $('#sekianafraz-reminder-color-text').value) || '#4b5563',
      timer_value: ($('#sekianafraz-reminder-color-timer-value') && $('#sekianafraz-reminder-color-timer-value').value) || '#5F0027',
      timer_bg: ($('#sekianafraz-reminder-color-timer-bg') && $('#sekianafraz-reminder-color-timer-bg').value) || '#000000',
      timer_text: ($('#sekianafraz-reminder-color-timer-text') && $('#sekianafraz-reminder-color-timer-text').value) || '#ffffff',
      close_btn: ($('#sekianafraz-reminder-color-close-btn') && $('#sekianafraz-reminder-color-close-btn').value) || '#4b5563',
      coupon_highlight: ($('#sekianafraz-reminder-color-coupon-highlight') && $('#sekianafraz-reminder-color-coupon-highlight').value) || '#5F0027',
    };
    data.coupon_restrict_user = !!$('#sekianafraz-coupon-restrict-user')?.checked;
    data.coupon_restrict_guest = !!$('#sekianafraz-coupon-restrict-guest')?.checked;
    return data;
  }
  function normalizeTargetUrl(u) {
    if (!u) return '';
    const url = String(u).trim();
    if (/^([a-z][a-z0-9+.-]*:)?\/\//i.test(url)) return url;
    if (url[0] === '/') return url;
    return 'https://' + url;
  }
  window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS = {
    mountModalRows, layoutReminder, renderSensorHeaderWordmark, renderModal, renderDeviceToggle,
    refreshCouponOwnership,
    renderCouponLimitSection, renderReminderSection, mountCouponLimit,
    mountCustomCouponTemplate, mountReminder, loadCouponLimitFields,
    bindSearchScoped, addChipScoped, field, list, placementList,
    couponStrategyList, conditionTitleOf, loadPlacementFields,
    refreshCouponAmountUnit, bindCouponAmountUnit, labelOf, bindSearch,
    addChip, bindKeywords, getSensorData, normalizeTargetUrl,
    basePlacementOf, isAllPlacement, isGroupedContentPlacement, uiPlacementOf,
    updateVisitCalculationVisibility, bindVisitMetric, syncVisitConditionControl, renderExclusions,
    refreshCouponStrategyRestriction, bindCouponStrategyRestriction
  };
})();
