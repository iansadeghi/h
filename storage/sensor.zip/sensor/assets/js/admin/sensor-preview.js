(function () {
  const {
    $, $all, api, toast, resolveFrontendFont
  } = window.SEKIANAFRAZ_ADMIN_CORE;
  const getSensorData = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS.getSensorData(...args);
  const renderActionFields = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.renderActionFields(...args);
  const markModalDirty = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_LIFECYCLE.markModalDirty(...args);
  const showConflictConfirm = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_LIFECYCLE.showConflictConfirm(...args);
  function hexToRgba(hex, alpha) {
    const number = parseInt(String(hex).replace('#', ''), 16);
    return `rgba(${(number >> 16) & 255},${(number >> 8) & 255},${number & 255},${alpha})`;
  }
  function getBannerHTML(data) {
    return window.SEKIANAFRAZ_BANNER_VIEW.render(data, { inheritedFont: window.SEKIANAFRAZ_FRONTEND_FONT });
  }
  function mountPreviewArea() {
  }
  function enterPreviewFrame(area, frame, frames) {
    const animation = window.SEKIANAFRAZ_ADMIN_CONTROLS.playMotion(frame, frames, { duration: 200 });
    area._audienceEnter = animation;
    animation?.finished.then(() => {
      if (area._audienceEnter !== animation) return;
      area._audienceEnter = null;
      if (area._previewRefreshPending) {
        area._previewRefreshPending = false;
        updatePreview();
      }
    }).catch(() => {});
  }
  function syncPhonePreview(oldPhone, freshPhone) {
    const oldInput = oldPhone.querySelector('input');
    const freshInput = freshPhone.querySelector('input');
    if (oldInput && freshInput) {
      oldInput.style.cssText = freshInput.style.cssText;
      oldInput.placeholder = freshInput.placeholder;
    }
    const prompt = oldPhone.querySelector('.sekianafraz-modal__prompt');
    const freshPrompt = freshPhone.querySelector('.sekianafraz-modal__prompt');
    if (prompt && freshPrompt) {
      prompt.style.cssText = freshPrompt.style.cssText;
      prompt.textContent = freshPrompt.textContent;
    }
    const oldSend = oldPhone.querySelector('.sekianafraz-modal__send');
    const freshSend = freshPhone.querySelector('.sekianafraz-modal__send');
    if (oldSend && freshSend) {
      oldSend.style.cssText = freshSend.style.cssText;
      const normal = oldSend.querySelector('.sekianafraz-modal__send-normal');
      const freshNormal = freshSend.querySelector('.sekianafraz-modal__send-normal');
      if (normal && freshNormal) normal.textContent = freshNormal.textContent;
      const loading = oldSend.querySelector('.sekianafraz-modal__send-loading');
      const freshLoading = freshSend.querySelector('.sekianafraz-modal__send-loading');
      if (loading && freshLoading) {
        loading.style.cssText = freshLoading.style.cssText;
        loading.lastChild.textContent = freshLoading.lastChild?.textContent || '';
        const spinner = loading.querySelector('.sekianafraz-modal__spinner');
        if (spinner) spinner.style.cssText = freshLoading.querySelector('.sekianafraz-modal__spinner')?.style.cssText || '';
      }
    }
    ['.sekianafraz-modal__success', '.sekianafraz-modal__correction'].forEach((selector) => {
      const old = oldPhone.querySelector(selector);
      const fresh = freshPhone.querySelector(selector);
      if (!old || !fresh) return;
      old.style.cssText = fresh.style.cssText;
      old.textContent = fresh.textContent;
    });
  }
  async function sendPreviewPhone(area) {
    const phone = area.querySelector('.sekianafraz-modal__stage-phone');
    const input = phone?.querySelector('input');
    if (!input || area._sekianafrazPreviewBusy) return;
    const sendButton = phone.querySelector('.sekianafraz-modal__send');
    if (!input.value.trim()) {
      window.SEKIANAFRAZ_BANNER_VIEW.showSendError(sendButton, 'شماره تلفن معتبر نیست.'); return;
    }
    const draft = getSensorData();
    if (!draft) { window.SEKIANAFRAZ_BANNER_VIEW.showSendError(sendButton, 'ارسال انجام نشد. دوباره تلاش کنید.'); return; }
    if (draft.coupon_strategy === 'individual' && !$('#sekianafraz-coupon-amount')?.value.trim()) {
      window.SEKIANAFRAZ_BANNER_VIEW.showSendError(sendButton, 'ارسال انجام نشد. دوباره تلاش کنید.');
      return;
    }
    if (window.SEKIANAFRAZ_CURRENT_EDIT_ID) draft.id = window.SEKIANAFRAZ_CURRENT_EDIT_ID;
    draft.preview_vars = area._sekianafrazPreviewVars || {};
    area._sekianafrazPreviewBusy = true;
    sendButton.disabled = true;
    window.SEKIANAFRAZ_BANNER_VIEW.setSendButtonState(sendButton, 'loading');
    try {
      const result = await api('banner/preview-send', { method: 'POST', data: {
        draft, phone: input.value.trim(), preview_token: area._sekianafrazPreviewCorrection ? area._sekianafrazPreviewToken || '' : ''
      } });
      if (!result.success) throw result;
      area._sekianafrazPreviewToken = result.preview_token || '';
      const current = area.querySelector('.sekianafraz-modal__stage-phone');
      if (!current) return;
      current.querySelector('.sekianafraz-modal__success').hidden = false;
      current.querySelector('.sekianafraz-modal__correction').hidden = !!area._sekianafrazPreviewCorrection;
      window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS.setStage(3);
      await window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(area.querySelector('[data-sekianafraz-banner]'), 3, 'forward');
    } catch (failure) {
      const current = area.querySelector('.sekianafraz-modal__stage-phone');
      if (!current) return;
      window.SEKIANAFRAZ_BANNER_VIEW.showSendError(current.querySelector('.sekianafraz-modal__send'),
        failure?.message || 'ارسال انجام نشد. دوباره تلاش کنید.');
    } finally {
      area._sekianafrazPreviewBusy = false;
      const currentButton = area.querySelector('.sekianafraz-modal__send');
      if (currentButton && currentButton.dataset.state !== 'error') {
        window.SEKIANAFRAZ_BANNER_VIEW.setSendButtonState(currentButton, 'normal');
        currentButton.disabled = false;
      }
    }
  }
  function bindPreviewCard(frame, area) {
    if (frame._sekianafrazPreviewBound) return;
    frame._sekianafrazPreviewBound = true;
    const card = frame.querySelector('.sekianafraz-modal__card');
    card.querySelector('.sekianafraz-modal__stage-phone')?.addEventListener('submit', event => {
      event.preventDefault(); sendPreviewPhone(area);
    });
    frame.addEventListener('click', event => {
      if (event.target.closest('.sekianafraz-modal__close')) {
        togglePreviewVisibility();
        return;
      }
      const copy = event.target.closest('.sekianafraz-modal__copy');
      if (copy) {
        const value = card.querySelector('.sekianafraz-modal__coupon-code').textContent.replace(/\s/g, '');
        const data = frame._sekianafrazBannerData;
        window.SEKIANAFRAZ_ADMIN_CONTROLS.copyText(value).then(() => {
          copy.textContent = 'کپی شد!';
          copy.style.backgroundColor = hexToRgba(data.button_color || '#000000', .25);
          setTimeout(() => { copy.textContent = 'کپی'; copy.style.backgroundColor = data.copy_bg_color || hexToRgba(data.button_color || '#000000', .15); }, 2000);
        }).catch(() => {});
        return;
      }
      const introButton = event.target.closest('.sekianafraz-modal__primary');
      const phone = card.querySelector('.sekianafraz-modal__stage-phone');
      if (!phone) return;
      if (introButton) {
        area._sekianafrazPreviewCorrection = false;
        area._sekianafrazPreviewToken = '';
        window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS.setStage(2);
        window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(frame, 2, 'forward').then(() => phone.querySelector('input')?.focus());
      } else if (event.target.closest('.sekianafraz-modal__back-icon')) {
        window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS.setStage(1);
        window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(frame, 1, 'back');
      } else if (event.target.closest('.sekianafraz-modal__correction')) {
        area._sekianafrazPreviewCorrection = true;
        const send = phone.querySelector('.sekianafraz-modal__send');
        window.SEKIANAFRAZ_BANNER_VIEW.setSendButtonState(send, 'normal');
        send.disabled = false;
        const input = phone.querySelector('input');
        input.value = '';
        window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS.setStage(2);
        window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(frame, 2, 'back').then(() => {
          phone.querySelector('.sekianafraz-modal__success').hidden = true;
          phone.querySelector('.sekianafraz-modal__correction').hidden = true;
          input.focus();
        });
      }
    });
  }
  function updatePreview() {
    const modal = $('#sekianafraz-sensor-modal');
    if (!modal || modal._previewUpdateQueued || $('#sekianafraz-action-fields')?.dataset.suspendPreview === '1') return;
    modal._previewUpdateQueued = true;
    requestAnimationFrame(() => {
      modal._previewUpdateQueued = false;
      if (modal.isConnected && modal.classList.contains('has-preview')) renderPreview();
    });
  }
  function syncPreviewStage(frame) {
    if (!frame || !frame.hasAttribute('data-multi-stage')) return;
    const stage = Number($('#sekianafraz-action-fields')?.dataset.bannerStage || 1);
    if (stage === 3) {
      const success = frame.querySelector('.sekianafraz-modal__success');
      const correction = frame.querySelector('.sekianafraz-modal__correction');
      if (success) success.hidden = false;
      if (correction) correction.hidden = !!$('#sekianafraz-preview-column')?._sekianafrazPreviewCorrection;
    }
    const current = Number(frame.dataset.multiStage || 1);
    window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(frame, stage, stage < current ? 'back' : 'forward');
  }
  function renderPreview() {
    const modal = $('#sekianafraz-sensor-modal');
    if (!modal) return;
    const data = getSensorData({ preview: true });
    if (!data) return;
    const modalEl = document.getElementById('sekianafraz-sensor-modal');
    const couponDisabled = !!(modalEl && modalEl.dataset && modalEl.dataset.acCouponDisabled === '1');
    const hasCoupon = !couponDisabled && data.coupon_strategy !== 'none';
    const act = data.action;
    if (act !== 'banner' && act !== 'both') return;
    const fontType = $('#sekianafraz-banner-font-type');
    if (fontType && fontType.value === 'inherit' && !window.SEKIANAFRAZ_FRONTEND_FONT) {
      resolveFrontendFont().then(() => updatePreview());
      return;
    }
    const placement = data.placement;
    const firstItemLabel = $all('#sekianafraz-chips [data-id] span')[0]?.textContent || '';
    const sampleLocationNames = {
      product_single: 'محصول نمونه', product_cat: 'دسته‌بندی نمونه', product_tag: 'برچسب نمونه',
      product_in_cat: 'محصول نمونه', product_in_tag: 'محصول نمونه',
      post_single: 'مطلب نمونه', post_cat: 'دسته‌بندی مطلب نمونه', post_tag: 'برچسب مطلب نمونه',
      post_in_cat: 'مطلب نمونه', post_in_tag: 'مطلب نمونه',
      page: 'برگه نمونه', search_terms: 'عبارت نمونه'
    };
    let locationName = firstItemLabel || sampleLocationNames[placement] || '';
    if (placement === 'custom_url') locationName = '';
    if (data.visit_calculation === 'aggregate') locationName = '';
    const loggedAudience = $('#sekianafraz-action-fields')?.dataset.previewAudience === 'logged' &&
      ['single', 'single_sms'].includes(data.logged_behavior);
    const visibleCoupon = hasCoupon && (data.banner_type !== 'multi' || loggedAudience);
    const rawCouponAmount = String($('#sekianafraz-coupon-amount')?.value || '').trim();
    const rawCouponValidHours = String($('#sekianafraz-coupon-valid-hours')?.value || '').trim();
    const mockVars = {
      'display_name': 'مدیر سیستم',
      'coupon_code': visibleCoupon ? 'Sensor Coupon' : '{{coupon_code}}',
      'coupon_expiry_time': visibleCoupon ? '۱۴۰۲/۱۰/۳۰' : '{{coupon_expiry_time}}',
      'coupon_value': hasCoupon && rawCouponAmount ? data.coupon_amount : '{{coupon_value}}',
      'coupon_valid_hours': hasCoupon && rawCouponValidHours ? data.coupon_valid_hours : '{{coupon_valid_hours}}',
      'product_name': locationName,
      'category_name': locationName,
      'product_tag_name': locationName,
      'post_name': locationName,
      'post_category_name': locationName,
      'post_tag_name': locationName,
      'page_name': locationName,
      'search_term': locationName
    };
    const appearance = loggedAudience ? data.logged_banner : data;
    let html = appearance.banner_text || '';
    Object.keys(mockVars).forEach(k => { html = html.replace(new RegExp('{{' + k + '}}', 'g'), mockVars[k]); });
    const bannerData = {
      ...data,
      ...(data.multi_colors || {}),
      ...(loggedAudience ? appearance : {}),
      banner_type: loggedAudience ? 'single' : data.banner_type,
      html: html,
      title: appearance.banner_title || 'تبریک میگم!',
      coupon_code: visibleCoupon ? ((data.coupon_strategy === 'fixed' && data.fixed_code) ? data.fixed_code : 'Sensor Coupon') : '',
      button_color: appearance.banner_button_color || '#000000',
      banner_button_text: appearance.banner_button_text || (loggedAudience || data.banner_type !== 'multi' ? 'بزن بریم!' : 'دریافت تخفیف'),
      target_url: data.banner_type === 'multi' && !loggedAudience ? '' : (appearance.banner_button_closes ? '' : appearance.banner_target_url || ''),
      banner_button_closes: data.banner_type === 'multi' && !loggedAudience ? true : appearance.banner_button_closes,
    };
    const area = document.getElementById('sekianafraz-preview-column');
    if (area) {
      const nextAudience = loggedAudience ? 'logged' : 'guest';
      const oldFrame = area.querySelector('[data-sekianafraz-banner]');
      if (area._audienceExit) {
        if (area._sekianafrazPreviewAudience !== nextAudience) return;
        const clipping = getComputedStyle(oldFrame).clipPath;
        const transform = getComputedStyle(oldFrame).transform;
        area._audienceExit.cancel(); area._audienceExit = null;
        oldFrame.inert = false;
        area._previewRefreshPending = true;
        enterPreviewFrame(area, oldFrame, [
          { clipPath: clipping, transform }, { clipPath: 'inset(0 0 0 0)', transform: 'translateY(0)' }
        ]);
        return;
      }
      if (area._audienceEnter && area._sekianafrazPreviewAudience === nextAudience && !area._audienceReplacing) {
        area._previewRefreshPending = true;
        return;
      }
      if (oldFrame && area._sekianafrazPreviewAudience !== nextAudience && !area._audienceReplacing && modal.dataset.formReady === '1') {
        const css = getComputedStyle(oldFrame);
        const start = { clipPath: css.clipPath === 'none' ? 'inset(0 0 0 0)' : css.clipPath, transform: css.transform };
        area._audienceEnter?.cancel();
        area._audienceEnter = null;
        const exit = window.SEKIANAFRAZ_ADMIN_CONTROLS.playMotion(oldFrame, [
          start, { clipPath: 'inset(0 0 100% 0)', transform: 'translateY(-8px)' }
        ], { duration: 160, fill: 'both' });
        if (exit) {
          oldFrame.inert = true;
          area._audienceExit = exit;
          exit.finished.then(() => {
            if (area._audienceExit !== exit || !area.isConnected) return;
            area._audienceExit = null;
            area._audienceReplacing = true;
            renderPreview();
            exit.cancel();
          }).catch(() => {});
          return;
        }
      }
      area._sekianafrazPreviewVars = Object.fromEntries(Object.entries(mockVars).filter(([key]) =>
        ['product_name', 'category_name', 'product_tag_name', 'post_name',
          'post_category_name', 'post_tag_name', 'page_name', 'search_term'].includes(key)));
      const currentCard = area.querySelector('.sekianafraz-modal__card');
      const freshWrap = document.createElement('div');
      freshWrap.innerHTML = getBannerHTML(bannerData);
      const freshFrame = freshWrap.firstElementChild;
      const freshCard = freshFrame.querySelector('.sekianafraz-modal__card');
      let card;
      if (currentCard && currentCard._sekianafrazPreviewType === 'multi' && bannerData.banner_type === 'multi') {
        currentCard.parentElement._multiTransition?.cancel();
        currentCard.parentElement.style.cssText = freshFrame.style.cssText;
        const oldIntro = currentCard.querySelector('.sekianafraz-modal__stage-intro');
        const nextIntro = freshCard.querySelector('.sekianafraz-modal__stage-intro');
        nextIntro.hidden = !!oldIntro?.hidden;
        oldIntro.replaceWith(nextIntro);
        const stage = parseInt(currentCard.parentElement.dataset.multiStage || '1', 10) || 1;
        const oldHeader = currentCard.querySelector('.sekianafraz-modal__header');
        const nextHeader = freshCard.querySelector('.sekianafraz-modal__header');
        if (oldHeader && nextHeader) oldHeader.replaceWith(nextHeader);
        window.SEKIANAFRAZ_BANNER_VIEW.setMultiHeaderStage(currentCard.parentElement, stage);
        syncPhonePreview(currentCard.querySelector('.sekianafraz-modal__stage-phone'),
          freshCard.querySelector('.sekianafraz-modal__stage-phone'));
        card = currentCard;
      } else {
        area.replaceChildren(freshFrame);
        card = freshCard;
        area._sekianafrazPreviewToken = '';
        area._sekianafrazPreviewCorrection = false;
      }
      card._sekianafrazPreviewType = bannerData.banner_type;
      card.parentElement._sekianafrazBannerData = bannerData;
      bindPreviewCard(card.parentElement, area);
      syncPreviewStage(card.parentElement);
      if (area._audienceReplacing) {
        area._audienceReplacing = false;
        card.parentElement.inert = false;
        enterPreviewFrame(area, card.parentElement, [
          { clipPath: 'inset(0 0 100% 0)', transform: 'translateY(8px)' },
          { clipPath: 'inset(0 0 0 0)', transform: 'translateY(0)' }
        ]);
      }
      area._sekianafrazPreviewAudience = nextAudience;
      const reminderPreviewWrap = $('#sekianafraz-reminder-preview-wrap');
      const lockedRemPreview = false;
      const remEnabled = data.reminder_enabled && visibleCoupon;
      if (lockedRemPreview) {
        if (reminderPreviewWrap) reminderPreviewWrap.style.display = 'none';
      } else if (remEnabled && reminderPreviewWrap) {
        reminderPreviewWrap.style.display = 'block';
        const remMsg = data.reminder_message_template || 'فقط {Timer} ساعت برای استفاده از کد تخفیف {coupon_code} باقی مونده!';
        const showTimer = data.reminder_show_timer_panel;
        const colors = data.reminder_colors;
        let remHtml = `<div style="background:${colors.bg};color:${colors.text};padding:12px 20px;display:flex;align-items:center;justify-content:space-between;flex-direction:row;font-family:Arad,sans-serif;direction:rtl;position:relative;overflow:hidden;width:100%;box-sizing:border-box">`;
        const textWidth = showTimer ? '70%' : '100%';
        const textAlign = showTimer ? 'right' : 'center';
        const highlightColor = colors.coupon_highlight || '#5F0027';
        const couponTag = `<strong class="sekianafraz-preview-coupon sekianafraz-reminder-coupon" data-code="Sensor Coupon" style="padding:2px 6px; margin:0 2px; cursor:pointer; background:${hexToRgba(highlightColor, 0.3)}; color:${highlightColor}; border-radius:4px; transition: all 0.2s">Sensor Coupon</strong>`;
        const timerSpan = `<span style="color:${colors.timer_value};font-weight:bold;margin:0 2px">00:59:59</span>`;
        remHtml += `<div class="sekianafraz-reminder-content" style="width:${textWidth};font-size:14px;line-height:1.9;text-align:${textAlign};box-sizing:border-box">${remMsg.replace('{coupon_code}', couponTag).replace('{Timer}', timerSpan)}</div>`;
        if (showTimer) {
          remHtml += `<div class="sekianafraz-reminder-timer-panel" style="display:flex;gap:4px;width:30%;height:32px;direction:ltr;justify-content:flex-start;align-items:center;box-sizing:border-box;margin-right:15px">
          ${['00', '59', '59'].map(v => `<div class="sekianafraz-timer-unit" style="background:${colors.timer_bg};color:${colors.timer_text};width:28px;height:28px;display:flex;align-items:center;justify-content:center;border-radius:4px;font-size:12px;font-weight:bold">${v}</div>`).join('<span style="color:' + colors.text + ';font-weight:bold;align-self:center">:</span>')}
        </div>`;
        }
        remHtml += `<div style="position:absolute;top:3px;left:3px;cursor:pointer;color:${colors.close_btn}"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></div>`;
        remHtml += `</div>`;
        reminderPreviewWrap.innerHTML = remHtml;
        window.SEKIANAFRAZ_APPLY_REMINDER_STYLES(reminderPreviewWrap.firstElementChild, data.reminder_styles);
      } else if (reminderPreviewWrap) {
        reminderPreviewWrap.style.display = 'none';
      }
    }
  }
  function morphPreviewButton(btn, nextText) {
    if (!btn) return;
    let label = btn.querySelector('.sekianafraz-preview-label-incoming') || btn.querySelector('.sekianafraz-preview-label');
    if (!label) return;
    clearTimeout(btn._sekianafrazMorphEndTimer);
    btn.querySelectorAll('.sekianafraz-preview-label').forEach((item) => {
      if (item !== label) item.remove();
    });
    label.classList.remove('sekianafraz-preview-label-incoming', 'sekianafraz-preview-label-outgoing');
    btn.classList.remove('is-morphing', 'is-expanding', 'is-collapsing');
    btn.style.removeProperty('--sekianafraz-preview-label-shift');
    if (label.textContent === nextText) {
      btn.style.width = '';
      return;
    }
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      label.textContent = nextText;
      btn.classList.remove('is-morphing');
      btn.style.width = '';
      return;
    }
    const currentWidth = btn.getBoundingClientRect().width;
    const currentLabelWidth = label.getBoundingClientRect().width;
    const clone = btn.cloneNode(true);
    const cloneLabel = clone.querySelector('.sekianafraz-preview-label');
    clone.removeAttribute('id');
    clone.classList.remove('is-morphing', 'is-expanding', 'is-collapsing');
    clone.style.cssText = 'position:fixed;visibility:hidden;pointer-events:none;display:inline-flex;width:max-content;transition:none;';
    if (cloneLabel) cloneLabel.textContent = nextText;
    btn.parentNode.appendChild(clone);
    const targetWidth = clone.getBoundingClientRect().width;
    const targetLabelWidth = cloneLabel ? cloneLabel.getBoundingClientRect().width : currentLabelWidth;
    clone.remove();
    btn.style.width = currentWidth + 'px';
    btn.getBoundingClientRect();
    const incomingLabel = label.cloneNode(true);
    incomingLabel.textContent = nextText;
    label.classList.add('sekianafraz-preview-label-outgoing');
    incomingLabel.classList.add('sekianafraz-preview-label-incoming');
    btn.appendChild(incomingLabel);
    btn.style.setProperty('--sekianafraz-preview-label-shift', ((currentLabelWidth + targetLabelWidth) / 2 + 6) + 'px');
    btn.classList.add(targetWidth > currentWidth ? 'is-expanding' : 'is-collapsing');
    btn.getBoundingClientRect();
    btn.classList.add('is-morphing');
    requestAnimationFrame(() => {
      btn.style.width = targetWidth + 'px';
    });
    btn._sekianafrazMorphEndTimer = setTimeout(() => {
      label.remove();
      incomingLabel.classList.remove('sekianafraz-preview-label-incoming');
      btn.classList.remove('is-morphing', 'is-expanding', 'is-collapsing');
      btn.style.removeProperty('--sekianafraz-preview-label-shift');
      btn.style.width = '';
    }, 460);
  }
  function hasBannerPreview() {
    const action = $('#sekianafraz-action')?.value;
    const wrap = $('#sekianafraz-action-fields');
    return ['banner', 'both'].includes(action) && !($('#sekianafraz-banner-type')?.value === 'multi' &&
      wrap?.dataset.previewAudience === 'logged' && $('#sekianafraz-logged-behavior')?.value === 'sms');
  }
  function refreshPreviewAvailability() {
    const modal = $('#sekianafraz-sensor-modal');
    if (!modal) return;
    const available = hasBannerPreview();
    if (!available && modal.classList.contains('has-preview')) {
      modal._restorePreview = true;
      togglePreviewVisibility(true);
    } else if (available && modal._restorePreview && !modal.classList.contains('has-preview')) {
      modal._restorePreview = false;
      togglePreviewVisibility(true);
    }
    const button = $('#sekianafraz-preview-sensor');
    window.SEKIANAFRAZ_ADMIN_CONTROLS.setHeaderControlVisible(button, available);
    const deviceToggle = $('#sekianafraz-device-toggle');
    window.SEKIANAFRAZ_ADMIN_CONTROLS.setHeaderControlVisible(deviceToggle, available && modal.classList.contains('has-preview'), 'grid');
  }
  function togglePreviewVisibility(automatic = false) {
    const modal = document.getElementById('sekianafraz-sensor-modal');
    if (!modal) return;
    if (automatic !== true) modal._restorePreview = false;
    const isVisible = !modal.classList.contains('has-preview');
    if (isVisible && !hasBannerPreview()) return;
    if (isVisible) {
      if (typeof window.SEKIANAFRAZ_ADMIN_FUNCS.setDevice === 'function') {
        window.SEKIANAFRAZ_ADMIN_FUNCS.setDevice(1);
      } else {
        modal.setAttribute('data-device', '1');
      }
      updatePreview();
    }
    modal.classList.toggle('has-preview', isVisible);
    const btn = document.getElementById('sekianafraz-preview-sensor');
    if (btn) {
      morphPreviewButton(btn, isVisible ? 'پنهان کردن پیش‌نمایش' : 'پیش‌نمایش بنر');
    }
    const appearance = document.getElementById('sekianafraz-action-fields');
    if (appearance) window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.refreshBannerConditionalControls(appearance);
    const deviceToggle = document.getElementById('sekianafraz-device-toggle');
    if (deviceToggle) {
      window.SEKIANAFRAZ_ADMIN_CONTROLS.setHeaderControlVisible(deviceToggle, isVisible, 'grid');
    }
  }
  function bindLiveEvents(modal) {
    if (modal._liveEventsBound) return;
    modal._liveEventsBound = true;
    const settingsChanged = event => {
      if (modal._validationAttempted) validateRequiredFields(false);
      if (!event.target.closest('#sekianafraz-preview-column') &&
          $('#sekianafraz-action-fields')?.dataset.suspendPreview !== '1') updatePreview();
    };
    modal.addEventListener('input', settingsChanged);
    modal.addEventListener('change', settingsChanged);
    modal.addEventListener('click', event => {
      if (modal._validationAttempted && !event.target.closest('#sekianafraz-preview-column')) queueMicrotask(() => validateRequiredFields(false));
    });
    modal.addEventListener('input', (e) => {
      if (e && e.target && e.target.closest && e.target.closest('#sekianafraz-sensor-modal') &&
          !e.target.closest('#sekianafraz-preview-column')) {
        if (e.target.matches && e.target.matches('input, textarea, select')) {
          markModalDirty(modal);
        }
      }
    });
    modal.addEventListener('change', (e) => {
      if (e && e.target && e.target.closest && e.target.closest('#sekianafraz-sensor-modal') &&
          !e.target.closest('#sekianafraz-preview-column')) {
        if (e.target.matches && e.target.matches('input, textarea, select')) {
          markModalDirty(modal);
        }
      }
    });
  }
  function previewSensor() {
    togglePreviewVisibility();
  }
  function fillSensorDefaults() {
    const defaults = {
      'sekianafraz-min':'3', 'sekianafraz-min-duration':'120', 'sekianafraz-coupon-valid-hours':'72',
      'sekianafraz-coupon-usage-limit':'3', 'sekianafraz-coupon-length':'4',
      'sekianafraz-display-name-fallback':'کاربر',
      'sekianafraz-reminder-message':'فقط {Timer} ساعت برای استفاده از کد تخفیف {coupon_code} باقی مونده!',
      'sekianafraz-multi-prompt':'شماره تلفنتو وارد کن تا کد رو برات پیامک کنیم',
      'sekianafraz-multi-phone-placeholder':'شماره تلفن', 'sekianafraz-multi-submit-text':'ارسال کد تخفیف',
      'sekianafraz-multi-sending-text':'درحال ارسال', 'sekianafraz-multi-success-text':'کد تخفیف رو برات پیامک کردیم!',
      'sekianafraz-multi-correction-text':'شمارتو اشتباه وارد کردی؟'
    };
    Object.entries(defaults).forEach(([id,value]) => { const el = $('#' + id); if (el && !el.value.trim()) {el.value = value; el._sekianafrazSelectSync?.();} });
    const wrap = $('#sekianafraz-action-fields');
    const button = $('#sekianafraz-banner-button-text');
    const multi = $('#sekianafraz-banner-type')?.value === 'multi';
    if (button && !button.value.trim()) button.value = multi && wrap?.dataset.previewAudience !== 'logged' ? 'دریافت تخفیف' : 'بزن بریم!';
    if (multi && wrap) {
      const variants = window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.collectBannerVariants();
      if (!variants.guest.banner_button_text?.trim()) variants.guest.banner_button_text = 'دریافت تخفیف';
      if (!variants.logged.banner_button_text?.trim()) variants.logged.banner_button_text = 'بزن بریم!';
      wrap._guestAppearance = variants.guest; wrap._loggedAppearance = variants.logged; wrap._loggedEdited = true;
    }
    window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS.refreshCouponStrategyRestriction();
    updatePreview();
  }
  function validateRequiredFields(report = false) {
    const modal = $('#sekianafraz-sensor-modal');
    if (!modal) return false;
    const errors = [];
    const value = id => String($('#' + id)?.value || '').trim();
    const require = (id, valid, audience) => { if (!valid) errors.push({id,audience}); };
    const multi = value('sekianafraz-banner-type') === 'multi';
    const action = value('sekianafraz-action'), strategy = value('sekianafraz-coupon-strategy');
    const variants = window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.collectBannerVariants();
    require('sekianafraz-name', !!value('sekianafraz-name'));
    require('sekianafraz-action', !!action);
    const placement = value('sekianafraz-placement');
    require('sekianafraz-placement', !!placement);
    const data = placement ? getSensorData() : null;
    if (placement) require(placement === 'custom_url' ? 'sekianafraz-items' : placement === 'search_terms' ? 'sekianafraz-key' : 'sekianafraz-search', !!data?.items?.length);
    const metric = value('sekianafraz-visit-metric');
    if (metric !== 'duration') require('sekianafraz-min', Number(value('sekianafraz-min')) > 0);
    if (metric !== 'views') require('sekianafraz-min-duration', Number(value('sekianafraz-min-duration')) > 0);
    if (strategy === 'fixed') require('sekianafraz-fixed-code', !!value('sekianafraz-fixed-code'));
    if (!['fixed','none'].includes(strategy)) {
      require('sekianafraz-coupon-amount', Number(value('sekianafraz-coupon-amount').replace(/[,٬،\s]/g, '')) > 0);
      if (value('sekianafraz-ctype') === 'custom') require('sekianafraz-coupon-length', Number(value('sekianafraz-coupon-length')) >= 3);
      if ($('#sekianafraz-coupon-limit-enabled')?.checked) require('sekianafraz-limit-search', !!modal.querySelector('#sekianafraz-limit-chips [data-id]'));
    }
    if (['banner','both'].includes(action)) {
      require('sekianafraz-banner-text', !!variants.guest.banner_text?.trim(), 'guest');
      if (!multi && !variants.guest.banner_button_closes) require('sekianafraz-banner-target-url', !!variants.guest.banner_target_url?.trim(), 'guest');
      if (multi && ['single','single_sms'].includes(value('sekianafraz-logged-behavior')) && !variants.logged.banner_button_closes) require('sekianafraz-banner-target-url', !!variants.logged.banner_target_url?.trim(), 'logged');
      if (multi && ['single','single_sms'].includes(value('sekianafraz-logged-behavior'))) require('sekianafraz-banner-text', !!variants.logged.banner_text?.trim(), 'logged');
    }
    if (['sms','both'].includes(action) || multi) {
      const mode = value('sekianafraz-sms-mode'); require(mode === 'pattern' ? 'sekianafraz-sms-pattern' : 'sekianafraz-sms-text', !!value(mode === 'pattern' ? 'sekianafraz-sms-pattern' : 'sekianafraz-sms-text'), multi ? 'guest' : undefined);
      if (data?.visit_calculation === 'aggregate' && value(mode === 'pattern' ? 'sekianafraz-sms-pattern' : 'sekianafraz-sms-text').includes('{{target_url}}')) require('sekianafraz-sms-target-url', !!value('sekianafraz-sms-target-url'), multi ? 'guest' : undefined);
    }
    if (multi && ['sms','single_sms'].includes(value('sekianafraz-logged-behavior'))) {
      const mode = value('sekianafraz-logged-sms-mode'); require(mode === 'pattern' ? 'sekianafraz-logged-sms-pattern' : 'sekianafraz-logged-sms-text', !!value(mode === 'pattern' ? 'sekianafraz-logged-sms-pattern' : 'sekianafraz-logged-sms-text'), 'logged');
      if (data?.visit_calculation === 'aggregate' && value(mode === 'pattern' ? 'sekianafraz-logged-sms-pattern' : 'sekianafraz-logged-sms-text').includes('{{target_url}}')) require('sekianafraz-logged-sms-target-url', !!value('sekianafraz-logged-sms-target-url'), 'logged');
    }
    if (report && errors[0]?.audience && $('#sekianafraz-action-fields')?.dataset.previewAudience !== errors[0].audience) {
      $('#sekianafraz-audience-toggle [data-audience="' + errors[0].audience + '"]')?.click();
    }
    modal.querySelectorAll('.sekianafraz-field.is-invalid').forEach(field => field.classList.remove('is-invalid'));
    modal.querySelectorAll('[aria-invalid="true"]').forEach(el => el.removeAttribute('aria-invalid'));
    const audience = $('#sekianafraz-action-fields')?.dataset.previewAudience || 'guest';
    errors.forEach(error => {
      if (error.audience && error.audience !== audience) return;
      const el = $('#' + error.id), field = el?.closest('.sekianafraz-field');
      if (!el || !field) return;
      el.setAttribute('aria-invalid','true');
      if (el.tagName === 'SELECT') el.nextElementSibling?.querySelector('.rcs-current')?.setAttribute('aria-invalid','true');
      field.classList.add('is-invalid');
    });
    if (report && errors.length) {
      toast('همه فیلدهای مورد نیاز را پر کنید.');
      window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS.revealField($('#' + errors[0].id));
      requestAnimationFrame(() => {
        const first = modal.querySelector('.sekianafraz-field.is-invalid');
        first?.scrollIntoView({behavior:window.matchMedia?.('(prefers-reduced-motion:reduce)').matches ? 'auto' : 'smooth',block:'center'});
        first?.querySelector('input,textarea,select')?.focus({preventScroll:true});
      });
    }
    return !errors.length;
  }
  async function saveSensor() {
    const modal = $('#sekianafraz-sensor-modal'); modal._validationAttempted = true;
    fillSensorDefaults();
    if (!validateRequiredFields(true)) return;
    const data = getSensorData();
    if (!data) { toast('همه فیلدها را به درستی وارد کنید.'); return; }
    const act = data.action;
    const metric = data.visit_metric || 'views';
    const minViewsOk = metric === 'duration' || (parseInt($('#sekianafraz-min')?.value || '0', 10) > 0);
    const minDurationOk = metric === 'views' || (parseInt($('#sekianafraz-min-duration')?.value || '0', 10) > 0);
    const basicOk = !!(data.name && data.placement && data.items.length && minViewsOk && minDurationOk && data.window && data.action);
    if (!basicOk) { toast('همه فیلدها را به درستی وارد کنید.'); return; }
    if (act === 'sms' || act === 'both' || data.banner_type === 'multi') {
      if (!data.sms_mode) { toast('همه فیلدها را به درستی وارد کنید.'); return; }
      if ((data.sms_mode === 'promo' && !data.sms_text) || (data.sms_mode === 'pattern' && !data.sms_pattern)) {
        toast('همه فیلدها را به درستی وارد کنید.'); return;
      }
    }
    if ((act === 'banner' || act === 'both') && !data.banner_text) { toast('همه فیلدها را به درستی وارد کنید.'); return; }
    if (data.banner_type === 'multi' && /\{\{(?:coupon_code|coupon_expiry_time)\}\}/.test(data.banner_text)) {
      toast('کد و زمان انقضای کوپن پیش از ثبت شماره ساخته نمی‌شود؛ این متغیرها را از متن بنر مهمان حذف کنید.'); return;
    }
    if (data.banner_type === 'multi' && data.coupon_strategy === 'none') {
      toast('بنر چندمرحله‌ای باید کد تخفیف داشته باشد.'); return;
    }
    if (data.banner_type === 'multi' && (data.sms_mode === 'promo'
      ? !String(data.sms_text || '').includes('{{coupon_code}}')
      : !/(?:^|\n)\s*\{\{coupon_code\}\}\s*(?=$|\n)/.test(String(data.sms_pattern || '')))) {
      toast('متغیر {{coupon_code}} را در متن یا متغیرهای پترن پیامک بنر چندمرحله‌ای قرار دهید.'); return;
    }
    if (data.banner_type === 'multi' && ['single', 'single_sms'].includes(data.logged_behavior) && !data.logged_banner?.banner_text) {
      toast('متن بنر کاربران وارد شده را وارد کنید.'); return;
    }
    if (data.banner_type === 'multi' && ['sms', 'single_sms'].includes(data.logged_behavior) &&
        (!data.logged_sms_mode || (data.logged_sms_mode === 'promo' ? !data.logged_sms_text : !data.logged_sms_pattern))) {
      toast('پیامک مجزای کاربران وارد شده را تنظیم کنید.'); return;
    }
    if (data.visit_calculation === 'aggregate') {
      const locationVars = {
        product_single: 'product_name', product_cat: 'category_name', product_tag: 'product_tag_name',
        product_in_cat: 'product_name', product_in_tag: 'product_name',
        post_single: 'post_name', post_cat: 'post_category_name', post_tag: 'post_tag_name',
        post_in_cat: 'post_name', post_in_tag: 'post_name',
        page: 'page_name', search_terms: 'search_term'
      };
      const locationVar = locationVars[data.placement] || '';
      const token = locationVar ? '{{' + locationVar + '}}' : '';
      const actionTexts = [data.banner_text || '', data.logged_banner?.banner_text || '', data.sms_text || '', data.sms_pattern || '', data.logged_sms_text || '', data.logged_sms_pattern || ''];
      if (token && actionTexts.some(text => String(text).indexOf(token) !== -1)) {
        toast('متغیر مکان در حالت محاسبه تجمیعی قابل استفاده نیست؛ آن را از متن بنر یا پیامک حذف کنید.');
        return;
      }
    }
    if (data.coupon_type === 'custom') {
      if (!data.coupon_custom_length || data.coupon_custom_length < 3) { toast('طول رشته‌کارکتر میانی نباید کمتر از 3 باشد.'); return; }
      const re = /^[A-Za-z0-9_]*$/;
      if (!re.test(data.coupon_custom_prefix || '') || !re.test(data.coupon_custom_suffix || '')) {
        toast('پیشوند/پسوند فقط می‌تواند شامل حروف و اعداد انگلیسی و _ باشد.');
        return;
      }
    }
    if (window.SEKIANAFRAZ_CURRENT_EDIT_ID) { data.id = window.SEKIANAFRAZ_CURRENT_EDIT_ID; }
    const submit = async (resolution) => {
      const payload = { ...data };
      if (resolution) payload.conflict_resolution = resolution;
      await api('sensors/save', { method: 'POST', data: payload });
      location.reload();
    };
    try {
      await submit('');
    } catch (err) {
      if (err && err.code === 'PLACEMENT_CONFLICT') {
        showConflictConfirm(err, (resolution) => submit(resolution));
        return;
      }
      if (err?.code === 'VALIDATION' && err.field) {
        const ids = {fixed_code:'sekianafraz-fixed-code', coupon_amount:'sekianafraz-coupon-amount', name:'sekianafraz-name', banner_text:'sekianafraz-banner-text'};
        const el = $('#' + (ids[err.field] || 'sekianafraz-' + err.field.replace(/_/g,'-')));
        const field = el?.closest('.sekianafraz-field'); field?.classList.add('is-invalid'); el?.setAttribute('aria-invalid','true');
        field?.scrollIntoView({behavior:'smooth',block:'center'});
      }
      toast(err.message || (err?.code === 'VALIDATION' ? 'همه فیلدهای مورد نیاز را پر کنید.' : 'خطا در ذخیره سنسور'));
      console.error(err);
    }
  }
  window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW = {
    refreshPreviewAvailability,
    hexToRgba, getBannerHTML, mountPreviewArea,
    updatePreview, morphPreviewButton, togglePreviewVisibility,
    fillSensorDefaults, validateRequiredFields, bindLiveEvents, previewSensor, saveSensor
  };
})();
