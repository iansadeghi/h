(function () {
  const {
    $, $all, api, toast, withBtnLoader, updateVarsTables, escAttr
  } = window.SEKIANAFRAZ_ADMIN_CORE;
  const {
    mountCustomSelects, applyNumberGuards, applyModalCheckboxSkin, mountColorFields, setFieldVisible, finishFormInitialization
  } = window.SEKIANAFRAZ_ADMIN_CONTROLS;
  const fields = () => window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS;
  const preview = () => window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW;
  const renderModal = (...args) => fields().renderModal(...args);
  const loadPlacementFields = (...args) => fields().loadPlacementFields(...args);
  const mountCustomCouponTemplate = (...args) => fields().mountCustomCouponTemplate(...args);
  const mountCouponLimit = (...args) => fields().mountCouponLimit(...args);
  const mountReminder = (...args) => fields().mountReminder(...args);
  const bindCouponAmountUnit = (...args) => fields().bindCouponAmountUnit(...args);
  const loadCouponLimitFields = (...args) => fields().loadCouponLimitFields(...args);
  const addChip = (...args) => fields().addChip(...args);
  const addChipScoped = (...args) => fields().addChipScoped(...args);
  const mountPreviewArea = (...args) => preview().mountPreviewArea(...args);
  const bindLiveEvents = (...args) => preview().bindLiveEvents(...args);
  const saveSensor = (...args) => preview().saveSensor(...args);
  const renderActionFields = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.renderActionFields(...args);
  const applyBannerRadiusState = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.applyBannerRadiusState(...args);
  const applyBannerPaddingState = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.applyBannerPaddingState(...args);
  function suppressModalBrowserSuggestions(modal) {
    if (!modal || !modal.querySelectorAll) return;
    const harden = (root) => {
      const fields = [];
      if (root.matches && root.matches('input, textarea')) fields.push(root);
      if (root.querySelectorAll) fields.push(...root.querySelectorAll('input, textarea'));
      fields.forEach((el) => {
        el.setAttribute('autocomplete', 'off');
        el.setAttribute('data-form-type', 'other');
        el.setAttribute('data-lpignore', 'true');
        el.setAttribute('data-1p-ignore', 'true');
        el.setAttribute('data-bwignore', 'true');
        el.setAttribute('data-protonpass-ignore', 'true');
      });
      const forms = [];
      if (root.matches && root.matches('form')) forms.push(root);
      if (root.querySelectorAll) forms.push(...root.querySelectorAll('form'));
      forms.forEach((form) => form.setAttribute('autocomplete', 'off'));
    };
    harden(modal);
    if (modal._sekianafrazAutocompleteObserver) return;
    modal._sekianafrazAutocompleteObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        mutation.addedNodes.forEach((node) => {
          if (node && node.nodeType === 1) harden(node);
        });
      });
    });
    modal._sekianafrazAutocompleteObserver.observe(modal, { childList: true, subtree: true });
  }
  function mountCouponStrategy() {
    fields().mountModalRows();
    const strategy = $('#sekianafraz-coupon-strategy');
    if (!strategy) return;
    const toggle = () => {
      const fixed = strategy.value === 'fixed';
      const enabled = strategy.value !== 'none';
      const fixedWrap = $('#sekianafraz-fixed-code-wrap');
      const individual = $('#sekianafraz-individual-wrap');
      const expiry = $('#sekianafraz-expiry-wrap');
      setFieldVisible(fixedWrap, fixed);
      setFieldVisible(individual, enabled && !fixed);
      setFieldVisible(expiry, enabled && !fixed);
      ['sekianafraz-cmode', 'sekianafraz-coupon-amount'].forEach(id => {
        const field = $('#' + id)?.closest('.sekianafraz-field');
        setFieldVisible(field, enabled && !fixed);
      });
      setFieldVisible($('#sekianafraz-custom-coupon-template-wrap'), enabled && !fixed && $('#sekianafraz-ctype')?.value === 'custom', 'grid');
      const shipping = $('#sekianafraz-coupon-free-shipping-option');
      setFieldVisible(shipping, enabled && !fixed);
      fields().refreshCouponOwnership();
      updateVarsTables();
    };
    strategy.addEventListener('change', toggle);
    fields().bindCouponStrategyRestriction();
    toggle();
  }
  function ensureModalLoader(modal) {
    if (!modal.querySelector(':scope > .sekianafraz-modal-loading-overlay')) {
      const overlay = document.createElement('div'); overlay.className = 'sekianafraz-modal-loading-overlay';
      overlay.innerHTML = '<button type="button" class="sekianafraz-modal-loading-close" aria-label="بستن">\n<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>\n</button><div class="sekianafraz-modal-loader" role="status" aria-live="polite" aria-label="درحال بارگذاری"><span class="sekianafraz-loader" aria-hidden="true"></span><span class="sekianafraz-modal-loader-label">درحال بارگذاری...</span></div>';
      overlay.querySelector('.sekianafraz-modal-loading-close').addEventListener('click', () => closeSensorModal(modal));
      modal.append(overlay);
    }
  }
  function openModal() {
    const modal = $('#sekianafraz-sensor-modal'); if (!modal) return;
    modal._preparedAdd = false;
    modal._restorePreview = false;
    modal._closeRevision = (modal._closeRevision || 0) + 1;
    modal.classList.remove('closing', 'is-prewarming');
    modal.classList.add('is-edit-loading');
    window.SEKIANAFRAZ_ADMIN_CONTROLS.disposeModalControls(modal);
    modal.innerHTML = '<div class="sekianafraz-modal-edit-shell"><div class="content"></div></div>';
    modal.classList.add('is-form-preparing');
    modal.dataset.formReady = '0';
    ensureModalLoader(modal);
    modal.hidden = false;
    modal.dataset.dirty = ''; modal.dataset.baseline = ''; modal.dataset.lockDirty = '1';
    modal._validationAttempted = false; modal._loadRevision = (modal._loadRevision || 0) + 1;
    document.body.classList.add('sekianafraz-sensor-modal-open');
    document.body.style.overflow = 'hidden';
    bindModalClose(modal);
  }
  function closeSensorModal(modal) {
    if (!modal || modal.hidden) return;
    modal._loadRevision = (modal._loadRevision || 0) + 1;
    const closeRevision = modal._closeRevision = (modal._closeRevision || 0) + 1;
    modal.classList.add('closing');
    let finished = false;
    const onEnd = event => {
      if (event && event.target !== modal) return;
      if (finished || closeRevision !== modal._closeRevision) { modal.removeEventListener('animationend', onEnd); return; }
      finished = true;
      modal.hidden = true;
      modal.classList.remove('closing', 'is-edit-loading', 'is-form-preparing');
      modal.classList.remove('has-preview');
      document.body.classList.remove('sekianafraz-sensor-modal-open');
      document.body.style.overflow = '';
      modal.removeEventListener('animationend', onEnd);
      modal._preparedAdd = false;
      warmAddModal();
    };
    modal.addEventListener('animationend', onEnd);
    setTimeout(onEnd, 400);
  }
  function collectModalSnapshot(modal) {
    if (!modal) return '';
    const actions = window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS;
    const appearanceIds = new Set(Object.values(actions.appearanceFields));
    const persistent = Array.from(modal.querySelectorAll('input, select, textarea')).filter(el => {
      if (el.closest('#sekianafraz-preview-column, #sekianafraz-reminder-preview-wrap')) return false;
      if (['sekianafraz-search','sekianafraz-limit-search'].includes(el.id)) return false;
      return !appearanceIds.has(el.id) && !el.closest('#sekianafraz-action-fields .sekianafraz-spacing-control') && el.name !== 'sekianafraz-banner-image-mode';
    }).map((el, index) => [el.id || el.name || el.dataset.acInc || String(index), el.type,
      ['checkbox','radio'].includes(el.type) ? el.checked : el.value]);
    const chips = ['sekianafraz-chips','sekianafraz-limit-chips'].map(id => [id,
      Array.from(modal.querySelectorAll('#' + id + ' [data-id]')).map(el => el.dataset.id).sort()]);
    const canonical = value => {
      if (Array.isArray(value)) return value.map(canonical);
      if (value && typeof value === 'object') return Object.fromEntries(Object.keys(value).sort().map(key => [key,canonical(value[key])]));
      return value;
    };
    return JSON.stringify(canonical({fields:persistent, chips, variants:actions.collectBannerVariants()}));
  }
  function commitModalBaseline(modal) {
    if (!modal) return;
    modal.dataset.baseline = collectModalSnapshot(modal);
    modal.dataset.dirty = '';
  }
  function isModalActuallyDirty(modal) {
    if (!modal) return false;
    const base = String(modal.dataset.baseline || '');
    if (!base) return modal.dataset.dirty === '1';
    const cur = collectModalSnapshot(modal);
    return cur !== base;
  }
  function scheduleModalBaseline(modal) {
    if (!modal) return;
    commitModalBaseline(modal);
    modal.dataset.lockDirty = '';
  }
  function markModalDirty(modal) {
    if (!modal) return;
    if (modal.dataset && (modal.dataset.lockDirty === '1' || modal.dataset.suppressDirty === '1')) return;
    modal.dataset.dirty = '1';
  }
  function shouldConfirmClose(modal) {
    return modal.dataset.formReady === '1' && isModalActuallyDirty(modal);
  }
  function showCloseConfirm(modal) {
    if (!modal) return;
    if (document.getElementById('sekianafraz-confirm-backdrop')) return;
    const backdrop = document.createElement('div');
    backdrop.id = 'sekianafraz-confirm-backdrop';
    backdrop.className = 'sekianafraz-confirm-backdrop';
    backdrop.innerHTML =
      '<div class="sekianafraz-confirm" role="dialog" aria-modal="true" aria-labelledby="sekianafraz-confirm-title" aria-describedby="sekianafraz-confirm-desc">' +
      '<div class="sekianafraz-confirm__content">' +
      '<div class="sekianafraz-confirm__head">' +
      '<div class="sekianafraz-confirm__titlewrap">' +
      '<h3 class="sekianafraz-confirm__title" id="sekianafraz-confirm-title">مطمئنی می‌خوای ببندیش؟</h3>' +
      '<p class="sekianafraz-confirm__desc" id="sekianafraz-confirm-desc">اگر این پنجره رو ببندی، تغییراتت ذخیره نمی‌شن.</p>' +
      '</div>' +
      '<button class="sekianafraz-confirm__x" type="button" aria-label="بستن پیام">' +
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M18 6L6 18" stroke="#111" stroke-width="2" stroke-linecap="round"/>' +
      '<path d="M6 6L18 18" stroke="#111" stroke-width="2" stroke-linecap="round"/>' +
      '</svg>' +
      '</button>' +
      '</div>' +
      '<div class="sekianafraz-confirm__actions">' +
      '<button class="sekianafraz-confirm__btn sekianafraz-confirm__btn--primary" type="button">انصراف</button>' +
      '<button class="sekianafraz-confirm__btn sekianafraz-confirm__btn--danger" type="button">بستن</button>' +
      '</div>' +
      '</div>' +
      '</div>';
    document.body.appendChild(backdrop);
    document.body.classList.add('sekianafraz-confirm-open');
    const closeConfirm = () => {
      backdrop.classList.add('is-closing');
      setTimeout(() => { backdrop.remove(); document.body.classList.remove('sekianafraz-confirm-open'); }, 180);
    };
    const cancelBtn = backdrop.querySelector('.sekianafraz-confirm__btn--primary');
    const dangerBtn = backdrop.querySelector('.sekianafraz-confirm__btn--danger');
    const closeBtn = backdrop.querySelector('.sekianafraz-confirm__x');
    cancelBtn && cancelBtn.addEventListener('click', closeConfirm);
    closeBtn && closeBtn.addEventListener('click', closeConfirm);
    dangerBtn && dangerBtn.addEventListener('click', () => {
      closeConfirm();
      closeSensorModal(modal);
    });
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) closeConfirm();
    });
  }
  function showDeleteConfirm(idOrIds, onDelete) {
    if (document.getElementById('sekianafraz-confirm-backdrop')) return;
    const backdrop = document.createElement('div');
    backdrop.id = 'sekianafraz-confirm-backdrop';
    backdrop.className = 'sekianafraz-confirm-backdrop';
    backdrop.innerHTML =
      '<div class="sekianafraz-confirm" role="dialog" aria-modal="true">' +
      '<div class="sekianafraz-confirm__content">' +
      '<div class="sekianafraz-confirm__head">' +
      '<div class="sekianafraz-confirm__titlewrap">' +
      '<h3 class="sekianafraz-confirm__title">مطمئنی می‌خوای حذفش کنی؟</h3>' +
      '<p class="sekianafraz-confirm__desc">' + (onDelete ? 'شماره‌های انتخاب‌شده حذف می‌شوند.' : 'برای حذف موقت، وضعیت انتشار سنسور رو تغییر بده.') + '</p>' +
      '</div>' +
      '<button class="sekianafraz-confirm__x" type="button" aria-label="بستن پیام">' +
      '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">' +
      '<path d="M18 6L6 18" stroke="#111" stroke-width="2" stroke-linecap="round"/>' +
      '<path d="M6 6L18 18" stroke="#111" stroke-width="2" stroke-linecap="round"/>' +
      '</svg>' +
      '</button>' +
      '</div>' +
      '<div class="sekianafraz-confirm__actions">' +
      '<button class="sekianafraz-confirm__btn sekianafraz-confirm__btn--primary" type="button">انصراف</button>' +
      '<button class="sekianafraz-confirm__btn sekianafraz-confirm__btn--danger" type="button">حذف</button>' +
      '</div>' +
      '</div>' +
      '</div>';
    document.body.appendChild(backdrop);
    document.body.classList.add('sekianafraz-confirm-open');
    const closeConfirm = () => {
      backdrop.classList.add('is-closing');
      setTimeout(() => { backdrop.remove(); document.body.classList.remove('sekianafraz-confirm-open'); }, 180);
    };
    const cancelBtn = backdrop.querySelector('.sekianafraz-confirm__btn--primary');
    const deleteBtn = backdrop.querySelector('.sekianafraz-confirm__btn--danger');
    const closeBtn = backdrop.querySelector('.sekianafraz-confirm__x');
    cancelBtn && cancelBtn.addEventListener('click', closeConfirm);
    closeBtn && closeBtn.addEventListener('click', closeConfirm);
    deleteBtn && deleteBtn.addEventListener('click', async () => {
      const done = window.SEKIANAFRAZ_ADMIN_CORE.startButtonLoading(deleteBtn, 'حذف');
      try {
        if (onDelete) { await onDelete(); closeConfirm(); return; }
        if (Array.isArray(idOrIds)) {
          await api('sensors/bulk', { method: 'POST', data: { action: 'delete', ids: idOrIds } });
        } else {
          await api('sensors/delete', { method: 'POST', data: { id: idOrIds } });
        }
        location.reload();
      } catch (err) {
        toast(err.message || 'خطا در حذف سنسور');
      } finally { done(); }
    });
    backdrop.addEventListener('click', (e) => {
      if (e.target === backdrop) closeConfirm();
    });
  }
  function showConflictConfirm(conflictData, onResolve, onCancel, operation = 'save') {
    if (document.getElementById('sekianafraz-confirm-backdrop')) return;
    const data = conflictData && typeof conflictData === 'object' ? conflictData : {};
    const conflicts = Array.isArray(data.conflicts) ? data.conflicts : [];
    const scope = data.scope && typeof data.scope === 'object' ? data.scope : {};
    const smartLabel = String(data.smart_label || 'استثناسازی مکان(های) مشترک از سنسور فعلی');
    const cancelLabel = operation === 'activation' ? 'صرف نظر از فعالسازی سنسور' : 'صرف‌نظر از ذخیره این سنسور';
    const groupMarkup = conflicts.map((conflict) => {
      const samples = Array.isArray(conflict.items) ? conflict.items : [];
      return '<section class="sekianafraz-conflict-group" data-sensor-id="' + escAttr(conflict.sensor_id || '') + '">' +
        '<div class="sekianafraz-conflict-group__head"><strong>سنسور «' + escAttr(conflict.sensor_name || '') + '»</strong><span>' + escAttr(conflict.count || 0) + ' مکان مشترک</span></div>' +
        '<ul class="sekianafraz-conflict-items">' + samples.map((item) => '<li>' + escAttr(item.label || ('#' + item.id)) + '</li>').join('') + '</ul>' +
        (conflict.has_more ? '<button type="button" class="sekianafraz-conflict-more">مشاهده همه</button>' : '') +
        '</section>';
    }).join('');
    const backdrop = document.createElement('div');
    backdrop.id = 'sekianafraz-confirm-backdrop';
    backdrop.className = 'sekianafraz-confirm-backdrop sekianafraz-conflict-backdrop';
    backdrop.innerHTML = '<div class="sekianafraz-confirm sekianafraz-conflict-confirm" role="dialog" aria-modal="true" aria-labelledby="sekianafraz-conflict-title">' +
      '<div class="sekianafraz-confirm__content">' +
      '<div class="sekianafraz-confirm__head">' +
      '<div class="sekianafraz-confirm__titlewrap">' +
      '<h3 class="sekianafraz-confirm__title" id="sekianafraz-conflict-title">تداخل در مکان سنسورها</h3>' +
      '<p class="sekianafraz-confirm__desc">مکان سنسور تعیین‌شده شامل مکان‌هایی است که سنسورهای فعال دیگر پوشش می‌دهند. این هم‌پوشانی باید برطرف شود.</p>' +
      '</div>' +
      '<button class="sekianafraz-confirm__x" type="button" aria-label="بستن پیام"><svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6L18 18" stroke="#111" stroke-width="2" stroke-linecap="round"/></svg></button>' +
      '</div>' +
      '<div class="sekianafraz-conflict-groups">' + groupMarkup + '</div>' +
      '<div class="sekianafraz-confirm__actions sekianafraz-conflict-actions">' +
      '<button class="sekianafraz-confirm__btn sekianafraz-confirm__btn--primary sekianafraz-conflict-cancel" type="button">' + cancelLabel + '</button>' +
      (data.smart_allowed === true ? '<button class="sekianafraz-confirm__btn sekianafraz-conflict-smart" type="button">' + escAttr(smartLabel) + '</button>' : '') +
      '<button class="sekianafraz-confirm__btn sekianafraz-confirm__btn--danger sekianafraz-conflict-deactivate" type="button">' + (conflicts.length > 1 ? 'غیرفعال‌سازی سنسورهای متداخل' : 'غیرفعال‌سازی سنسور ' + escAttr((conflicts[0] && conflicts[0].sensor_name) || 'متداخل')) + '</button>' +
      '</div>' +
      '</div></div>';
    document.body.appendChild(backdrop);
    document.body.classList.add('sekianafraz-confirm-open');
    let closed = false;
    const closeConfirm = (cancelled) => {
      if (closed) return;
      closed = true;
      backdrop.classList.add('is-closing');
      setTimeout(() => {
        backdrop.remove();
        document.body.classList.remove('sekianafraz-confirm-open');
        if (cancelled && typeof onCancel === 'function') onCancel();
      }, 180);
    };
    const buttons = Array.from(backdrop.querySelectorAll('.sekianafraz-confirm__actions button'));
    const runResolution = async (resolution, button) => {
      const done = window.SEKIANAFRAZ_ADMIN_CORE.startButtonLoading(button, 'اعمال تغییرات');
      buttons.forEach((item) => { item.disabled = true; });
      try {
        await onResolve(resolution);
        closeConfirm(false);
      } catch (error) {
        buttons.forEach((item) => { item.disabled = false; });
        toast((error && error.message) || 'خطا در رفع تداخل سنسورها');
      } finally { done(); }
    };
    backdrop.querySelector('.sekianafraz-conflict-cancel')?.addEventListener('click', () => closeConfirm(true));
    backdrop.querySelector('.sekianafraz-confirm__x')?.addEventListener('click', () => closeConfirm(true));
    backdrop.querySelector('.sekianafraz-conflict-smart')?.addEventListener('click', (event) => runResolution('smart', event.currentTarget));
    backdrop.querySelector('.sekianafraz-conflict-deactivate')?.addEventListener('click', (event) => runResolution('deactivate', event.currentTarget));
    backdrop.addEventListener('click', (event) => { if (event.target === backdrop) closeConfirm(true); });
    backdrop.querySelectorAll('.sekianafraz-conflict-more').forEach((button) => {
      let page = 0;
      button.addEventListener('click', async () => {
        if (button.dataset.loading === '1') return;
        const done = window.SEKIANAFRAZ_ADMIN_CORE.startButtonLoading(button, 'بارگذاری');
        try {
          const group = button.closest('.sekianafraz-conflict-group');
          const conflictSensorId = parseInt(group?.dataset.sensorId || '0', 10) || 0;
          const result = await api('sensors/conflict-items', {
            method: 'POST',
            data: {
              placement: scope.placement || '',
              items: Array.isArray(scope.items) ? scope.items : [],
              id: parseInt(scope.id || '0', 10) || 0,
              conflict_sensor_id: conflictSensorId,
              page: page + 1,
              per_page: 20
            }
          });
          const list = group && group.querySelector('.sekianafraz-conflict-items');
          if (list) {
            if (page === 0) list.innerHTML = '';
            list.insertAdjacentHTML('beforeend', (result.items || []).map((item) => '<li>' + escAttr(item.label || ('#' + item.id)) + '</li>').join(''));
          }
          page = parseInt(result.page || String(page + 1), 10) || (page + 1);
          if (!result.has_more) button.remove();
        } catch (error) {
          toast((error && error.message) || 'خطا در بارگذاری مکان‌های مشترک');
        } finally { done(); }
      });
    });
  }
  function bindModalClose(modal) {
    const closeBtn = document.getElementById('sekianafraz-close-modal');
    if (!closeBtn) return;
    closeBtn.addEventListener('click', () => {
      if (shouldConfirmClose(modal)) {
        showCloseConfirm(modal);
      } else {
        closeSensorModal(modal);
      }
    });
  }
  let cachedAddMarkup = '';
  function prepareAddModal(modal) {
    window.SEKIANAFRAZ_CURRENT_EDIT_ID = null;
    modal._restorePreview = false;
    window.SEKIANAFRAZ_ADMIN_CONTROLS.disposeModalControls(modal);
    modal._validationAttempted = false;
    modal.dataset.formReady = '0';
    modal.dataset.dirty = ''; modal.dataset.baseline = ''; modal.dataset.lockDirty = '1';
    modal.classList.add('is-form-preparing');
    const overlay = modal.querySelector(':scope > .sekianafraz-modal-loading-overlay');
    modal.innerHTML = '<div>' + (cachedAddMarkup || renderModal('add')) + '</div>';
    suppressModalBrowserSuggestions(modal);
    if (overlay) modal.append(overlay);
    bindModalClose(modal);
    mountPreviewArea(modal);
    bindLiveEvents(modal);
    const placement = $('#sekianafraz-placement');
    placement.selectedIndex = -1;
    const action = $('#sekianafraz-action');
    if (action?.dataset.emptyDefault === '1') {
      action.selectedIndex = -1;
      action.dataset.emptyDefaultApplied = '1';
    }
    mountCustomSelects(modal);
    mountCustomCouponTemplate();
    if ($('#sekianafraz-coupon-mid-pattern')) $('#sekianafraz-coupon-mid-pattern').value = 'mixed';
    mountCouponStrategy();
    placement.addEventListener('change', () => loadPlacementFields(placement.value));
    loadPlacementFields(placement.value);
    mountCouponLimit();
    mountReminder();
    bindCouponAmountUnit();
    applyModalCheckboxSkin(modal);
    applyNumberGuards();
    const save = $('#sekianafraz-save-sensor');
    save.addEventListener('click', withBtnLoader(save, saveSensor));
    finishFormInitialization(modal);
    scheduleModalBaseline(modal);
  }
  function warmAddModal() {
    const modal = $('#sekianafraz-sensor-modal');
    if (!modal || !modal.hidden || modal.classList.contains('closing')) return;
    cachedAddMarkup ||= renderModal('add');
    modal.classList.add('is-prewarming');
    prepareAddModal(modal);
    modal._preparedAdd = true;
  }
  function openModalForAdd() {
    const modal = $('#sekianafraz-sensor-modal');
    if (!modal || !modal.hidden) return;
    window.SEKIANAFRAZ_CURRENT_EDIT_ID = null;
    modal._preparedAdd = false;
    modal._loadRevision = (modal._loadRevision || 0) + 1;
    modal._closeRevision = (modal._closeRevision || 0) + 1;
    modal.classList.remove('closing', 'is-prewarming');
    modal.hidden = false;
    window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS.mount(modal);
    document.body.classList.add('sekianafraz-sensor-modal-open');
    document.body.style.overflow = 'hidden';
  }
  window.addEventListener('resize', () => {
    const modal = $('#sekianafraz-sensor-modal');
    if (modal?.hidden && modal._preparedAdd) finishFormInitialization(modal);
  });
  async function prefillSensor(id) {
    const MODE = 'edit';
    window.SEKIANAFRAZ_CURRENT_EDIT_ID = id;
    const modal = $('#sekianafraz-sensor-modal');
    const revision = modal._loadRevision;
    const active = () => revision === modal._loadRevision && !modal.hidden && !modal.classList.contains('closing');
    try {
      const j = await api('sensors/get?id=' + id);
      if (!active()) return;
      if (!j.success) throw new Error('load failed');
      modal.dataset.formReady = '0';
      modal.classList.add('is-form-preparing');
      const html = renderModal(MODE);
      const shell = modal.querySelector(':scope > .sekianafraz-modal-edit-shell');
      if (!shell) throw new Error('edit shell missing');
      shell.innerHTML = html;
      suppressModalBrowserSuggestions(modal);
      ensureModalLoader(modal);
      fields().renderExclusions(j.item.exclusions || {}, id);
      modal.dataset.dirty = '';
      modal.dataset.lockDirty = '1';
      bindModalClose(modal);
      mountPreviewArea(modal);
      bindLiveEvents(modal);
      const placement = $('#sekianafraz-placement');
      placement.addEventListener('change', () => {
        loadPlacementFields(placement.value);
        fields().renderExclusions({}, id);
      });
      const uiPlacement = fields().uiPlacementOf(j.item.placement || 'product_single', j.item.items || []);
      $('#sekianafraz-placement').value = uiPlacement;
      loadPlacementFields($('#sekianafraz-placement').value);
      applyNumberGuards();
      $('#sekianafraz-name').value = j.item.name || '';
      const applyVisitSettings = () => {
        if ($('#sekianafraz-min')) $('#sekianafraz-min').value = String(j.item.min_views || 1);
        if ($('#sekianafraz-min-duration')) $('#sekianafraz-min-duration').value = String(j.item.min_duration || 1);
        if ($('#sekianafraz-visit-condition')) {
          $('#sekianafraz-visit-condition').value = j.item.visit_condition === 'and' ? 'and' : 'or';
          fields().syncVisitConditionControl(false);
        }
        if ($('#sekianafraz-visit-metric')) {
          $('#sekianafraz-visit-metric').value = j.item.visit_metric || 'views';
          $('#sekianafraz-visit-metric').dispatchEvent(new Event('change'));
        }
        fields().updateVisitCalculationVisibility();
        const canAggregate = uiPlacement.endsWith('_all') || fields().isGroupedContentPlacement(uiPlacement) || (Array.isArray(j.item.items) && j.item.items.length > 1);
        if ($('#sekianafraz-visit-calculation')) {
          $('#sekianafraz-visit-calculation').value = canAggregate ? (j.item.visit_calculation || 'individual') : 'individual';
          $('#sekianafraz-visit-calculation').dispatchEvent(new Event('change'));
        }
      };
      applyVisitSettings();
      const chipsContainerCheck = () => document.querySelector('#sekianafraz-dynamic #sekianafraz-chips');
      let tries = 0; const fillGeneric = async () => {
        if (Array.isArray(j.item.items) && j.item.items.indexOf('*') !== -1) { applyVisitSettings(); return; }
        const chips = chipsContainerCheck(); if (!chips) { if (tries++ < 20) { return setTimeout(fillGeneric, 100); } else { return; } }
        if (Array.isArray(j.item.items) && j.item.items.length) {
          const ids = j.item.items.join(',');
          const lab = await api('labels?placement=' + encodeURIComponent(j.item.placement || '') + '&ids=' + encodeURIComponent(ids), { method: 'GET' });
            if (!active()) return;
          const map = new Map(); (lab.items || []).forEach(x => map.set(String(x.id), x.label));
          j.item.items.forEach((val) => { const label = map.get(String(val)) || String(val); addChip(j.item.placement || '', String(val), label); });
        }
        applyVisitSettings();
      };
      const fillCustomUrl = () => {
        let t = 0; const tick = () => {
          const inp = $('#sekianafraz-items'); if (!inp) { if (t++ < 20) return setTimeout(tick, 100); else return; }
          const first = (Array.isArray(j.item.items) && j.item.items.length) ? String(j.item.items[0]) : ''; inp.value = first; applyVisitSettings();
        }; tick();
      };
      const fillSearchTerms = () => {
        let t = 0; const tick = () => {
          const chips = chipsContainerCheck(); const inp = $('#sekianafraz-key'); if (!chips || !inp) { if (t++ < 20) return setTimeout(tick, 100); else return; }
          if (Array.isArray(j.item.items)) j.item.items.forEach(v => addChip('search_terms', String(v), String(v)));
          applyVisitSettings();
        }; tick();
      };
      if (j.item.placement === 'custom_url') fillCustomUrl();
      else if (j.item.placement === 'search_terms') fillSearchTerms();
      else await fillGeneric();
      $('#sekianafraz-window').value = j.item.window || '24h';
      $('#sekianafraz-ctype').value = j.item.coupon_type || 'mixed';
      if ($('#sekianafraz-coupon-prefix')) $('#sekianafraz-coupon-prefix').value = j.item.coupon_custom_prefix || '';
      if ($('#sekianafraz-coupon-suffix')) $('#sekianafraz-coupon-suffix').value = j.item.coupon_custom_suffix || '';
      if ($('#sekianafraz-coupon-length')) $('#sekianafraz-coupon-length').value = String(j.item.coupon_custom_length || 4);
      if ($('#sekianafraz-coupon-mid-pattern')) $('#sekianafraz-coupon-mid-pattern').value = j.item.coupon_custom_mid_pattern || 'mixed';
      $('#sekianafraz-coupon-strategy').value = j.item.coupon_strategy || 'individual';
      $('#sekianafraz-fixed-code').value = j.item.fixed_code || '';
      $('#sekianafraz-coupon-amount').value = String(j.item.coupon_amount || 0);
      $('#sekianafraz-cmode').value = j.item.coupon_mode || 'fixed';
      mountCouponStrategy();
      if ($('#sekianafraz-visit-condition')) {
        $('#sekianafraz-visit-condition').value = j.item.visit_condition === 'and' ? 'and' : 'or';
        fields().syncVisitConditionControl(false);
        fields().refreshCouponStrategyRestriction();
      }
      bindCouponAmountUnit();
      $('#sekianafraz-coupon-valid-hours').value = String(j.item.coupon_valid_hours || 72);
      $('#sekianafraz-coupon-usage-limit').value = String(j.item.coupon_usage_limit ?? 3);
      $('#sekianafraz-coupon-restrict-user').checked = !!j.item.coupon_restrict_user;
      $('#sekianafraz-coupon-restrict-guest').checked = !!j.item.coupon_restrict_guest;
      if ($('#sekianafraz-coupon-free-shipping')) $('#sekianafraz-coupon-free-shipping').checked = !!j.item.coupon_free_shipping;
      $('#sekianafraz-coupon-strategy').dispatchEvent(new Event('change'));
      $('#sekianafraz-action').value = j.item.action || 'banner';
      renderActionFields($('#sekianafraz-action').value);
      mountCustomSelects(modal);
      mountCustomCouponTemplate();
      let triesAct = 0; const fillAct = () => {
        const actSel = $('#sekianafraz-action'); const smsMode = $('#sekianafraz-sms-mode');
        if (!actSel || (actSel.value === 'sms' && !smsMode) || (actSel.value === 'both' && !smsMode)) { if (triesAct++ < 20) return setTimeout(fillAct, 100); else return; }
        if (j.item.action === 'sms' || j.item.action === 'both' || j.item.banner_type === 'multi') {
          if ($('#sekianafraz-sms-mode')) {
            $('#sekianafraz-sms-mode').value = j.item.sms_mode || 'promo';
            $('#sekianafraz-sms-mode').dispatchEvent(new Event('change'));
          }
          if ((j.item.sms_mode === 'promo' || !j.item.sms_mode) && $('#sekianafraz-sms-text')) $('#sekianafraz-sms-text').value = j.item.sms_text || '';
          if (j.item.sms_mode === 'pattern' && $('#sekianafraz-sms-pattern')) $('#sekianafraz-sms-pattern').value = j.item.sms_pattern || '';
          if ($('#sekianafraz-sms-target-url')) $('#sekianafraz-sms-target-url').value = j.item.sms_target_url || '';
          window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.updateSmsTargets();
          if ($('#sekianafraz-sms-delay-type')) {
            $('#sekianafraz-sms-delay-type').value = j.item.banner_type === 'multi' ? 'immediate' : (j.item.sms_delay_type || 'immediate');
            $('#sekianafraz-sms-delay-type').dispatchEvent(new Event('change'));
          }
          window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.setSmsDelayMinutes($('#sekianafraz-sms-delay-minutes'),
            j.item.sms_delay_minutes ?? 60);
        }
        if ((j.item.action === 'banner' || j.item.action === 'both')) {
          if ($('#sekianafraz-banner-title')) $('#sekianafraz-banner-title').value = j.item.banner_title || '';
          if ($('#sekianafraz-banner-button-text')) $('#sekianafraz-banner-button-text').value = j.item.banner_button_text || '';
          if ($('#sekianafraz-banner-text')) $('#sekianafraz-banner-text').value = j.item.banner_text || '';
          if ($('#sekianafraz-banner-svg-color')) {
            const col = j.item.banner_svg_color || '#000000';
            $('#sekianafraz-banner-svg-color').value = col;
            $('#sekianafraz-banner-svg-color').dispatchEvent(new Event('input', { bubbles: true }));
          }
        }
        if ((j.item.action === 'banner' || j.item.action === 'both') && $('#sekianafraz-button-color')) {
          $('#sekianafraz-button-color').value = (j.item.banner_button_color && String(j.item.banner_button_color).trim()) || '#000000';
          if ($('#sekianafraz-banner-bg-color')) $('#sekianafraz-banner-bg-color').value = j.item.banner_bg_color || '#ffffff';
          if ($('#sekianafraz-banner-title-color')) $('#sekianafraz-banner-title-color').value = j.item.banner_title_color || '#0d0d0d';
          if ($('#sekianafraz-banner-text-color')) $('#sekianafraz-banner-text-color').value = j.item.banner_text_color || '#4b5563';
          if ($('#sekianafraz-banner-coupon-color')) $('#sekianafraz-banner-coupon-color').value = j.item.banner_coupon_color || '#5c5c5c';
        }
        if ((j.item.action === 'banner' || j.item.action === 'both')) {
          if ($('#sekianafraz-banner-image') && j.item.banner_image) {
            $('#sekianafraz-banner-image').value = j.item.banner_image;
            const p = $('#sekianafraz-banner-preview');
            const r = $('#sekianafraz-remove-image');
            if (p) { p.src = j.item.banner_image; p.style.display = 'block'; }
            if (r) r.style.display = 'inline-block';
          }
          applyBannerRadiusState(j.item);
          applyBannerPaddingState(j.item);
          window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.applyBannerMarginState(j.item);
          if ($('#sekianafraz-display-name-fallback')) {
            $('#sekianafraz-display-name-fallback').value = j.item.display_name_fallback || '';
          }
          if ($('#sekianafraz-banner-font-type')) {
            $('#sekianafraz-banner-font-type').value = j.item.banner_font_type || 'arad';
            $('#sekianafraz-banner-font-type').dispatchEvent(new Event('change'));
          }
          mountColorFields(modal);
        }
        if ($('#sekianafraz-hide-banner-logged-in')) {
          $('#sekianafraz-hide-banner-logged-in').checked = !!j.item.hide_banner_for_logged_in;
        }
        if (j.item.action === 'banner' || j.item.action === 'both') {
          const close = $('#sekianafraz-banner-show-close');
          if (close) close.checked = !!j.item.banner_show_close;
          const hiddenBg = $('#sekianafraz-banner-close-hide-bg');
          if (hiddenBg) hiddenBg.checked = !!j.item.banner_close_hide_bg;
          const position = $('#sekianafraz-banner-close-position');
          if (position) position.value = j.item.banner_close_position || 'left';
          ['close_bg_color', 'close_icon_color'].forEach((key) => {
            const input = $('#sekianafraz-' + key.replace(/_/g, '-') + '-color');
            if (input) input.value = j.item[key] || (key === 'close_bg_color' ? '#f1f1f1' : '#111111');
          });
          window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.applyBannerVariants(j.item);
          if ($('#sekianafraz-logged-sms-target-url')) $('#sekianafraz-logged-sms-target-url').value = j.item.logged_sms_target_url || '';
          window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.updateSmsTargets();
        }
        updateVarsTables(modal);
      };
      fillAct();
      mountCouponLimit();
      if (j.item.reminder_enabled) {
        $('#sekianafraz-reminder-enabled').checked = true;
        $('#sekianafraz-reminder-message').value = j.item.reminder_message_template || 'فقط {Timer} ساعت برای استفاده از کد تخفیف {coupon_code} باقی مونده!';
        $('#sekianafraz-reminder-timer-panel').checked = j.item.reminder_show_timer_panel || false;
        if (j.item.reminder_colors) {
          const colors = j.item.reminder_colors;
          if (colors.bg) $('#sekianafraz-reminder-color-bg').value = colors.bg;
          if (colors.text) $('#sekianafraz-reminder-color-text').value = colors.text;
          if (colors.timer_value) $('#sekianafraz-reminder-color-timer-value').value = colors.timer_value;
          if (colors.timer_bg) $('#sekianafraz-reminder-color-timer-bg').value = colors.timer_bg;
          if (colors.timer_text) $('#sekianafraz-reminder-color-timer-text').value = colors.timer_text;
          if (colors.close_btn) $('#sekianafraz-reminder-color-close-btn').value = colors.close_btn;
          if (colors.coupon_highlight) $('#sekianafraz-reminder-color-coupon-highlight').value = colors.coupon_highlight;
        }
      }
      mountReminder();
      window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.applyReminderStyles(j.item);
      mountColorFields(modal);
      applyModalCheckboxSkin(modal);
      applyNumberGuards();
      if (j.item.coupon_limit_enabled) {
        const limitEnabled = $('#sekianafraz-coupon-limit-enabled');
        if (limitEnabled) limitEnabled.checked = true;
        const t = (j.item.coupon_limit_type === 'category') ? 'category' : 'product';
        const productType = $('#sekianafraz-limit-type-product');
        const categoryType = $('#sekianafraz-limit-type-category');
        if (productType) {
          productType.checked = t === 'product';
          productType.setAttribute('aria-checked', String(productType.checked));
        }
        if (categoryType) {
          categoryType.checked = t === 'category';
          categoryType.setAttribute('aria-checked', String(categoryType.checked));
        }
        if (limitEnabled) limitEnabled.dispatchEvent(new Event('change'));
        {
          const ids = Array.isArray(j.item.coupon_limit_ids) ? j.item.coupon_limit_ids : [];
          if (ids.length) {
            const placementForLabels = t === 'product' ? 'product_single' : 'product_cat';
            const lab = await api('labels?placement=' + encodeURIComponent(placementForLabels) + '&ids=' + encodeURIComponent(ids.join(',')), { method: 'GET' });
            if (!active()) return;
            const map = new Map(); (lab.items || []).forEach(x => map.set(String(x.id), x.label));
            ids.forEach((val) => { const label = map.get(String(val)) || String(val); addChipScoped('sekianafraz-limit-chips', placementForLabels, String(val), label); });
          }
        }
      }
      const save = $('#sekianafraz-save-sensor'); save.addEventListener('click', withBtnLoader(save, saveSensor));
      finishFormInitialization(modal);
      scheduleModalBaseline(modal);
    } catch (e) {
      if (!active()) return;
      modal.classList.remove('is-form-preparing', 'is-edit-loading');
      modal.dataset.formReady = '0';
      modal.innerHTML = '<div><div class="header"><div class="sekianafraz-modal-header-actions"><button class="close" id="sekianafraz-close-modal">\n<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>\n</button></div></div><div class="content"><div class="sekianafraz-field">بارگذاری اطلاعات سنسور با خطا مواجه شد.</div></div></div>';
      $('#sekianafraz-close-modal').addEventListener('click', () => closeSensorModal(modal));
    }
  }
  window.SEKIANAFRAZ_ADMIN_SENSOR_LIFECYCLE = {
    openModal, closeSensorModal, collectModalSnapshot, commitModalBaseline,
    isModalActuallyDirty, scheduleModalBaseline, markModalDirty,
    shouldConfirmClose, showCloseConfirm, showDeleteConfirm, showConflictConfirm, bindModalClose,
    warmAddModal, openModalForAdd, prefillSensor
  };
})();
