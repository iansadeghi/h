(function () {
  function $(q, ctx) { return (ctx || document).querySelector(q) }
  function $all(q, ctx) { return Array.from((ctx || document).querySelectorAll(q)) }
  const rest = (window.SEKIANAFRAZ_ADMIN && SEKIANAFRAZ_ADMIN.rest) || '';
  const nonce = (window.SEKIANAFRAZ_ADMIN && SEKIANAFRAZ_ADMIN.nonce) || '';
  const currencyLabel = (window.SEKIANAFRAZ_ADMIN && SEKIANAFRAZ_ADMIN.currency) || (window.SEKIANAFRAZAdmin && SEKIANAFRAZAdmin.currency) || 'تومان';
  function escAttr(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
  function _sekianafrazMeasureTextWidth(text, refEl) {
    const cs = window.getComputedStyle(refEl);
    const span = document.createElement('span');
    span.textContent = text || '';
    span.style.position = 'absolute';
    span.style.visibility = 'hidden';
    span.style.whiteSpace = 'pre';
    span.style.fontFamily = cs.fontFamily;
    span.style.fontSize = cs.fontSize;
    span.style.fontWeight = cs.fontWeight;
    span.style.fontStyle = cs.fontStyle;
    span.style.letterSpacing = cs.letterSpacing;
    span.style.textTransform = cs.textTransform;
    span.style.fontVariant = cs.fontVariant;
    span.style.fontStretch = cs.fontStretch;
    span.style.direction = cs.direction;
    span.style.unicodeBidi = cs.unicodeBidi;
    document.body.appendChild(span);
    const w = span.getBoundingClientRect().width;
    span.remove();
    return w;
  }
  function fitDisplayNameFallbackToPlaceholder() {
    const input = document.getElementById('sekianafraz-display-name-fallback');
    if (!input || input.disabled) return;
    const ph = input.getAttribute('placeholder') || '';
    if (!ph) return;
    if (!document.body) return;
    if (input.dataset.sekianafrazFitDone === '1' && input.dataset.sekianafrazFitPh === ph) return;
    const cs = window.getComputedStyle(input);
    const textW = _sekianafrazMeasureTextWidth(ph, input);
    const pl = parseFloat(cs.paddingLeft) || 0;
    const pr = parseFloat(cs.paddingRight) || 0;
    const bl = parseFloat(cs.borderLeftWidth) || 0;
    const br = parseFloat(cs.borderRightWidth) || 0;
    const total = textW + pl + pr + bl + br;
    const target = (cs.boxSizing === 'border-box') ? total : textW;
    input.style.width = (Math.round(target * 100) / 100) + 'px';
    input.dataset.sekianafrazFitDone = '1';
    input.dataset.sekianafrazFitPh = ph;
  }
  let _sekianafrazFitRaf = null;
  function scheduleFitDisplayNameFallback() {
    if (_sekianafrazFitRaf) return;
    _sekianafrazFitRaf = window.requestAnimationFrame(function () {
      _sekianafrazFitRaf = null;
      try { fitDisplayNameFallbackToPlaceholder(); } catch (e) { }
    });
  }
  try {
    const mo = new MutationObserver(function () { scheduleFitDisplayNameFallback(); });
    mo.observe(document.documentElement, { childList: true, subtree: true });
    window.addEventListener('resize', function () {
      const input = document.getElementById('sekianafraz-display-name-fallback');
      if (input) input.dataset.sekianafrazFitDone = '';
      scheduleFitDisplayNameFallback();
    });
    scheduleFitDisplayNameFallback();
    if (document.fonts && document.fonts.ready && typeof document.fonts.ready.then === 'function') {
      document.fonts.ready.then(function () {
        const input = document.getElementById('sekianafraz-display-name-fallback');
        if (input) input.dataset.sekianafrazFitDone = '';
        scheduleFitDisplayNameFallback();
      });
    }
  } catch (e) { }
  async function api(path, { method = 'GET', data } = {}) {
    let url = rest + path;
    const qIndex = url.indexOf('?');
    if (qIndex !== -1 && url.indexOf('?', qIndex + 1) !== -1) {
      url = url.substring(0, qIndex + 1) + url.substring(qIndex + 1).replace(/\?/g, '&');
    }
    const r = await fetch(url, { method, headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce }, credentials: 'same-origin', body: method === 'GET' ? undefined : JSON.stringify(data || {}) });
    let j = null; try { j = await r.json() } catch (e) { }
    if (!r.ok) throw (j || { message: r.statusText });
    return j
  }
  function startButtonLoading(btn, operation) {
    if (!btn || btn.dataset.loading === '1') return () => {};
    const label = btn.textContent;
    operation = operation || (/ذخیره/.test(label) ? 'ذخیره' : /حذف/.test(label) ? 'حذف' :
      /بررسی|تست/.test(label) ? 'بررسی' : /ارسال/.test(label) ? 'ارسال' :
      /غیرفعال/.test(label) ? 'غیرفعال‌سازی' : /فعال/.test(label) ? 'فعال‌سازی' :
      /خروجی/.test(label) ? 'دریافت خروجی' : 'بارگذاری');
    btn._sekianafrazLoadingAnimation?.cancel();
    const savedStyle = btn.getAttribute('style');
    const savedDisabled = btn.disabled;
    const savedBusy = btn.getAttribute('aria-busy');
    const width = btn.getBoundingClientRect().width;
    const fontSize = getComputedStyle(btn).fontSize;
    const children = Array.from(btn.childNodes);
    const animateWidth = (from, to) => {
      btn._sekianafrazLoadingAnimation?.cancel();
      if (btn.animate && !window.matchMedia?.('(prefers-reduced-motion: reduce)').matches && from !== to) {
        btn._sekianafrazLoadingAnimation = btn.animate(
          [{ width: from + 'px' }, { width: to + 'px' }],
          { duration: 240, easing: 'cubic-bezier(.16, 1, .3, 1)' }
        );
      }
    };
    btn.disabled = true; btn.dataset.loading = '1'; btn.setAttribute('aria-busy', 'true');
    btn.style.fontSize = fontSize;
    const spinner = document.createElement('span'); spinner.className = 'sekianafraz-button-spinner'; spinner.setAttribute('aria-hidden', 'true');
    const text = document.createElement('span'); text.className = 'sekianafraz-button-loading-text'; text.textContent = 'درحال ' + operation;
    btn.replaceChildren(spinner, text);
    const probe = btn.cloneNode(true);
    probe.removeAttribute('id'); probe.setAttribute('aria-hidden', 'true');
    Object.assign(probe.style, {
      position: 'absolute', visibility: 'hidden', pointerEvents: 'none',
      width: 'max-content', minWidth: '0', maxWidth: 'none',
      inlineSize: 'max-content', minInlineSize: '0', maxInlineSize: 'none',
      flex: 'none', transition: 'none', transform: 'none', boxSizing: 'border-box'
    });
    btn.parentNode.appendChild(probe);
    const targetWidth = Math.ceil(Math.max(width, probe.getBoundingClientRect().width));
    probe.remove();
    Object.assign(btn.style, { width: targetWidth + 'px', minWidth: width + 'px', maxWidth: 'none', flexShrink: '0', boxSizing: 'border-box' });
    animateWidth(width, targetWidth);
    let finished = false;
    return () => {
      if (finished) return;
      finished = true;
      const currentWidth = btn.getBoundingClientRect().width;
      btn._sekianafrazLoadingAnimation?.cancel();
      btn.replaceChildren(...children); btn.disabled = savedDisabled; btn.dataset.loading = '';
      if (savedBusy === null) btn.removeAttribute('aria-busy'); else btn.setAttribute('aria-busy', savedBusy);
      if (savedStyle === null) btn.removeAttribute('style'); else btn.setAttribute('style', savedStyle);
      animateWidth(currentWidth, btn.getBoundingClientRect().width);
    };
  }
  function withBtnLoader(btn, fn, operation) {
    return async function (...args) {
      if (!btn || btn.dataset.loading === '1') return;
      const done = startButtonLoading(btn, operation);
      try { await fn(...args); } finally { done(); }
    };
  }
  function setBulkActionsVisible(el, visible) {
    if (!el) return;
    clearTimeout(el._bulkTimer);
    if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
      el.classList.remove('is-entering', 'is-leaving'); el.hidden = !visible; return;
    }
    if (visible) {
      const entering = el.hidden || el.classList.contains('is-leaving');
      el.hidden = false; el.classList.remove('is-leaving');
      if (entering) { void el.offsetWidth; el.classList.add('is-entering'); el._bulkTimer = setTimeout(() => el.classList.remove('is-entering'), 760); }
    } else if (!el.hidden && !el.classList.contains('is-leaving')) {
      el.classList.remove('is-entering'); el.classList.add('is-leaving');
      el._bulkTimer = setTimeout(() => { el.hidden = true; el.classList.remove('is-leaving'); }, 620);
    }
  }
  function renderVarsTable(vars, withFallback = false) {
    const rows = vars.map(v => {
      let label = v.label;
      const token = v.token || '{{' + v.key + '}}';
      if (v.key === 'display_name' && withFallback) {
        const placeholderText = 'کاربر وارد نشده رو چی صدا بزنم؟';
        label += ' <span class="sekianafraz-display-name-fallback-wrap">'
          + '<input type="text" id="sekianafraz-display-name-fallback" placeholder="' + placeholderText + '">'
        + '</span>';
      }
      return '<tr><td>' + label + '</td><td class="sekianafraz-var-token-cell"><code dir="ltr">' + escAttr(token) + '</code>' +
        '<button type="button" class="sekianafraz-copy-variable" data-copy-variable="' + escAttr(token) + '" aria-label="کپی متغیر ' + escAttr(token) + '">' +
        '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="11" height="11" rx="2"></rect><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"></path></svg>' +
        '<span class="sekianafraz-copy-variable-tooltip" role="status">کپی شد!</span></button></td></tr>';
    }).join('');
    return '<table class="sekianafraz-table sekianafraz-vars-table"><thead><tr><th>عنوان</th><th>متغیر</th></tr></thead><tbody>' + rows + '</tbody></table>'
  }
  function renderColorFields(items, extraClass) {
    return '<div class="sekianafraz-color-fields' + (extraClass ? ' ' + escAttr(extraClass) : '') + '">' +
      items.map((item) => {
        const id = item[0];
        const label = item[1];
        const value = item[2];
        return '<label class="sekianafraz-color-field" for="' + escAttr(id) + '" style="--sekianafraz-color-value:' + escAttr(value) + '">' +
          '<span class="sekianafraz-color-swatch"><input type="color" id="' + escAttr(id) + '" value="' + escAttr(value) + '" aria-label="' + escAttr(label) + '"></span>' +
          '<span class="sekianafraz-color-label">' + label + '</span></label>';
      }).join('') + '</div>';
  }
  function updateVarsTables(modalCtx) {
    const root = (modalCtx && modalCtx.querySelector) ? modalCtx : document;
    const modal = (root && root.id === 'sekianafraz-sensor-modal') ? root : document.getElementById('sekianafraz-sensor-modal');
    const couponDisabled = !!(modal && modal.dataset && modal.dataset.acCouponDisabled === '1');
    const strategy = (root.querySelector && root.querySelector('#sekianafraz-coupon-strategy')) || document.getElementById('sekianafraz-coupon-strategy');
    const calculation = (root.querySelector && root.querySelector('#sekianafraz-visit-calculation')) || document.getElementById('sekianafraz-visit-calculation');
    const placement = (root.querySelector && root.querySelector('#sekianafraz-placement')) || document.getElementById('sekianafraz-placement');
    const tables = modal ? Array.from(modal.querySelectorAll('.sekianafraz-vars-table')) : [];
    if (!tables.length) return;
    const val = strategy ? String(strategy.value || '').trim() : '';
    const isFixed = (val === 'fixed');
    const isNone = couponDisabled || (val === 'none');
    const isAggregate = !!(calculation && calculation.value === 'aggregate');
    const basePlacement = String(placement ? placement.value : '').replace(/_all$/, '');
    const locationVars = {
      product_single: '{{product_name}}',
      product_in_cat: '{{product_name}}',
      product_in_tag: '{{product_name}}',
      product_cat: '{{category_name}}',
      product_tag: '{{product_tag_name}}',
      post_single: '{{post_name}}',
      post_in_cat: '{{post_name}}',
      post_in_tag: '{{post_name}}',
      post_cat: '{{post_category_name}}',
      post_tag: '{{post_tag_name}}',
      page: '{{page_name}}',
      search_terms: '{{search_term}}'
    };
    const locationToken = locationVars[basePlacement] || '';
    tables.forEach((table) => {
      table.querySelectorAll('tbody tr').forEach((tr) => {
        const keyTd = tr.cells && tr.cells[1];
        if (!keyTd) return;
        const code = keyTd.querySelector ? keyTd.querySelector('code') : null;
        const key = String(code ? code.textContent : keyTd.textContent || '').trim();
        let hide = isAggregate && locationToken !== '' && key === locationToken;
        if (!hide && key.indexOf('{{coupon_') === 0) {
          if (isNone) hide = true;
          if (!hide && isFixed && (key === '{{coupon_expiry_time}}' || key === '{{coupon_valid_hours}}')) hide = true;
        }
        tr.style.display = hide ? 'none' : '';
      });
    });
  }
  function filterVarsByCoupon(vars, modalCtx) {
    try {
      const root = (modalCtx && modalCtx.querySelector) ? modalCtx : document;
      const modal = (root && root.id === 'sekianafraz-sensor-modal') ? root : document.getElementById('sekianafraz-sensor-modal');
      const couponDisabled = !!(modal && modal.dataset && modal.dataset.acCouponDisabled === '1');
      const strategy = (root.querySelector && root.querySelector('#sekianafraz-coupon-strategy')) || document.getElementById('sekianafraz-coupon-strategy');
      const val = strategy ? String(strategy.value || '').trim() : '';
      const isNone = couponDisabled || (val === 'none');
      const isFixed = (val === 'fixed');
      let out = (vars || []).slice();
      if (isNone) {
        out = out.filter(v => {
          const k = (v && (v.key || v.name)) ? String(v.key || v.name) : '';
          return !(k.indexOf('coupon_') === 0);
        });
      }
      if (isFixed) {
        out = out.filter(v => {
          const k = (v && (v.key || v.name)) ? String(v.key || v.name) : '';
          return !(k === 'coupon_expiry_time' || k === 'coupon_valid_hours');
        });
      }
      return out;
    } catch (e) {
      return vars || [];
    }
  }
  function getVarsForCurrent(action, mode) {
    const placement = $('#sekianafraz-placement') ? $('#sekianafraz-placement').value : 'product_single';
    return { placement, action, mode };
  }
  function adminNotice(msg, type, opts) {
    const o = opts || {};
    const id = o.id ? String(o.id) : '';
    const t = (typeof type === 'string' ? type : (type === true ? 'success' : (type === false ? 'error' : 'info')));
    const wrap = document.querySelector('#wpbody-content .wrap') || document.querySelector('.wrap') || document.body;
    let n = id ? document.getElementById(id) : null;
    if (!n) {
      n = document.createElement('div');
      if (id) n.id = id;
      n.className = 'notice is-dismissible sekianafraz-admin-notice';
      n.style.marginTop = '12px';
      const p = document.createElement('p');
      p.className = 'sekianafraz-admin-notice-text';
      n.appendChild(p);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'notice-dismiss';
      btn.innerHTML = '<span class="screen-reader-text">Dismiss this notice.</span>';
      btn.addEventListener('click', () => {
        if (n && n.parentNode) n.parentNode.removeChild(n);
      });
      n.appendChild(btn);
      const first = wrap.firstElementChild;
      if (first && first.tagName && first.tagName.toLowerCase() === 'h1') {
        first.insertAdjacentElement('afterend', n);
      } else {
        wrap.insertAdjacentElement('afterbegin', n);
      }
    }
    n.classList.remove('notice-success', 'notice-error', 'notice-warning', 'notice-info');
    if (t === 'success') n.classList.add('notice-success');
    else if (t === 'error') n.classList.add('notice-error');
    else if (t === 'warning') n.classList.add('notice-warning');
    else n.classList.add('notice-info');
    const p = n.querySelector('p') || n.querySelector('.sekianafraz-admin-notice-text') || n;
    p.textContent = String(msg || '');
    if (o.sticky) return n;
    const timeout = (typeof o.timeout === 'number') ? o.timeout : (t === 'success' ? 2000 : 4500);
    if (timeout > 0) {
      clearTimeout(n._sekianafrazT);
      n._sekianafrazT = setTimeout(() => { if (n && n.parentNode) n.parentNode.removeChild(n); }, timeout);
    }
    return n;
  }
  function toast(msg, opts) {
    opts = opts || {};
    const id = opts.id || '';
    let n = id ? document.getElementById(id) : null;
    if (!n) {
      n = document.createElement('div');
      n.className = 'sekianafraz-badge';
      n.style.position = 'fixed';
      n.style.bottom = ((typeof opts.bottom === 'number') ? opts.bottom : 20) + 'px';
      n.style.left = ((typeof opts.left === 'number') ? opts.left : 20) + 'px';
      if (id) n.id = id;
      document.body.appendChild(n);
    }
    n.textContent = msg;
    clearTimeout(n._sekianafrazToastTimer);
    clearTimeout(n._sekianafrazToastRemoveTimer);
    n.classList.remove('is-leaving');
    if (opts.sticky) return n;
    const timeout = (typeof opts.timeout === 'number') ? opts.timeout : 4000;
    n._sekianafrazToastTimer = setTimeout(() => {
      if (!n || !n.parentNode) return;
      n.classList.add('is-leaving');
      const removeToast = () => {
        clearTimeout(n._sekianafrazToastRemoveTimer);
        if (n && n.parentNode) n.parentNode.removeChild(n);
      };
      n.addEventListener('animationend', removeToast, { once: true });
      n._sekianafrazToastRemoveTimer = setTimeout(removeToast, 450);
    }, timeout);
    return n;
  }
  let frontendFontPromise = null;
  function parseFontFamilies(fontFamily) {
    if (!fontFamily) return [];
    return fontFamily.split(',').map((f) => f.trim().replace(/^["']|["']$/g, '')).filter(Boolean);
  }
  function ensureFrontendFontFaces(doc, families) {
    if (!doc || !families.length || document.getElementById('sekianafraz-frontend-fonts')) return;
    const rules = [];
    Array.from(doc.styleSheets || []).forEach((sheet) => {
      let cssRules = null;
      try {
        cssRules = sheet.cssRules;
      } catch (e) {
        cssRules = null;
      }
      if (!cssRules) return;
      Array.from(cssRules).forEach((rule) => {
        if (rule.type !== CSSRule.FONT_FACE_RULE) return;
        const family = (rule.style.getPropertyValue('font-family') || '').replace(/^["']|["']$/g, '').trim();
        if (families.includes(family)) rules.push(rule.cssText);
      });
    });
    if (!rules.length) return;
    const style = document.createElement('style');
    style.id = 'sekianafraz-frontend-fonts';
    style.textContent = rules.join('\n');
    document.head.appendChild(style);
  }
  function resolveFrontendFont() {
    if (window.SEKIANAFRAZ_FRONTEND_FONT) return Promise.resolve(window.SEKIANAFRAZ_FRONTEND_FONT);
    if (frontendFontPromise) return frontendFontPromise;
    frontendFontPromise = new Promise((resolve) => {
      const fallback = () => resolve('inherit');
      if (!window.SEKIANAFRAZ_ADMIN || (!SEKIANAFRAZ_ADMIN.home_url && !SEKIANAFRAZ_ADMIN.base_path)) return fallback();
      const iframe = document.createElement('iframe');
      iframe.style.cssText = 'position:absolute;left:-9999px;top:-9999px;width:1px;height:1px;visibility:hidden;border:0;';
      iframe.onload = () => {
        try {
          const doc = iframe.contentDocument;
          const font = doc && doc.body ? getComputedStyle(doc.body).fontFamily : '';
          window.SEKIANAFRAZ_FRONTEND_FONT = (font && font.trim()) ? font : 'inherit';
          ensureFrontendFontFaces(doc, parseFontFamilies(window.SEKIANAFRAZ_FRONTEND_FONT));
        } catch (e) {
          window.SEKIANAFRAZ_FRONTEND_FONT = 'inherit';
        }
        iframe.remove();
        resolve(window.SEKIANAFRAZ_FRONTEND_FONT);
      };
      iframe.src = SEKIANAFRAZ_ADMIN.home_url || SEKIANAFRAZ_ADMIN.base_path;
      document.body.appendChild(iframe);
      setTimeout(() => {
        if (!window.SEKIANAFRAZ_FRONTEND_FONT) {
          window.SEKIANAFRAZ_FRONTEND_FONT = 'inherit';
          iframe.remove();
          resolve(window.SEKIANAFRAZ_FRONTEND_FONT);
        }
      }, 3000);
    });
    return frontendFontPromise;
  }
  window.SEKIANAFRAZ_ADMIN_CORE = {
    $, $all, rest, nonce, currencyLabel, escAttr, api,
    startButtonLoading, setBulkActionsVisible, withBtnLoader, renderVarsTable, renderColorFields, updateVarsTables, filterVarsByCoupon,
    getVarsForCurrent, adminNotice, toast, resolveFrontendFont
  };
})();
