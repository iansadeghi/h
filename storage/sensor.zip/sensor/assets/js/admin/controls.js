(function () {
  const { toast } = window.SEKIANAFRAZ_ADMIN_CORE;
  const formMotion = new WeakMap();
  const motionDuration = 360;
  const motionEase = 'cubic-bezier(.25,.8,.25,1)';
  const reduceMotion = () => !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const formRoot = el => el?.closest('.sensor-modal-fields');
  const modalOf = el => el?.closest('#sekianafraz-sensor-modal');
  const canMove = el => !reduceMotion() && modalOf(el)?.dataset.formReady === '1' && modalOf(el)?.dataset.layoutInstant !== '1';
  const isShown = el => !!el && !el.hidden && getComputedStyle(el).display !== 'none';
  const wanted = el => el?._sekianafrazVisible ?? isShown(el);
  const px = value => parseFloat(value) || 0;
  const isRow = el => el?.classList.contains('sekianafraz-form-row');
  const isRowOverlay = el => el?.dataset?.formOverlay === '1';
  const isCollection = el => el?.classList.contains('sekianafraz-color-fields') || el?.classList.contains('sekianafraz-radius-manual-list');
  const groupSelector = '.sekianafraz-form-row, .sekianafraz-color-fields, .sekianafraz-radius-manual-list';
  document.addEventListener('click', () => {
    document.querySelectorAll('.sekianafraz-custom-select[data-open="1"]').forEach(wrapper => wrapper.setAttribute('data-open','0'));
  });
  function disposeModalControls(modal) {
    modal?._controlDisposers?.forEach(dispose => dispose());
    if (modal) modal._controlDisposers = [];
  }
  function setAudienceToggleVisible(el, show) {
    if (!el) return;
    el.classList.toggle('is-visible', !!show);
    el.inert = !show;
    el.setAttribute('aria-hidden', String(!show));
  }
  function setHeaderControlVisible(el, show, display = 'flex') {
    if (!el || el._headerVisible === show) return;
    const initial = el._headerVisible === undefined;
    el._headerVisible = show;
    el._headerMotion?.cancel();
    el.inert = !show; el.setAttribute('aria-hidden', String(!show));
    if (initial || reduceMotion() || modalOf(el)?.dataset.formReady !== '1') {
      el.style.display = show ? display : 'none'; return;
    }
    el.style.display = display;
    const frames = [{opacity:0,transform:'translateX(-26px) scale(.97)',filter:'blur(3px)'},
      {opacity:1,transform:'translateX(0) scale(1)',filter:'blur(0)'}];
    const animation = el.animate(show ? frames : [...frames].reverse(), {duration:360,easing:'cubic-bezier(.16, 1, .3, 1)',fill:'both'});
    el._headerMotion = animation;
    animation.finished.then(() => {
      if (el._headerMotion !== animation) return;
      if (!show) el.style.display = 'none';
      animation.cancel(); el._headerMotion = null;
    }).catch(() => {});
  }
  function playMotion(el, frames, options = {}) {
    if (!el?.animate || reduceMotion()) return null;
    const animation = el.animate(frames, { duration: motionDuration, easing: motionEase, ...options });
    if (document.timeline?.currentTime != null) animation.startTime = document.timeline.currentTime;
    animation.finished.catch(() => {});
    return animation;
  }
  function directVisibility(el, show, display = '') {
    el.hidden = !show;
    el.style.display = show ? (isRow(el) ? '' : display) : 'none';
    el.inert = !show;
    el.setAttribute('aria-hidden', String(!show));
    if (el.classList.contains('sekianafraz-conditional-content')) el.classList.toggle('is-expanded', show);
  }
  function stateFor(root) {
    let state = formMotion.get(root);
    if (!state) {
      state = { pending: false, captured: false, before: new Map(), rows: new Set(), collections: new Set(), fields: new Map(), moves: new Map(), regions: new Map(), active: null };
      formMotion.set(root, state);
    }
    return state;
  }
  function measure(el) {
    const rect = el.getBoundingClientRect(), css = getComputedStyle(el);
    return { rect, parent: el.parentElement, clip: css.clipPath || 'none', mt: px(css.marginTop), mb: px(css.marginBottom), pt: px(css.paddingTop), pb: px(css.paddingBottom), gap: px(css.marginInlineEnd) };
  }
  function enqueue(root) {
    const state = stateFor(root);
    if (!state.pending) {
      state.pending = true;
      requestAnimationFrame(() => flushLayout(root));
    }
    return state;
  }
  function beginFormLayout(el) {
    const root = formRoot(el);
    if (!root || !canMove(el)) return;
    const state = enqueue(root);
    if (state.captured) return;
    state.captured = true;
    root.querySelectorAll(groupSelector).forEach(group => {
      state.before.set(group, measure(group));
      Array.from(group.children).forEach(child => state.before.set(child, measure(child)));
    });
    const active = state.active;
    if (!active) return;
    active.fields.forEach((change, node) => {
      const before = state.before.get(node) || measure(node);
      state.before.set(node, before);
      state.fields.set(node, { before, show: wanted(node), display: node._sekianafrazDisplay || '' });
    });
    active.rows.forEach(row => state.rows.add(row));
    active.collections.forEach(group => state.collections.add(group));
    active.moves.forEach((_, node) => state.moves.set(node, node.getBoundingClientRect()));
    active.regions.forEach((_, node) => state.regions.set(node, measure(node)));
  }
  function pendingAncestor(el, fields) {
    let node = el.parentElement;
    while (node) { if (fields.has(node)) return fields.get(node); node = node.parentElement; }
    return null;
  }
  function animateWithin(ancestor) {
    return !ancestor || ancestor.show && ancestor.before.rect.height > 0;
  }
  function prepareRow(row) {
    const children = Array.from(row.children).filter(child => !isRowOverlay(child)), visible = children.filter(wanted), count = visible.length;
    row.style.setProperty('--form-columns', Math.max(1, count));
    row.classList.toggle('is-empty', count === 0);
    children.forEach(child => {
      const show = wanted(child), index = visible.indexOf(child);
      child.style.flexBasis = show ? `calc(${100 / count}% - ${18 * (count - 1) / count}px)` : '0px';
      child.style.marginInlineEnd = (show && index < count - 1 ? 18 : 0) + 'px';
      child.style.minWidth = '0';
      directVisibility(child, show, child._sekianafrazDisplay || '');
    });
    return { row, children, visible, count };
  }
  function layoutRow(row) { prepareRow(row); }
  function conditionalLineOffset(el, rect) {
    const checkbox = document.getElementById(el.dataset.conditionalCheckbox || '');
    if (!checkbox || !wanted(el)) return null;
    const circle = checkbox.getBoundingClientRect();
    return (circle.bottom ?? circle.top + circle.height) + 5 - rect.top;
  }
  function flushLayout(root) {
    const state = stateFor(root);
    const fields = new Map(state.fields), rows = new Set(state.rows), collections = new Set(state.collections), moves = new Map(state.moves), regions = new Map(state.regions);
    const before = new Map(state.before);
    state.pending = false; state.captured = false;
    state.fields.clear(); state.rows.clear(); state.collections.clear(); state.moves.clear(); state.regions.clear(); state.before.clear();
    state.active?.cancel();
    if (!root.isConnected || !canMove(root)) {
      fields.forEach((change, el) => directVisibility(el, change.show, change.display));
      rows.forEach(prepareRow);
      collections.forEach(group => Array.from(group.children).forEach(child => directVisibility(child, wanted(child), child._sekianafrazDisplay || '')));
      return;
    }
    fields.forEach((change, el) => {
      const ancestor = pendingAncestor(el, fields);
      if (!ancestor || ancestor.show) directVisibility(el, change.show, change.display);
    });
    fields.forEach((change, el) => {
      if (!change.show || pendingAncestor(el, fields)) return;
      el.querySelectorAll(groupSelector).forEach(group => (isRow(group) ? rows : collections).add(group));
    });
    const rowPlans = [], collectionPlans = [], heightPlans = [], movePlans = [];
    rows.forEach(row => {
      const ancestor = pendingAncestor(row, fields);
      if (!row.isConnected || (ancestor && !ancestor.show)) return;
      rowPlans.push({ ...prepareRow(row), animate: animateWithin(ancestor) && !fields.has(row) });
    });
    collections.forEach(parent => {
      const ancestor = pendingAncestor(parent, fields);
      if (!parent.isConnected || (ancestor && !ancestor.show)) return;
      const children = Array.from(parent.children);
      children.forEach(child => directVisibility(child, wanted(child), child._sekianafrazDisplay || ''));
      collectionPlans.push({ parent, children, animate: animateWithin(ancestor) && !fields.has(parent) });
    });
    rowPlans.forEach(plan => {
      plan.end = measure(plan.row);
      plan.ends = new Map(plan.children.map(child => [child, measure(child)]));
    });
    collectionPlans.forEach(plan => {
      plan.end = measure(plan.parent);
      plan.ends = new Map(plan.children.filter(wanted).map(child => [child, child.getBoundingClientRect()]));
    });
    fields.forEach((change, el) => {
      if (!el.isConnected || !animateWithin(pendingAncestor(el, fields)) || isRow(el.parentElement) || isCollection(el.parentElement)) return;
      heightPlans.push({ el, change, end: measure(el), clip: true });
    });
    regions.forEach((start, el) => {
      if (el.isConnected) heightPlans.push({ el, change: { before: start, show: true, display: el._sekianafrazDisplay || '' }, end: measure(el), clip: false });
    });
    moves.forEach((start, el) => {
      if (el.isConnected) movePlans.push({ el, start, end: el.getBoundingClientRect() });
    });
    const linePlans = heightPlans.map(({el, end}) => ({el, offset: conditionalLineOffset(el, end.rect)}));
    linePlans.forEach(({el, offset}) => { if (offset !== null) el.style.setProperty('--conditional-line-top', offset + 'px'); });
    const saved = new Map(), animations = [];
    const preserve = (el, keys) => {
      let styles = saved.get(el);
      if (!styles) { styles = {}; saved.set(el, styles); }
      keys.forEach(key => { if (!(key in styles)) styles[key] = el.style[key] || ''; });
    };
    const add = (el, frames) => {
      const animation = playMotion(el, frames, { fill: 'both' });
      if (animation) animations.push(animation);
    };
    const batch = { fields, rows, collections, moves, regions, cancel: () => finish(true) };
    state.active = batch;
    const finish = settle => {
      if (state.active !== batch) return;
      state.active = null;
      animations.forEach(animation => animation.cancel());
      saved.forEach((styles, el) => Object.assign(el.style, styles));
      if (!settle) return;
      fields.forEach((change, el) => directVisibility(el, change.show, change.display));
      rowPlans.forEach(({row, children, visible, count}) => {
        children.forEach(child => directVisibility(child, visible.includes(child), child._sekianafrazDisplay || ''));
        row.classList.toggle('is-empty', !count);
      });
      collectionPlans.forEach(({children, ends}) => children.forEach(child => directVisibility(child, ends.has(child), child._sekianafrazDisplay || '')));
    };
    const heightFrames = (start, end, show) => [
      { height: start.rect.height + 'px', marginTop: (start.rect.height ? start.mt : 0) + 'px', marginBottom: (start.rect.height ? start.mb : 0) + 'px', paddingTop: (start.rect.height ? start.pt : 0) + 'px', paddingBottom: (start.rect.height ? start.pb : 0) + 'px' },
      { height: (show ? end.rect.height : 0) + 'px', marginTop: (show ? end.mt : 0) + 'px', marginBottom: (show ? end.mb : 0) + 'px', paddingTop: (show ? end.pt : 0) + 'px', paddingBottom: (show ? end.pb : 0) + 'px' }
    ];
    heightPlans.forEach(({el, change, end, clip}) => {
      const start = change.before;
      if (Math.abs(start.rect.height - end.rect.height) < .5 && change.show) return;
      if (!start.rect.height && !end.rect.height) return;
      preserve(el, ['overflow', 'boxSizing']);
      directVisibility(el, true, change.display);
      el.inert = !change.show;
      el.setAttribute('aria-hidden', String(!change.show));
      el.classList.toggle('is-expanded', change.show && el.classList.contains('sekianafraz-conditional-content'));
      el.style.boxSizing = 'border-box';
      if (clip) el.style.overflow = 'clip';
      add(el, heightFrames(start, end, change.show));
    });
    rowPlans.forEach(({row, children, visible, count, end, ends, animate}) => {
      if (!animate || !end.rect.width && !before.get(row)?.rect.width) return;
      children.forEach(child => {
        const previous = before.get(child), next = ends.get(child), show = visible.includes(child);
        const transferred = previous && previous.parent !== row;
        const start = transferred ? { ...previous, rect: { ...previous.rect, width: 0, height: 0 }, gap: 0 } : previous;
        if (!start || (!start.rect.width && !next.rect.width)) return;
        const basis = child.style.flexBasis, gap = child.style.marginInlineEnd;
        if (Math.abs(start.rect.width - next.rect.width) < .5 && Math.abs(start.rect.height - next.rect.height) < .5 && Math.abs(start.gap - px(gap)) < .5) return;
        preserve(child, ['overflow', 'boxSizing']);
        directVisibility(child, true, child._sekianafrazDisplay || '');
        child.inert = !show; child.setAttribute('aria-hidden', String(!show));
        child.style.overflow = transferred ? 'visible' : 'clip'; child.style.boxSizing = 'border-box';
        add(child, [
          { flexBasis: start.rect.width + 'px', marginInlineEnd: start.gap + 'px', height: start.rect.height + 'px' },
          { flexBasis: basis, marginInlineEnd: gap, height: (show ? next.rect.height : 0) + 'px' }
        ]);
      });
      const start = before.get(row);
      if (start && (Math.abs(start.rect.height - end.rect.height) >= .5 || !count)) {
        preserve(row, ['overflow', 'boxSizing']);
        row.classList.remove('is-empty'); row.style.overflow = 'clip'; row.style.boxSizing = 'border-box';
        add(row, heightFrames(start, end, !!count));
      }
    });
    collectionPlans.forEach(({parent, children, end, ends, animate}) => {
      if (!animate || !end.rect.width) return;
      const moving = children.filter(child => {
        const start = before.get(child), old = start?.rect, next = ends.get(child);
        const clipped = start && !['none', 'inset(0 0 0 0)', 'inset(0px)', 'inset(0px 0px 0px 0px)'].includes(start.clip);
        return old && ((!!old.width !== !!next?.width) || clipped || next && (Math.abs(old.left - next.left) > .5 || Math.abs(old.top - next.top) > .5 || Math.abs(old.width - next.width) > .5));
      });
      if (!moving.length) return;
      preserve(parent, ['height', 'overflow', 'boxSizing']);
      parent.style.height = end.rect.height + 'px'; parent.style.overflow = 'clip'; parent.style.boxSizing = 'border-box';
      children.forEach(child => {
        const old = before.get(child)?.rect, next = ends.get(child);
        if (!old?.width && !next?.width) return;
        const target = next || old, show = !!next;
        preserve(child, ['position', 'left', 'top', 'width', 'height', 'margin', 'flex', 'overflow']);
        directVisibility(child, true, child._sekianafrazDisplay || '');
        child.inert = !show; child.setAttribute('aria-hidden', String(!show));
        Object.assign(child.style, { position: 'absolute', left: (target.left - end.rect.left) + 'px', top: (target.top - end.rect.top) + 'px', width: target.width + 'px', height: target.height + 'px', margin: '0', flex: 'none', overflow: 'clip' });
        if (!moving.includes(child)) return;
        const dx = show && old.width ? (old.right ?? old.left + old.width) - (next.right ?? next.left + next.width) : 0;
        const dy = show && old.width ? old.top - next.top : 0;
        add(child, [
          { transform: `translate(${dx}px,${dy}px)`, clipPath: old.width ? before.get(child).clip === 'none' ? 'inset(0 0 0 0)' : before.get(child).clip : 'inset(0 0 100% 0)' },
          { transform: 'translate(0,0)', clipPath: show ? 'inset(0 0 0 0)' : 'inset(0 0 100% 0)' }
        ]);
      });
      const start = before.get(parent);
      if (start) add(parent, [{height: start.rect.height + 'px'}, {height: end.rect.height + 'px'}]);
    });
    movePlans.forEach(({el, start, end}) => {
      const dx = (start.right ?? start.left + start.width) - (end.right ?? end.left + end.width), dy = start.top - end.top;
      if (!start.width || !end.width || Math.abs(dx) < .5 && Math.abs(dy) < .5) return;
      add(el, [{transform: `translate(${dx}px,${dy}px)`}, {transform: 'translate(0,0)'}]);
    });
    if (!animations.length) { finish(true); return; }
    let remaining = animations.length;
    const done = () => { if (--remaining === 0) finish(true); };
    animations.forEach(animation => animation.finished.then(done, done));
  }
  function refreshFormRow(row) {
    if (!isRow(row)) return;
    const root = formRoot(row);
    if (root && canMove(row)) { beginFormLayout(row); enqueue(root).rows.add(row); }
    else prepareRow(row);
  }
  function setFieldVisible(el, show, display = '') {
    if (!el) return;
    show = !!show;
    if (wanted(el) === show) {
      el.inert = !show;
      el.setAttribute('aria-hidden', String(!show));
      return;
    }
    beginFormLayout(el);
    const root = formRoot(el), animated = root && canMove(el), state = animated ? enqueue(root) : null;
    const before = state?.before.get(el) || (animated ? measure(el) : null);
    el._sekianafrazVisible = show; el._sekianafrazDisplay = display;
    el.dataset.formVisible = show ? '1' : '0'; el.inert = !show; el.setAttribute('aria-hidden', String(!show));
    el.classList.toggle('is-expanded', show && el.classList.contains('sekianafraz-conditional-content'));
    if (!animated) { directVisibility(el, show, display); refreshFormRow(el.parentElement); return; }
    state.fields.set(el, { before: state.fields.get(el)?.before || before, show, display });
    if (isRow(el.parentElement)) state.rows.add(el.parentElement);
    else if (isCollection(el.parentElement)) state.collections.add(el.parentElement);
  }
  function moveFormField(el, destination, prepend = false) {
    if (!el || !destination || el.parentElement === destination) return;
    const root = formRoot(el), oldParent = el.parentElement;
    beginFormLayout(el);
    const animated = root && canMove(el), state = animated ? enqueue(root) : null;
    const moving = el.querySelector('.sekianafraz-reminder-checkbox-field') || el;
    const start = animated ? moving.getBoundingClientRect() : null;
    if (animated) {
      if (!state.before.has(el)) state.before.set(el, measure(el));
      Array.from(oldParent.children).filter(node => node !== el && node.getBoundingClientRect().width).forEach(node => state.moves.set(node, state.before.get(node)?.rect || node.getBoundingClientRect()));
      [oldParent, destination].filter(node => !isRow(node)).forEach(node => { if (!state.regions.has(node)) state.regions.set(node, measure(node)); });
    }
    if (!isRow(destination)) { el.style.flexBasis = ''; el.style.marginInlineEnd = ''; }
    prepend ? destination.prepend(el) : destination.appendChild(el);
    if (animated && start.width) state.moves.set(moving, start);
    refreshFormRow(oldParent); refreshFormRow(destination);
  }
  function makeFormRow(id, nodes, anchor) {
    nodes = nodes.filter(Boolean);
    if (!nodes.length) return null;
    let row = document.getElementById(id);
    if (!row) { row = document.createElement('div'); row.id = id; row.className = 'sekianafraz-form-row'; (anchor || nodes[0]).before(row); }
    nodes.forEach(node => { if (node.parentElement !== row) row.appendChild(node); });
    refreshFormRow(row);
    return row;
  }
  function animateFormContent(el, departing = false) {
    if (!el || !canMove(el)) return;
    if (departing) { el._contentBefore = el.getBoundingClientRect().height; return; }
    const before = el._contentBefore;
    delete el._contentBefore;
    if (before === undefined) return;
    el._contentMotion?.cancel();
    const overflow = el.style.overflow || '';
    el.style.overflow = 'clip';
    const animation = playMotion(el, [{height: before + 'px'}, {height: el.getBoundingClientRect().height + 'px'}]);
    el._contentMotion = animation;
    animation?.finished.then(() => { if (el._contentMotion === animation) el.style.overflow = overflow; }).catch(() => {});
  }
  function finishFormInitialization(modal) {
    window.SEKIANAFRAZ_ADMIN_CONTROLS.mountCustomSelects(modal);
    const root = modal.querySelector('.sensor-modal-fields');
    if (root) {
      root.querySelectorAll('.sekianafraz-form-row').forEach(row => layoutRow(row, null, false));
      const lines = Array.from(root.querySelectorAll('[data-conditional-checkbox]')).map(el => ({el, offset: conditionalLineOffset(el, el.getBoundingClientRect())}));
      lines.forEach(({el, offset}) => { if (offset !== null) el.style.setProperty('--conditional-line-top', offset + 'px'); });
      root.getBoundingClientRect();
    }
    modal.dataset.formReady = '1';
    modal.classList.remove('is-form-preparing', 'is-edit-loading');
    modal.querySelector(':scope > .sekianafraz-modal-loading-overlay')?.remove();
  }
  function normalizeDigits(s) {
    if (!s) return '';
    const map = {
      '۰':'0','۱':'1','۲':'2','۳':'3','۴':'4','۵':'5','۶':'6','۷':'7','۸':'8','۹':'9',
      '٠':'0','١':'1','٢':'2','٣':'3','٤':'4','٥':'5','٦':'6','٧':'7','٨':'8','٩':'9'
    };
    return String(s).replace(/[۰-۹٠-٩]/g, ch => map[ch] || ch);
  }
  function sanitizeAffix(v) {
    v = normalizeDigits(String(v || ''));
    v = v.replace(/[^A-Za-z0-9_]/g, '');
    if (v.length > 32) v = v.slice(0, 32);
    return v;
  }
  function mountCustomSelectOn(sel) {
    if (!sel || sel.tagName !== 'SELECT' || sel.multiple) return;
    if (sel.dataset.enhanced === '1') { sel._sekianafrazSelectSync?.(); return; }
    const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] || c));
    const renderOptLabel = (opt) => {
      if (!opt) return '';
      const text = esc(opt.textContent || '');
      return '<span class="rcs-main"><span class="rcs-text">' + text + '</span></span>';
    };
    const isRange = sel.dataset.customSelectMode === 'range';
    const wrapper = document.createElement('div'); wrapper.className = 'sekianafraz-custom-select'; wrapper.setAttribute('data-open', '0');
    const current = document.createElement('button'); current.type = 'button'; current.className = 'rcs-current';
    const menu = document.createElement('div'); menu.className = 'rcs-menu';
    let syncRange = () => {};
    let placementItemSelect = null;
    if (sel.id === 'sekianafraz-placement') {
      wrapper.classList.add('sekianafraz-placement-select');
      const groups = [
        {
          id: 'products',
          title: 'محصولات',
          description: 'تک‌محصولات ووکامرسی، دسته‌بندی‌ها و برچسب‌ها',
          lottie: 'products.json',
          values: ['product_single', 'product_single_all', 'product_cat', 'product_cat_all', 'product_in_cat', 'product_tag', 'product_tag_all', 'product_in_tag']
        },
        {
          id: 'posts',
          title: 'مطالب',
          description: 'تک‌مطلب‌ها، دسته‌بندی‌ها و برچسب‌ها',
          lottie: 'posts.json',
          values: ['post_single', 'post_single_all', 'post_cat', 'post_cat_all', 'post_in_cat', 'post_tag', 'post_tag_all', 'post_in_tag']
        },
        {
          id: 'pages',
          title: 'برگه‌ها',
          description: 'تک‎‌برگه‌ها',
          lottie: 'pages.json',
          values: ['page', 'page_all']
        }
      ];
      const layer = document.createElement('div');
      layer.className = 'sekianafraz-placement-layer';
      layer.innerHTML = '<section class="sekianafraz-placement-dialog" role="dialog" aria-modal="true" aria-label="مکان سنسور">' +
        '<header class="sekianafraz-placement-header">' +
          '<div class="sekianafraz-placement-title-wrap">' +
            '<span class="sekianafraz-placement-title sekianafraz-placement-title-main">مکان سنسور</span>' +
            '<button type="button" class="sekianafraz-placement-title sekianafraz-placement-title-back" aria-label="بازگشت">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="9 18 15 12 9 6"/></svg>' +
              '<span>بازگشت</span>' +
            '</button>' +
          '</div>' +
          '<button type="button" class="sekianafraz-placement-close" aria-label="بستن"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>' +
        '</header>' +
        '<div class="sekianafraz-placement-slider-wrap">' +
          '<div class="sekianafraz-placement-slider">' +
            '<div class="sekianafraz-placement-pane sekianafraz-placement-detail-pane">' +
              '<div class="sekianafraz-placement-detail-scroll"><div class="sekianafraz-placement-detail-content"></div></div>' +
              '<div class="sekianafraz-placement-confirm-wrap" hidden><button type="button" class="sekianafraz-placement-confirm">مکان رو انتخاب کردم</button></div>' +
            '</div>' +
            '<div class="sekianafraz-placement-pane sekianafraz-placement-items-pane"></div>' +
            '<div class="sekianafraz-placement-pane sekianafraz-placement-categories-pane"></div>' +
          '</div>' +
        '</div>' +
      '</section>';
      const slider = layer.querySelector('.sekianafraz-placement-slider');
      const categoriesPane = layer.querySelector('.sekianafraz-placement-categories-pane');
      const itemsPane = layer.querySelector('.sekianafraz-placement-items-pane');
      const detailPane = layer.querySelector('.sekianafraz-placement-detail-pane');
      const detailContent = layer.querySelector('.sekianafraz-placement-detail-content');
      const confirmWrap = layer.querySelector('.sekianafraz-placement-confirm-wrap');
      const confirmButton = layer.querySelector('.sekianafraz-placement-confirm');
      const backButton = layer.querySelector('.sekianafraz-placement-title-back');
      const closeButton = layer.querySelector('.sekianafraz-placement-close');
      const categoryMarkup = groups.map((group, index) =>
        '<button type="button" class="sekianafraz-placement-category" data-placement-category="' + group.id + '" style="--sekianafraz-placement-index:' + index + '">' +
          '<span class="sekianafraz-placement-category-main">' +
            '<span class="sekianafraz-placement-lottie" data-lottie="' + group.lottie + '" aria-hidden="true"></span>' +
            '<span class="sekianafraz-placement-category-copy">' +
              '<span class="sekianafraz-placement-category-title">' + group.title + '</span>' +
              '<span class="sekianafraz-placement-category-description">' + group.description + '</span>' +
            '</span>' +
          '</span>' +
          '<span class="sekianafraz-placement-category-arrow" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg></span>' +
        '</button>'
      ).join('');
      categoriesPane.innerHTML = '<div class="sekianafraz-placement-categories">' + categoryMarkup + '</div>';
      itemsPane.appendChild(menu);
      document.getElementById('sekianafraz-sensor-modal').querySelector('.content').appendChild(layer);
      layer.hidden = true;
      itemsPane.inert = true;
      detailPane.inert = true;
      let resizeObserver, modalObserver, openObserver, timer, rowTimer, restoreTimer, currentGroup = null, currentLevel = 'categories', detailField = null;
      const animatedRows = new Set();
      const animations = [];
      const assetsUrl = String(window.SEKIANAFRAZ_ADMIN?.assets_url || '');
      const categoryCards = Array.from(categoriesPane.querySelectorAll('.sekianafraz-placement-category'));
      const clearAnimatedRows = () => {
        clearTimeout(rowTimer);
        rowTimer = null;
        animatedRows.forEach(row => {
          const motion = row._sekianafrazPlacementMotion;
          if (motion) motion.cancel();
          delete row._sekianafrazPlacementMotion;
          row.style.removeProperty('opacity');
          row.style.removeProperty('transform');
          row.style.removeProperty('will-change');
        });
        animatedRows.clear();
      };
      const animateRows = (rows, category = false, wait = 0) => {
        clearAnimatedRows();
        if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
        const visibleRows = rows.filter(row => row?.isConnected && !row.hidden);
        visibleRows.forEach(row => {
          row.style.opacity = '0';
          row.style.transform = 'translateY(-9px)';
          row.style.willChange = 'opacity, transform';
          animatedRows.add(row);
        });
        const start = () => {
          rowTimer = null;
          visibleRows.forEach((row, index) => {
            if (!row.isConnected) return;
            const motion = row.animate([
              { opacity: 0, transform: 'translateY(-9px)' },
              { opacity: 1, transform: 'translateY(0)' }
            ], {
              duration: category ? 620 : 500,
              delay: index * (category ? 160 : 78),
              easing: 'cubic-bezier(.16,1,.3,1)',
              fill: 'both'
            });
            row._sekianafrazPlacementMotion = motion;
            motion.finished.then(() => {
              if (row._sekianafrazPlacementMotion !== motion) return;
              row.style.removeProperty('opacity');
              row.style.removeProperty('transform');
              row.style.removeProperty('will-change');
              motion.cancel();
              delete row._sekianafrazPlacementMotion;
              animatedRows.delete(row);
            }, () => {});
          });
        };
        if (wait > 0) rowTimer = setTimeout(start, wait);
        else requestAnimationFrame(start);
      };
      const animateCategories = wait => animateRows(categoryCards, true, wait);
      const applyFilter = () => {
        const allowed = currentGroup ? new Set(currentGroup.values) : null;
        const visible = [];
        menu.querySelectorAll('.rcs-item').forEach(item => {
          const option = Array.from(sel.options).find(opt => opt.value === item.getAttribute('data-value'));
          item.hidden = !!option?.hidden || !!(allowed && !allowed.has(item.getAttribute('data-value')));
          item.classList.remove('is-group-last');
          if (!item.hidden) visible.push(item);
        });
        if (visible.length) visible[visible.length - 1].classList.add('is-group-last');
      };
      const restoreDetailNodes = () => {
        clearTimeout(restoreTimer);
        const results = document.getElementById('sekianafraz-results');
        results?.remove();
        const dynamic = document.getElementById('sekianafraz-dynamic');
        if (detailField && dynamic && detailField.isConnected && detailPane.contains(detailField)) dynamic.appendChild(detailField);
        detailField = null;
        detailContent.replaceChildren();
      };
      const syncPlacementSelection = () => {
        const selectedValue = String(sel.value || '');
        const hasItem = !!document.querySelector('#sekianafraz-chips [data-id]');
        menu.querySelectorAll('.sekianafraz-placement-option').forEach(item => {
          const value = String(item.getAttribute('data-value') || '');
          const complete = value === selectedValue && (/_all$/.test(value) || hasItem);
          if (complete) item.setAttribute('data-selected', '1');
          else item.removeAttribute('data-selected');
        });
      };
      const refreshConfirm = () => {
        syncPlacementSelection();
        if (currentLevel !== 'detail') {
          confirmWrap.hidden = true;
          return;
        }
        const hasItem = !!document.querySelector('#sekianafraz-chips [data-id]');
        confirmWrap.hidden = !hasItem;
      };
      const mountDetailNodes = () => {
        const dynamic = document.getElementById('sekianafraz-dynamic');
        detailField = dynamic?.querySelector(':scope > .sekianafraz-field') || null;
        if (detailField) detailContent.appendChild(detailField);
        refreshConfirm();
        const rows = Array.from(detailContent.children).filter(node => node.nodeType === 1 && !node.hidden && getComputedStyle(node).display !== 'none');
        animateRows(rows, false, 150);
      };
      const showCategories = (animate = true) => {
        clearTimeout(restoreTimer);
        restoreDetailNodes();
        currentGroup = null;
        currentLevel = 'categories';
        layer.classList.remove('is-category', 'is-detail');
        slider.style.transform = 'translateX(-66.666666%)';
        categoriesPane.inert = false;
        itemsPane.inert = true;
        detailPane.inert = true;
        applyFilter();
        refreshConfirm();
        if (animate) animateCategories(150);
      };
      const showCategory = group => {
        currentGroup = group;
        currentLevel = 'items';
        layer.classList.add('is-category');
        layer.classList.remove('is-detail');
        applyFilter();
        const visibleItems = [];
        let index = 0;
        menu.querySelectorAll('.rcs-item').forEach(item => {
          if (item.hidden) return;
          item.style.setProperty('--sekianafraz-placement-index', String(index++));
          visibleItems.push(item);
        });
        slider.style.transform = 'translateX(-33.333333%)';
        categoriesPane.inert = true;
        itemsPane.inert = false;
        detailPane.inert = true;
        refreshConfirm();
        animateRows(visibleItems, false, 150);
      };
      const showDetail = (opt, item) => {
        clearTimeout(restoreTimer);
        restoreDetailNodes();
        const changed = String(sel.value) !== String(opt.value);
        if (changed) {
          const instant = ownerModal?.dataset.layoutInstant;
          if (ownerModal) ownerModal.dataset.layoutInstant = '1';
          sel.value = opt.value;
          sel.dispatchEvent(new Event('change', { bubbles: true }));
          if (ownerModal) {
            if (instant === undefined) delete ownerModal.dataset.layoutInstant;
            else ownerModal.dataset.layoutInstant = instant;
          }
        } else {
          sel._sekianafrazSelectSync?.();
        }
        updateLabel();
        menu.querySelectorAll('.rcs-item[data-selected]').forEach(el => el.removeAttribute('data-selected'));
        if (/_all$/.test(String(opt.value || ''))) {
          item.setAttribute('data-selected', '1');
          close();
          return;
        }
        currentLevel = 'detail';
        layer.classList.add('is-category', 'is-detail');
        slider.style.transform = 'translateX(0)';
        categoriesPane.inert = true;
        itemsPane.inert = true;
        detailPane.inert = false;
        mountDetailNodes();
      };
      placementItemSelect = showDetail;
      const mountLotties = () => {
        if (!window.lottie?.loadAnimation || animations.length) return;
        categoryCards.forEach(card => {
          const container = card.querySelector('.sekianafraz-placement-lottie');
          const file = container?.dataset.lottie;
          if (!container || !file) return;
          const animation = window.lottie.loadAnimation({
            container,
            renderer: 'svg',
            loop: false,
            autoplay: false,
            path: assetsUrl + 'lottie/' + file,
            rendererSettings: { preserveAspectRatio: 'xMidYMid meet' }
          });
          let playing = false;
          animation.addEventListener('DOMLoaded', () => animation.goToAndStop(0, true));
          animation.addEventListener('complete', () => { playing = false; });
          card.addEventListener('mouseenter', () => {
            if (layer.classList.contains('is-hover-locked') || playing) return;
            playing = true;
            animation.goToAndPlay(0, true);
          });
          animations.push(animation);
        });
      };
      categoryCards.forEach(card => {
        const group = groups.find(item => item.id === card.dataset.placementCategory);
        card.addEventListener('click', () => group && showCategory(group));
      });
      backButton.addEventListener('click', event => {
        event.stopPropagation();
        if (currentLevel === 'detail') {
          const group = currentGroup;
          showCategory(group);
          restoreTimer = setTimeout(restoreDetailNodes, 340);
        } else if (currentLevel === 'items') showCategories(true);
      });
      const dispose = () => {
        resizeObserver?.disconnect();
        modalObserver?.disconnect();
        openObserver?.disconnect();
        detailObserver?.disconnect();
        clearTimeout(timer);
        clearAnimatedRows();
        clearTimeout(restoreTimer);
        restoreDetailNodes();
        animations.forEach(animation => animation.destroy());
        document.body.classList.remove('sekianafraz-placement-modal-open');
        layer.remove();
      };
      const ownerModal = sel.closest('#sekianafraz-sensor-modal');
      (ownerModal._controlDisposers ||= []).push(dispose);
      const position = () => {
        const fields = sel.closest('.sensor-modal-fields');
        const modal = sel.closest('#sekianafraz-sensor-modal');
        if (!sel.isConnected || !modal || !fields || !layer.parentNode) { dispose(); return; }
        const rect = modal.classList.contains('has-preview') ? fields.getBoundingClientRect() : layer.parentNode.getBoundingClientRect();
        const body = layer.parentNode.getBoundingClientRect();
        const parent = layer.parentNode.getBoundingClientRect();
        Object.assign(layer.style, {left: (rect.left - parent.left) + 'px', top: (body.top - parent.top) + 'px', width: rect.width + 'px', height: body.height + 'px'});
      };
      let wasOpen = false;
      const unlockHover = event => {
        if (!layer.classList.contains('is-hover-locked')) return;
        const origin = layer._sekianafrazHoverOrigin;
        if (origin) {
          const dx = event.clientX - origin.x;
          const dy = event.clientY - origin.y;
          if ((dx * dx) + (dy * dy) < 9) return;
        }
        layer.classList.remove('is-hover-locked');
        layer._sekianafrazHoverOrigin = null;
        const hoveredCard = document.elementFromPoint(event.clientX, event.clientY)?.closest('.sekianafraz-placement-category');
        if (hoveredCard && layer.contains(hoveredCard)) hoveredCard.dispatchEvent(new Event('mouseenter'));
      };
      layer.addEventListener('pointermove', unlockHover, { passive:true });
      const close = () => { wrapper.setAttribute('data-open', '0'); };
      confirmButton.addEventListener('click', event => {
        event.stopPropagation();
        close();
      });
      const detailObserver = new MutationObserver(refreshConfirm);
      detailObserver.observe(detailPane, { childList: true, subtree: true });
      detailPane.addEventListener('input', refreshConfirm);
      openObserver = new MutationObserver(() => {
        if (!sel.isConnected) { dispose(); return; }
        const open = wrapper.getAttribute('data-open') === '1';
        if (open === wasOpen) return;
        wasOpen = open;
        clearTimeout(timer);
        clearTimeout(restoreTimer);
        if (open) {
          document.body.classList.add('sekianafraz-placement-modal-open');
          layer.classList.add('is-hover-locked');
          layer._sekianafrazHoverOrigin = wrapper._sekianafrazPlacementHoverOrigin || null;
          restoreDetailNodes();
          showCategories(false);
          position();
          mountLotties();
          animateCategories(80);
          layer.hidden = false;
          layer.getBoundingClientRect();
          layer.classList.add('is-open');
          closeButton.focus({preventScroll:true});
        } else {
          document.body.classList.remove('sekianafraz-placement-modal-open');
          layer.classList.remove('is-open', 'is-hover-locked');
          layer._sekianafrazHoverOrigin = null;
          timer = setTimeout(() => {
            restoreDetailNodes();
            layer.hidden = true;
            showCategories(false);
            if (current.isConnected) current.focus({preventScroll:true});
          }, 240);
        }
      });
      openObserver.observe(wrapper, {attributes: true, attributeFilter: ['data-open']});
      layer.addEventListener('click', event => {
        event.stopPropagation();
        if (event.target === layer || event.target.closest('.sekianafraz-placement-close')) close();
      });
      layer.addEventListener('keydown', event => {
        if (event.key === 'Escape') {
          event.stopPropagation();
          if (currentLevel === 'detail') {
            const group = currentGroup;
            showCategory(group);
            restoreTimer = setTimeout(restoreDetailNodes, 340);
          } else if (currentLevel === 'items') showCategories(true);
          else close();
          return;
        }
        if (event.key !== 'Tab') return;
        const focusables = Array.from(layer.querySelectorAll('button,input,[tabindex="0"]')).filter(item => !item.closest('[inert]') && !item.hidden && item.offsetParent !== null);
        if (!focusables.length) return;
        const index = focusables.indexOf(document.activeElement);
        event.preventDefault();
        focusables[(index + (event.shiftKey ? -1 : 1) + focusables.length) % focusables.length].focus({preventScroll:true});
      });
      resizeObserver = new ResizeObserver(position);
      resizeObserver.observe(sel.closest('.sensor-modal-fields'));
      modalObserver = new MutationObserver(position);
      modalObserver.observe(ownerModal, {attributes:true, attributeFilter:['class','data-device']});
      wrapper._placementLayer = layer;
      wrapper._placementPicker = { applyFilter, showCategories, showCategory, showDetail, refreshConfirm, syncPlacementSelection };
      mountLotties();
    }
    const updateLabel = () => {
      let opt = sel.options[sel.selectedIndex];
      if (!opt || String(opt.value) !== String(sel.value)) {
        try { opt = Array.from(sel.options).find(o => String(o.value) === String(sel.value)) || opt; } catch (e) { }
      }
      const placeholder = !String(sel.value || '') ? (sel.dataset.placeholder || (sel.id === 'sekianafraz-placement' ? 'انتخاب نشده' : '')) : '';
      const label = isRange && current.querySelector('.rcs-text');
      if (label) label.textContent = opt?.textContent || placeholder;
      else current.innerHTML = opt ? renderOptLabel(opt) : '<span class="rcs-main"><span class="rcs-text">' + esc(placeholder) + '</span></span>';
    };
    const syncSelected = () => {
      updateLabel();
      const v = sel.value;
      try {
        menu.querySelectorAll('.rcs-item').forEach(it => {
          const option = Array.from(sel.options).find(opt => opt.value === it.getAttribute('data-value'));
          it.setAttribute('aria-disabled', String(!!option?.disabled));
          it.hidden = !!option?.hidden;
          if (sel.id !== 'sekianafraz-placement') {
            if (String(it.getAttribute('data-value')) === String(v)) it.setAttribute('data-selected', '1');
            else it.removeAttribute('data-selected');
          }
        });
      } catch (e) { }
      syncRange();
      wrapper._placementPicker?.applyFilter?.();
      wrapper._placementPicker?.syncPlacementSelection?.();
    };
    syncSelected();
    sel._sekianafrazSelectSync = syncSelected;
    if (!sel.dataset.sekianafrazBoundCustomSelectSync) {
      sel.dataset.sekianafrazBoundCustomSelectSync = '1';
      sel.addEventListener('change', () => syncSelected());
    }
    if (isRange) {
      wrapper.classList.add('sekianafraz-range-select');
      const options = Array.from(sel.options).filter(opt => !opt.disabled && !opt.hidden);
      const control = document.createElement('div'); control.className = 'rcs-range-control';
      const range = document.createElement('input'); range.type = 'range'; range.className = 'rcs-range-input';
      range.min = '0'; range.max = String(Math.max(0, options.length - 1)); range.step = '1';
      range.setAttribute('aria-label', sel.getAttribute('aria-label') || 'انتخاب بازه');
      menu.id = sel.id + '-range-menu'; menu.setAttribute('role', 'group');
      menu.setAttribute('aria-label', range.getAttribute('aria-label'));
      menu.inert = true;
      current.setAttribute('aria-controls', menu.id); current.setAttribute('aria-expanded', 'false');
      current.setAttribute('aria-label', range.getAttribute('aria-label'));
      syncRange = () => {
        let index = options.findIndex(opt => opt.value === sel.value);
        if (index < 0) index = options.reduce((nearest, opt, i) =>
          Math.abs(Number(opt.value) - Number(sel.value)) < Math.abs(Number(options[nearest].value) - Number(sel.value)) ? i : nearest, 0);
        range.value = String(index);
        range.disabled = sel.disabled || !options.length;
        current.disabled = sel.disabled;
        range.style.setProperty('--range-progress', (options.length > 1 ? index / (options.length - 1) * 100 : 0) + '%');
        range.setAttribute('aria-valuetext', sel.options[sel.selectedIndex]?.textContent.trim() || '');
      };
      range.addEventListener('input', event => {
        event.stopPropagation();
        const option = options[Number(range.value)];
        if (!option || sel.value === option.value) return;
        sel.value = option.value;
        sel.dispatchEvent(new Event('change', { bubbles: true }));
        const label = current.querySelector('.rcs-text');
        label.classList.remove('is-range-value-changing');
        void label.offsetWidth;
        label.classList.add('is-range-value-changing');
      });
      menu.addEventListener('click', event => event.stopPropagation());
      const stopDragging = () => range.classList.remove('is-dragging');
      range.addEventListener('pointerdown', event => {
        range.classList.add('is-dragging');
        try { range.setPointerCapture(event.pointerId); } catch (_) {}
      });
      ['pointerup', 'pointercancel', 'blur', 'lostpointercapture'].forEach(name => range.addEventListener(name, stopDragging));
      wrapper.addEventListener('keydown', event => {
        if (event.key === 'Escape' && wrapper.getAttribute('data-open') === '1') {
          event.preventDefault(); event.stopPropagation();
          wrapper.setAttribute('data-open', '0'); current.focus({ preventScroll: true });
        } else if ((event.key === 'ArrowDown' || event.key === 'ArrowUp') && event.target === current) {
          event.preventDefault();
          if (wrapper.getAttribute('data-open') !== '1') current.click();
          range.focus({ preventScroll: true });
        }
      });
      openObserver = new MutationObserver(() => {
        if (!sel.isConnected) { dispose(); return; }
        const open = wrapper.getAttribute('data-open') === '1';
        menu.inert = !open;
        current.setAttribute('aria-expanded', String(open));
        if (!open) stopDragging();
      }).observe(wrapper, { attributes: true, attributeFilter: ['data-open'] });
      control.appendChild(range); menu.appendChild(control); syncRange();
    } else Array.from(sel.options).forEach((opt, index) => {
      const item = document.createElement('div'); item.className = 'rcs-item'; item.setAttribute('data-value', opt.value);
      item.style.setProperty('--rcs-index', String(index));
      if (sel.id === 'sekianafraz-placement') {
        item.classList.add('sekianafraz-placement-option');
        item.tabIndex = 0;
        item.setAttribute('role', 'button');
        item.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); item.click(); } });
        const directPlacement = /_all$/.test(String(opt.value || ''));
        if (directPlacement) item.classList.add('is-direct-placement');
        item.innerHTML = '<span class="sekianafraz-placement-option-main"><span class="sekianafraz-placement-option-title">' + esc(opt.textContent || '') + '</span></span><span class="sekianafraz-placement-option-arrow" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5.5 8.5 12 15 18.5"/></svg></span>';
      } else item.innerHTML = renderOptLabel(opt);
      if (opt.selected && sel.id !== 'sekianafraz-placement') item.setAttribute('data-selected', '1');
      item.addEventListener('click', () => {
        if (opt.disabled || opt.hidden) return;
        if (sel.id === 'sekianafraz-placement' && placementItemSelect) {
          placementItemSelect(opt, item);
          return;
        }
        sel.value = opt.value; sel.dispatchEvent(new Event('change', { bubbles: true }));
        updateLabel();
        menu.querySelectorAll('.rcs-item[data-selected]')?.forEach(el => el.removeAttribute('data-selected'));
        item.setAttribute('data-selected', '1');
        wrapper.setAttribute('data-open', '0');
      });
      menu.appendChild(item);
    });
    current.addEventListener('click', (e) => {
      e.stopPropagation();
      const open = wrapper.getAttribute('data-open') === '1';
      if (!open) {
        if (sel.id === 'sekianafraz-placement') wrapper._sekianafrazPlacementHoverOrigin = e.detail > 0 ? { x:e.clientX, y:e.clientY } : null;
        if (isRange) {
          syncSelected();
          document.querySelectorAll('.sekianafraz-custom-select[data-open="1"]').forEach(other => other.setAttribute('data-open', '0'));
        }
        menu.style.setProperty('--rcs-menu-height', menu.scrollHeight + 'px');
      }
      if (isRange) {
        menu.inert = open;
        current.setAttribute('aria-expanded', String(!open));
      }
      wrapper.setAttribute('data-open', open ? '0' : '1');
    });
    sel.style.display = 'none'; sel.parentNode.insertBefore(wrapper, sel.nextSibling);
    wrapper.appendChild(current); if (!wrapper._placementLayer) wrapper.appendChild(menu);
    sel.dataset.enhanced = '1';
  }
  function mountCustomSelects(ctx) {
    const root = ctx || document;
    root.querySelectorAll('select').forEach(sel => { if (sel.closest('.sekianafraz-admin')) mountCustomSelectOn(sel); });
  }
  function applyModalCheckboxSkin(modal) {
    if (!modal || !modal.querySelectorAll) return;
    modal.querySelectorAll('input[type="checkbox"]').forEach((inp) => {
      if (!inp || inp.hidden || inp.getAttribute('aria-hidden') === 'true') return;
      if (inp.closest('.sekianafraz-toggle')) return;
      if (inp.name === 'sekianafraz-limit-type') {
        inp.classList.add('ui-checkbox');
        inp.setAttribute('role', 'radio');
        inp.setAttribute('aria-checked', String(inp.checked));
        if (!inp.dataset.sekianafrazExclusive) {
          inp.dataset.sekianafrazExclusive = '1';
          inp.addEventListener('click', () => {
            modal.querySelectorAll('input[name="sekianafraz-limit-type"]').forEach(peer => {
              peer.checked = peer === inp;
              peer.setAttribute('aria-checked', String(peer.checked));
            });
          }, true);
          inp.addEventListener('keydown', event => {
            if (!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)) return;
            event.preventDefault();
            const peers = Array.from(modal.querySelectorAll('input[name="sekianafraz-limit-type"]'));
            const next = peers[(peers.indexOf(inp) + 1) % peers.length];
            next.focus({preventScroll:true}); next.click();
          });
        }
        return;
      }
      if (modal.id !== 'sekianafraz-sensor-modal') { inp.classList.add('ui-checkbox'); return; }
      if (inp.closest('.kianex-checkbox')) return;
      inp.classList.remove('ui-checkbox');
      inp.classList.add('kianex-checkbox__input');
      const control = document.createElement('span');
      control.className = 'kianex-checkbox';
      inp.before(control);
      control.appendChild(inp);
      control.insertAdjacentHTML('beforeend', '<span class="kianex-checkbox__visual" aria-hidden="true"><svg class="kianex-checkbox__tick" viewBox="0 0 20 20" focusable="false"><path class="kianex-checkbox__tick-path" pathLength="16" transform="translate(2.8 2.8) scale(.72)" d="M4.8 10.4 8.2 13.5 15.2 6.5" /></svg></span>');
      inp.addEventListener('change', () => {
        control.classList.remove('is-checking', 'is-unchecking');
        void control.offsetWidth;
        control.classList.add(inp.checked ? 'is-checking' : 'is-unchecking');
      });
      control.addEventListener('animationend', (event) => {
        if (event.animationName.includes('jelly')) control.classList.remove('is-checking', 'is-unchecking');
      });
    });
  }
function applyNumberGuards() {
    const enforceMin = (inp) => {
      if (!inp || inp.dataset.positiveGuard === '1') return;
      inp.dataset.positiveGuard = '1';
      const minAttr = inp.getAttribute('min');
      const minVal = (minAttr !== null && String(minAttr).trim() !== '') ? parseFloat(minAttr) : 1;
      const clampMin = (!isNaN(minVal) ? minVal : 1);
      if (!(minAttr !== null && String(minAttr).trim() === '0')) {
        if (minAttr === null || String(minAttr).trim() === '') inp.setAttribute('min', '1');
      }
      const normalize = () => {
        const v = inp.value;
        if (v === '' || v === null) return;
        const n = parseFloat(v);
        if (isNaN(n)) return;
        if (n < clampMin) inp.value = String(clampMin);
      };
      inp.addEventListener('input', normalize);
      inp.addEventListener('blur', () => {
        const v = inp.value;
        if (v === '' || v === null) return;
        const n = parseFloat(v);
        if (isNaN(n) || n < clampMin) inp.value = String(clampMin);
      });
    };
    document.querySelectorAll('.sekianafraz-admin input[type="number"]').forEach(enforceMin);
  }
  function enhanceTooltips(ctx) {
    const root = ctx || document;
    root.querySelectorAll('.sekianafraz-tooltip:not([data-pop="1"])').forEach((tip) => {
      tip.setAttribute('data-pop', '1');
      const text = tip.getAttribute('data-tip') || '';
      let pop = null;
      const show = () => {
        if (!text) return;
        pop = document.createElement('div');
        pop.className = 'sekianafraz-tooltip-pop';
        pop.textContent = text;
        Object.assign(pop.style, {
          position: 'fixed',
          background: '#111', color: '#fff', padding: '8px 10px', borderRadius: '8px',
          lineHeight: '1.6', fontSize: '12px', zIndex: '1000000', maxWidth: '380px',
          boxShadow: '0 8px 24px rgba(0,0,0,.18)'
        });
        document.body.appendChild(pop);
        const r = tip.getBoundingClientRect();
        const top = Math.max(8, r.top - (pop.offsetHeight + 10));
        const right = Math.max(8, window.innerWidth - r.right);
        pop.style.top = top + 'px';
        pop.style.right = right + 'px';
      };
      const hide = () => { if (pop && pop.parentNode) { pop.parentNode.removeChild(pop); pop = null; } };
      tip.addEventListener('mouseenter', show);
      tip.addEventListener('focus', show);
      tip.addEventListener('mouseleave', hide);
      tip.addEventListener('blur', hide);
    });
  }
  function mountInputDirections(ctx) {
    const root = ctx && ctx.querySelectorAll ? ctx : document;
    root.querySelectorAll('input, textarea').forEach((field) => {
      if (field.dataset.sekianafrazDirectionReady === '1') return;
      const type = String(field.getAttribute('type') || 'text').toLowerCase();
      if (['hidden', 'checkbox', 'radio', 'color', 'range', 'file', 'button', 'submit', 'reset'].includes(type)) return;
      field.dataset.sekianafrazDirectionReady = '1';
      field.dir = ['number', 'email', 'url', 'tel'].includes(type) || field.inputMode === 'latin' ? 'ltr' : 'auto';
    });
  }
  function watchInputDirections() {
    mountInputDirections(document);
    if (document.documentElement.dataset.sekianafrazDirectionObserver === '1') return;
    document.documentElement.dataset.sekianafrazDirectionObserver = '1';
    const observer = new MutationObserver((records) => {
      records.forEach((record) => record.addedNodes.forEach((node) => {
        if (!node || node.nodeType !== 1) return;
        if (node.matches && node.matches('input, textarea')) mountInputDirections(node.parentNode || document);
        else mountInputDirections(node);
      }));
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  function copyText(value) {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
      return navigator.clipboard.writeText(value);
    }
    return new Promise((resolve, reject) => {
      const textarea = document.createElement('textarea');
      textarea.value = value;
      textarea.setAttribute('readonly', '');
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        resolve();
      } catch (error) {
        reject(error);
      } finally {
        textarea.remove();
      }
    });
  }
  function bindVariableCopy() {
    if (document.documentElement.dataset.sekianafrazVariableCopyBound === '1') return;
    document.documentElement.dataset.sekianafrazVariableCopyBound = '1';
    document.addEventListener('click', (event) => {
      const button = event.target.closest('.sekianafraz-copy-variable');
      if (!button) return;
      event.preventDefault();
      const value = button.dataset.copyVariable || '';
      copyText(value).then(() => {
        button.classList.remove('is-copied');
        void button.offsetWidth;
        button.classList.add('is-copied');
        clearTimeout(button._sekianafrazCopyTimer);
        button._sekianafrazCopyTimer = setTimeout(() => button.classList.remove('is-copied'), 1500);
      }).catch(() => toast('کپی متغیر انجام نشد'));
    });
  }
  function mountColorFields(ctx) {
    const root = ctx && ctx.querySelectorAll ? ctx : document;
    root.querySelectorAll('.sekianafraz-color-field input[type="color"]').forEach((input) => {
      const field = input.closest('.sekianafraz-color-field');
      if (!field) return;
      const sync = () => field.style.setProperty('--sekianafraz-color-value', input.value || '#000000');
      sync();
      if (input.dataset.sekianafrazColorBound === '1') return;
      input.dataset.sekianafrazColorBound = '1';
      input.addEventListener('input', sync);
      input.addEventListener('change', sync);
    });
  }
  window.SEKIANAFRAZ_ADMIN_CONTROLS = {
    disposeModalControls, setHeaderControlVisible, setFieldVisible, beginFormLayout, refreshFormRow, makeFormRow, playMotion, animateFormContent, setAudienceToggleVisible, moveFormField, finishFormInitialization,
    normalizeDigits, sanitizeAffix, mountCustomSelectOn, mountCustomSelects,
    applyModalCheckboxSkin, applyNumberGuards, enhanceTooltips,
    mountInputDirections, watchInputDirections, bindVariableCopy, mountColorFields, copyText
  };
})();
