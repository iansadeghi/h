(function () {
  const { $, escAttr } = window.SEKIANAFRAZ_ADMIN_CORE;
  const { setFieldVisible, beginFormLayout, playMotion, moveFormField } = window.SEKIANAFRAZ_ADMIN_CONTROLS;
  const reduced = () => !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
  const titles = ['مرحله اول', 'مرحله دوم', 'مرحله سوم'];
  function start(key, title) {
    const id = 'sekianafraz-section-' + key;
    return '<section class="sekianafraz-sensor-section" id="' + id + '" data-collapsed="1">' +
      '<h3 class="sekianafraz-section-heading"><button type="button" class="sekianafraz-section-toggle" id="' + id + '-toggle" aria-expanded="false" aria-controls="' + id + '-body">' +
      '<svg class="sekianafraz-section-lines" aria-hidden="true" focusable="false"><path class="sekianafraz-section-outline"></path><path class="sekianafraz-section-chevron"></path></svg>' +
      '<span class="sekianafraz-section-title">' + escAttr(title) + '</span></button></h3>' +
      '<div class="sekianafraz-section-body" id="' + id + '-body" role="region" aria-labelledby="' + id + '-toggle" aria-hidden="true" inert><div class="sekianafraz-section-content">';
  }
  const end = () => '</div></div></section>';
  function create(key, title) {
    const template = document.createElement('template');
    template.innerHTML = start(key, title) + end();
    return template.content.firstElementChild;
  }
  function draw(section) {
    const state = section._sectionMotion;
    if (!state?.width) return;
    const { width: w, height: h, titleWidth: tw, titleHeight: th, progress: p } = state;
    const mix = (a, b) => a + (b - a) * p;
    const mid = h / 2, left = Math.max(1, (w - tw) / 2 - 14), right = Math.min(w - 1, (w + tw) / 2 + 14);
    const open = [[right, mid], [right, mid], [w - 1, mid], [w - 1, mid], [w - 1, mid], [w - 1, mid]];
    const closed = [[1, mid], [1, 1], [w - 1, 1], [w - 1, h - 1], [1, h - 1], [1, mid]];
    const path = (a, b) => a.map((point, i) => (i ? 'L' : 'M') + mix(point[0], b[i][0]).toFixed(2) + ',' + mix(point[1], b[i][1]).toFixed(2)).join(' ');
    state.outline.setAttribute('d', path(open, closed));
    state.chevron.setAttribute('d', path([[1, mid], [left / 2, mid], [left, mid]], [[26, mid - 3], [32, mid + 3], [38, mid - 3]]));
    state.chevron.style.strokeWidth = String(mix(1, 2.2));
    const shade = Math.round(mix(224, 145));
    state.chevron.style.stroke = 'rgb(' + shade + ',' + shade + ',' + shade + ')';
    state.title.style.transform = 'translate(' + mix((w - tw) / 2, w - 20 - tw * .84) + 'px,' + mix((h - th) / 2, (h - th * .84) / 2) + 'px) scale(' + mix(1, .84) + ')';
  }
  function measure(section) {
    const state = section._sectionMotion;
    if (!state) return;
    const width = state.button.clientWidth;
    if (!width) return;
    const titleWidth = state.title.offsetWidth, titleHeight = state.title.offsetHeight;
    const height = Math.max(64, titleHeight + 28);
    state.width = width;
    state.height = height;
    state.titleWidth = titleWidth;
    state.titleHeight = titleHeight;
    state.button.style.height = height + 'px';
    state.svg.setAttribute('viewBox', '0 0 ' + width + ' ' + height);
    draw(section);
  }
  function setExpanded(section, expanded, animate = true) {
    if (!section?._sectionMotion) return;
    const state = section._sectionMotion, target = expanded ? 0 : 1;
    cancelAnimationFrame(state.frame);
    if (!expanded && state.body.contains(document.activeElement)) state.button.focus({ preventScroll: true });
    section.dataset.collapsed = expanded ? '0' : '1';
    state.button.setAttribute('aria-expanded', String(expanded));
    state.body.inert = !expanded;
    state.body.setAttribute('aria-hidden', String(!expanded));
    measure(section);
    if (!animate || reduced()) {
      state.progress = target;
      section.classList.remove('is-section-moving');
      draw(section);
      return;
    }
    section.classList.add('is-section-moving');
    const from = state.progress, began = performance.now(), duration = 620;
    const tick = now => {
      if (!section.isConnected) return;
      const time = Math.min(1, (now - began) / duration);
      const eased = time < .5 ? 4 * time * time * time : 1 - Math.pow(-2 * time + 2, 3) / 2;
      state.progress = from + (target - from) * eased;
      draw(section);
      if (time < 1) state.frame = requestAnimationFrame(tick);
      else section.classList.remove('is-section-moving');
    };
    state.frame = requestAnimationFrame(tick);
  }
  function mount(root) {
    const modal = root.closest('#sekianafraz-sensor-modal') || root;
    root.querySelectorAll('.sekianafraz-sensor-section').forEach(section => {
      if (section._sectionMotion) return;
      const button = section.querySelector('.sekianafraz-section-toggle');
      const collapsed = section.dataset.collapsed !== '0';
      section._sectionMotion = {
        button, title: button.querySelector('.sekianafraz-section-title'), svg: button.querySelector('svg'),
        outline: button.querySelector('.sekianafraz-section-outline'), chevron: button.querySelector('.sekianafraz-section-chevron'),
        body: section.querySelector('.sekianafraz-section-body'), progress: collapsed ? 1 : 0, frame: 0
      };
      button.setAttribute('aria-expanded', String(!collapsed));
      section._sectionMotion.body.inert = collapsed;
      section._sectionMotion.body.setAttribute('aria-hidden', String(collapsed));
      button.addEventListener('click', () => setExpanded(section, section.dataset.collapsed === '1'));
      const observer = typeof ResizeObserver === 'function' ? new ResizeObserver(() => measure(section)) : null;
      observer?.observe(button);
      observer?.observe(section._sectionMotion.title);
      modal._controlDisposers ||= [];
      const dispose = () => { observer?.disconnect(); cancelAnimationFrame(section._sectionMotion.frame); };
      section._sectionMotion.dispose = dispose;
      modal._controlDisposers.push(dispose);
      measure(section);
    });
  }
  function setTitle(key, title) {
    const section = $('#sekianafraz-section-' + key), node = section?.querySelector('.sekianafraz-section-title');
    if (node && node.textContent !== title) { node.textContent = title; measure(section); }
  }
  function parkControls() {
    const home = $('#sekianafraz-banner-controls-home');
    if (!home) return;
    const wrap = $('#sekianafraz-action-fields'), modal = $('#sekianafraz-sensor-modal');
    wrap?.querySelectorAll('.sekianafraz-sensor-section').forEach(section => {
      const dispose = section._sectionMotion?.dispose;
      dispose?.();
      if (dispose && modal) modal._controlDisposers = (modal._controlDisposers || []).filter(item => item !== dispose);
    });
    wrap?.querySelector('.sekianafraz-radius-field')?._disposeStyle?.();
    const reminder = $('#sekianafraz-reminder-wrap');
    if (reminder) $('#sekianafraz-reminder-home')?.prepend(reminder);
    ['sekianafraz-banner-options-row', 'sekianafraz-close-position-slot', 'sekianafraz-reminder-home'].forEach(id => {
      const node = $('#' + id);
      if (node) home.appendChild(node);
    });
    $('#sekianafraz-reaction-options')?.replaceChildren();
    $('#sekianafraz-logged-behavior-slot')?.replaceChildren();
  }
  function mountAction(wrap, action) {
    if (wrap.querySelector('.sekianafraz-sensor-section')) return;
    if (action === 'sms') {
      const section = create('sms', 'تنظیمات ارسال پیامک');
      section.querySelector('.sekianafraz-section-content').append(...Array.from(wrap.childNodes));
      wrap.appendChild(section);
      mount($('#sekianafraz-sensor-modal'));
      return;
    }
    const sms = wrap.querySelector('#sekianafraz-sms-wrap'), loggedSms = wrap.querySelector('#sekianafraz-logged-sms-wrap');
    const font = wrap.querySelector('#sekianafraz-banner-font-row');
    const section = create('banner', 'تنظیمات نمایش بنر');
    const content = section.querySelector('.sekianafraz-section-content');
    const tabs = document.createElement('div');
    tabs.id = 'sekianafraz-stage-tabs';
    tabs.className = 'sekianafraz-stage-tabs';
    tabs.setAttribute('role', 'tablist');
    tabs.setAttribute('aria-label', 'مراحل بنر');
    tabs.innerHTML = '<span class="sekianafraz-stage-indicator" aria-hidden="true"></span>' + titles.map((title, index) =>
      '<button type="button" role="tab" id="sekianafraz-stage-tab-' + (index + 1) + '" aria-controls="sekianafraz-stage-panel" data-stage="' + (index + 1) + '">' + title + '</button>').join('');
    const panel = document.createElement('div');
    panel.id = 'sekianafraz-stage-panel';
    panel.setAttribute('role', 'tabpanel');
    panel.tabIndex = 0;
    const selectors = ['#sekianafraz-banner-title-row', '.sekianafraz-banner-text-field', '#sekianafraz-banner-options-row',
      '#sekianafraz-banner-target-wrap', '#sekianafraz-close-position-slot', '#sekianafraz-reminder-home',
      '.sekianafraz-banner-image-field', '#sekianafraz-multi-fields', '.sekianafraz-banner-colors',
      '.sekianafraz-radius-field', '.sekianafraz-padding-field', '.sekianafraz-margin-field'];
    selectors.forEach(selector => { const node = wrap.querySelector(selector) || (selector.startsWith('#') ? $(selector) : null); if (node) panel.appendChild(node); });
    Array.from(wrap.children).filter(node => ![sms, loggedSms, font].includes(node)).forEach(node => panel.appendChild(node));
    content.append(tabs, panel);
    if (font) content.appendChild(font);
    wrap.appendChild(section);
    [[sms, 'sms'], [loggedSms, 'logged-sms']].forEach(([node, key]) => {
      if (!node) return;
      const smsSection = create(key, 'تنظیمات ارسال پیامک');
      smsSection.querySelector('.sekianafraz-section-content').appendChild(node);
      wrap.appendChild(smsSection);
    });
    wrap.dataset.bannerStage = '1';
    tabs.addEventListener('click', event => {
      const button = event.target.closest('button[data-stage]');
      if (button) setStage(Number(button.dataset.stage));
    });
    tabs.addEventListener('keydown', event => {
      const buttons = Array.from(tabs.querySelectorAll('button'));
      const index = buttons.indexOf(event.target);
      if (index < 0 || !['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? 2 : (index + (event.key === 'ArrowLeft' ? 1 : 2)) % 3;
      buttons[next].focus();
      setStage(next + 1);
    });
    mount($('#sekianafraz-sensor-modal'));
    refresh(wrap);
  }
  function setStage(stage) {
    const wrap = $('#sekianafraz-action-fields');
    if (!wrap || ![1, 2, 3].includes(stage) || wrap.dataset.bannerStage === String(stage)) return;
    beginFormLayout(wrap);
    wrap.dataset.bannerStage = String(stage);
    window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS.refreshBannerConditionalControls(wrap);
    const panel = $('#sekianafraz-stage-panel');
    panel?._stageEntry?.cancel();
    if (panel) panel._stageEntry = playMotion(panel, [{ opacity: .45, transform: 'translateY(8px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 320 });
    window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW.updatePreview();
  }
  function refresh(wrap) {
    const multi = $('#sekianafraz-banner-type')?.value === 'multi';
    const audience = wrap.dataset.previewAudience === 'logged';
    const behavior = $('#sekianafraz-logged-behavior')?.value;
    const steps = multi && !audience;
    const banner = ['banner', 'both'].includes(wrap.dataset.action) && !(multi && audience && behavior === 'sms');
    const stage = Number(wrap.dataset.bannerStage || 1);
    setFieldVisible($('#sekianafraz-section-banner'), banner);
    setFieldVisible($('#sekianafraz-section-sms'), wrap.dataset.action === 'sms' || (multi ? !audience : wrap.dataset.action === 'both'));
    setFieldVisible($('#sekianafraz-section-logged-sms'), multi && audience && ['sms', 'single_sms'].includes(behavior));
    setTitle('banner', steps ? 'تنظیمات نمایش بنر' : 'تنظیمات نمایش بنر');
    setTitle('sms', steps ? 'تنظیمات ارسال پیامک' : 'تنظیمات ارسال پیامک');
    const tabs = $('#sekianafraz-stage-tabs');
    setFieldVisible(tabs, steps);
    if (tabs) {
      tabs.style.setProperty('--stage-index', stage - 1);
      tabs.querySelectorAll('button').forEach(button => {
        const active = Number(button.dataset.stage) === stage;
        button.setAttribute('aria-selected', String(active));
        button.tabIndex = active ? 0 : -1;
      });
    }
    const panel = $('#sekianafraz-stage-panel');
    panel?.setAttribute('aria-labelledby', steps ? 'sekianafraz-stage-tab-' + stage : 'sekianafraz-section-banner-toggle');
    const colorTitle = wrap.querySelector('.sekianafraz-banner-colors > label');
    if (colorTitle) colorTitle.textContent = steps ? 'رنگ‌های ' + titles[stage - 1] : 'رنگ‌های بنر';
    const font = wrap.querySelector('#sekianafraz-banner-font-row');
    const content = $('#sekianafraz-section-banner .sekianafraz-section-content');
    if (font && panel && content) {
      if (steps && font.parentElement !== content) moveFormField(font, content);
      if (!steps && font.parentElement !== panel) {
        moveFormField(font, panel);
        panel.insertBefore(font, panel.querySelector('.sekianafraz-radius-field'));
      }
    }
  }
  function revealField(field) {
    const wrap = $('#sekianafraz-action-fields');
    if (field?.closest('#sekianafraz-stage-panel') && $('#sekianafraz-banner-type')?.value === 'multi' && wrap?.dataset.previewAudience !== 'logged') {
      const id = field.id;
      setStage(/multi-(success|correction)/.test(id) ? 3 : /multi-/.test(id) ? 2 : 1);
    }
    const section = field?.closest('.sekianafraz-sensor-section');
    if (section) setExpanded(section, true);
  }
  window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS = { start, end, mount, mountAction, parkControls, refresh, setStage, revealField };
})();
