(function () {
  const {
    $, filterVarsByCoupon, renderVarsTable, renderColorFields, updateVarsTables
  } = window.SEKIANAFRAZ_ADMIN_CORE;
  const { mountCustomSelects, applyModalCheckboxSkin, mountColorFields, setFieldVisible, makeFormRow, beginFormLayout, refreshFormRow, animateFormContent, applyNumberGuards, playMotion, setAudienceToggleVisible } = window.SEKIANAFRAZ_ADMIN_CONTROLS;
  const field = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS.field(...args);
  const list = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS.list(...args);
  const updatePreview = (...args) => window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW.updatePreview(...args);
  const sections = () => window.SEKIANAFRAZ_ADMIN_SENSOR_SECTIONS;
  const guide = () => window.SEKIANAFRAZ_ADMIN_SMS_GUIDE;
  function withoutGuestDisplayName(prefix, vars) {
    return guide().isGuestMultiSms(prefix) ? vars.filter(item => item.key !== 'display_name') : vars;
  }
  function syncGuestSmsVars(wrap) {
    const target = wrap.querySelector('#sekianafraz-vars-sms');
    if (!target || !target.firstElementChild) return;
    const shown = Array.from(target.querySelectorAll('code')).some(code => code.textContent === '{{display_name}}');
    if (shown !== guide().isGuestMultiSms('sms')) return;
    const placement = basePlacementOf($('#sekianafraz-placement')?.value || 'product_single');
    const catalog = window.SEKIANAFRAZ_ADMIN_VARS?.[placement] || window.SEKIANAFRAZ_ADMIN_VARS?.product_single;
    if (!catalog) return;
    const mode = $('#sekianafraz-sms-mode')?.value === 'pattern' ? 'pattern' : 'promo';
    target.innerHTML = renderVarsTable(withoutGuestDisplayName('sms', filterVarsByCoupon(catalog[mode] || [])), false);
    updateVarsTables($('#sekianafraz-sensor-modal'));
  }
  function renderSmsTarget(prefix) {
    return '<div class="sekianafraz-field" id="sekianafraz-' + prefix + '-target-url-wrap" style="display:none"><label for="sekianafraz-' + prefix + '-target-url">لینک مقصد</label><input type="text" dir="ltr" id="sekianafraz-' + prefix + '-target-url" placeholder="site.com/example"></div>';
  }
  function updateSmsTargets() {
    const aggregate = $('#sekianafraz-visit-calculation')?.value === 'aggregate';
    ['sms', 'logged-sms'].forEach(prefix => {
      const input = $('#sekianafraz-' + prefix + '-text') || $('#sekianafraz-' + prefix + '-pattern');
      const field = $('#sekianafraz-' + prefix + '-target-url');
      if (!field) return;
      const visible = !!input && input.value.includes('{{target_url}}');
      field.required = visible && aggregate;
      setFieldVisible(field.closest('.sekianafraz-field'), visible);
    });
  }
  function updateBannerTarget(wrap) {
    const name = wrap.querySelector('#sekianafraz-banner-button-text')?.value.trim() || 'بزن بریم!';
    const closes = wrap.querySelector('#sekianafraz-banner-button-closes');
    const label = wrap.querySelector('#sekianafraz-banner-button-closes-label');
    const linkLabel = wrap.querySelector('#sekianafraz-banner-target-label');
    if (label) label.textContent = 'دکمه «' + name + '» باعث بسته‌شدن بنر شود';
    if (linkLabel) linkLabel.textContent = 'لینک دکمه «' + name + '»';
    const multi = $('#sekianafraz-banner-type')?.value === 'multi';
    const logged = $('#sekianafraz-logged-behavior')?.value || 'single_sms';
    const single = !multi || (wrap.dataset.previewAudience === 'logged' && ['single', 'single_sms'].includes(logged));
    const field = wrap.querySelector('#sekianafraz-banner-target-url');
    if (field) field.required = single && !closes?.checked;
    setFieldVisible(wrap.querySelector('#sekianafraz-banner-target-wrap'), single);
    setFieldVisible(wrap.querySelector('#sekianafraz-banner-target-field'), single && !closes?.checked);
  }
  const smsDelayPresets = [
    [1, '1 دقیقه'], [5, '5 دقیقه'], [10, '10 دقیقه'], [15, '15 دقیقه'],
    [30, '30 دقیقه'], [45, '45 دقیقه'], [60, '1 ساعت'], [120, '2 ساعت'],
    [180, '3 ساعت'], [240, '4 ساعت'], [720, '12 ساعت'], [960, '16 ساعت'], [1440, '24 ساعت']
  ];
  function renderSmsDelayMinutes(id) {
    return '<div id="' + id + '-wrap" style="display:none"><div class="sekianafraz-field">' +
      '<label for="' + id + '">مدت زمان تاخیر ارسال پیامک</label>' +
      '<select id="' + id + '" data-custom-select-mode="range" aria-label="مدت زمان تاخیر ارسال پیامک">' +
      smsDelayPresets.map(([value, label]) => '<option value="' + value + '"' + (value === 60 ? ' selected' : '') + '>' + label + '</option>').join('') +
      '</select></div></div>';
  }
  function setSmsDelayMinutes(select, value) {
    if (!select) return;
    const parsed = parseInt(value, 10);
    const minutes = String(Number.isFinite(parsed) && parsed > 0 ? Math.min(1440, parsed) : 60);
    select.querySelectorAll('[data-legacy-delay]').forEach(option => option.remove());
    if (!Array.from(select.options).some(option => option.value === minutes)) {
      const option = new Option(minutes + ' دقیقه', minutes);
      option.hidden = true; option.dataset.legacyDelay = '1'; select.appendChild(option);
    }
    select.value = minutes;
    select._sekianafrazSelectSync?.();
  }
  function basePlacementOf(placement) {
    return String(placement || '').replace(/_all$/, '');
  }
  const radiusTargets = [
    ['card', 'کارت بنر'],
    ['image', 'تصویر'],
    ['discount', 'باکس تخفیف'],
    ['copy', 'دکمه کپی'],
    ['primary', 'دکمه اصلی'], ['close', 'دکمه بستن'], ['back', 'دکمه بازگشت'], ['phone', 'فیلد شماره تلفن'],
    ['send', 'دکمه ارسال'], ['success', 'پیام موفقیت'], ['correction', 'دکمه اصلاح شماره']
  ];
  const paddingTargets = [
    ['card', 'کارت بنر'],
    ['primary', 'دکمه اصلی'],
    ['discount', 'باکس تخفیف'],
    ['copy', 'دکمه کپی کوپن'],
    ['title', 'متن عنوان'],
    ['description', 'متن توضیحات'], ['close', 'دکمه‌های بستن و بازگشت'], ['phone', 'فیلد شماره تلفن'],
    ['send', 'دکمه ارسال'], ['success', 'پیام موفقیت'], ['correction', 'دکمه اصلاح شماره'],
    ['prompt', 'متن درخواست شماره']
  ];
  const marginTargets = [['card', 'باکس بنر'], ['close', 'دکمه‌های بستن و بازگشت']];
  const marginDefaults = {card:{t:0,r:0,b:0,l:0},close:{t:24,r:0,b:0,l:24}};
  const paddingDefaults = {
    card: { t: 24, r: 24, b: 24, l: 24 },
    primary: { t: 13, r: 13, b: 13, l: 13 },
    discount: { t: 10, r: 10, b: 10, l: 10 },
    copy: { t: 8, r: 12, b: 8, l: 12 },
    title: { t: 0, r: 0, b: 0, l: 0 },
    description: { t: 0, r: 0, b: 0, l: 0 },
    close: { t: 10, r: 10, b: 10, l: 10 }, phone: { t: 12, r: 12, b: 12, l: 12 },
    send: { t: 12, r: 12, b: 12, l: 12 }, success: { t: 8, r: 8, b: 8, l: 8 },
    correction: { t: 8, r: 8, b: 8, l: 8 }, prompt: { t: 0, r: 0, b: 0, l: 0 },
    sending: { t: 8, r: 8, b: 8, l: 8 }, error: { t: 8, r: 8, b: 8, l: 8 }
  };
  paddingDefaults.reminder_coupon = {t:2,r:6,b:2,l:6};
  paddingDefaults.reminder_timer = {t:0,r:0,b:0,l:0};
  paddingDefaults.reminder_bar = {t:15,r:15,b:15,l:15};
  marginDefaults.reminder_text = {t:0,r:0,b:0,l:0};
  marginDefaults.reminder_timer = {t:0,r:15,b:0,l:0};
  const linkedControlIcon = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10.6 13.4a4 4 0 0 0 5.7 0l2.1-2.1a4 4 0 0 0-5.7-5.7l-1.2 1.2"></path><path d="M13.4 10.6a4 4 0 0 0-5.7 0l-2.1 2.1a4 4 0 0 0 5.7 5.7l1.2-1.2"></path></svg>';
  function clampRadius(value) {
    const number = parseInt(value, 10);
    return Math.max(0, Number.isFinite(number) ? number : 0);
  }
  function clampPadding(value) {
    return Math.min(200, clampRadius(value));
  }
  function renderRadiusItem(target, label) {
    const corners = [
      ['tr', 'بالا راست'], ['tl', 'بالا چپ'],
      ['br', 'پایین راست'], ['bl', 'پایین چپ']
    ];
    return '<div class="sekianafraz-radius-item" data-radius-target="' + target + '" data-linked="1">' +
      '<span class="sekianafraz-radius-item-label">' + label + '</span>' +
      '<div class="sekianafraz-radius-capsule">' +
      '<div class="sekianafraz-radius-direct-inputs">' +
      corners.map((corner) => '<label class="sekianafraz-radius-direct-input"><input type="number" min="0" value="' + (['close', 'back'].includes(target) ? 50 : target === 'reminder_coupon' ? 4 : target === 'reminder_timer' ? 6 : 0) + '" data-radius-corner="' + corner[0] + '" title="' + corner[1] + '" aria-label="' + corner[1] + ' ' + label + '"><span aria-hidden="true">px</span></label>').join('') +
      '</div>' +
      '<button type="button" class="sekianafraz-radius-link is-linked" aria-label="اتصال مقادیر گردی ' + label + '" aria-pressed="true">' + linkedControlIcon + '</button>' +
      '</div></div>';
  }
  function renderPaddingItem(target, label) {
    const sides = [
      ['t', 'بالا'], ['r', 'راست'],
      ['b', 'پایین'], ['l', 'چپ']
    ];
    const values = paddingDefaults[target];
    const linked = true;
    return '<div class="sekianafraz-radius-item" data-padding-target="' + target + '" data-linked="' + (linked ? '1' : '0') + '">' +
      '<span class="sekianafraz-radius-item-label">' + label + '</span>' +
      '<div class="sekianafraz-radius-capsule">' +
      '<div class="sekianafraz-radius-direct-inputs">' +
      sides.map((side) => '<label class="sekianafraz-radius-direct-input"><input type="number" min="0" max="200" value="' + values[side[0]] + '" data-padding-side="' + side[0] + '" title="' + side[1] + '" aria-label="پدینگ ' + side[1] + ' ' + label + '"><span aria-hidden="true">px</span></label>').join('') +
      '</div>' +
      '<button type="button" class="sekianafraz-radius-link' + (linked ? ' is-linked' : '') + '" aria-label="اتصال مقادیر پدینگ ' + label + '" aria-pressed="' + (linked ? 'true' : 'false') + '">' + linkedControlIcon + '</button>' +
      '</div></div>';
  }
  function renderMarginItem(target, label) {
    const sides = [
      ['t', 'بالا'], ['r', 'راست'],
      ['b', 'پایین'], ['l', 'چپ']
    ];
    const values = marginDefaults[target];
    const linked = new Set(Object.values(values)).size === 1;
    return '<div class="sekianafraz-radius-item" data-margin-target="' + target + '" data-linked="' + (linked ? '1' : '0') + '">' +
      '<span class="sekianafraz-radius-item-label">' + label + '</span>' +
      '<div class="sekianafraz-radius-capsule">' +
      '<div class="sekianafraz-radius-direct-inputs">' +
      sides.map((side) => '<label class="sekianafraz-radius-direct-input"><input type="number" min="0" max="200" value="' + values[side[0]] + '" data-margin-side="' + side[0] + '" title="' + side[1] + '" aria-label="مارجین ' + side[1] + ' ' + label + '"><span aria-hidden="true">px</span></label>').join('') +
      '</div>' +
      '<button type="button" class="sekianafraz-radius-link' + (linked ? ' is-linked' : '') + '" aria-label="اتصال مقادیر مارجین ' + label + '" aria-pressed="' + (linked ? 'true' : 'false') + '">' + linkedControlIcon + '</button>' +
      '</div></div>';
  }
  function renderReminderStyleControls() {
    return '<div id="sekianafraz-reminder-styles" class="sekianafraz-spacing-control">' +
      '<div class="sekianafraz-field"><label>مقدار گردی حاشیه</label><div class="sekianafraz-radius-manual-list">' +
      renderRadiusItem('reminder_coupon', 'هایلایت کد') + renderRadiusItem('reminder_timer', 'تایمر') + '</div></div>' +
      '<div class="sekianafraz-field"><label>پدینگ</label><div class="sekianafraz-radius-manual-list">' +
      renderPaddingItem('reminder_coupon', 'هایلایت کد') + renderPaddingItem('reminder_timer', 'تایمر') + renderPaddingItem('reminder_bar', 'نوار یادآور') + '</div></div>' +
      '<div class="sekianafraz-field"><label>مارجین</label><div class="sekianafraz-radius-manual-list">' +
      renderMarginItem('reminder_text', 'متن') + renderMarginItem('reminder_timer', 'تایمر') + '</div></div></div>';
  }
  function mountReminderStyleControls() {
    const root = $('#sekianafraz-reminder-styles');
    if (!root || root._bound) return;
    root._bound = true;
    root.querySelectorAll('.sekianafraz-radius-item').forEach(item => {
      const kind = item.dataset.radiusTarget ? 'radius' : item.dataset.paddingTarget ? 'padding' : 'margin';
      const selector = kind === 'radius' ? '[data-radius-corner]' : kind === 'padding' ? '[data-padding-side]' : '[data-margin-side]';
      const apply = kind === 'radius' ? setRadiusValues : kind === 'padding' ? setPaddingValues : setMarginValues;
      const values = kind === 'radius' ? radiusValues : kind === 'padding' ? paddingValues : marginValues;
      item.querySelectorAll(selector).forEach(input => input.addEventListener('input', () => {
        const value = kind === 'radius' ? Math.min(200, clampRadius(input.value)) : clampPadding(input.value);
        input.value = String(value);
        if (item.dataset.linked === '1') {
          const keys = kind === 'radius' ? ['tl','tr','br','bl'] : ['t','r','b','l'];
          apply(item, Object.fromEntries(keys.map(key => [key, value])));
        }
      }));
      item.querySelector('.sekianafraz-radius-link').addEventListener('click', () => {
        const linked = item.dataset.linked !== '1'; setRadiusLinked(item, linked);
        if (linked) { const current = values(item); const value = Object.values(current)[0]; apply(item, Object.fromEntries(Object.keys(current).map(key => [key,value]))); }
        updatePreview();
      });
    });
  }
  function collectReminderStyles() {
    const result = {radii:{},paddings:{},margins:{}};
    $('#sekianafraz-reminder-styles')?.querySelectorAll('.sekianafraz-radius-item').forEach(item => {
      const kind = item.dataset.radiusTarget ? 'radii' : item.dataset.paddingTarget ? 'paddings' : 'margins';
      const target = (item.dataset.radiusTarget || item.dataset.paddingTarget || item.dataset.marginTarget).replace('reminder_', '');
      result[kind][target] = kind === 'radii' ? radiusValues(item) : kind === 'paddings' ? paddingValues(item) : marginValues(item);
    });
    return result;
  }
  function applyReminderStyles(data) {
    const stored = data.reminder_styles || {};
    $('#sekianafraz-reminder-styles')?.querySelectorAll('.sekianafraz-radius-item').forEach(item => {
      const kind = item.dataset.radiusTarget ? 'radii' : item.dataset.paddingTarget ? 'paddings' : 'margins';
      const target = (item.dataset.radiusTarget || item.dataset.paddingTarget || item.dataset.marginTarget).replace('reminder_', '');
      const values = stored[kind]?.[target];
      if (values) (kind === 'radii' ? setRadiusValues : kind === 'paddings' ? setPaddingValues : setMarginValues)(item, values);
      const current = kind === 'radii' ? radiusValues(item) : kind === 'paddings' ? paddingValues(item) : marginValues(item);
      setRadiusLinked(item, new Set(Object.values(current)).size === 1);
    });
  }
  function renderRadiusControls() {
    const toggleIcon = '<svg class="sekianafraz-radius-toggle-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m15 18-6-6 6-6"></path></svg>';
    return '<div class="sekianafraz-field sekianafraz-radius-field sekianafraz-spacing-control" data-mode="simple">' +
      '<div class="sekianafraz-radius-heading">' +
      '<label id="sekianafraz-radius-title" aria-label="نسبت گردی حاشیه اجزای بنر"><span class="sekianafraz-radius-word-slot" aria-hidden="true"><span class="sekianafraz-radius-word sekianafraz-radius-word--simple">نسبت</span><span class="sekianafraz-radius-word sekianafraz-radius-word--manual">مقدار</span></span> <span aria-hidden="true">گردی حاشیه اجزای بنر</span></label>' +
      '<button type="button" class="sekianafraz-radius-manual-toggle" aria-expanded="false">' + toggleIcon + '<span class="sekianafraz-radius-toggle-label-wrap"><span class="sekianafraz-radius-toggle-label">تنظیم دستی</span></span></button>' +
      '</div>' +
      '<div class="sekianafraz-radius-viewport"><div class="sekianafraz-radius-stage">' +
      '<section class="sekianafraz-radius-panel sekianafraz-radius-panel--manual">' +
      '<div class="sekianafraz-radius-manual-list">' + radiusTargets.map((item) => renderRadiusItem(item[0], item[1])).join('') + '</div>' +
      '</section>' +
      '<section class="sekianafraz-radius-panel sekianafraz-radius-panel--simple">' +
      '<input type="range" id="sekianafraz-banner-radius" min="0" max="40" step="1" value="0" aria-label="نسبت گردی حاشیه اجزای بنر">' +
      '</section>' +
      '</div></div></div>';
  }
  function renderPaddingControls() {
    return '<div class="sekianafraz-field sekianafraz-padding-field sekianafraz-spacing-control">' +
      '<div class="sekianafraz-padding-heading"><label>پدینگ اجزای بنر</label></div>' +
      '<div class="sekianafraz-radius-manual-list sekianafraz-padding-list">' + paddingTargets.map((item) => renderPaddingItem(item[0], item[1])).join('') + '</div>' +
      '</div>';
  }
  function renderMarginControls() {
    return '<div class="sekianafraz-field sekianafraz-margin-field sekianafraz-spacing-control">' +
      '<div class="sekianafraz-margin-heading"><label>مارجین اجزای بنر</label></div>' +
      '<div class="sekianafraz-radius-manual-list sekianafraz-margin-list">' + marginTargets.map((item) => renderMarginItem(item[0], item[1])).join('') + '</div>' +
      '</div>';
  }
  function renderBannerColorControls() {
    return '<div class="sekianafraz-field sekianafraz-color-section sekianafraz-banner-colors"><label>رنگ‌های بنر</label>' + renderColorFields([
      ['sekianafraz-banner-bg-color', 'پس‌زمینه بنر', '#ffffff'],
      ['sekianafraz-banner-title-color', 'عنوان بنر', '#0d0d0d'],
      ['sekianafraz-banner-text-color', 'متن بنر', '#4b5563'],
      ['sekianafraz-banner-coupon-color', 'متن کوپن', '#5c5c5c'],
      ['sekianafraz-button-color', 'دکمه بنر', '#000000'],
      ['sekianafraz-banner-svg-color', 'آیکون بنر', '#5F0027'],
      ['sekianafraz-banner-button-text-color', 'متن دکمه بنر', '#ffffff'],
      ['sekianafraz-discount-bg-color', 'پس‌زمینه باکس تخفیف', '#f2f2f2'],
      ['sekianafraz-discount-border-color', 'حاشیه باکس تخفیف', '#d1d5db'],
      ['sekianafraz-copy-bg-color', 'پس‌زمینه کپی', '#e5e7eb'], ['sekianafraz-copy-text-color', 'متن کپی', '#000000'],
      ['sekianafraz-close-bg-color', 'پس‌زمینه دکمه بستن', '#f1f1f1'], ['sekianafraz-close-icon-color', 'آیکون بستن', '#111111'],
      ['sekianafraz-back-bg-color', 'پس‌زمینه دکمه بازگشت', '#f1f1f1'], ['sekianafraz-back-icon-color', 'آیکون و متن بازگشت', '#111111'],
      ['sekianafraz-phone-bg-color', 'پس‌زمینه فیلد شماره', '#ffffff'], ['sekianafraz-phone-text-color', 'متن فیلد شماره', '#111827'],
      ['sekianafraz-phone-border-color', 'حاشیه فیلد شماره', '#d1d5db'], ['sekianafraz-send-bg-color', 'دکمه ارسال', '#000000'],
      ['sekianafraz-send-text-color', 'متن دکمه ارسال', '#ffffff'], ['sekianafraz-prompt-color', 'درخواست شماره', '#4b5563'],
      ['sekianafraz-sending-color', 'متن داخل دکمه هنگام ارسال', '#ffffff'], ['sekianafraz-loader-color', 'لودر داخل دکمه', '#ffffff'],
      ['sekianafraz-success-bg-color', 'پس‌زمینه موفقیت', '#ffffff'], ['sekianafraz-success-color', 'پیام موفقیت', '#111827'],
      ['sekianafraz-correction-bg-color', 'پس‌زمینه اصلاح شماره', '#ffffff'], ['sekianafraz-correction-color', 'متن اصلاح شماره', '#b8b8b8'],
      ['sekianafraz-correction-border-color', 'حاشیه زیر اصلاح شماره', '#b8b8b8']
    ], 'sekianafraz-banner-color-fields') + '</div>';
  }
  function radiusValues(item) {
    const values = {};
    item.querySelectorAll('[data-radius-corner]').forEach((input) => {
      values[input.dataset.radiusCorner] = clampRadius(input.value);
    });
    return values;
  }
  function setRadiusValues(item, values) {
    const normalized = {
      tl: clampRadius(values && values.tl), tr: clampRadius(values && values.tr),
      br: clampRadius(values && values.br), bl: clampRadius(values && values.bl)
    };
    item.querySelectorAll('[data-radius-corner]').forEach((input) => { input.value = normalized[input.dataset.radiusCorner]; });
  }
  function paddingValues(item) {
    const values = {};
    item.querySelectorAll('[data-padding-side]').forEach((input) => {
      values[input.dataset.paddingSide] = clampPadding(input.value);
    });
    return values;
  }
  function setPaddingValues(item, values) {
    const normalized = {
      t: clampPadding(values && values.t), r: clampPadding(values && values.r),
      b: clampPadding(values && values.b), l: clampPadding(values && values.l)
    };
    item.querySelectorAll('[data-padding-side]').forEach((input) => { input.value = normalized[input.dataset.paddingSide]; });
  }
  function marginValues(item) { const values = {}; item.querySelectorAll('[data-margin-side]').forEach(input => { values[input.dataset.marginSide] = clampPadding(input.value); }); return values; }
  function setMarginValues(item, values) { item.querySelectorAll('[data-margin-side]').forEach(input => { input.value = clampPadding(values?.[input.dataset.marginSide]); }); }
  function setRadiusLinked(item, linked) {
    item.dataset.linked = linked ? '1' : '0';
    const button = item.querySelector('.sekianafraz-radius-link');
    if (!button) return;
    button.classList.toggle('is-linked', linked);
    button.setAttribute('aria-pressed', linked ? 'true' : 'false');
  }
  function setRadiusToggleLabel(button, nextText, direction, animate) {
    if (!button) return;
    const current = button.querySelector('.sekianafraz-radius-toggle-label-incoming') || button.querySelector('.sekianafraz-radius-toggle-label');
    if (!current || current.textContent === nextText) return;
    clearTimeout(button._sekianafrazRadiusMorphTimer);
    button.querySelectorAll('.sekianafraz-radius-toggle-label').forEach((label) => {
      if (label !== current) label.remove();
    });
    current.classList.remove('sekianafraz-radius-toggle-label-outgoing', 'sekianafraz-radius-toggle-label-incoming');
    button.classList.remove('is-morphing', 'is-to-manual', 'is-to-simple');
    if (!animate || (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches)) {
      current.textContent = nextText;
      return;
    }
    const incoming = current.cloneNode(true);
    incoming.textContent = nextText;
    current.classList.add('sekianafraz-radius-toggle-label-outgoing');
    incoming.classList.add('sekianafraz-radius-toggle-label-incoming');
    current.parentNode.appendChild(incoming);
    button.classList.add(direction === 'manual' ? 'is-to-manual' : 'is-to-simple');
    button.getBoundingClientRect();
    button.classList.add('is-morphing');
    button._sekianafrazRadiusMorphTimer = setTimeout(() => {
      current.remove();
      incoming.classList.remove('sekianafraz-radius-toggle-label-incoming');
      button.classList.remove('is-morphing', 'is-to-manual', 'is-to-simple');
    }, 420);
  }
  function updateRadiusProgress(slider) {
    if (!slider) return;
    const ratio = Math.max(0, Math.min(1, Number(slider.value) / 40));
    slider.style.setProperty('--radius-progress', 'calc(' + (ratio * 100) + '% + ' + (10 - 20 * ratio) + 'px)');
  }
  function setRadiusMode(root, mode, animate = true) {
    const normalizedMode = mode === 'manual' ? 'manual' : 'simple';
    if (!animate) root.classList.add('is-setting-mode');
    const title = root.querySelector('#sekianafraz-radius-title');
    const slot = title?.querySelector('.sekianafraz-radius-word-slot');
    const word = slot?.querySelector('.sekianafraz-radius-word--' + normalizedMode);
    if (word) slot.style.width = word.getBoundingClientRect().width + 'px';
    root.dataset.mode = normalizedMode;
    title?.setAttribute('aria-label', (normalizedMode === 'manual' ? 'مقدار' : 'نسبت') + ' گردی حاشیه اجزای بنر');
    if (!animate) {
      requestAnimationFrame(() => root.classList.remove('is-setting-mode'));
    }
    const button = root.querySelector('.sekianafraz-radius-manual-toggle');
    if (button) {
      button.setAttribute('aria-expanded', normalizedMode === 'manual' ? 'true' : 'false');
      setRadiusToggleLabel(button, normalizedMode === 'manual' ? 'تنظیم نسبی' : 'تنظیم دستی', normalizedMode, animate);
    }
  }
  function initializeManualRadii(root, force = false) {
    if (!force && root.dataset.manualInitialized === '1') return;
    const radius = clampRadius(root.querySelector('#sekianafraz-banner-radius')?.value || 0);
    const defaults = {
      card: radius,
      image: radius * .5,
      discount: radius * .5,
      copy: radius * .375,
      primary: radius * .5,
      close: radius > 0 || force ? radius * .375 : radiusValues(root.querySelector('[data-radius-target="close"]')).tl,
      back: radius > 0 || force ? radius * .375 : radiusValues(root.querySelector('[data-radius-target="back"]')).tl,
      phone: radius * .5, send: radius * .5,
      success: radius * .5, correction: 0, error: radius * .5
    };
    root.querySelectorAll('.sekianafraz-radius-item').forEach((item) => {
      const value = defaults[item.dataset.radiusTarget] || 0;
      setRadiusValues(item, { tl: value, tr: value, br: value, bl: value });
      setRadiusLinked(item, true);
    });
    root.dataset.manualInitialized = '1';
  }
  function collectBannerRadiusState() {
    const root = document.querySelector('.sekianafraz-radius-field');
    const simple = clampRadius(root?.querySelector('#sekianafraz-banner-radius')?.value || 0);
    const values = {};
    root?.querySelectorAll('.sekianafraz-radius-item').forEach((item) => { values[item.dataset.radiusTarget] = radiusValues(item); });
    return { mode: root?.dataset.mode === 'manual' ? 'manual' : 'simple', simple, values };
  }
  function collectBannerPaddingState() {
    const values = {};
    document.querySelectorAll('.sekianafraz-padding-field [data-padding-target]').forEach((item) => {
      values[item.dataset.paddingTarget] = paddingValues(item);
    });
    return values;
  }
  function collectBannerMarginState() {
    const values = {};
    document.querySelectorAll('.sekianafraz-margin-field [data-margin-target]').forEach((item) => {
      values[item.dataset.marginTarget] = marginValues(item);
    });
    return values;
  }
  function applyBannerRadiusState(data, animate = false) {
    const root = document.querySelector('.sekianafraz-radius-field');
    if (!root) return;
    const simple = clampRadius(data && data.banner_border_radius);
    const slider = root.querySelector('#sekianafraz-banner-radius');
    if (slider) { slider.value = String(simple); updateRadiusProgress(slider); }
    const stored = data && data.banner_border_radii && typeof data.banner_border_radii === 'object' ? data.banner_border_radii : null;
    if (stored) {
      root.querySelectorAll('.sekianafraz-radius-item').forEach((item) => {
        const initial = ['close', 'back'].includes(item.dataset.radiusTarget) ? 50 : 0;
        const fallback = { tl: initial, tr: initial, br: initial, bl: initial };
        const values = stored[item.dataset.radiusTarget] || fallback;
        setRadiusValues(item, values);
        setRadiusLinked(item, new Set(Object.values(radiusValues(item))).size === 1);
      });
      root.dataset.manualInitialized = '1';
    }
    setRadiusMode(root, data && data.banner_radius_mode === 'manual' ? 'manual' : 'simple', animate);
    const kind = $('#sekianafraz-banner-type')?.value === 'multi' && $('#sekianafraz-action-fields')?.dataset.previewAudience !== 'logged' ? 'multi' : 'single';
    root.dataset.appearanceKind = kind;
    root._modes ||= {};
    root._modes[kind] = root.dataset.mode;
  }
  function applyBannerPaddingState(data) {
    const root = document.querySelector('.sekianafraz-padding-field');
    if (!root) return;
    const stored = data && data.banner_paddings && typeof data.banner_paddings === 'object' ? data.banner_paddings : {};
    root.querySelectorAll('[data-padding-target]').forEach((item) => {
      const values = stored[item.dataset.paddingTarget] || paddingDefaults[item.dataset.paddingTarget];
      setPaddingValues(item, values);
      setRadiusLinked(item, true);
    });
  }
  function applyBannerMarginState(data) {
    const root = document.querySelector('.sekianafraz-margin-field');
    if (!root) return;
    const stored = data && data.banner_margins && typeof data.banner_margins === 'object' ? data.banner_margins : {};
    root.querySelectorAll('[data-margin-target]').forEach((item) => {
      const values = stored[item.dataset.marginTarget] || marginDefaults[item.dataset.marginTarget];
      setMarginValues(item, values);
      setRadiusLinked(item, new Set(Object.values(marginValues(item))).size === 1);
    });
  }
  function mountBannerStyleControls(wrap) {
    const oldSvgColor = wrap.querySelector('#sekianafraz-banner-svg-color');
    if (oldSvgColor) {
      const oldSvgField = oldSvgColor.closest('div[style*="margin-top"]');
      if (oldSvgField) oldSvgField.remove();
    }
    const oldColor = wrap.querySelector('#sekianafraz-banner-bg-color');
    const oldColorField = oldColor && oldColor.closest('.sekianafraz-field');
    if (oldColorField) oldColorField.outerHTML = renderBannerColorControls();
    const colorSection = wrap.querySelector('.sekianafraz-banner-colors');
    const bannerTextField = wrap.querySelector('.sekianafraz-banner-text-field');
    if (colorSection && bannerTextField) bannerTextField.after(colorSection);
    const oldRadius = wrap.querySelector('#sekianafraz-banner-radius');
    const oldRadiusField = oldRadius && oldRadius.closest('.sekianafraz-field');
    if (oldRadiusField && !oldRadiusField.classList.contains('sekianafraz-radius-field')) oldRadiusField.outerHTML = renderRadiusControls();
    mountColorFields(wrap);
    const radiusRoot = wrap.querySelector('.sekianafraz-radius-field');
    if (!radiusRoot) return;
    setRadiusMode(radiusRoot, radiusRoot.dataset.mode, false);
    if (window.ResizeObserver) {
      const observer = new ResizeObserver(() => {
        if (!radiusRoot.isConnected) { observer.disconnect(); return; }
        const slot = radiusRoot.querySelector('.sekianafraz-radius-word-slot');
        const word = slot.querySelector('.sekianafraz-radius-word--' + radiusRoot.dataset.mode);
        slot.style.width = word.getBoundingClientRect().width + 'px';
      });
      radiusRoot.querySelectorAll('.sekianafraz-radius-word').forEach(word => observer.observe(word));
      const modal = $('#sekianafraz-sensor-modal');
      const dispose = () => {
        observer.disconnect();
        if (modal) modal._controlDisposers = (modal._controlDisposers || []).filter(item => item !== dispose);
      };
      radiusRoot._disposeStyle = dispose;
      if (modal) { modal._controlDisposers ||= []; modal._controlDisposers.push(dispose); }
    }
    const slider = radiusRoot.querySelector('#sekianafraz-banner-radius');
    updateRadiusProgress(slider);
    slider?.addEventListener('input', () => {
      updateRadiusProgress(slider);
      initializeManualRadii(radiusRoot, true);
    });
    slider?.addEventListener('pointerdown', (event) => {
      radiusRoot.classList.add('is-dragging');
      if (slider.setPointerCapture) slider.setPointerCapture(event.pointerId);
    });
    ['pointerup', 'pointercancel', 'blur'].forEach((eventName) => slider?.addEventListener(eventName, () => radiusRoot.classList.remove('is-dragging')));
    radiusRoot.querySelector('.sekianafraz-radius-manual-toggle')?.addEventListener('click', () => {
      const nextMode = radiusRoot.dataset.mode === 'manual' ? 'simple' : 'manual';
      if (nextMode === 'manual') initializeManualRadii(radiusRoot);
      setRadiusMode(radiusRoot, nextMode);
      const kind = $('#sekianafraz-banner-type')?.value === 'multi' && wrap.dataset.previewAudience !== 'logged' ? 'multi' : 'single';
      radiusRoot._modes ||= {};
      radiusRoot._modes[kind] = nextMode;
      if (wrap.dataset.previewAudience !== 'logged') {
        wrap._guestRadiusModes ||= {};
        wrap._guestRadiusModes[kind] = nextMode;
      }
      updatePreview();
    });
    radiusRoot.querySelectorAll('.sekianafraz-radius-item').forEach((item) => {
      item.querySelectorAll('[data-radius-corner]').forEach((input) => input.addEventListener('input', () => {
        const value = clampRadius(input.value);
        input.value = String(value);
        if (item.dataset.linked === '1') {
          setRadiusValues(item, { tl: value, tr: value, br: value, bl: value });
        }
      }));
      item.querySelector('.sekianafraz-radius-link')?.addEventListener('click', () => {
        const linked = item.dataset.linked !== '1';
        setRadiusLinked(item, linked);
        if (linked) {
          const first = item.querySelector('[data-radius-corner]');
          const value = clampRadius(first?.value || 0);
          setRadiusValues(item, { tl: value, tr: value, br: value, bl: value });
          updatePreview();
        }
      });
    });
    const paddingRoot = wrap.querySelector('.sekianafraz-padding-field');
    paddingRoot?.querySelectorAll('[data-padding-target]').forEach((item) => {
      item.querySelectorAll('[data-padding-side]').forEach((input) => input.addEventListener('input', () => {
        const value = clampPadding(input.value);
        input.value = String(value);
        if (item.dataset.linked === '1') {
          setPaddingValues(item, { t: value, r: value, b: value, l: value });
        }
      }));
      item.querySelector('.sekianafraz-radius-link')?.addEventListener('click', () => {
        const linked = item.dataset.linked !== '1';
        setRadiusLinked(item, linked);
        if (linked) {
          const first = item.querySelector('[data-padding-side]');
          const value = clampPadding(first?.value || 0);
          setPaddingValues(item, { t: value, r: value, b: value, l: value });
          updatePreview();
        }
      });
    });    const marginRoot = wrap.querySelector('.sekianafraz-margin-field');
    marginRoot?.querySelectorAll('[data-margin-target]').forEach((item) => {
      item.querySelectorAll('[data-margin-side]').forEach((input) => input.addEventListener('input', () => {
        const value = clampPadding(input.value);
        input.value = String(value);
        if (item.dataset.linked === '1') {
          setMarginValues(item, { t: value, r: value, b: value, l: value });
        }
      }));
      item.querySelector('.sekianafraz-radius-link')?.addEventListener('click', () => {
        const linked = item.dataset.linked !== '1';
        setRadiusLinked(item, linked);
        if (linked) {
          const first = item.querySelector('[data-margin-side]');
          const value = clampPadding(first?.value || 0);
          setMarginValues(item, { t: value, r: value, b: value, l: value });
          updatePreview();
        }
      });
    });
  }
  const appearanceFields = {
    banner_title: 'sekianafraz-banner-title', banner_button_text: 'sekianafraz-banner-button-text', banner_text: 'sekianafraz-banner-text',
    banner_button_color: 'sekianafraz-button-color', banner_image: 'sekianafraz-banner-image',
    banner_svg_color: 'sekianafraz-banner-svg-color', banner_bg_color: 'sekianafraz-banner-bg-color',
    banner_title_color: 'sekianafraz-banner-title-color', banner_text_color: 'sekianafraz-banner-text-color',
    banner_coupon_color: 'sekianafraz-banner-coupon-color', banner_font_type: 'sekianafraz-banner-font-type',
    banner_button_closes: 'sekianafraz-banner-button-closes', banner_target_url: 'sekianafraz-banner-target-url',
    banner_show_close: 'sekianafraz-banner-show-close',
    banner_close_hide_bg: 'sekianafraz-banner-close-hide-bg', banner_close_position: 'sekianafraz-banner-close-position',
    close_bg_color: 'sekianafraz-close-bg-color', close_icon_color: 'sekianafraz-close-icon-color',
    banner_button_text_color: 'sekianafraz-banner-button-text-color',
    discount_bg_color: 'sekianafraz-discount-bg-color', discount_border_color: 'sekianafraz-discount-border-color',
    copy_bg_color: 'sekianafraz-copy-bg-color', copy_text_color: 'sekianafraz-copy-text-color'
  };
  const multiFields = {
    multi_prompt: 'sekianafraz-multi-prompt', multi_phone_placeholder: 'sekianafraz-multi-phone-placeholder',
    multi_submit_text: 'sekianafraz-multi-submit-text', multi_sending_text: 'sekianafraz-multi-sending-text',
    multi_success_text: 'sekianafraz-multi-success-text', multi_correction_text: 'sekianafraz-multi-correction-text'
  };
  const multiColors = ['phone-bg', 'phone-text', 'phone-border', 'send-bg', 'send-text', 'prompt',
    'sending', 'loader', 'success-bg', 'success', 'correction-bg', 'correction', 'correction-border',
    'back-bg', 'back-icon'];
  function captureAppearance(wrap) {
    const data = {};
    Object.keys(appearanceFields).forEach((key) => {
      const el = $('#' + appearanceFields[key]);
      if (el) data[key] = el.type === 'checkbox' ? el.checked : el.value;
    });
    data.banner_hide_image = getBannerImageMode(wrap) === 'none';
    const radius = collectBannerRadiusState();
    data.banner_border_radius = radius.simple;
    data.banner_radius_mode = radius.mode;
    data.banner_border_radii = radius.values;
    data.banner_paddings = collectBannerPaddingState();
    data.banner_margins = collectBannerMarginState();
    return data;
  }
  function applyAppearance(wrap, data, animate = false) {
    wrap.dataset.suspendPreview = '1';
    try {
      Object.keys(appearanceFields).forEach((key) => {
        const el = $('#' + appearanceFields[key]);
        if (!el || data[key] === undefined) return;
        if (el.type === 'checkbox') el.checked = !!data[key]; else el.value = data[key];
        if (el.type === 'color') el.dispatchEvent(new Event('input'));
      });
      applyBannerRadiusState(data, animate);
      applyBannerPaddingState(data);
      applyBannerMarginState(data);
      const imageInput = wrap.querySelector('#sekianafraz-banner-image');
      if (imageInput) imageInput._customImage = data.banner_image || '';
      syncImageCards(wrap, data.banner_hide_image ? 'none' : data.banner_image ? 'custom' : 'default');
      wrap.querySelector('#sekianafraz-banner-font-type')?.dispatchEvent(new Event('change'));
      refreshBannerConditionalControls(wrap);
      mountCustomSelects($('#sekianafraz-sensor-modal'));
    } finally {
      delete wrap.dataset.suspendPreview;
    }
  }
  function collectBannerVariants() {
    const wrap = $('#sekianafraz-action-fields');
    if (!wrap) return { guest: {}, logged: {} };
    const current = captureAppearance(wrap);
    return wrap.dataset.previewAudience === 'logged'
      ? { guest: wrap._guestAppearance || current, logged: current }
      : { guest: current, logged: wrap._loggedEdited ? (wrap._loggedAppearance || current) : { ...current, banner_button_text: '', banner_radius_mode: 'simple' } };
  }
  function applyBannerVariants(item) {
    const wrap = $('#sekianafraz-action-fields');
    if (!wrap) return;
    applyAppearance(wrap, item);
    Object.keys(multiFields).forEach((key) => {
      const el = wrap.querySelector('#' + multiFields[key]);
      if (el) el.value = item[key] || '';
    });
    multiColors.forEach((key) => {
      const el = wrap.querySelector('#sekianafraz-' + key + '-color');
      if (el && item.multi_colors?.['multi_' + key.replace(/-/g, '_') + '_color']) el.value = item.multi_colors['multi_' + key.replace(/-/g, '_') + '_color'];
    });
    $('#sekianafraz-banner-type').value = item.banner_type === 'multi' ? 'multi' : 'single';
    if (item.banner_type === 'multi') {
      const buttonText = $('#sekianafraz-banner-button-text');
      if (buttonText && (!buttonText.value.trim() || buttonText.value.trim() === 'بزن بریم!')) buttonText.value = 'دریافت تخفیف';
    }
    $('#sekianafraz-logged-behavior').value = item.banner_type === 'multi' ? item.logged_behavior || 'single_sms' : 'single_sms';
    const radiusRoot = wrap.querySelector('.sekianafraz-radius-field');
    if (radiusRoot) {
      const kind = item.banner_type === 'multi' ? 'multi' : 'single';
      radiusRoot._modes = { [kind]: item.banner_radius_mode || (kind === 'multi' ? 'manual' : 'simple') };
      radiusRoot.dataset.appearanceKind = kind;
      setRadiusMode(radiusRoot, radiusRoot._modes[kind], false);
      wrap._bannerType = kind;
      wrap._guestRadiusModes = { [kind]: radiusRoot._modes[kind] };
    }
    wrap._guestAppearance = captureAppearance(wrap);
    wrap._loggedAppearance = item.logged_banner && Object.keys(item.logged_banner).length ? item.logged_banner : { ...wrap._guestAppearance, banner_button_text: '', banner_radius_mode: 'simple' };
    wrap._loggedEdited = !!(item.logged_banner && Object.keys(item.logged_banner).length);
    if (item.logged_sms_mode) {
      wrap.querySelector('#sekianafraz-logged-sms-mode').value = item.logged_sms_mode;
      wrap.querySelector('#sekianafraz-logged-sms-mode').dispatchEvent(new Event('change'));
      const sms = wrap.querySelector('#sekianafraz-logged-sms-' + (item.logged_sms_mode === 'pattern' ? 'pattern' : 'text'));
      if (sms) sms.value = item.logged_sms_mode === 'pattern' ? item.logged_sms_pattern || '' : item.logged_sms_text || '';
    }
    const loggedTarget = $('#sekianafraz-logged-sms-target-url');
    if (loggedTarget) loggedTarget.value = item.logged_sms_target_url || '';
    const loggedDelay = $('#sekianafraz-logged-sms-delay-type');
    if (loggedDelay) { loggedDelay.value = item.logged_sms_delay_type || 'immediate'; loggedDelay.dispatchEvent(new Event('change')); }
    const loggedMinutes = $('#sekianafraz-logged-sms-delay-minutes');
    setSmsDelayMinutes(loggedMinutes, item.logged_sms_delay_minutes);
    refreshBannerConditionalControls(wrap);
    mountCustomSelects(wrap);
    mountColorFields(wrap);
  }
  function refreshBannerConditionalControls(wrap) {
    if (!wrap) return;
    window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS.refreshCouponOwnership();
    const multi = $('#sekianafraz-banner-type')?.value === 'multi';
    syncGuestSmsVars(wrap);
    const logged = $('#sekianafraz-logged-behavior')?.value || 'single_sms';
    const audience = wrap.dataset.previewAudience === 'logged';
    if (audience && (!multi || logged === 'none')) {
      $('#sekianafraz-audience-toggle [data-audience="guest"]')?.click();
      if (wrap.dataset.previewAudience === 'guest') return;
    }
    const steps = multi && !audience;
    const stage = steps ? Number(wrap.dataset.bannerStage || 1) : 1;
    const showBanner = ['banner', 'both'].includes(wrap.dataset.action) && !(multi && audience && logged === 'sms');
    const showIntro = showBanner && stage === 1;
    const showClose = steps || !!$('#sekianafraz-banner-show-close')?.checked;
    const couponEnabled = $('#sekianafraz-coupon-strategy')?.value !== 'none' && $('#sekianafraz-sensor-modal')?.dataset.acCouponDisabled !== '1';
    const showCoupon = couponEnabled && !steps;
    const showImage = getBannerImageMode(wrap) !== 'none';
    const hasCustomImage = !!wrap.querySelector('#sekianafraz-banner-image')?.value;
    const radiusRoot = wrap.querySelector('.sekianafraz-radius-field');
    if (radiusRoot) {
      const kind = steps ? 'multi' : 'single';
      const previous = radiusRoot.dataset.appearanceKind;
      radiusRoot._modes ||= {};
      if (previous && previous !== kind) {
        radiusRoot._modes[previous] = radiusRoot.dataset.mode;
        if (radiusRoot._modes[kind] === undefined && kind === 'multi') initializeManualRadii(radiusRoot);
        setRadiusMode(radiusRoot, radiusRoot._modes[kind] || (kind === 'multi' ? 'manual' : 'simple'));
      }
      radiusRoot.dataset.appearanceKind = kind;
    }
    setFieldVisible($('#sekianafraz-banner-show-close')?.closest('.sekianafraz-field'), !steps);
    setFieldVisible($('#sekianafraz-close-options'), showBanner && showClose && !steps);
    const closeHideField = $('#sekianafraz-banner-close-hide-bg')?.closest('.sekianafraz-field');
    const colorSection = wrap.querySelector('.sekianafraz-banner-colors');
    const optionsRow = $('#sekianafraz-banner-options-row');
    if (closeHideField) {
      if (steps && stage > 1 && colorSection) colorSection.before(closeHideField);
      else if (optionsRow && closeHideField.parentElement !== optionsRow) optionsRow.appendChild(closeHideField);
      refreshFormRow(optionsRow);
    }
    setFieldVisible(closeHideField, showClose);
    setFieldVisible($('#sekianafraz-logged-behavior-wrap'), multi);
    setFieldVisible($('#sekianafraz-hide-banner-logged-in-wrap'), !multi);
    setFieldVisible(wrap.querySelector('#sekianafraz-multi-fields'), steps && stage !== 1);
    [0, 1, 2].forEach(index => setFieldVisible(wrap.querySelector('#sekianafraz-multi-text-row-' + index), steps && stage === (index === 2 ? 3 : 2)));
    setFieldVisible(wrap.querySelector('#sekianafraz-logged-sms-wrap'), multi && audience && ['sms', 'single_sms'].includes(logged));
    setFieldVisible(wrap.querySelector('#sekianafraz-sms-wrap'), multi ? !audience : wrap.dataset.action !== 'banner');
    setFieldVisible(wrap.querySelector('#sekianafraz-sms-delay-type')?.closest('.sekianafraz-field'), !multi);
    setFieldVisible(wrap.querySelector('#sekianafraz-sms-delay-minutes-wrap'), !multi && $('#sekianafraz-sms-delay-type')?.value === 'delayed');
    setFieldVisible(wrap.querySelector('#sekianafraz-sms-delay-row'), !multi);
    wrap.querySelectorAll('.sekianafraz-radius-field [data-radius-target], .sekianafraz-padding-field [data-padding-target], .sekianafraz-margin-field [data-margin-target]').forEach(el => {
      const target = el.dataset.radiusTarget || el.dataset.paddingTarget || el.dataset.marginTarget;
      const visible = target === 'close' ? showClose :
        target === 'back' ? steps && stage === 2 :
        target === 'image' ? showIntro && showImage && hasCustomImage :
        ['phone', 'send', 'prompt'].includes(target) ? steps && stage === 2 :
        ['success', 'correction'].includes(target) ? steps && stage === 3 :
        ['discount', 'copy'].includes(target) ? showCoupon :
        ['primary', 'title', 'description'].includes(target) ? showIntro : true;
      setFieldVisible(el, visible);
    });
    multiColors.forEach(key => {
      const phase = ['success-bg', 'success', 'correction-bg', 'correction', 'correction-border'].includes(key) ? 3 : 2;
      setFieldVisible(wrap.querySelector('#sekianafraz-' + key + '-color')?.closest('.sekianafraz-color-field'), steps && stage === phase);
    });
    ['sekianafraz-banner-title-color', 'sekianafraz-banner-text-color', 'sekianafraz-button-color', 'sekianafraz-banner-button-text-color'].forEach(id => {
      setFieldVisible($('#' + id)?.closest('.sekianafraz-color-field'), showIntro);
    });
    ['sekianafraz-discount-bg-color', 'sekianafraz-discount-border-color', 'sekianafraz-copy-bg-color', 'sekianafraz-copy-text-color', 'sekianafraz-banner-coupon-color'].forEach(id => {
      setFieldVisible($('#' + id)?.closest('.sekianafraz-color-field'), showCoupon);
    });
    wrap.querySelectorAll('.sekianafraz-banner-text-field .sekianafraz-vars-table tbody tr').forEach(row => {
      const token = row.querySelector('code')?.textContent || '';
      if (/\{\{(?:coupon_code|coupon_expiry_time)\}\}/.test(token)) setFieldVisible(row, showCoupon);
    });
    ['sekianafraz-close-bg-color', 'sekianafraz-close-icon-color'].forEach(id => {
      setFieldVisible($('#' + id)?.closest('.sekianafraz-color-field'), showClose && (id !== 'sekianafraz-close-bg-color' || !$('#sekianafraz-banner-close-hide-bg')?.checked));
    });
    syncImageCards(wrap);
    setFieldVisible($('#sekianafraz-banner-svg-color')?.closest('.sekianafraz-color-field'), showIntro && showImage && !hasCustomImage);
    const button = $('#sekianafraz-banner-button-text');
    const label = button?.closest('.sekianafraz-field')?.querySelector('label');
    if (label) label.textContent = steps ? 'متن دکمه دریافت تخفیف' : 'متن دکمه بنر';
    if (button) button.placeholder = steps ? 'پیش‌فرض: دریافت تخفیف' : 'پیش‌فرض: بزن بریم!';
    const bannerText = $('#sekianafraz-banner-text');
    if (bannerText) bannerText.placeholder = steps
      ? 'مثلاً: به {{product_name}} علاقه داری؟\nیه تخفیف ویژه 20 درصدی دارم برات!\nبرای دریافت کد تخفیف روی لینک زیر کلیک کن.'
      : 'مثلاً: به {{product_name}} علاقه داری؟\nفقط تا 24 ساعت مهلت داری این محصول رو با 10 درصد تخفیف بخری؛\nکد تخفیف زیر رو توی سبد خرید استفاده کن:';
    window.SEKIANAFRAZ_ADMIN_CONTROLS.setAudienceToggleVisible($('#sekianafraz-audience-toggle'), multi && logged !== 'none');
    wrap.querySelectorAll('#sekianafraz-banner-title-row, .sekianafraz-banner-text-field, .sekianafraz-banner-image-field').forEach(el => setFieldVisible(el, showIntro));
    wrap.querySelectorAll('.sekianafraz-banner-colors, #sekianafraz-banner-font-row, .sekianafraz-radius-field, .sekianafraz-padding-field, .sekianafraz-margin-field').forEach(el => setFieldVisible(el, showBanner));
    setFieldVisible($('#sekianafraz-banner-options-row'), showBanner);
    updateBannerTarget(wrap);
    sections().refresh(wrap);
    window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW.refreshPreviewAvailability();
    $('#sekianafraz-reminder-wrap')?._refreshVisibility?.();
    if (wrap.dataset.suspendPreview !== '1') updatePreview();
  }
  function renderBannerImageOptions() {
    const noneIcon = '<svg class="sekianafraz-lucide-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="2" x2="22" y1="2" y2="22"/><path d="M10.41 10.41a2 2 0 1 1-2.83-2.83"/><line x1="13.5" x2="6" y1="13.5" y2="21"/><line x1="18" x2="21" y1="12" y2="15"/><path d="M3.59 3.59A1.99 1.99 0 0 0 3 5v14a2 2 0 0 0 2 2h14c.55 0 1.052-.22 1.41-.59"/><path d="M21 15V5a2 2 0 0 0-2-2H9"/></svg>';
    const customIcon = '<svg class="sekianafraz-lucide-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.3 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v10l-3.1-3.1a2 2 0 0 0-2.814.014L6 21"/><path d="m14 19.5 3-3 3 3"/><path d="M17 22v-5.5"/><circle cx="9" cy="9" r="2"/></svg>';
    const defaultIcon = '<svg id="sekianafraz-default-svg" style="color:#5F0027" viewBox="-4 -4 72 72" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--emojione-monotone" preserveAspectRatio="xMidYMid meet" fill="#5F0027"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M39.668 47.588c1.553-1.529.715-5.041-1.822-9.098c.922-.144 1.784-.364 2.436-.701c2.346-1.211 3.93-3.418 5.129-5.701c1.289-2.449 2.154-5.141 3.836-7.371c.284-.377.568-.715.851-1.033c3.629.435 6.526 1.215 6.526 1.215l1.107-2.813a29.917 29.917 0 0 0-4.286-1.187c.892-.507 1.474-.665 1.474-.665l-1.049-2.836c-1.682.711-3.047 1.76-4.19 3.016c-4.272-.239-8.574.612-11.968 3.244c-2.552 1.98-4.276 4.725-5.898 7.471a44.86 44.86 0 0 0-4.581-3.927c.306-.503.634-.955.987-1.304c2.133-2.1 4.947-3.443 6.793-5.846c3.88-5.046 1.042-12.956-2.15-17.052c-.572.551-1.518 1.354-2.23 1.988c3.393 3.475 5.766 9.559 3.107 14.105c-1.486 2.541-4.232 4.135-6.152 6.318c-.332.379-.629.859-.898 1.389c-5.021-3.601-9.629-5.05-11.455-3.252a2.35 2.35 0 0 0-.442.634l-.007-.007l-.049.143c-.068.155-.13.316-.172.492L2 61l36.662-12.818l-.01-.01c.394-.127.741-.314 1.016-.584M9.293 56.332l-3.06-1.426l2.065-5.95l9.471 4.412l-8.476 2.964m16.951-5.927l-15.879-7.399l2.065-5.949l11.866 5.956c-7.083-4.61-9.801-11.907-9.801-11.907l.706-2.033c1.255 3.175 4.016 7.129 7.81 10.861c3.826 3.766 7.881 6.494 11.122 7.713l-7.889 2.758m6.099-18.74c1.658-2.377 3.367-4.776 5.743-6.483c2.262-1.626 5.934-1.923 9.415-1.728c-1.176 2.054-2.045 4.333-2.825 6.522c-.943 2.65-2.207 5.398-4.617 7.023c-.65.438-1.561.758-2.534.995c-1.337-2.049-3.091-4.215-5.182-6.329" fill="currentColor"></path><path d="M23.033 22c1.002 0-2.002-3-1.5-5.631c1.924-.148 6.322.719 3.762-2.797c2.896.51 4.396-1.652 1.662-3.701c.91.064 2.324-1.652 1.309-1.869c-3.252-.689-4.525 1.07-2.461 3.607c-2.17-.404-3.939.605-2.309 2.871c-6.266-.781-2.701 7.52-.463 7.52" fill="currentColor"></path><path d="M44.545 19.334c.939-.424-.654-3.225-1.172-3.941c3.963-.424 3.813-1.605 1.328-4.135c6.756.227.209-3.613 1.127-5.133c.795-1.318 3.234.064 3.008-.67c-.762-2.455-7.99-.795-3.416 3.789c-3.992.078-4.375 1.383-1.4 4.088c-5.182.057-.954 6.668.525 6.002" fill="currentColor"></path><path d="M61.697 29.225c-1.582.443-1.826.277-1.615 1.852c-3.654-1.682-7.52-4.021-5.174 2.176c-4.15-2.471-3.943-.307-4.719 3.254c-1.01-.787-2.445-2.861-2.445-2.861l-1.52 1.291s2.785 3.928 4.16 3.705c1.209-.195 1.867-2.48 1.934-4.494c3.85 1.625 5.693 1.842 3.932-2.91c3.078 1.729 6.852 3.254 5.447-2.013" fill="currentColor"></path><path opacity="0.3" d="M6.049 11.437l2.828 2.829l-2.828 2.828l-2.829-2.828z" fill="currentColor"></path><path opacity="0.3" d="M12.824 23.198l-2.83 2.828l-2.829-2.83l2.83-2.829z" fill="currentColor"></path><path opacity="0.3" d="M17.22 7l2.828 2.828l-2.829 2.83l-2.828-2.83z" fill="currentColor"></path><path opacity="0.3" d="M48.011 46.484l-2.83-2.829l2.828-2.828l2.83 2.829z" fill="currentColor"></path><path opacity="0.3" d="M41.705 56.186l-2.828-2.828l2.828-2.829l2.829 2.829z" fill="currentColor"></path><path opacity="0.3" d="M54.113 58.42l-2.83-2.829l2.827-2.83l2.83 2.829z" fill="currentColor"></path><path opacity="0.3" d="M56.941 45.536l-2.828-2.829l2.828-2.828l2.828 2.828z" fill="currentColor"></path><path opacity="0.3" d="M52.22 10l2.828 2.828l-2.829 2.829l-2.828-2.829z" fill="currentColor"></path></g></svg>';
    const card = (mode, icon, title) => '<div class="sekianafraz-image-choice">' +
      '<label class="sekianafraz-image-card" data-image-mode="' + mode + '">' +
      '<input type="radio" name="sekianafraz-banner-image-mode" value="' + mode + '"' + (mode === 'default' ? ' checked' : '') + '>' +
      '<span class="sekianafraz-image-card-icon">' + icon +
      (mode === 'custom' ? '<img id="sekianafraz-banner-preview" src="" alt="تصویر انتخاب‌شده" style="display:none">' : '') +
      '</span><span class="sekianafraz-image-card-title">' + title + '</span></label>' +
      (mode === 'custom' ? '<button type="button" id="sekianafraz-remove-image" class="sekianafraz-image-remove" style="display:none" aria-label="حذف تصویر اختصاصی"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button>' : '') + '</div>';
    return '<div class="sekianafraz-field sekianafraz-banner-image-field"><label>تصویر بنر</label>' +
      '<div id="sekianafraz-image-options" class="sekianafraz-image-cards" role="radiogroup" aria-label="تصویر بنر">' +
      card('none', noneIcon, 'بدون تصویر') + card('default', defaultIcon, 'تصویر پیش‌فرض') +
      card('custom', customIcon, 'تصویر اختصاصی') + '</div><input type="hidden" id="sekianafraz-banner-image"></div>';
  }
  function getBannerImageMode(wrap) {
    return wrap?.querySelector('#sekianafraz-banner-image')?.dataset.imageMode || 'default';
  }
  function syncImageCards(wrap, mode) {
    const image = wrap.querySelector('#sekianafraz-banner-image');
    if (!image) return;
    mode = mode || image.dataset.imageMode || (image.value ? 'custom' : 'default');
    image.dataset.imageMode = mode;
    wrap.querySelectorAll('[name="sekianafraz-banner-image-mode"]').forEach(input => {
      input.checked = input.value === mode;
      const card = input.closest('.sekianafraz-image-card');
      card.classList.toggle('is-selected', input.checked);
      card.classList.toggle('has-custom-image', input.value === 'custom' && !!image.value && mode === 'custom');
    });
    const preview = wrap.querySelector('#sekianafraz-banner-preview');
    if (preview) { preview.src = image.value || ''; setFieldVisible(preview, mode === 'custom' && !!image.value); }
    setFieldVisible(wrap.querySelector('#sekianafraz-remove-image'), mode === 'custom' && !!image.value, 'inline-flex');
  }
  function mountActionRows(wrap) {
    const fieldOf = id => wrap.querySelector('#' + id)?.closest('.sekianafraz-field');
    const bannerType = fieldOf('sekianafraz-banner-type');
    const slot = $('#sekianafraz-banner-type-slot');
    if (bannerType && slot) { slot.replaceChildren(bannerType); setFieldVisible(slot, true); }
    const loggedBehavior = wrap.querySelector('#sekianafraz-logged-behavior-wrap');
    if (loggedBehavior) $('#sekianafraz-logged-behavior-slot')?.replaceChildren(loggedBehavior);
    const hideLogged = wrap.querySelector('#sekianafraz-hide-banner-logged-in-wrap');
    if (hideLogged) $('#sekianafraz-reaction-options')?.replaceChildren(hideLogged);
    const position = wrap.querySelector('#sekianafraz-close-options');
    if (position) $('#sekianafraz-close-position-slot')?.replaceChildren(position);
    const options = $('#sekianafraz-banner-options-row');
    [fieldOf('sekianafraz-banner-show-close'), fieldOf('sekianafraz-banner-close-hide-bg')].filter(Boolean).forEach(node => options?.appendChild(node));
    refreshFormRow(options);
    const image = wrap.querySelector('.sekianafraz-banner-image-field');
    const title = fieldOf('sekianafraz-banner-title');
    const text = wrap.querySelector('.sekianafraz-banner-text-field');
    const colors = wrap.querySelector('.sekianafraz-banner-colors');
    if (text && image) text.after(image);
    if (image && colors) image.after(colors);
    makeFormRow('sekianafraz-banner-title-row', [title, fieldOf('sekianafraz-banner-button-text')]);
    [['prompt', 'phone-placeholder'], ['submit-text', 'sending-text'], ['success-text', 'correction-text']].forEach((pair, index) => {
      makeFormRow('sekianafraz-multi-text-row-' + index, pair.map(key => fieldOf('sekianafraz-multi-' + key)));
    });
    makeFormRow('sekianafraz-banner-font-row', [fieldOf('sekianafraz-banner-font-type')]);
    makeFormRow('sekianafraz-sms-delay-row', [fieldOf('sekianafraz-sms-delay-type'), wrap.querySelector('#sekianafraz-sms-delay-minutes-wrap')]);
    makeFormRow('sekianafraz-logged-sms-delay-row', [fieldOf('sekianafraz-logged-sms-delay-type'), wrap.querySelector('#sekianafraz-logged-sms-delay-minutes-wrap')]);
    wrap.querySelectorAll('#sekianafraz-vars, #sekianafraz-vars-sms, #sekianafraz-logged-vars').forEach(table => {
      const wrapper = table.parentElement;
      if (wrapper.classList.contains('sekianafraz-banner-text-field')) return;
      wrapper.classList.add('sekianafraz-sms-vars-field');
      wrapper.querySelector(':scope > label')?.remove();
    });
    window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS.layoutReminder();
  }
  function refreshActionVariableTables(wrap, placement) {
    const action = wrap.dataset.action;
    const fallback = $('#sekianafraz-display-name-fallback')?.value;
    const catalog = window.SEKIANAFRAZ_ADMIN_VARS?.[placement] || window.SEKIANAFRAZ_ADMIN_VARS?.product_single;
    if (!catalog) return;
    const render = (id, mode, fallback, prefix) => {
      const target = wrap.querySelector('#' + id);
      if (target) target.innerHTML = renderVarsTable(withoutGuestDisplayName(prefix, filterVarsByCoupon(catalog[mode] || [])), fallback);
    };
    if (action === 'sms') render('sekianafraz-vars', $('#sekianafraz-sms-mode')?.value === 'pattern' ? 'pattern' : 'promo', false, 'sms');
    else {
      render(action === 'banner' ? 'sekianafraz-vars' : 'sekianafraz-vars-banner', 'banner', true);
      render('sekianafraz-vars-sms', $('#sekianafraz-sms-mode')?.value === 'pattern' ? 'pattern' : 'promo', false, 'sms');
      render('sekianafraz-logged-vars', $('#sekianafraz-logged-sms-mode')?.value === 'pattern' ? 'pattern' : 'promo', false, 'logged-sms');
    }
    const fallbackInput = $('#sekianafraz-display-name-fallback');
    if (fallbackInput && fallback !== undefined) fallbackInput.value = fallback;
    updateVarsTables($('#sekianafraz-sensor-modal'));
    if (action !== 'sms') refreshBannerConditionalControls(wrap);
  }
  function renderAdditionalBannerFields() {
    return list('نوع بنر', 'sekianafraz-banner-type', [['single', 'تک‌مرحله‌ای'], ['multi', 'چندمرحله‌ای']]) +
      '<div id="sekianafraz-banner-target-wrap"><div class="sekianafraz-field"><label class="sekianafraz-conditional-label" style="display:flex;align-items:center;gap:6px;width:100%"><input class="ui-checkbox" type="checkbox" id="sekianafraz-banner-button-closes" checked><span class="sekianafraz-checkbox-copy" id="sekianafraz-banner-button-closes-label">دکمه «بزن بریم!» باعث بسته‌شدن بنر شود</span></label></div><div class="sekianafraz-field" id="sekianafraz-banner-target-field" style="display:none"><label id="sekianafraz-banner-target-label" for="sekianafraz-banner-target-url">لینک دکمه «بزن بریم!»</label><input type="text" dir="ltr" id="sekianafraz-banner-target-url" placeholder="https://site.com/example"></div></div>' +
      '<div class="sekianafraz-field"><label><input class="ui-checkbox" type="checkbox" id="sekianafraz-banner-show-close"> نمایش آیکون بستن</label></div>' +
      '<div class="sekianafraz-field"><label><input class="ui-checkbox" type="checkbox" id="sekianafraz-banner-close-hide-bg"> پنهان‌سازی پس‌زمینه آیکون بستن</label></div>' +
      '<div id="sekianafraz-close-options" style="display:none">' + list('موقعیت آیکون بستن', 'sekianafraz-banner-close-position', [['left', 'بالا سمت چپ'], ['right', 'بالا سمت راست']]) + '</div>' +
      '<div id="sekianafraz-multi-fields">' +
      field('متن درخواست شماره تلفن', 'text', 'sekianafraz-multi-prompt', '', 'شماره تلفنتو وارد کن تا کد رو برات پیامک کنیم') +
      field('متن داخل فیلد شماره تلفن', 'text', 'sekianafraz-multi-phone-placeholder', '', 'شماره تلفن') +
      field('متن دکمه ارسال', 'text', 'sekianafraz-multi-submit-text', '', 'ارسال کد تخفیف') +
      field('متن درحال ارسال', 'text', 'sekianafraz-multi-sending-text', '', 'درحال ارسال...') +
      field('متن پس از ارسال', 'text', 'sekianafraz-multi-success-text', '', 'کد تخفیف رو برات پیامک کردیم!') +
      field('تنظیم اصلاح شماره تلفن', 'text', 'sekianafraz-multi-correction-text', '', 'شمارتو اشتباه وارد کردی؟') + '</div>' +
      '<div id="sekianafraz-logged-behavior-wrap">' + list('رفتار سنسور دربرابر کاربران وارد شده', 'sekianafraz-logged-behavior', [
        ['none', 'عدم اجرای سنسور'], ['single', 'نمایش بنر تک‌مرحله‌ای'],
        ['sms', 'ارسال پیامک مجزا'], ['single_sms', 'نمایش بنر تک‌مرحله‌ای + ارسال پیامک مجزا']
      ]) + '</div>' +
      renderSmsConfig('logged-sms', 'sekianafraz-logged-vars');
  }
  function syncAudienceToggle(toggle, audience) {
    if (!toggle) return;
    toggle.dataset.active = audience === 'logged' ? '1' : '0';
    toggle.querySelectorAll('button[data-audience]').forEach(button => {
      const active = button.dataset.audience === audience;
      button.classList.toggle('active', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }
  function renderSmsConfig(prefix, varsId) {
    return '<div id="sekianafraz-' + prefix + '-wrap">' +
      list('نوع ارسال پیامک', 'sekianafraz-' + prefix + '-mode', [['promo', 'ارسال از وب‌سرویس تبلیغاتی'], ['pattern', 'ارسال با وب‌سرویس خدماتی (پترن)']]) +
      '<div id="sekianafraz-' + prefix + '-extra"></div><div class="sekianafraz-field"><div id="' + varsId + '"></div></div>' +
      list('تاخیر در ارسال پیامک', 'sekianafraz-' + prefix + '-delay-type', [['immediate', 'ارسال بلافاصله'], ['delayed', 'ارسال با تاخیر']]) +
      renderSmsDelayMinutes('sekianafraz-' + prefix + '-delay-minutes') + '</div>';
  }
  function mountSmsConfig(prefix, varsId) {
    const select = $('#sekianafraz-' + prefix + '-mode');
    if (!select) return;
    const extra = $('#sekianafraz-' + prefix + '-extra');
    const refresh = () => {
      const previous = select.dataset.smsMode;
      select._smsDrafts ||= {};
      if (previous) {
        select._smsDrafts[previous] = {
          text: extra.querySelector('textarea')?.value || '',
          url: extra.querySelector('#sekianafraz-' + prefix + '-target-url')?.value || ''
        };
      }
      beginFormLayout(extra);
      animateFormContent(extra, true);
      const pattern = select.value === 'pattern';
      const id = 'sekianafraz-' + prefix + (pattern ? '-pattern' : '-text');
      const draft = select._smsDrafts[select.value];
      extra.innerHTML = '<div class="sekianafraz-field"><div class="sekianafraz-sms-label-row"><label for="' + id + '">' + (pattern ? 'کد پترن و متغیرها' : 'متن پیامک') +
        '</label>' + guide().buttonHtml(prefix) + '</div><textarea id="' + id + '" rows="' + (pattern ? 4 : 6) + '" placeholder="' +
        (pattern ? '12875&#10;{{coupon_code}}' : 'قصد خرید &#x2066;{{product_name}}&#x2069; رو داری؟&#10;با استفاده از کد تخفیف زیر، اون رو با 20 درصد تخفیف بخر:&#10;&#x2066;{{coupon_code}}&#x2069;&#10;خرید:&#10;&#x2066;{{target_url}}&#x2069;&#10;لغو11') + '"></textarea></div>' + renderSmsTarget(prefix);
      extra.querySelector('textarea').value = draft?.text || '';
      const target = $('#sekianafraz-' + prefix + '-target-url');
      target.value = draft?.url ?? select.dataset.targetUrl ?? '';
      target.placeholder = pattern ? 'example' : 'site.com/example';
      select.dataset.smsMode = select.value;
      const placement = basePlacementOf($('#sekianafraz-placement')?.value || 'product_single');
      const vars = filterVarsByCoupon(window.SEKIANAFRAZ_ADMIN_VARS?.[placement]?.[pattern ? 'pattern' : 'promo'] || []);
      $('#' + varsId).innerHTML = renderVarsTable(withoutGuestDisplayName(prefix, vars));
      updateSmsTargets();
      animateFormContent(extra);
      updateVarsTables($('#sekianafraz-sensor-modal'));
    };
    select.addEventListener('change', refresh);
    refresh();
    const delay = $('#sekianafraz-' + prefix + '-delay-type');
    const refreshDelay = () => setFieldVisible($('#sekianafraz-' + prefix + '-delay-minutes-wrap'),
      delay.value === 'delayed' && (prefix === 'logged-sms' || $('#sekianafraz-banner-type')?.value !== 'multi'));
    delay.addEventListener('change', refreshDelay);
    refreshDelay();
  }
  function captureActionDraft(wrap) {
    const draft = wrap._actionDraft || { values: {}, smsDrafts: {} };
    if (!wrap.dataset.action) return draft;
    const roots = [wrap, $('#sekianafraz-banner-type-slot'), $('#sekianafraz-reaction-options'), $('#sekianafraz-logged-behavior-slot')];
    roots.forEach(root => root?.querySelectorAll('input[id], textarea[id], select[id]').forEach(input => {
      draft.values[input.id] = input.type === 'checkbox' ? input.checked : input.value;
      if (input._smsDrafts) draft.smsDrafts[input.id] = input._smsDrafts;
    }));
    if (['banner', 'both'].includes(wrap.dataset.action)) {
      const variants = collectBannerVariants();
      draft.banner = { ...variants.guest, logged_banner: variants.logged,
        banner_type: $('#sekianafraz-banner-type')?.value || 'single',
        logged_behavior: $('#sekianafraz-logged-behavior')?.value || 'single_sms' };
      Object.entries(multiFields).forEach(([key, id]) => { draft.banner[key] = $('#' + id)?.value || ''; });
      draft.banner.multi_colors = Object.fromEntries(multiColors.map(key => ['multi_' + key.replace(/-/g, '_') + '_color', $('#sekianafraz-' + key + '-color')?.value || '']));
      ['mode', 'text', 'pattern', 'target-url', 'delay-type', 'delay-minutes'].forEach(key => {
        const input = $('#sekianafraz-logged-sms-' + key);
        if (input) draft.banner['logged_sms_' + key.replace(/-/g, '_')] = input.value;
      });
    }
    wrap._actionDraft = draft;
    return draft;
  }
  function restoreActionDraft(wrap, draft) {
    ['sms', 'logged-sms'].forEach(prefix => {
      const id = 'sekianafraz-' + prefix + '-mode', select = $('#' + id);
      if (!select || draft.values[id] === undefined) return;
      select._smsDrafts = draft.smsDrafts[id] || {};
      delete select.dataset.smsMode;
      select.value = draft.values[id];
      select.dispatchEvent(new Event('change'));
    });
    Object.entries(draft.values).forEach(([id, value]) => {
      const input = $('#' + id);
      if (!input) return;
      if (input.type === 'checkbox') input.checked = value;
      else if (id.endsWith('-sms-delay-minutes') || id === 'sekianafraz-sms-delay-minutes') setSmsDelayMinutes(input, value);
      else input.value = value;
    });
    if (draft.banner && ['banner', 'both'].includes(wrap.dataset.action)) applyBannerVariants(draft.banner);
    ['sms', 'logged-sms'].forEach(prefix => $('#sekianafraz-' + prefix + '-delay-type')?.dispatchEvent(new Event('change')));
    mountColorFields(wrap);
    mountCustomSelects($('#sekianafraz-sensor-modal'));
    updateSmsTargets();
  }
  function switchAudience(wrap, audience) {
    if (wrap.dataset.previewAudience === audience) return;
    beginFormLayout(wrap);
    const current = captureAppearance(wrap);
    if (wrap.dataset.previewAudience === 'guest') {
      wrap._guestAppearance = current;
      if (!wrap._loggedEdited) wrap._loggedAppearance = { ...current, banner_button_text: '', banner_radius_mode: 'simple' };
    } else {
      wrap._loggedAppearance = current;
      wrap._loggedEdited = true;
    }
    wrap.dataset.previewAudience = audience;
    applyAppearance(wrap, audience === 'guest' ? wrap._guestAppearance : wrap._loggedAppearance, true);
    syncAudienceToggle($('#sekianafraz-audience-toggle'), audience);
    const panel = $('#sekianafraz-action-fields');
    panel._audienceMotion?.cancel();
    panel._audienceMotion = window.SEKIANAFRAZ_ADMIN_CONTROLS.playMotion(panel,
      [{ opacity: .4, transform: 'translateY(10px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 360 });
    updatePreview();
  }
  function renderActionFields(v) {
    const wrap = $('#sekianafraz-action-fields');
    const draft = captureActionDraft(wrap);
    beginFormLayout(wrap);
    animateFormContent(wrap, true);
    sections().parkControls();
    wrap.dataset.action = v;
    wrap.dataset.previewAudience = 'guest';
    wrap.dataset.bannerStage = '1';
    wrap._bannerType = 'single';
    wrap._guestRadiusModes = { single: 'simple' };
    const optionRow = $('#sekianafraz-banner-options-row');
    optionRow?.replaceChildren();
    setFieldVisible($('#sekianafraz-banner-type-slot'), false);
    $('#sekianafraz-banner-type-slot')?.replaceChildren();
    $('#sekianafraz-close-position-slot')?.replaceChildren();
    if (!['banner', 'sms', 'both'].includes(v)) {
      wrap.removeAttribute('data-action');
      wrap.innerHTML = '';
      setAudienceToggleVisible($('#sekianafraz-audience-toggle'), false);
      animateFormContent(wrap);
      window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS.refreshCouponOwnership();
      window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW.refreshPreviewAvailability();
      try { applyModalCheckboxSkin(document.getElementById('sekianafraz-sensor-modal')); } catch (e) {}
      try { updateVarsTables(document.getElementById('sekianafraz-sensor-modal')); } catch (e) {}
      return;
    }
    if (v === 'sms') {
      wrap.innerHTML = renderSmsConfig('sms', 'sekianafraz-vars');
    } else {
      const placement = basePlacementOf($('#sekianafraz-placement')?.value || 'product_single');
      const vars = filterVarsByCoupon(window.SEKIANAFRAZ_ADMIN_VARS?.[placement]?.banner || []);
      wrap.innerHTML = renderAdditionalBannerFields() +
        (v === 'both' ? '<div class="sekianafraz-field" id="sekianafraz-hide-banner-logged-in-wrap"><label><input type="checkbox" class="ui-checkbox" id="sekianafraz-hide-banner-logged-in"> <span>عدم نمایش بنر برای کاربر وارد شده</span></label></div>' : '') +
        field('عنوان بنر', 'text', 'sekianafraz-banner-title', '', 'پیش‌فرض: تبریک میگم!') +
        field('متن دکمه بنر', 'text', 'sekianafraz-banner-button-text', '', 'پیش‌فرض: بزن بریم!') +
        '<div class="sekianafraz-field sekianafraz-banner-text-field"><label for="sekianafraz-banner-text">متن نمایشی</label><textarea id="sekianafraz-banner-text" rows="4" placeholder="مثلاً: به {{product_name}} علاقه داری؟&#10;فقط تا 24 ساعت مهلت داری این محصول رو با 10 درصد تخفیف بخری؛&#10;کد تخفیف زیر رو توی سبد خرید استفاده کن:" required></textarea><div id="' + (v === 'banner' ? 'sekianafraz-vars' : 'sekianafraz-vars-banner') + '">' + renderVarsTable(vars, true) + '</div></div>' +
        renderBannerImageOptions() + renderBannerColorControls() +
        list('فونت متن‌های بنر', 'sekianafraz-banner-font-type', [['arad', 'استفاده از فونت آراد'], ['inherit', 'استفاده از فونت پیش‌فرض بدنه سایت']]) +
        renderRadiusControls() + renderPaddingControls() + renderMarginControls() + renderSmsConfig('sms', 'sekianafraz-vars-sms');
      $('#sekianafraz-logged-behavior').value = 'single_sms';
      mountBannerStyleControls(wrap);
      wrap._guestAppearance = captureAppearance(wrap);
      wrap._loggedAppearance = { ...wrap._guestAppearance, banner_button_text: '', banner_radius_mode: 'simple' };
      wrap._loggedEdited = false;
    }
    mountSmsConfig('sms', v === 'sms' ? 'sekianafraz-vars' : 'sekianafraz-vars-sms');
    mountSmsConfig('logged-sms', 'sekianafraz-logged-vars');
    mountActionRows(wrap);
    sections().mountAction(wrap, v);
    $('#sekianafraz-banner-type')?.addEventListener('change', () => {
      const root = wrap.querySelector('.sekianafraz-radius-field');
      const next = $('#sekianafraz-banner-type').value;
      const buttonText = $('#sekianafraz-banner-button-text');
      if (buttonText) {
        const current = buttonText.value.trim();
        if (next === 'multi' && (!current || current === 'بزن بریم!')) buttonText.value = 'دریافت تخفیف';
        if (next === 'single' && current === 'دریافت تخفیف') buttonText.value = 'بزن بریم!';
      }
      if (root && wrap.dataset.previewAudience !== 'logged') wrap._guestRadiusModes[wrap._bannerType] = root.dataset.mode;
      if (wrap.dataset.previewAudience === 'logged') switchAudience(wrap, 'guest');
      if (root) {
        const mode = wrap._guestRadiusModes[next] || (next === 'multi' ? 'manual' : 'simple');
        if (mode === 'manual') initializeManualRadii(root);
        root.dataset.appearanceKind = next;
        setRadiusMode(root, mode);
      }
      wrap._bannerType = next;
      refreshBannerConditionalControls(wrap);
    });
    ['sekianafraz-logged-behavior', 'sekianafraz-banner-show-close', 'sekianafraz-banner-close-hide-bg', 'sekianafraz-banner-close-position'].forEach(id =>
      $('#' + id)?.addEventListener('change', () => refreshBannerConditionalControls(wrap)));
    const strategy = $('#sekianafraz-coupon-strategy');
    if (strategy && !strategy.dataset.bannerBound) {
      strategy.dataset.bannerBound = '1';
      strategy.addEventListener('change', () => {
        refreshActionVariableTables(wrap, basePlacementOf($('#sekianafraz-placement')?.value || 'product_single'));
        refreshBannerConditionalControls(wrap);
      });
    }
    const audienceToggle = $('#sekianafraz-audience-toggle');
    if (audienceToggle && !audienceToggle.dataset.audienceBound) {
      audienceToggle.dataset.audienceBound = '1';
      audienceToggle.addEventListener('click', event => {
        const button = event.target.closest('button[data-audience]');
        if (button) switchAudience(wrap, button.dataset.audience);
      });
    }
    syncAudienceToggle(audienceToggle, 'guest');
    if (!wrap.dataset.targetInputBound) {
      wrap.dataset.targetInputBound = '1';
      wrap.addEventListener('input', event => {
        if (event.target.matches('#sekianafraz-sms-text, #sekianafraz-sms-pattern, #sekianafraz-logged-sms-text, #sekianafraz-logged-sms-pattern')) updateSmsTargets();
        if (event.target.id === 'sekianafraz-banner-button-text') updateBannerTarget(wrap);
      });
    }
    $('#sekianafraz-banner-button-closes')?.addEventListener('change', () => updateBannerTarget(wrap));
    const calculation = $('#sekianafraz-visit-calculation');
    if (calculation && !calculation.dataset.targetBound) {
      calculation.dataset.targetBound = '1';
      calculation.addEventListener('change', updateSmsTargets);
    }
    restoreActionDraft(wrap, draft);
    refreshBannerConditionalControls(wrap);
    refreshActionVariableTables(wrap, basePlacementOf($('#sekianafraz-placement')?.value || 'product_single'));
    const imageInput = wrap.querySelector('#sekianafraz-banner-image');
    const removeImage = wrap.querySelector('#sekianafraz-remove-image');
    const svgColor = wrap.querySelector('#sekianafraz-banner-svg-color');
    const svgEl = wrap.querySelector('#sekianafraz-default-svg');
    let mediaFrame = null;
    let pickedImage = false;
    let restoreMode = 'default';
    const selectImageMode = mode => {
      beginFormLayout(wrap);
      if (imageInput.value) imageInput._customImage = imageInput.value;
      imageInput.value = mode === 'custom' ? imageInput._customImage || '' : '';
      syncImageCards(wrap, mode);
      refreshBannerConditionalControls(wrap);
    };
    const openImagePicker = previousMode => {
      if (typeof wp === 'undefined' || !wp.media) return;
      restoreMode = previousMode || getBannerImageMode(wrap);
      pickedImage = false;
      if (!mediaFrame) {
        mediaFrame = wp.media({ title: 'انتخاب تصویر بنر', button: { text: 'استفاده از این تصویر' }, multiple: false, library: { type: 'image' } });
        mediaFrame.on('select', () => {
          const attachment = mediaFrame.state().get('selection')?.first()?.toJSON();
          if (!attachment) return;
          if (attachment.filesizeInBytes > 500 * 1024) { alert('حجم تصویر نباید بیشتر از 500 کیلوبایت باشد.'); return; }
          pickedImage = true;
          imageInput._customImage = attachment.url;
          selectImageMode('custom');
          imageInput.dispatchEvent(new Event('change', { bubbles: true }));
        });
        mediaFrame.on('close', () => {
          if (!pickedImage && !imageInput.value && getBannerImageMode(wrap) === 'custom') selectImageMode(restoreMode === 'custom' ? 'default' : restoreMode);
        });
      }
      mediaFrame.open();
    };
    if (imageInput) {
      wrap.querySelectorAll('[name="sekianafraz-banner-image-mode"]').forEach(input => input.addEventListener('change', () => {
        if (!input.checked) return;
        const previousMode = getBannerImageMode(wrap);
        selectImageMode(input.value);
        if (input.value === 'custom') openImagePicker(previousMode);
      }));
      wrap.querySelector('[data-image-mode="custom"]')?.addEventListener('click', event => {
        if (getBannerImageMode(wrap) !== 'custom') return;
        event.preventDefault();
        openImagePicker('custom');
      });
      removeImage?.addEventListener('click', () => {
        imageInput.value = '';
        imageInput._customImage = '';
        selectImageMode('default');
        imageInput.dispatchEvent(new Event('change', { bubbles: true }));
      });
      syncImageCards(wrap);
    }
    svgColor?.addEventListener('input', () => {
      if (!svgEl) return;
      const defaultCard = svgEl.closest('[data-image-mode="default"]');
      if (defaultCard) defaultCard.style.color = svgColor.value;
      svgEl.setAttribute('fill', svgColor.value);
    });
    applyNumberGuards();
    animateFormContent(wrap);
    animateFormContent(optionRow);
    const entryTargets = [$('#sekianafraz-banner-type-slot'), $('#sekianafraz-reaction-options'), $('#sekianafraz-logged-behavior-slot'), ...wrap.querySelectorAll(':scope > .sekianafraz-sensor-section')].filter(el => el && !el.hidden && getComputedStyle(el).display !== 'none');
    entryTargets.forEach((el, index) => {
      el._actionEntryMotion?.cancel();
      const motion = playMotion(el, [{ opacity: 0, transform: 'translateY(12px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 420, delay: index * 45, fill: 'both' });
      el._actionEntryMotion = motion;
      motion?.finished.then(() => {
        if (el._actionEntryMotion !== motion) return;
        motion.cancel();
        el._actionEntryMotion = null;
      }).catch(() => {});
    });
    window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS.refreshCouponOwnership();
    try { applyModalCheckboxSkin(document.getElementById('sekianafraz-sensor-modal')); } catch (e) {}
    try { updateVarsTables(document.getElementById('sekianafraz-sensor-modal')); } catch (e) {}
  }
  window.SEKIANAFRAZ_ADMIN_SENSOR_ACTIONS = {
    renderActionFields, refreshBannerConditionalControls, refreshActionVariableTables, updateSmsTargets, getBannerImageMode,
    renderReminderStyleControls, mountReminderStyleControls, collectReminderStyles, applyReminderStyles, appearanceFields,
    renderRadiusControls,
    renderPaddingControls,
    mountBannerStyleControls,
    collectBannerRadiusState,
    applyBannerRadiusState,
    collectBannerMarginState,
    applyBannerMarginState,
    collectBannerPaddingState,
    applyBannerPaddingState,
    collectBannerVariants,
    applyBannerVariants,
    setSmsDelayMinutes,
    multiFields,
    multiColors
  };
})();
