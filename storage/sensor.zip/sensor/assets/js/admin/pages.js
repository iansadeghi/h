(function () {
  const { $, $all, api, withBtnLoader, toast } = window.SEKIANAFRAZ_ADMIN_CORE;
  const lifecycle = () => window.SEKIANAFRAZ_ADMIN_SENSOR_LIFECYCLE;
  const openModalForAdd = (...args) => lifecycle().openModalForAdd(...args);
  const showDeleteConfirm = (...args) => lifecycle().showDeleteConfirm(...args);
  const openModal = (...args) => lifecycle().openModal(...args);
  const prefillSensor = (...args) => lifecycle().prefillSensor(...args);
  const showConflictConfirm = (...args) => lifecycle().showConflictConfirm(...args);
  function mountSms() {
    const container = $('#sekianafraz-sms-provider-fields');
    const sel = $('#sekianafraz-sms-provider'); if (!sel) return;
    let fieldsRequest = 0;
    async function loadFields() {
      const request = ++fieldsRequest;
      const provider = sel.value;
      container.classList.add('is-loading');
      container.setAttribute('aria-live', 'polite');
      container.innerHTML = '<div class="sekianafraz-provider-loader" role="status"><span class="sekianafraz-provider-loader__spinner" aria-hidden="true"></span><span>درحال بارگذاری...</span></div>';
      let j;
      try {
        j = await api('sms/fields?provider=' + encodeURIComponent(provider));
      } catch (err) {
        if (request !== fieldsRequest) return;
        container.classList.remove('is-loading');
        container.innerHTML = '';
        toast(err && err.message ? err.message : 'خطا در بارگذاری تنظیمات درگاه');
        return;
      }
      if (request !== fieldsRequest || provider !== sel.value) return;
      const frag = document.createDocumentFragment();
      (j.fields || []).forEach(f => {
        const wrap = document.createElement('div'); wrap.className = 'sekianafraz-field';
        const lab = document.createElement('label'); lab.textContent = f.label; wrap.appendChild(lab);
        const inp = document.createElement('input');
        inp.required = true;
        inp.type = f.type === 'password' ? 'password' : 'text';
        inp.value = f.value || '';
        inp.dataset.key = f.key;
        inp.name = `sekianafraz_sms_${sel.value}_${f.key}`;
        inp.autocomplete = f.type === 'password' ? 'new-password' : 'off';
        inp.autocapitalize = 'none';
        inp.spellcheck = false;
        inp.readOnly = true;
        inp.addEventListener('focus', () => { inp.readOnly = false; }, { once: true });
        inp.setAttribute('data-lpignore', 'true');
        inp.setAttribute('data-1p-ignore', 'true');
        inp.setAttribute('data-bwignore', 'true');
        wrap.appendChild(inp);
        frag.appendChild(wrap);
      });
      container.classList.remove('is-loading');
      container.innerHTML = ''; container.appendChild(frag);
      const btnResolve = $('#sekianafraz-test-resolve');
      if (btnResolve && !btnResolve.dataset.sekianafrazBound) {
        btnResolve.dataset.sekianafrazBound = '1';
        btnResolve.addEventListener('click', withBtnLoader(btnResolve, async () => {
          const uid = parseInt(($('#sekianafraz-user-id').value || '0'), 10) || 0; if (!uid) return;
          const r = await api('phone/resolve?user_id=' + uid, { method: 'GET' });
          toast(r.success ? `کاربر شناسایی شد: ${r.phone || ''}` : 'کاربر شناسایی نشد!');
        }));
      }
      const btnPromo = $('#sekianafraz-test-promo');
      if (btnPromo && !btnPromo.dataset.sekianafrazBound) {
        btnPromo.dataset.sekianafrazBound = '1';
        btnPromo.addEventListener('click', withBtnLoader(btnPromo, async () => {
          const phone = $('#sekianafraz-dest-1').value.trim(); if (!phone) return;
          const r = await api('sms/test_promo', { method: 'POST', data: { phone } });
          toast(r.success ? 'تبریک؛ وب‌سرویس تبلیغاتی به‌خوبی کار می‌کند.' : (r.message || 'خطا در ارسال تبلیغاتی'));
        }));
      }
      const btnPattern = $('#sekianafraz-test-pattern');
      if (btnPattern && !btnPattern.dataset.sekianafrazBound) {
        btnPattern.dataset.sekianafrazBound = '1';
        btnPattern.addEventListener('click', withBtnLoader(btnPattern, async () => {
          const phone = $('#sekianafraz-dest-2').value.trim(); const template = $('#sekianafraz-pattern-code').value.trim(); if (!phone || !template) return;
          const r = await api('sms/test_pattern', { method: 'POST', data: { phone, template } });
          toast(r.success ? 'تبریک؛ ارسال وب‌سرویس خدماتی (پترن) موفق بود.' : (r.message || 'خطا در ارسال وب‌سرویس خدماتی (پترن)'));
        }));
      }
    }
    sel.addEventListener('change', loadFields);
    loadFields();
    const saveBtn = $('#sekianafraz-sms-save');
    saveBtn && saveBtn.addEventListener('click', withBtnLoader(saveBtn, async () => {
      const config = {}; $all('#sekianafraz-sms-provider-fields [data-key]').forEach(i => config[i.dataset.key] = i.value);
      await api('sms/save', { method: 'POST', data: { provider: sel.value, config } });
    }));
    const testBtn = $('#sekianafraz-sms-test');
    testBtn && testBtn.addEventListener('click', withBtnLoader(testBtn, async () => {
      const j = await api('sms/test', { method: 'POST', data: {} });
      if (!j || !j.success) {
        toast(j && j.message ? j.message : 'اتصال به درگاه ناموفق بود.');
        return;
      }
      const balance = (j.balance !== null && j.balance !== undefined) ? j.balance : 'نامشخص';
      toast(`موجودی شما: ${balance}`);
    }));
  }
  function mountCompat() {
    const list = $('#sekianafraz-compat-list');
    if (!list) return;
    const nameInput = $('#sekianafraz-compat-name');
    const metaInput = $('#sekianafraz-compat-meta');
    const saveBtn = $('#sekianafraz-compat-save');
    const scanBtn = $('#sekianafraz-compat-scan');
    const closeSvg = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M5 5l10 10M15 5L5 15" fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"/></svg>';
    const createRow = (item) => {
      const li = document.createElement('li');
      li.className = 'sekianafraz-compat-item is-custom';
      li.dataset.id = item.id;
      li.dataset.metaKey = item.meta_key || '';
      const label = document.createElement('span');
      label.textContent = item.label || '';
      li.appendChild(label);
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'sekianafraz-compat-remove';
      btn.setAttribute('aria-label', 'حذف سازگاری');
      btn.innerHTML = closeSvg;
      li.appendChild(btn);
      return li;
    };
    list.addEventListener('click', async (e) => {
      const btn = e.target.closest('.sekianafraz-compat-remove');
      if (!btn) return;
      const li = btn.closest('li');
      const id = li && li.dataset ? li.dataset.id : '';
      if (!id) return;
      btn.disabled = true;
      try {
        const j = await api('phone/compat/remove', { method: 'POST', data: { id } });
        if (j && j.success) {
          li.remove();
        } else {
          toast(j && j.message ? j.message : 'خطا در حذف سازگاری');
        }
      } catch (err) {
        toast('خطا در حذف سازگاری');
      } finally {
        btn.disabled = false;
      }
    });
    if (scanBtn && !scanBtn.dataset.sekianafrazBound) {
      scanBtn.dataset.sekianafrazBound = '1';
      scanBtn.addEventListener('click', async () => {
        if (scanBtn.dataset.loading === '1') return;
        scanBtn.dataset.loading = '1';
        scanBtn.disabled = true;
        scanBtn.classList.add('is-loading');
        scanBtn.setAttribute('aria-busy', 'true');
        try {
          const j = await api('phone/compat/scan', { method: 'POST', data: {} });
          if (!j || !j.success) {
            toast(j && j.message ? j.message : 'خطا در شناسایی متای شماره تلفن');
            return;
          }
          const items = Array.isArray(j.items) ? j.items : [];
          let added = 0;
          items.forEach((item) => {
            const metaKey = item && item.meta_key ? String(item.meta_key) : '';
            if (!metaKey) return;
            const duplicate = Array.from(list.querySelectorAll('[data-meta-key]')).some((row) => row.dataset.metaKey === metaKey);
            if (duplicate) return;
            list.appendChild(createRow(item));
            added++;
          });
          if (added > 0) {
            toast(added + ' کلید متای شماره تلفن شناسایی و اضافه شد.' + (j.limit_reached ? ' ظرفیت سازگاری سفارشی تکمیل شد.' : ''));
          } else if (j.limit_reached) {
            toast('ظرفیت ۵۰ سازگاری سفارشی تکمیل است.');
          } else {
            toast('متای شماره تلفن جدیدی پیدا نشد.');
          }
        } catch (err) {
          toast(err && err.message ? err.message : 'خطا در شناسایی متای شماره تلفن');
        } finally {
          scanBtn.dataset.loading = '';
          scanBtn.disabled = false;
          scanBtn.classList.remove('is-loading');
          scanBtn.removeAttribute('aria-busy');
        }
      });
    }
    saveBtn && saveBtn.addEventListener('click', withBtnLoader(saveBtn, async () => {
      const label = (nameInput && nameInput.value || '').trim();
      const metaKey = (metaInput && metaInput.value || '').trim();
      if (!label || !metaKey) {
        toast('نام و کلید متا را وارد کنید.');
        return;
      }
      const j = await api('phone/compat/add', { method: 'POST', data: { label, meta_key: metaKey } });
      if (!j || !j.success) {
        toast(j && j.message ? j.message : 'خطا در ذخیره سازگاری');
        return;
      }
      const existing = list.querySelector('[data-id="' + j.item.id + '"]');
      if (!existing && !j.duplicate) {
        list.appendChild(createRow(j.item));
      }
      if (nameInput) nameInput.value = '';
      if (metaInput) metaInput.value = '';
    }));
  }
  function mountSensors() {
    const add = $('#sekianafraz-add-sensor'); if (!add) return;
    lifecycle().warmAddModal();
    add.addEventListener('click', () => openModalForAdd());
    const bulkWrap = $('#sekianafraz-bulk-actions');
    const selectAll = $('#sekianafraz-select-all');
    const tableBody = $('#sekianafraz-sensors-body');
    const loader = $('#sekianafraz-sensor-loader');
    const getRowChecks = () => $all('.sekianafraz-sensor-select');
    const setBulkActionsVisible = visible => window.SEKIANAFRAZ_ADMIN_CORE.setBulkActionsVisible(bulkWrap, visible);
    const updateBulkState = () => {
      const rowChecks = getRowChecks();
      const selectedCount = rowChecks.filter(c => c.checked).length;
      setBulkActionsVisible(selectedCount > 0);
      if ($('#sekianafraz-bulk-enable')) $('#sekianafraz-bulk-enable').textContent = 'فعال کردن همه (' + selectedCount + ')';
      if ($('#sekianafraz-bulk-disable')) $('#sekianafraz-bulk-disable').textContent = 'غیرفعال کردن همه (' + selectedCount + ')';
      if ($('#sekianafraz-bulk-delete')) $('#sekianafraz-bulk-delete').textContent = 'حذف همه (' + selectedCount + ')';
      if (selectAll) selectAll.checked = rowChecks.length > 0 && rowChecks.every(c => c.checked);
    };
    if (selectAll) {
      selectAll.addEventListener('change', () => {
        getRowChecks().forEach(c => { c.checked = selectAll.checked; });
        updateBulkState();
      });
    }
    const bulkEnable = $('#sekianafraz-bulk-enable');
    const bulkDisable = $('#sekianafraz-bulk-disable');
    const bulkDelete = $('#sekianafraz-bulk-delete');
    const getSelectedIds = () => getRowChecks().filter(c => c.checked).map(c => parseInt(c.dataset.id, 10)).filter(Boolean);
    const setRowStatus = (button, enabled) => {
      button.setAttribute('aria-pressed', enabled ? 'true' : 'false');
      button.querySelector('.rsad-status-label').textContent = enabled ? 'غیرفعال‌سازی' : 'فعال‌سازی';
      const statusCell = button.closest('tr')?.querySelector('.sekianafraz-sensor-status');
      if (statusCell) statusCell.textContent = enabled ? 'فعال' : 'غیرفعال';
    };
    if (bulkEnable) {
      bulkEnable.addEventListener('click', withBtnLoader(bulkEnable, async () => {
        const ids = getSelectedIds(); if (!ids.length) return;
        try {
          await api('sensors/bulk', { method: 'POST', data: { action: 'enable', ids } });
          location.reload();
        } catch (error) {
          toast((error && error.message) || 'خطا در فعال‌سازی سنسورها', { id: 'sekianafraz-global-alert', timeout: 5000 });
        }
      }));
    }
    if (bulkDisable) {
      bulkDisable.addEventListener('click', withBtnLoader(bulkDisable, async () => {
        const ids = getSelectedIds(); if (!ids.length) return;
        try {
          await api('sensors/bulk', { method: 'POST', data: { action: 'disable', ids } });
          location.reload();
        } catch (error) {
          toast((error && error.message) || 'خطا در غیرفعال‌سازی سنسورها', { id: 'sekianafraz-global-alert', timeout: 5000 });
        }
      }));
    }
    if (bulkDelete) {
      bulkDelete.addEventListener('click', withBtnLoader(bulkDelete, async () => {
        const ids = getSelectedIds(); if (!ids.length) return;
        showDeleteConfirm(ids);
      }));
    }
    if (tableBody) {
      tableBody.addEventListener('change', async (e) => {
        const target = e.target;
        if (target.classList.contains('sekianafraz-sensor-select')) {
          updateBulkState();
          return;
        }
      });
      tableBody.addEventListener('click', async (e) => {
        const target = e.target.closest('.sekianafraz-status-toggle');
        if (target) {
          if (target.disabled) return;
          const id = parseInt(target.dataset.id, 10);
          const status = target.getAttribute('aria-pressed') === 'true' ? 'draft' : 'publish';
          target.disabled = true;
          let pendingConflict = false;
          toast('در حال ذخیره…', { id: 'sekianafraz-global-alert', sticky: true });
          try {
            const res = await api('sensors/status', { method: 'POST', data: { id, status } });
            if (!res || res.success !== true) {
              const msg = (res && (res.message || res.code)) ? String(res.message || res.code) : 'خطا در تغییر وضعیت سنسور';
              throw new Error(msg);
            }
            setRowStatus(target, status === 'publish');
            toast(status === 'publish' ? 'سنسور فعال شد' : 'سنسور غیرفعال شد', { id: 'sekianafraz-global-alert', timeout: 1500 });
          } catch (err) {
            if (err && err.code === 'PLACEMENT_CONFLICT' && status === 'publish') {
              pendingConflict = true;
              toast('برای فعال‌سازی، تداخل مکان‌ها را مشخص کنید.', { id: 'sekianafraz-global-alert', timeout: 2200 });
              showConflictConfirm(
                err,
                async (resolution) => {
                  const result = await api('sensors/status', { method: 'POST', data: { id, status, conflict_resolution: resolution } });
                  if (!result || result.success !== true) throw new Error((result && result.message) || 'خطا در تغییر وضعیت سنسور');
                  setRowStatus(target, true);
                  target.disabled = false;
                  toast('سنسور فعال شد', { id: 'sekianafraz-global-alert', timeout: 1500 });
                },
                () => { target.disabled = false; },
                'activation'
              );
              return;
            }
            const msg = (err && err.message) ? String(err.message) : 'خطا در تغییر وضعیت سنسور';
            toast(msg, { id: 'sekianafraz-global-alert', timeout: 4500 });
          } finally {
            if (!pendingConflict) target.disabled = false;
          }
          return;
        }
        const btn = e.target.closest('[data-delete],[data-edit]');
        if (!btn) return;
        if (btn.hasAttribute('data-delete')) {
          const id = btn.getAttribute('data-delete');
          showDeleteConfirm(id);
          return;
        }
        if (btn.hasAttribute('data-edit')) {
          const id = btn.getAttribute('data-edit');
          openModal();
          await prefillSensor(parseInt(id, 10));
        }
      });
    }
    const buildRow = (item) => {
      const enabled = item.status === 'publish';
      const escapeHtml = (value) => String(value == null ? '' : value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));
      const id = escapeHtml(item.id);
      const chips = (item.item_labels || []).map(lab => '<span class="sekianafraz-chip" style="cursor:default">' + escapeHtml(lab) + '</span>').join(' ');
      const metric = item.visit_metric || 'views';
      const condition = metric === 'duration'
        ? String(item.min_duration || 1) + ' ثانیه بازدید'
        : (metric === 'both' ? String(item.min_views || 1) + ' بار بازدید ' + (item.visit_condition === 'and' ? 'و' : 'یا') + ' ' + String(item.min_duration || 1) + ' ثانیه بازدید' : String(item.min_views || 1) + ' بار بازدید');
      return '<tr>'
        + '<td class="sekianafraz-select-col"><label class="checkBox"><input type="checkbox" class="sekianafraz-sensor-select" data-id="' + id + '"><div class="transition"></div></label></td>'
        + '<td>' + escapeHtml(item.name) + '</td>'
        + '<td class="sekianafraz-sensor-status">' + (enabled ? 'فعال' : 'غیرفعال') + '</td>'
        + '<td>' + escapeHtml(condition) + '</td>'
        + '<td>' + escapeHtml(item.window) + '</td>'
        + '<td>' + chips + '</td>'
        + '<td class="rsad-actions-td"><div class="rsad-actions"><button type="button" class="rsad-btn rsad-btn--status sekianafraz-status-toggle" data-id="' + id + '" aria-pressed="' + (enabled ? 'true' : 'false') + '"><span class="rsad-status-radio" aria-hidden="true"></span><span class="rsad-status-label">' + (enabled ? 'غیرفعال‌سازی' : 'فعال‌سازی') + '</span></button><button type="button" class="rsad-btn rsad-btn--edit" data-edit="' + id + '"><span class="dashicons dashicons-edit"></span>ویرایش</button><button type="button" class="rsad-btn rsad-btn--delete" data-delete="' + id + '"><span class="dashicons dashicons-trash"></span>حذف</button></div></td>'
        + '</tr>';
    };
    const loadMore = async () => {
      if (!tableBody || !loader) return;
      if (tableBody.dataset.loading === '1') return;
      if (tableBody.dataset.hasMore !== '1') return;
      tableBody.dataset.loading = '1';
      loader.hidden = false;
      const nextPage = parseInt(tableBody.dataset.page || '1', 10) + 1;
      try {
        const res = await api('sensors/list?page=' + nextPage + '&per_page=20', { method: 'GET' });
        const rows = (res.items || []).map(buildRow).join('');
        tableBody.insertAdjacentHTML('beforeend', rows);
        tableBody.dataset.page = String(nextPage);
        tableBody.dataset.hasMore = res.has_more ? '1' : '0';
      } finally {
        tableBody.dataset.loading = '';
        loader.hidden = true;
      }
    };
    if (tableBody) {
      window.addEventListener('scroll', () => {
        const rect = tableBody.getBoundingClientRect();
        if (rect.bottom - window.innerHeight < 200) loadMore();
      });
    }
    updateBulkState();
  }
  function mountLeads() {
    const button = $('#sekianafraz-leads-load-more'), body = $('#sekianafraz-leads-body');
    if (!button || !body) return;
    const selectAll = $('#sekianafraz-leads-select-all'), bulk = $('#sekianafraz-leads-bulk');
    const empty = $('#sekianafraz-leads-empty'), table = body.closest('table');
    const updateEmpty = () => {
      const isEmpty = !body.querySelector('tr[data-id]');
      empty.hidden = !isEmpty || hasMore; table.hidden = isEmpty;
      if (isEmpty) { selectAll.checked = false; selectAll.indeterminate = false; }
    };
    const statuses = { sent: 'ارسال‌شده', failed: 'ناموفق', pending: 'در انتظار' };
    let loading = false, hasMore = body.dataset.hasMore === '1';
    const checks = () => Array.from(body.querySelectorAll('.sekianafraz-lead-select'));
    const selected = () => checks().filter(c => c.checked).map(c => Number(c.dataset.id));
    const renderOwner = (cell, accounts, pending = false) => {
      if (!cell) return;
      cell.replaceChildren();
      cell.dataset.ownerStatus = pending ? 'pending' : (accounts.length ? 'matched' : 'unmatched');
      if (pending) { cell.append(document.createTextNode('در انتظار تطبیق')); return; }
      if (!accounts.length) { cell.append(document.createTextNode('ناموجود')); return; }
      cell.append(document.createTextNode('بله · '));
      accounts.forEach((account, i) => {
        if (i) cell.append(document.createTextNode('، '));
        const a = document.createElement('a'); a.textContent = account.name;
        const url = new URL('user-edit.php', location.href); url.searchParams.set('user_id', account.id); a.href = url.href;
        cell.append(a);
      });
    };
    let ownerRefreshBusy = false, ownerRefreshTimer = 0;
    const pendingOwnerIds = () => Array.from(body.querySelectorAll('tr[data-id] [data-owner-cell][data-owner-status="pending"]'))
      .map(cell => Number(cell.closest('tr')?.dataset.id)).filter(Boolean).slice(0, 50);
    const scheduleOwnerRefresh = (delay = 1500) => {
      clearTimeout(ownerRefreshTimer);
      if (!body.isConnected || !pendingOwnerIds().length) return;
      ownerRefreshTimer = setTimeout(refreshPendingOwners, delay);
    };
    const refreshPendingOwners = async () => {
      if (ownerRefreshBusy || !body.isConnected) return;
      const ids = pendingOwnerIds();
      if (!ids.length) return;
      ownerRefreshBusy = true;
      try {
        const result = await api('leads/owners', {method:'POST', data:{ids}});
        const waiting = new Set((result.pending_ids || []).map(Number));
        ids.forEach(id => {
          if (waiting.has(id)) return;
          const cell = body.querySelector('tr[data-id="' + id + '"] [data-owner-cell]');
          const accounts = (result.items && (result.items[id] || result.items[String(id)])) || [];
          renderOwner(cell, accounts, false);
        });
      } catch (_) {
      } finally {
        ownerRefreshBusy = false;
        scheduleOwnerRefresh(3000);
      }
    };
    const updateBulk = () => {
      const ids = selected();
      window.SEKIANAFRAZ_ADMIN_CORE.setBulkActionsVisible(bulk, ids.length > 0);
      selectAll.checked = checks().length > 0 && checks().every(c => c.checked);
      selectAll.indeterminate = ids.length > 0 && !selectAll.checked;
      bulk.querySelectorAll('[data-leads-export]').forEach(a => {
        const url = new URL(a.dataset.exportBase, location.href); url.searchParams.set('ids', ids.join(',')); a.href = url.href;
      });
    };
    const rowFor = item => {
      const tr = document.createElement('tr'); tr.dataset.id = item.id;
      const select = document.createElement('td'); select.className = 'sekianafraz-select-col';
      select.innerHTML = '<label class="checkBox"><input type="checkbox" class="sekianafraz-lead-select" aria-label="انتخاب شماره"><div class="transition"></div></label>';
      select.querySelector('input').dataset.id = item.id; tr.append(select);
      [item.phone, item.sensor_name + ' #' + item.sensor_id, statuses[item.sms_status] || 'در انتظار', item.created_local].forEach((value, i) => {
        const td = document.createElement('td'); td.textContent = String(value ?? ''); if (i === 0 || i === 3) td.dir = 'ltr'; tr.append(td);
      });
      const owner = document.createElement('td'); owner.dataset.ownerCell = '';
      owner.dataset.ownerStatus = item.owner_status || 'pending';
      const accounts = item.owners || [];
      owner.append(document.createTextNode(item.owner_status === 'pending' ? 'در انتظار تطبیق' : accounts.length ? 'بله · ' : 'ناموجود'));
      if (item.owner_status !== 'pending') accounts.forEach((account, i) => {
        if (i) owner.append(document.createTextNode('، '));
        const a = document.createElement('a'); a.textContent = account.name;
        const url = new URL('user-edit.php', location.href); url.searchParams.set('user_id', account.id); a.href = url.href;
        owner.append(a);
      });
      tr.append(owner);
      const action = document.createElement('td'); action.className = 'rsad-actions-td';
      action.innerHTML = '<div class="rsad-actions"><button type="button" class="rsad-btn rsad-btn--delete" data-lead-delete><span class="dashicons dashicons-trash"></span>حذف</button></div>';
      tr.append(action); return tr;
    };
    const load = async () => {
      if (loading || !hasMore || !body.isConnected) return;
      loading = true; const done = window.SEKIANAFRAZ_ADMIN_CORE.startButtonLoading(button, 'بارگذاری');
      try {
        const data = await api('leads/list?before=' + encodeURIComponent(body.dataset.nextBefore));
        if (!body.isConnected) return;
        (data.items || []).forEach(item => body.append(rowFor(item)));
        body.dataset.nextBefore = String(data.next_before || 0); hasMore = !!data.has_more;
        updateEmpty(); button.hidden = !hasMore;
        updateBulk(); scheduleOwnerRefresh();
      } catch (error) {
        if (body.isConnected) { button.hidden = false; toast(error.message || 'دریافت شماره‌ها انجام نشد.'); }
      } finally { loading = false; done(); }
    };
    const remove = ids => {
      if (!ids.length) return;
      if (ids.length > 500) { toast('در هر عملیات حداکثر ۵۰۰ شماره انتخاب کنید.'); return; }
      lifecycle().showDeleteConfirm(ids, async () => {
        await api('leads/delete', {method:'POST', data:{ids}});
        ids.forEach(id => body.querySelector('tr[data-id="' + id + '"]')?.remove());
        updateEmpty(); updateBulk();
        if (hasMore && !body.querySelector('tr[data-id]')) load();
      });
    };
    body.addEventListener('change', updateBulk);
    body.addEventListener('click', event => { if (event.target.closest('[data-lead-delete]')) remove([Number(event.target.closest('tr').dataset.id)]); });
    selectAll.addEventListener('change', () => { checks().forEach(c => {c.checked = selectAll.checked;}); updateBulk(); });
    $('#sekianafraz-leads-delete').addEventListener('click', () => remove(selected()));
    bulk.querySelectorAll('[data-leads-export]').forEach(a => a.addEventListener('click', event => { if (selected().length > 500) { event.preventDefault(); toast('در هر خروجی حداکثر ۵۰۰ شماره انتخاب کنید.'); } }));
    button.addEventListener('click', load);
    if (window.IntersectionObserver) {
      const observer = new IntersectionObserver(entries => {
        if (!body.isConnected) { observer.disconnect(); return; }
        if (entries.some(entry => entry.isIntersecting) ) load();
      }, {rootMargin:'200px'});
      observer.observe(button);
    }
    updateEmpty(); updateBulk(); scheduleOwnerRefresh();
  }
  window.SEKIANAFRAZ_ADMIN_PAGES = { mountSms, mountCompat, mountSensors, mountLeads };
})();
