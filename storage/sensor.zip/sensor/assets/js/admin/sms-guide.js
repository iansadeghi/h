(function () {
  const { $ } = window.SEKIANAFRAZ_ADMIN_CORE;
  const icons = {
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>',
    copy: '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="8" y="8" width="11" height="11" rx="2"></rect><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"></path></svg>',
    close: '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>'
  };
  let active = null;
  function escText(value) {
    return String(value).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }
  function escAttr(value) {
    return escText(value).replace(/"/g, '&quot;').replace(/\n/g, '&#10;');
  }
  function isGuestMultiSms(prefix) {
    const wrap = $('#sekianafraz-action-fields');
    return prefix === 'sms' && !!wrap && wrap.dataset.action !== 'sms' && $('#sekianafraz-banner-type')?.value === 'multi';
  }
  function locationKey() {
    const placement = String($('#sekianafraz-placement')?.value || 'product_single').replace(/_all$/, '');
    const catalog = window.SEKIANAFRAZ_ADMIN_VARS?.[placement] || window.SEKIANAFRAZ_ADMIN_VARS?.product_single;
    return catalog?.promo?.[0]?.key || 'product_name';
  }
  function paragraph(text) {
    return '<p>' + escText(text) + '</p>';
  }
  function note(kind, body) {
    return '<div class="sekianafraz-guide-note is-' + kind + '" role="note">' +
      '<span class="sekianafraz-guide-note-icon">' + icons.alert + '</span>' +
      '<div class="sekianafraz-guide-note-body">' + body + '</div></div>';
  }
  function lineHtml(line) {
    const dir = /[\u0600-\u06FF]/.test(line) ? 'rtl' : 'ltr';
    const body = escText(line).replace(/\{\{[a-z_]+\}\}|site\.com(?:\/\{\d+\})?|\{\d+\}/g, token => '<bdi dir="ltr">' + token + '</bdi>');
    return '<div class="sekianafraz-guide-line" dir="' + dir + '">' + body + '</div>';
  }
  function sample(title, lines, direction) {
    const text = lines.join('\n');
    return '<section class="sekianafraz-guide-section">' +
      '<div class="sekianafraz-guide-section-title">' + escText(title) + '</div>' +
      '<div class="sekianafraz-guide-sample is-' + direction + '">' +
      '<button type="button" class="sekianafraz-copy-variable" data-copy-variable="' + escAttr(text) + '" aria-label="کپی نمونه">' + icons.copy +
      '<span class="sekianafraz-copy-variable-tooltip" role="status">کپی شد!</span></button>' +
      '<div class="sekianafraz-guide-sample-text">' +
      lines.map(lineHtml).join('') +
      '</div></div></section>';
  }
  function promoBody(multiGuest) {
    const lines = multiGuest ? [
      'کاربر عزیز!',
      'کد تخفیف دریافتی شما:',
      '{{coupon_code}}',
      'با این کد می‌توانید از 20% تخفیف تا 24 ساعت دیگر استفاده کنید.',
      'خرید از:',
      'site.com',
      'لغو11'
    ] : [
      '{{display_name}} عزیز!',
      'به {{' + locationKey() + '}} علاقه داری؟',
      'تا 24 ساعت دیگه میتونی از 1 میلیون تومان تخفیف ویژه استفاده کنی😍',
      'کد تخفیف:',
      '{{coupon_code}}',
      'خرید از:',
      '{{target_url}}',
      'لغو11'
    ];
    return note('warning', paragraph('ارسال از وب‌سرویس تبلیغاتی، پیام را به احتمال 100% به کاربر مخابره نمی‌کند! در این روش ممکن است پیام شما به بلک‌لیست کاربر برود.')) +
      note('danger', paragraph('در این نوع پیام، گذاشتن عبارت «لغو11» در پایان پیام الزامی است و درصورت نگذاشتن این عبارت، پیام شما توسط اپراتور دریافت نخواهد شد.')) +
      sample('نمونه پیامک ارسالی:', lines, 'rtl');
  }
  function patternBody(multiGuest) {
    const couponIndex = multiGuest ? 0 : 1;
    const targetIndex = multiGuest ? 1 : 2;
    const greeting = 'به نظر میاد دوره وبمستر هوشمند نظرتو جلب کرده👀';
    const provider = multiGuest ? [
      'کد تخفیف درخواستی شما:',
      '{' + couponIndex + '}',
      'دقت بفرمائید که فقط تا 24 ساعت دیگر امکان استفاده از این کد را دارید.',
      'خرید از:',
      'site.com/{' + targetIndex + '}'
    ] : [
      '{0} عزیز ' + greeting,
      'تا 24 ساعت فرصت داری از 240000 تومان تخفیف ویژه استفاده کنی🎉',
      'کد تخفیف:',
      '{' + couponIndex + '}',
      'خرید از',
      'site.com/{' + targetIndex + '}'
    ];
    const panel = ['12345'].concat(multiGuest ? [] : ['{{display_name}}'], ['{{coupon_code}}', '{{target_url}}']);
    return note('warning', paragraph('برای استفاده از وب‌سرویس خدماتی، به پنل ارائه‌دهنده خدمات پیامکی خود (مانند ملی پیامک) مراجعه فرمائید و پترن خود را ایجاد کنید، به جای هر متغیر، از ابتدای متن، به صورت ترتیبی از {0} به بالا استفاده کنید (مثال را بررسی کنید).')) +
      note('warning', paragraph('اگر پترن شما علی‌رغم رعایت استانداردهایی که در این راهنما گفته شده، تأیید نشد، به ما تیکت بزنید؛ هرچند قوانین ارسال پیامک تبلیغاتی کاملا تابع سیاست‌های ارائه‌دهنده و اپراتورها است.')) +
      note('danger', paragraph('آدرس سایت شما باید در انتهای پیام موجود باشد و محتوای سایت برای کارشناس ارائه‌دهنده خدمات پیامکی، باید مشخص باشد.') +
        paragraph('می‌توانید از الگوی زیر برای ارائه آدرس صفحه مورد نظر استفاده کنید:') +
        '<code class="sekianafraz-guide-code" dir="ltr">site.com/{' + targetIndex + '}</code>') +
      sample('نمونه متن برای ارسال در پنل ارائه‌دهنده', provider, 'rtl') +
      sample('نمونه متن برای قرار دادن در پنل سنسور', panel, 'ltr');
  }
  function close(immediate) {
    if (!active) return;
    const { layer, trigger, onKey } = active;
    active = null;
    document.removeEventListener('keydown', onKey, true);
    layer.classList.remove('is-open');
    if (immediate) layer.remove();
    else setTimeout(() => layer.remove(), 240);
    if (trigger && trigger.isConnected) trigger.focus({ preventScroll: true });
  }
  function open(prefix, trigger) {
    close(true);
    const pattern = $('#sekianafraz-' + prefix + '-mode')?.value === 'pattern';
    const multiGuest = isGuestMultiSms(prefix);
    const layer = document.createElement('div');
    layer.className = 'sekianafraz-guide-layer';
    layer.innerHTML = '<section class="sekianafraz-guide-dialog" role="dialog" aria-modal="true" aria-label="راهنمای نگارش">' +
      '<header class="sekianafraz-guide-header"><span class="sekianafraz-guide-title">راهنمای نگارش</span>' +
      '<button type="button" class="sekianafraz-guide-close" aria-label="بستن">' + icons.close + '</button></header>' +
      '<div class="sekianafraz-guide-body">' + (pattern ? patternBody(multiGuest) : promoBody(multiGuest)) + '</div></section>';
    const onKey = event => {
      if (event.key === 'Escape') {
        event.preventDefault();
        event.stopPropagation();
        close();
        return;
      }
      if (event.key !== 'Tab') return;
      const focusables = Array.from(layer.querySelectorAll('button')).filter(item => item.offsetParent !== null);
      if (!focusables.length) return;
      const index = focusables.indexOf(document.activeElement);
      event.preventDefault();
      focusables[(index + (event.shiftKey ? -1 : 1) + focusables.length) % focusables.length].focus({ preventScroll: true });
    };
    layer.addEventListener('click', event => {
      if (event.target === layer || event.target.closest('.sekianafraz-guide-close')) close();
    });
    document.addEventListener('keydown', onKey, true);
    document.body.appendChild(layer);
    active = { layer, trigger, onKey };
    layer.getBoundingClientRect();
    layer.classList.add('is-open');
    layer.querySelector('.sekianafraz-guide-close').focus({ preventScroll: true });
  }
  function buttonHtml(prefix) {
    return '<button type="button" class="sekianafraz-sms-guide-btn" data-sms-guide="' + prefix + '">راهنمای نگارش</button>';
  }
  document.addEventListener('click', event => {
    const button = event.target.closest('[data-sms-guide]');
    if (!button) return;
    event.preventDefault();
    open(button.dataset.smsGuide, button);
  });
  window.SEKIANAFRAZ_ADMIN_SMS_GUIDE = { open, close, buttonHtml, isGuestMultiSms };
})();
