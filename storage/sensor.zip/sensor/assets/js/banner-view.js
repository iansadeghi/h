(function () {
  function escapeHtml(value) { return String(value).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
  function hexToRgba(hex, alpha) {
    const number = parseInt(String(hex).replace('#', ''), 16);
    return `rgba(${(number >> 16) & 255},${(number >> 8) & 255},${number & 255},${alpha})`;
  }
  function lightenHex(hex, ratio = .18) {
    const value = String(hex || '').trim();
    const match = /^#([0-9a-f]{6})$/i.exec(value);
    if (!match) return '#7f3353';
    const number = parseInt(match[1], 16);
    const mix = (channel) => Math.round(channel + (255 - channel) * Math.max(0, Math.min(1, ratio)));
    const r = mix((number >> 16) & 255), g = mix((number >> 8) & 255), b = mix(number & 255);
    return '#' + [r, g, b].map((channel) => channel.toString(16).padStart(2, '0')).join('');
  }
  function setBottomPadding(padding, bottom = 3) {
    const parts = String(padding || '').trim().split(/\s+/);
    if (parts.length !== 4) return padding;
    parts[2] = Math.max(0, bottom) + 'px';
    return parts.join(' ');
  }
  function bannerMarginCss(data, target, mirror = false) {
    const defaults = target === 'close' ? {t:24,r:0,b:0,l:24} : {t:0,r:0,b:0,l:0};
    const values = {...defaults, ...data.banner_margins?.[target]};
    const sides = mirror ? ['t','l','b','r'] : ['t','r','b','l'];
    return sides.map(side => Math.max(0, Math.min(200, parseInt(values[side],10) || 0)) + 'px').join(' ');
  }
  function bannerHeaderActionMarginCss(data, mirror = false) {
    const clean = (value) => Math.max(0, Math.min(200, parseInt(value, 10) || 0));
    const cardStored = data.banner_paddings && data.banner_paddings.card && typeof data.banner_paddings.card === 'object' ? data.banner_paddings.card : {};
    const card = {
      t: clean(cardStored.t ?? 24), r: clean(cardStored.r ?? 24),
      b: clean(cardStored.b ?? 24), l: clean(cardStored.l ?? 24)
    };
    const stored = data.banner_margins && typeof data.banner_margins.close === 'object' ? data.banner_margins.close : null;
    const values = {
      t: clean(stored?.t ?? card.t), r: clean(stored?.r ?? 0),
      b: clean(stored?.b ?? 0), l: clean(stored?.l ?? (mirror ? card.r : card.l))
    };
    if (mirror) {
      return [values.t - card.t, values.l - card.r, values.b, values.r].map(value => value + 'px').join(' ');
    }
    return [values.t - card.t, values.r, values.b, values.l - card.l].map(value => value + 'px').join(' ');
  }
  function radiusCss(value, fallback) {
    const clean = (number) => Math.max(0, parseInt(number, 10) || 0);
    if (!value || typeof value !== 'object') return clean(fallback) + 'px';
    return [value.tl, value.tr, value.br, value.bl].map((corner) => clean(corner) + 'px').join(' ');
  }
  function resolveBannerRadii(data) {
    const radius = (data.banner_border_radius !== undefined && data.banner_border_radius !== null) ? parseInt(data.banner_border_radius, 10) || 0 : 0;
    if (data.banner_radius_mode === 'manual' && data.banner_border_radii && typeof data.banner_border_radii === 'object') {
      const stored = data.banner_border_radii;
      return {
        card: radiusCss(stored.card, 0), image: radiusCss(stored.image, 0),
        discount: radiusCss(stored.discount, 0), copy: radiusCss(stored.copy, 0),
        primary: radiusCss(stored.primary, 0), close: radiusCss(stored.close, 0), back: radiusCss(stored.back, 0),
        phone: radiusCss(stored.phone, 0), send: radiusCss(stored.send, 0),
        success: radiusCss(stored.success, 0), correction: radiusCss(stored.correction, 0), error: radiusCss(stored.error, 0)
      };
    }
    return {
      card: radiusCss(null, radius), image: radiusCss(null, radius * .5),
      discount: radiusCss(null, radius * .5), copy: radiusCss(null, radius * .375),
      primary: radiusCss(null, radius * .5), close: radius > 0 ? radiusCss(null, radius * .375) : radiusCss(data.banner_border_radii?.close, 50),
      back: radius > 0 ? radiusCss(null, radius * .375) : radiusCss(data.banner_border_radii?.back, 50),
      phone: radiusCss(null, radius * .5), send: radiusCss(null, radius * .5),
      success: radiusCss(null, radius * .5), correction: radiusCss(null, 0), error: radiusCss(null, radius * .5)
    };
  }
  function paddingCss(value, fallback) {
    const clean = (number) => Math.max(0, Math.min(200, parseInt(number, 10) || 0));
    const source = value && typeof value === 'object' ? value : fallback;
    return [source.t, source.r, source.b, source.l].map((side) => clean(side) + 'px').join(' ');
  }
  function resolveBannerPaddings(data) {
    const stored = data.banner_paddings && typeof data.banner_paddings === 'object' ? data.banner_paddings : {};
    return {
      card: paddingCss(stored.card, { t: 24, r: 24, b: 24, l: 24 }),
      primary: paddingCss(stored.primary, { t: 13, r: 13, b: 13, l: 13 }),
      discount: paddingCss(stored.discount, { t: 10, r: 10, b: 10, l: 10 }),
      copy: paddingCss(stored.copy, { t: 8, r: 12, b: 8, l: 12 }),
      title: paddingCss(stored.title, { t: 0, r: 0, b: 0, l: 0 }),
      description: paddingCss(stored.description, { t: 0, r: 0, b: 0, l: 0 }),
      close: paddingCss(stored.close, { t: 10, r: 10, b: 10, l: 10 }),
      phone: paddingCss(stored.phone, { t: 12, r: 12, b: 12, l: 12 }),
      send: paddingCss(stored.send, { t: 12, r: 12, b: 12, l: 12 }),
      success: paddingCss(stored.success, { t: 8, r: 8, b: 8, l: 8 }),
      correction: paddingCss(stored.correction, { t: 8, r: 8, b: 8, l: 8 }),
      prompt: paddingCss(stored.prompt, { t: 0, r: 0, b: 0, l: 0 }),
      sending: paddingCss(stored.sending, { t: 8, r: 8, b: 8, l: 8 }),
      error: paddingCss(stored.error, { t: 8, r: 8, b: 8, l: 8 })
    };
  }
  function setSendButtonState(button, state, message) {
    if (!button) return;
    ['normal', 'loading', 'error'].forEach((name) => {
      const part = button.querySelector('.sekianafraz-modal__send-' + name);
      if (part) part.hidden = name !== state;
    });
    const errorText = button.querySelector('.sekianafraz-modal__error-text');
    if (errorText && message !== undefined) errorText.textContent = String(message || '');
    button.dataset.state = state;
    button.setAttribute('aria-live', state === 'error' ? 'assertive' : 'polite');
  }
  function showSendError(button, message, duration = 3000) {
    if (!button) return;
    clearTimeout(button._sekianafrazErrorTimer);
    setSendButtonState(button, 'error', message);
    button.disabled = true;
    button._sekianafrazErrorTimer = setTimeout(() => {
      setSendButtonState(button, 'normal');
      button.disabled = false;
      button._sekianafrazErrorTimer = null;
    }, duration);
  }
  function setMultiHeaderStage(root, stage) {
    if (!root) return;
    const iconBack = root.querySelector('.sekianafraz-modal__back-icon');
    if (iconBack) iconBack.hidden = stage !== 2;
  }
  function transitionMultiStage(root, stage, direction = 'forward') {
    if (!root || ![1, 2, 3].includes(stage)) return Promise.resolve();
    if (root._multiTransition?.target === stage) return root._multiTransition.promise;
    root._multiTransition?.cancel();
    const current = parseInt(root.dataset.multiStage || '1', 10) || 1;
    const intro = root.querySelector('.sekianafraz-modal__stage-intro');
    const form = root.querySelector('.sekianafraz-modal__stage-phone');
    const entry = root.querySelector('.sekianafraz-modal__phone-entry');
    const success = root.querySelector('.sekianafraz-modal__stage-success');
    const from = current === 1 ? intro : current === 2 ? entry : success;
    const to = stage === 1 ? intro : stage === 2 ? entry : success;
    if (!to) return Promise.resolve();
    const reveal = () => {
      if (intro) intro.hidden = stage !== 1;
      if (form) form.hidden = stage === 1;
      if (entry) entry.hidden = stage !== 2;
      if (success) success.hidden = stage !== 3;
      root.dataset.multiStage = String(stage);
      setMultiHeaderStage(root, stage);
    };
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (current === stage || reduced || !from?.animate) {
      reveal();
      return Promise.resolve();
    }
    const offset = direction === 'back' ? 18 : -18;
    const state = { target: stage, cancelled: false, animations: [], promise: null, cancel: () => {
      state.cancelled = true;
      state.animations.forEach(animation => animation.cancel());
      if (root._multiTransition === state) {
        root._multiTransition = null;
        root.classList.remove('sekianafraz-modal--transitioning');
      }
    } };
    root._multiTransition = state;
    root.classList.add('sekianafraz-modal--transitioning');
    state.promise = (async () => {
      const exit = from.animate([{ opacity: 1, transform: 'translateX(0)' },
        { opacity: 0, transform: 'translateX(' + offset + 'px)' }], { duration: 130, easing: 'ease-in', fill: 'both' });
      state.animations.push(exit);
      await exit.finished.catch(() => {});
      if (state.cancelled) return;
      exit.cancel();
      reveal();
      const enter = to.animate([{ opacity: 0, transform: 'translateX(' + -offset + 'px)' },
        { opacity: 1, transform: 'translateX(0)' }], { duration: 190, easing: 'cubic-bezier(.16,1,.3,1)' });
      state.animations.push(enter);
      await enter.finished.catch(() => {});
      enter.cancel();
    })().finally(() => {
      if (root._multiTransition !== state) return;
      root._multiTransition = null;
      root.classList.remove('sekianafraz-modal--transitioning');
    });
    return state.promise;
  }
  function render(data, options = {}) {
    const multi = data.banner_type === 'multi';
    const btnColor = data.button_color || '#000000';
    const copyBg = data.copy_bg_color || hexToRgba(btnColor, .15);
    const title = data.title || 'تبریک میگم!';
    const radii = resolveBannerRadii(data);
    const paddings = resolveBannerPaddings(data);
    const correctionBorder = data.multi_correction_border_color || '#b8b8b8';
    const correctionBorderHover = lightenHex(correctionBorder, .18);
    const incentives = data.incentives;
    const hasDiscount = incentives == null || (Array.isArray(incentives) ? incentives : String(incentives).split(',').map(s => s.trim())).includes('discount');
    const hasCoupon = !multi && hasDiscount && !!String(data.coupon_code || '').trim();
    let fontFamily = 'Arad';
    if (data.banner_font_type === 'inherit') fontFamily = options.inheritedFont || 'inherit';
    const fontStack = fontFamily === 'inherit' ? 'inherit' : fontFamily + ', sans-serif';
    const variables = '--sekianafraz-banner-bg:' + (data.banner_bg_color || '#ffffff') +
      ';--sekianafraz-banner-radius:' + radii.card + ';--sekianafraz-banner-card-padding:' + paddings.card +
      ';--sekianafraz-banner-card-margin:' + bannerMarginCss(data, 'card') + ';--sekianafraz-banner-font:' + fontStack +
      (fontFamily === 'Arad' ? ";--sekianafraz-banner-font-settings:'DSTY' 2" : ';--sekianafraz-banner-font-settings:normal');
    const closeButton = '<button type="button" class="sekianafraz-modal__close" aria-label="بستن بنر" style="background:' + (data.banner_close_hide_bg ? 'transparent' : data.close_bg_color || '#f1f1f1') + ';color:' + (data.close_icon_color || '#111111') + ';margin:' + bannerHeaderActionMarginCss(data, !multi && data.banner_close_position === 'right') + ';padding:' + paddings.close + ';border-radius:' + radii.close + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M18 6 6 18M6 6l12 12"/></svg></button>';
    const multiHeader = multi ? '<div class="sekianafraz-modal__header">' +
      '<div class="sekianafraz-modal__header-back">' +
      '<button type="button" class="sekianafraz-modal__back sekianafraz-modal__back-icon" aria-label="بازگشت به مرحله قبل" hidden style="background:' + (data.multi_back_bg_color || '#f1f1f1') + ';color:' + (data.multi_back_icon_color || '#111111') + ';margin:' + bannerHeaderActionMarginCss(data, true) + ';padding:' + paddings.close + ';border-radius:' + radii.back + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="m9 18 6-6-6-6"/></svg></button>' +
      '</div>' + closeButton + '</div>' : '';
    return '<div class="sekianafraz-modal__frame" data-sekianafraz-banner' + (multi ? ' data-multi-stage="1"' : '') + ' style="' + escapeHtml(variables) + '"><div class="sekianafraz-modal__card" role="dialog" aria-modal="true" aria-label="' + escapeHtml(title) + '">' +
      multiHeader +
      '<div class="sekianafraz-modal__content sekianafraz-modal__stage-intro">' +
      (data.banner_hide_image ? '' :
        (data.banner_image ? '<img src="' + escapeHtml(data.banner_image) + '" style="width:100%;max-width:300px;border-radius:' + radii.image + ';object-fit:cover;max-height:180px">' :
          '<div style="width:100px;height:100px;margin:0 auto"><svg style="width:100%;height:100%;color:' + (data.banner_svg_color || '#000000') + '" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" aria-hidden="true" role="img" class="iconify iconify--emojione-monotone" preserveAspectRatio="xMidYMid meet" fill="' + (data.banner_svg_color || '#000000') + '"><g stroke-width="0"></g><g stroke-linecap="round" stroke-linejoin="round"></g><g><path d="M39.668 47.588c1.553-1.529.715-5.041-1.822-9.098c.922-.144 1.784-.364 2.436-.701c2.346-1.211 3.93-3.418 5.129-5.701c1.289-2.449 2.154-5.141 3.836-7.371c.284-.377.568-.715.851-1.033c3.629.435 6.526 1.215 6.526 1.215l1.107-2.813a29.917 29.917 0 0 0-4.286-1.187c.892-.507 1.474-.665 1.474-.665l-1.049-2.836c-1.682.711-3.047 1.76-4.19 3.016c-4.272-.239-8.574.612-11.968 3.244c-2.552 1.98-4.276 4.725-5.898 7.471a44.86 44.86 0 0 0-4.581-3.927c.306-.503.634-.955.987-1.304c2.133-2.1 4.947-3.443 6.793-5.846c3.88-5.046 1.042-12.956-2.15-17.052c-.572.551-1.518 1.354-2.23 1.988c3.393 3.475 5.766 9.559 3.107 14.105c-1.486 2.541-4.232 4.135-6.152 6.318c-.332.379-.629.859-.898 1.389c-5.021-3.601-9.629-5.05-11.455-3.252a2.35 2.35 0 0 0-.442.634l-.007-.007l-.049.143c-.068.155-.13.316-.172.492L2 61l36.662-12.818l-.01-.01c.394-.127.741-.314 1.016-.584M9.293 56.332l-3.06-1.426l2.065-5.95l9.471 4.412l-8.476 2.964m16.951-5.927l-15.879-7.399l2.065-5.949l11.866 5.956c-7.083-4.61-9.801-11.907-9.801-11.907l.706-2.033c1.255 3.175 4.016 7.129 7.81 10.861c3.826 3.766 7.881 6.494 11.122 7.713l-7.889 2.758m6.099-18.74c1.658-2.377 3.367-4.776 5.743-6.483c2.262-1.626 5.934-1.923 9.415-1.728c-1.176 2.054-2.045 4.333-2.825 6.522c-.943 2.65-2.207 5.398-4.617 7.023c-.65.438-1.561.758-2.534.995c-1.337-2.049-3.091-4.215-5.182-6.329" fill="currentColor"></path><path d="M23.033 22c1.002 0-2.002-3-1.5-5.631c1.924-.148 6.322.719 3.762-2.797c2.896.51 4.396-1.652 1.662-3.701c.91.064 2.324-1.652 1.309-1.869c-3.252-.689-4.525 1.07-2.461 3.607c-2.17-.404-3.939.605-2.309 2.871c-6.266-.781-2.701 7.52-.463 7.52" fill="currentColor"></path><path d="M44.545 19.334c.939-.424-.654-3.225-1.172-3.941c3.963-.424 3.813-1.605 1.328-4.135c6.756.227.209-3.613 1.127-5.133c.795-1.318 3.234.064 3.008-.67c-.762-2.455-7.99-.795-3.416 3.789c-3.992.078-4.375 1.383-1.4 4.088c-5.182.057-.954 6.668.525 6.002" fill="currentColor"></path><path d="M61.697 29.225c-1.582.443-1.826.277-1.615 1.852c-3.654-1.682-7.52-4.021-5.174 2.176c-4.15-2.471-3.943-.307-4.719 3.254c-1.01-.787-2.445-2.861-2.445-2.861l-1.52 1.291s2.785 3.928 4.16 3.705c1.209-.195 1.867-2.48 1.934-4.494c3.85 1.625 5.693 1.842 3.932-2.91c3.078 1.729 6.852 3.254 5.447-2.013" fill="currentColor"></path><path opacity="0.3" d="M6.049 11.437l2.828 2.829l-2.828 2.828l-2.829-2.828z" fill="currentColor"></path><path opacity="0.3" d="M12.824 23.198l-2.83 2.828l-2.829-2.83l2.83-2.829z" fill="currentColor"></path><path opacity="0.3" d="M17.22 7l2.828 2.828l-2.829 2.83l-2.828-2.83z" fill="currentColor"></path><path opacity="0.3" d="M48.011 46.484l-2.83-2.829l2.828-2.828l2.83 2.829z" fill="currentColor"></path><path opacity="0.3" d="M41.705 56.186l-2.828-2.828l2.828-2.829l2.829 2.829z" fill="currentColor"></path><path opacity="0.3" d="M54.113 58.42l-2.83-2.829l2.827-2.83l2.83 2.829z" fill="currentColor"></path><path opacity="0.3" d="M56.941 45.536l-2.828-2.829l2.828-2.828l2.828 2.828z" fill="currentColor"></path><path opacity="0.3" d="M52.22 10l2.828 2.828l-2.829 2.829l-2.828-2.829z" fill="currentColor"></path></g></svg></div>')
      ) +
      '<h2 style="font-family: inherit !important; font-size:1.5rem;font-weight:800;color:' + (data.banner_title_color || '#0d0d0d') + ';margin:0;padding:' + paddings.title + ';max-width:100%;box-sizing:border-box">' + escapeHtml(title) + '</h2>' +
      '<div style="font-family: inherit !important; color:' + (data.banner_text_color || '#4b5563') + ';font-size:.9rem;line-height:1.8;text-align:center;white-space:pre-wrap;padding:' + paddings.description + ';max-width:100%;box-sizing:border-box">' + (data.html || '') + '</div>' +
      (hasCoupon ? '<div class="sekianafraz-modal__discount-container" style="width:100%;padding-top:8px">' +
      '<div class="sekianafraz-modal__discount-box" style="position:relative;display:flex;direction:rtl;gap:12px;align-items:center;justify-content:space-between;width:100%;background:' + (data.discount_bg_color || '#f2f2f2') + ';border:1px dashed ' + (data.discount_border_color || '#d1d5db') + ';border-radius:' + radii.discount + ';padding:' + paddings.discount + ';box-sizing:border-box">' +
      '<button type="button" class="sekianafraz-modal__copy" style="font-family: inherit !important; background:' + copyBg + ';color:' + (data.copy_text_color || btnColor) + ';padding:' + paddings.copy + ';border-radius:' + radii.copy + ';font-size:.85rem;font-weight:700;transition:all .3s;width:5rem;text-align:center;border:none;cursor:pointer;box-sizing:border-box">کپی</button>' +
      '<span class="sekianafraz-modal__coupon-code" style="direction:ltr;text-align:left;overflow-wrap:anywhere;min-width:0;font-family: inherit !important;font-size:1.05rem;color:' + (data.banner_coupon_color || '#5c5c5c') + ';font-weight:800;letter-spacing:.1em">' + escapeHtml(data.coupon_code || '') + '</span>' +
      '</div>' +
      '</div>' : '') +
      '<div class="sekianafraz-modal__button-container" style="width:100%;display:flex;gap:12px;padding-top:12px">' +
      '<button type="button" class="sekianafraz-modal__primary" style="all:unset;display:inline-block;width:100%;padding:' + paddings.primary + ';border-radius:' + radii.primary + ';font-weight:800;border:none;background:' + btnColor + ';color:' + (data.banner_button_text_color || '#ffffff') + ';text-align:center;cursor:pointer;font-family: inherit !important;box-sizing:border-box;">' + escapeHtml(data.banner_button_text || (multi ? 'دریافت تخفیف' : 'بزن بریم!')) + '</button>' +
      '</div>' +
      '</div>' +
      (multi ? '<form class="sekianafraz-modal__stage-phone" hidden>' +
        '<div class="sekianafraz-modal__phone-entry">' +
        '<div class="sekianafraz-modal__prompt" style="color:' + (data.multi_prompt_color || '#4b5563') + ';font-size:14px;padding:' + paddings.prompt + '">' + escapeHtml(data.multi_prompt || 'شماره تلفنتو وارد کن تا کد رو برات پیامک کنیم') + '</div>' +
        '<input class="sekianafraz-modal__phone" type="tel" inputmode="tel" autocomplete="off" required placeholder="' + escapeHtml(data.multi_phone_placeholder || 'شماره تلفن') + '" style="all:unset;display:block;outline:0!important;box-shadow:none!important;box-sizing:border-box;font:inherit;line-height:normal;width:100%;background:' + (data.multi_phone_bg_color || '#ffffff') + ';color:' + (data.multi_phone_text_color || '#111827') + ';border:1px solid ' + (data.multi_phone_border_color || '#d1d5db') + '!important;border-radius:' + radii.phone + ';padding:' + paddings.phone + '">' +
        '<button class="sekianafraz-modal__send" type="submit" data-state="normal" style="all:unset;display:flex;outline:0!important;box-shadow:none!important;box-sizing:border-box;font:inherit;line-height:normal;width:100%;background:' + (data.multi_send_bg_color || '#000000') + ';color:' + (data.multi_send_text_color || '#ffffff') + ';border:0;border-radius:' + radii.send + ';padding:' + paddings.send + '">' +
        '<span class="sekianafraz-modal__send-normal">' + escapeHtml(data.multi_submit_text || 'ارسال کد تخفیف') + '</span>' +
        '<span class="sekianafraz-modal__send-loading sekianafraz-modal__sending" hidden style="color:' + (data.multi_sending_color || data.multi_send_text_color || '#ffffff') + '"><span class="sekianafraz-modal__spinner" style="color:' + (data.multi_loader_color || data.multi_send_text_color || '#ffffff') + '"></span>' + escapeHtml(data.multi_sending_text || 'درحال ارسال...') + '</span>' +
        '<span class="sekianafraz-modal__send-error sekianafraz-modal__error" role="alert" hidden><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-triangle-alert preview-icon" aria-hidden="true"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg><span class="sekianafraz-modal__error-text"></span></span>' +
        '</button></div>' +
        '<div class="sekianafraz-modal__stage-success" hidden>' +
        '<div class="sekianafraz-modal__success" role="status" hidden style="background:' + (data.multi_success_bg_color || '#ffffff') + ';color:' + (data.multi_success_color || '#111827') + ';border-radius:' + radii.success + ';padding:' + paddings.success + '">' + escapeHtml(data.multi_success_text || 'کد تخفیف رو برات پیامک کردیم!') + '</div>' +
        '<button class="sekianafraz-modal__correction" type="button" hidden style="background:' + (data.multi_correction_bg_color || '#ffffff') + ';color:' + (data.multi_correction_color || '#b8b8b8') + ';--sekianafraz-correction-border:' + correctionBorder + ';--sekianafraz-correction-border-hover:' + correctionBorderHover + ';border:0;border-bottom:1px solid var(--sekianafraz-correction-border);border-radius:' + radii.correction + ';padding:' + setBottomPadding(paddings.correction, 3) + '">' + escapeHtml(data.multi_correction_text || 'شمارتو اشتباه وارد کردی؟') + '</button>' +
        '</div></form>' : '') +
      '</div>' +
      (!multi && data.banner_show_close ? closeButton.replace('style="', 'style="' + (data.banner_close_position === 'right' ? 'right' : 'left') + ':0;') : '') +
      '</div>';
  }
  window.SEKIANAFRAZ_BANNER_VIEW = {
    render, resolveBannerRadii, resolveBannerPaddings, bannerMarginCss, bannerHeaderActionMarginCss,
    setSendButtonState, showSendError, setMultiHeaderStage, transitionMultiStage
  };
})();
