(function () {
  if (!window.SEKIANAFRAZ_CTX) return;
  const ctx = window.SEKIANAFRAZ_CTX;
  const REST = ctx.rest;
  let LS_SENSOR_KEY = 'sekianafraz_sensor_metrics_v5';
  let LS_SENSOR_CLEAN = 'sekianafraz_sensor_metrics_cleanup_v5';
  const SENSOR_BUCKET_MS = 60 * 60 * 1000;
  const SENSOR_BUCKET_SECONDS = SENSOR_BUCKET_MS / 1000;
  const MAX_STORAGE_AGE_SECONDS = 7 * 24 * 60 * 60;
  const AGGREGATE_KEY = '@aggregate';
  const COOKIE = 'sekianafraz_guest_id';
  const pendingSensors = new Set();
  const completedSensors = new Set();
  const failedAttempts = new Map();
  const triggerQueue = [];
  let activeTriggers = 0;
  const runtimeNonce = typeof document !== 'undefined' && document.currentScript ? document.currentScript.nonce : '';
  function uuid() { const bytes = new Uint8Array(32); crypto.getRandomValues(bytes); let i = 0; return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = bytes[i++] & 15; return (c === 'x' ? r : (r & 3 | 8)).toString(16); }); }
  function setCookie(name, value, days) { const d = new Date(); d.setTime(d.getTime() + days * 24 * 60 * 60 * 1000); const secure = location.protocol === 'https:' ? ';Secure' : ''; document.cookie = name + '=' + encodeURIComponent(value) + ';expires=' + d.toUTCString() + ';path=/;SameSite=Lax' + secure }
  function getCookie(name) { const n = name + '='; const ca = document.cookie.split(';'); for (let c of ca) { while (c.charAt(0) == ' ') c = c.substring(1); if (c.indexOf(n) == 0) { try { return decodeURIComponent(c.substring(n.length, c.length)) } catch (e) { return '' } } } return '' }
  function now() { return Math.floor(Date.now() / 1000) }
  function isRecord(value) { return !!value && typeof value === 'object' && !Array.isArray(value) }
  function metricStorageKey(sensor, entry) {
    return LS_SENSOR_KEY + ':' + sensor.id + ':' + encodeURIComponent(entry.storageKey);
  }
  function sensorLsRead() {
    const data = {};
    runtimeSensors.forEach(sensor => {
      sensor.entries.forEach(entry => {
        try {
          const stored = JSON.parse(localStorage.getItem(metricStorageKey(sensor, entry)) || 'null');
          if (!stored || !isRecord(stored.buckets)) return;
          if (!isRecord(data[sensor.id])) data[sensor.id] = {};
          data[sensor.id][entry.storageKey] = stored.buckets;
        } catch (e) { }
      });
    });
    return data;
  }
  function sensorLsWrite(data) {
    runtimeSensors.forEach(sensor => {
      sensor.entries.forEach(entry => {
        const buckets = data[sensor.id] && data[sensor.id][entry.storageKey];
        if (!isRecord(buckets)) return;
        const oldest = now() - MAX_STORAGE_AGE_SECONDS - SENSOR_BUCKET_SECONDS;
        Object.keys(buckets).forEach(key => { if ((parseInt(key, 10) || 0) < oldest) delete buckets[key]; });
        try { localStorage.setItem(metricStorageKey(sensor, entry), JSON.stringify({ touched: now(), buckets })); } catch (e) { }
      });
    });
  }
  function pathOnly(u) { try { const url = new URL(u, location.origin); return url.pathname + url.search } catch (e) { return location.pathname + location.search } }
  function ensureGuest() { let guest = getCookie(COOKIE); if (!/^[a-f0-9-]{36}$/.test(guest)) { guest = uuid(); setCookie(COOKIE, guest, 7); } return guest; }
  function windowSeconds(windowSpec) {
    if (windowSpec === '72h') return 72 * 60 * 60;
    if (windowSpec === '1w') return 7 * 24 * 60 * 60;
    return 24 * 60 * 60;
  }
  function normalizeSensor(raw) {
    const id = parseInt(raw && raw.id, 10) || 0;
    const placement = String(raw && raw.placement || '');
    const metric = ['views', 'duration', 'both'].includes(String(raw && raw.visit_metric || '')) ? String(raw.visit_metric) : 'views';
    const calculation = raw && raw.visit_calculation === 'aggregate' ? 'aggregate' : 'individual';
    const condition = raw && raw.visit_condition === 'and' ? 'and' : 'or';
    const matches = Array.from(new Set((Array.isArray(raw && raw.matches) ? raw.matches : []).map(String).filter(Boolean)));
    const entries = calculation === 'aggregate'
      ? [{ storageKey: AGGREGATE_KEY + '|' + placement, trackingKey: '' }]
      : matches.map(match => ({ storageKey: placement + '|' + match, trackingKey: match }));
    return {
      id,
      metric,
      calculation,
      condition,
      minViews: Math.max(1, parseInt(raw && (raw.min_views || raw.min), 10) || 1),
      minDurationMs: Math.max(1, parseInt(raw && raw.min_duration, 10) || 1) * 1000,
      window: String(raw && raw.window || '24h'),
      entries
    };
  }
  function ensureBuckets(data, sensorId, storageKey) {
    const id = String(sensorId);
    if (!isRecord(data[id])) data[id] = {};
    if (!isRecord(data[id][storageKey])) data[id][storageKey] = {};
    return data[id][storageKey];
  }
  function addMetric(data, sensorId, storageKey, bucketSeconds, views, durationMs, startMs) {
    const buckets = ensureBuckets(data, sensorId, storageKey);
    const bucketKey = String(bucketSeconds);
    if (!isRecord(buckets[bucketKey])) buckets[bucketKey] = { v: [], d: [] };
    const bucket = buckets[bucketKey];
    if (!Array.isArray(bucket.v)) bucket.v = [];
    if (!Array.isArray(bucket.d)) bucket.d = [];
    if (views > 0) bucket.v.push(startMs);
    if (durationMs > 0) {
      const endMs = startMs + durationMs;
      const last = bucket.d[bucket.d.length - 1];
      if (Array.isArray(last) && Math.abs(last[1] - startMs) < 1) last[1] = endMs;
      else bucket.d.push([startMs, endMs]);
    }
  }
  function cleanupSensorMetrics(data) {
    let last = 0;
    try { last = parseInt(localStorage.getItem(LS_SENSOR_CLEAN) || '0', 10) || 0; } catch (e) { }
    if (now() - last < 24 * 60 * 60) return;
    const oldest = now() - MAX_STORAGE_AGE_SECONDS - SENSOR_BUCKET_SECONDS;
    const defer = fn => typeof window.requestIdleCallback === 'function'
      ? window.requestIdleCallback(fn, { timeout: 2000 }) : setTimeout(fn, 50);
    let cursor = -1;
    try { cursor = localStorage.length - 1; } catch (e) { return; }
    const cleanBatch = () => {
      let checked = 0;
      try {
        while (cursor >= 0 && checked++ < 25) {
          const key = localStorage.key(cursor--);
          if (!key || !key.startsWith(LS_SENSOR_KEY + ':')) continue;
          let value = null;
          try { value = JSON.parse(localStorage.getItem(key)); } catch (e) { }
          if (!value || !Number.isFinite(value.touched) || value.touched < oldest) localStorage.removeItem(key);
        }
      } catch (e) { return; }
      if (cursor >= 0) defer(cleanBatch);
    };
    defer(cleanBatch);
    try { localStorage.setItem(LS_SENSOR_CLEAN, String(now())); } catch (e) { }
  }
  function recordSensorVisits(data, sensors, atMs) {
    const bucket = Math.floor(atMs / SENSOR_BUCKET_MS) * SENSOR_BUCKET_SECONDS;
    sensors.forEach(sensor => {
      if (sensor.metric === 'duration') return;
      sensor.entries.forEach(entry => addMetric(data, sensor.id, entry.storageKey, bucket, 1, 0, atMs));
    });
  }
  function totalsFor(data, sensor, entry, atMs) {
    const sensorData = isRecord(data[String(sensor.id)]) ? data[String(sensor.id)] : {};
    const buckets = isRecord(sensorData[entry.storageKey]) ? sensorData[entry.storageKey] : {};
    const cutoff = atMs - windowSeconds(sensor.window) * 1000;
    return Object.keys(buckets).reduce((totals, bucketKey) => {
      const bucketSeconds = parseInt(bucketKey, 10) || 0;
      const bucket = buckets[bucketKey];
      if ((bucketSeconds + SENSOR_BUCKET_SECONDS) * 1000 >= cutoff && isRecord(bucket)) {
        for (const value of Array.isArray(bucket.v) ? bucket.v : []) {
          if (Number.isFinite(value) && value >= cutoff && value <= atMs) totals.views++;
        }
        for (const segment of Array.isArray(bucket.d) ? bucket.d : []) {
          if (Array.isArray(segment) && Number.isFinite(segment[0]) && Number.isFinite(segment[1])) {
            totals.durationMs += Math.max(0, Math.min(segment[1], atMs) - Math.max(segment[0], cutoff));
          }
        }
      }
      return totals;
    }, { views: 0, durationMs: 0 });
  }
  function conditionsMet(sensor, totals) {
    if (sensor.metric === 'views') return totals.views >= sensor.minViews;
    if (sensor.metric === 'duration') return totals.durationMs >= sensor.minDurationMs;
    const viewsMet = totals.views >= sensor.minViews;
    const durationMet = totals.durationMs >= sensor.minDurationMs;
    return sensor.condition === 'or' ? viewsMet || durationMet : viewsMet && durationMet;
  }
  function qualifyingEntry(data, sensor, atMs) {
    for (const entry of sensor.entries) {
      if (conditionsMet(sensor, totalsFor(data, sensor, entry, atMs))) return entry;
    }
    return null;
  }
  let sessionReady = null;
  async function refreshSession() {
    const body = new URLSearchParams({ action: 'sekianafraz_context', context: JSON.stringify({ ...buildCtxPayload(), ts: ctx.ts, sig: ctx.sig }) });
    const response = await fetch(ctx.bootstrap, { method: 'POST', credentials: 'same-origin', headers: { 'X-SEKIANAFRAZ-Request': 'context' }, body });
    const result = await response.json();
    if (!response.ok || !result.success) throw result;
    Object.assign(ctx, result.data);
  }
  async function post(path, body, retried = false) {
    if (!sessionReady) sessionReady = refreshSession().catch(error => { sessionReady = null; throw error; });
    await sessionReady;
    const headers = { 'Content-Type': 'application/json', 'X-SEKIANAFRAZ-Ts': String(ctx.ts || ''), 'X-SEKIANAFRAZ-Sig': String(ctx.sig || '') };
    if (ctx.nonce) headers['X-WP-Nonce'] = ctx.nonce;
    const payload = { ...(body || {}), _sekianafraz_ts: ctx.ts, _sekianafraz_sig: ctx.sig };
    if (path === 'trigger') payload.guest_id = ctx.guest_id;
    const response = await fetch(REST + path, { method: 'POST', headers, credentials: 'same-origin', keepalive: true, body: JSON.stringify(payload) });
    let result = null;
    try { result = await response.json(); } catch (e) { }
    if (!response.ok && !retried && result && result.code === 'rest_cookie_invalid_nonce') {
      sessionReady = null;
      return post(path, body, true);
    }
    if (!response.ok || !result) throw (result || { message: response.statusText });
    return result;
  }
  async function checkSensors() {
    const identity = ctx.user ? 'u' + ctx.user : 'g' + ensureGuest();
    LS_SENSOR_KEY += ':' + (ctx.base_path || '/') + ':' + identity;
    LS_SENSOR_CLEAN += ':' + (ctx.base_path || '/') + ':' + identity;
    if (Array.isArray(ctx.sensors)) return ctx.sensors;
    try { await refreshSession(); return ctx.sensors || []; } catch (error) { return []; }
  }
  async function trigger(sensorId, pagePath, trackingKey) {
    const res = await post('trigger', { sensor_id: sensorId, tracking_key: trackingKey || '', guest_id: ensureGuest(), page_path: pagePath, ctx: buildCtxPayload(), _sekianafraz_ts: ctx.ts, _sekianafraz_sig: ctx.sig });
    if (res.success) {
      const hasBanner = (res.code === 'BANNER' || res.code === 'BOTH');
      if (res.data && res.data.reminder) {
        const r = res.data.reminder;
        try {
          if (typeof r.server_now_ms === 'number' && typeof r.expires_in_ms === 'number') {
            const clientNow = Date.now();
            r.client_now_ms = clientNow;
            r.expires_at_server_ms = r.server_now_ms + r.expires_in_ms;
          }
        } catch (e) { }
        if (!hasBanner) {
          try { localStorage.setItem('sekianafraz_reminder_active', JSON.stringify(r)); } catch (e2) { }
          const evt = new CustomEvent('sekianafraz_reminder_triggered', { detail: r });
          window.dispatchEvent(evt);
        }
      }
      if (hasBanner) {
        await ensureBannerAssets();
        showBanner(res.data);
      }
    }
    return res;
  }
  function queuedTrigger(sensorId, pagePath, trackingKey) {
    return new Promise((resolve, reject) => {
      triggerQueue.push({ sensorId, pagePath, trackingKey, resolve, reject });
      drainTriggers();
    });
  }
  function drainTriggers() {
    while (activeTriggers < 2 && triggerQueue.length) {
      const job = triggerQueue.shift();
      activeTriggers++;
      trigger(job.sensorId, job.pagePath, job.trackingKey).then(job.resolve, job.reject).finally(() => {
        activeTriggers--;
        drainTriggers();
      });
    }
  }
  function buildCtxPayload() {
    return {
      path: ctx.path || pathOnly(location.href),
      product_id: ctx.product_id || 0,
      post_id: ctx.post_id || 0,
      page_id: ctx.page_id || 0,
      product_cat_ids: ctx.product_cat_ids || [],
      product_tag_ids: ctx.product_tag_ids || [],
      post_cat_ids: ctx.post_cat_ids || [],
      post_tag_ids: ctx.post_tag_ids || [],
      search_term: ctx.search_term || ''
    };
  }
  function ensureAradFont(fontUrl) {
    if (!fontUrl || document.getElementById('sekianafraz-font-arad')) return;
    const link = document.createElement('link');
    link.id = 'sekianafraz-font-arad';
    link.rel = 'preload';
    link.as = 'font';
    link.type = 'font/woff2';
    link.crossOrigin = 'anonymous';
    link.href = fontUrl;
    document.head.appendChild(link);
    const style = document.createElement('style');
    if (runtimeNonce) style.nonce = runtimeNonce;
    style.textContent = "@font-face { font-family: 'Arad'; src: url('" + fontUrl + "') format('woff2-variations'); font-weight: 100 900; font-style: normal; }";
    document.head.appendChild(style);
  }
  let bannerAssetsReady = null;
  function ensureBannerAssets() {
    if (bannerAssetsReady) return bannerAssetsReady;
    const assets = ctx.banner_assets || {};
    const load = (url, type, attempt = 0) => new Promise((resolve, reject) => {
      if (!url) { resolve(); return; }
      const node = document.createElement(type === 'script' ? 'script' : 'link');
      if (runtimeNonce) node.nonce = runtimeNonce;
      if (type === 'script') { node.src = url; node.async = true; }
      else { node.rel = 'stylesheet'; node.href = url; }
      const timer = setTimeout(() => failed(), 15000);
      const failed = () => {
        clearTimeout(timer);
        node.onload = node.onerror = null;
        node.remove();
        if (attempt < 2) setTimeout(() => load(url, type, attempt + 1).then(resolve, reject), 1000);
        else reject(new Error('Banner assets unavailable'));
      };
      node.onload = () => { clearTimeout(timer); node.onerror = null; resolve(); };
      node.onerror = failed;
      document.head.appendChild(node);
    });
    const resources = (assets.styles || []).map(url => load(url, 'style'));
    if (!window.SEKIANAFRAZ_BANNER_VIEW) resources.push(load(assets.script, 'script'));
    bannerAssetsReady = Promise.all(resources).catch(error => { bannerAssetsReady = null; throw error; });
    return bannerAssetsReady;
  }
  function showBanner(data) {
    const m = document.createElement('div'); m.className = 'sekianafraz-modal';
    const multi = data.banner_type === 'multi';
    const btnColor = data.button_color || '#000000';
    const copyBg = data.copy_bg_color || hexToRgba(btnColor, .15);
    if (data.banner_font_type === 'arad' || !data.banner_font_type) ensureAradFont(ctx && ctx.arad_font_url);
    m.setAttribute('role', 'presentation');
    m.innerHTML = window.SEKIANAFRAZ_BANNER_VIEW.render(data);
    document.body.appendChild(m);
    const copyBtn = m.querySelector('.sekianafraz-modal__copy');
    copyBtn && copyBtn.addEventListener('click', () => {
      const txt = m.querySelector('.sekianafraz-modal__coupon-code').innerText.replace(/\s/g, '');
      const t = document.createElement('textarea'); t.value = txt; document.body.appendChild(t); t.select(); document.execCommand('copy'); document.body.removeChild(t);
      copyBtn.textContent = 'کپی شد!'; copyBtn.style.backgroundColor = hexToRgba(btnColor, 0.25); copyBtn.style.color = data.copy_text_color || btnColor; setTimeout(() => { copyBtn.textContent = 'کپی'; copyBtn.style.backgroundColor = copyBg; copyBtn.style.color = data.copy_text_color || btnColor; }, 2000);
    });
    const primary = m.querySelector('.sekianafraz-modal__primary');
    const closeModal = () => {
      if (!m || !m.parentNode || m.classList.contains('sekianafraz-modal--closing')) return;
      m.classList.add('sekianafraz-modal--closing');
      setTimeout(() => { if (m && m.parentNode) m.parentNode.removeChild(m); }, 180);
    };
    m.querySelector('.sekianafraz-modal__close')?.addEventListener('click', closeModal);
    if (multi) {
      const intro = m.querySelector('.sekianafraz-modal__stage-intro');
      const form = m.querySelector('.sekianafraz-modal__stage-phone');
      const phoneInput = form.querySelector('.sekianafraz-modal__phone');
      const sendButton = form.querySelector('.sekianafraz-modal__send');
      const success = form.querySelector('.sekianafraz-modal__success');
      const correctionButton = form.querySelector('.sekianafraz-modal__correction');
      let correction = false;
      let busy = false;
      let reminderActivated = false;
      const returnToPhone = () => {
        correction = true;
        window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(m.querySelector('[data-sekianafraz-banner]'), 2, 'back').then(() => {
          success.hidden = true;
          correctionButton.hidden = true;
          phoneInput.hidden = false;
          window.SEKIANAFRAZ_BANNER_VIEW.setSendButtonState(sendButton, 'normal');
          sendButton.disabled = false;
          phoneInput.focus();
        });
      };
      form.addEventListener('submit', async (event) => {
        event.preventDefault();
        if (busy) return;
        if (!data.send_token) {
          window.SEKIANAFRAZ_BANNER_VIEW.showSendError(sendButton, 'ارسال موقتاً ممکن نیست.');
          return;
        }
        busy = true;
        sendButton.disabled = true;
        window.SEKIANAFRAZ_BANNER_VIEW.setSendButtonState(sendButton, 'loading');
        try {
          const result = await post('banner/send', {
            send_token: data.send_token, phone: phoneInput.value.trim(), correction,
            page_path: currentPath, ctx: buildCtxPayload(), _sekianafraz_ts: ctx.ts, _sekianafraz_sig: ctx.sig
          });
          if (!result.success) throw result;
          success.hidden = false;
          correctionButton.hidden = correction;
          await window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(m.querySelector('[data-sekianafraz-banner]'), 3, 'forward');
          const reminder = result.reminder || data.reminder;
          if (!reminderActivated && reminder) {
            reminderActivated = true;
            const r = reminder;
            if (typeof r.server_now_ms === 'number' && typeof r.expires_in_ms === 'number') {
              r.client_now_ms = Date.now(); r.expires_at_server_ms = r.server_now_ms + r.expires_in_ms;
            }
            try { localStorage.setItem('sekianafraz_reminder_active', JSON.stringify(r)); } catch (e) { }
            window.dispatchEvent(new CustomEvent('sekianafraz_reminder_triggered', { detail: r }));
          }
        } catch (failure) {
          window.SEKIANAFRAZ_BANNER_VIEW.showSendError(sendButton,
            failure && failure.message ? String(failure.message) : 'ارسال انجام نشد. دوباره تلاش کنید.');
        } finally {
          busy = false;
          if (sendButton.dataset.state !== 'error') {
            window.SEKIANAFRAZ_BANNER_VIEW.setSendButtonState(sendButton, 'normal');
            sendButton.disabled = false;
          }
        }
      });
      correctionButton.addEventListener('click', () => { phoneInput.value = ''; returnToPhone(); });
      m.querySelector('.sekianafraz-modal__back-icon')?.addEventListener('click', () => {
        window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(m.querySelector('[data-sekianafraz-banner]'), 1, 'back');
      });
    }
    primary.addEventListener('click', (e) => {
      if (e && typeof e.preventDefault === 'function') e.preventDefault();
      if (e && typeof e.stopPropagation === 'function') e.stopPropagation();
      if (multi) {
        window.SEKIANAFRAZ_BANNER_VIEW.transitionMultiStage(m.querySelector('[data-sekianafraz-banner]'), 2, 'forward').then(() => {
          m.querySelector('.sekianafraz-modal__stage-phone input')?.focus();
        });
        return false;
      }
      if (data && data.reminder) {
        const r = data.reminder;
        try {
          if (typeof r.server_now_ms === 'number' && typeof r.expires_in_ms === 'number') {
            const clientNow = Date.now();
            r.client_now_ms = clientNow;
            r.expires_at_server_ms = r.server_now_ms + r.expires_in_ms;
          }
        } catch (e2) { }
        try { localStorage.setItem('sekianafraz_reminder_active', JSON.stringify(r)); } catch (e3) { }
        closeModal();
        const evt = new CustomEvent('sekianafraz_reminder_triggered', { detail: r });
        window.dispatchEvent(evt);
      } else {
        closeModal();
      }
      if (data.isPreview || data.banner_button_closes || !data.target_url) { return false; }
      window.location.assign(data.target_url);
      return false;
    });
    primary.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); primary.click(); } });
    m.addEventListener('click', (e) => { e.stopPropagation(); });
  }
  function escapeHtml(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] || c; }); }
  function hexToRgba(hex, alpha) { const h = hex.replace('#', ''); const bigint = parseInt(h, 16); const r = (bigint >> 16) & 255; const g = (bigint >> 8) & 255; const b = bigint & 255; return 'rgba(' + r + ',' + g + ',' + b + ',' + alpha + ')'; }
  let runtimeSensors = [];
  let currentPath = '';
  let durationTimer = null;
  let segmentStartedAt = null;
  let segmentWallStartedAt = null;
  function performanceNow() {
    return window.performance && typeof window.performance.now === 'function' ? window.performance.now() : Date.now();
  }
  function evaluateSensors(data, atMs) {
    runtimeSensors.forEach(sensor => {
      if (pendingSensors.has(sensor.id) || completedSensors.has(sensor.id) || (failedAttempts.get(sensor.id) || 0) >= 3) return;
      const entry = qualifyingEntry(data, sensor, atMs);
      if (!entry) return;
      pendingSensors.add(sensor.id);
      queuedTrigger(sensor.id, currentPath, entry.trackingKey)
        .then(res => {
          pendingSensors.delete(sensor.id);
          if (res && (res.success || ['LOGIN_REQUIRED', 'NO_PHONE', 'SKIPPED'].includes(res.code))) completedSensors.add(sensor.id);
          else retrySensor(sensor.id);
        })
        .catch(() => { pendingSensors.delete(sensor.id); retrySensor(sensor.id); });
    });
  }
  function retrySensor(id) {
    const attempts = (failedAttempts.get(id) || 0) + 1;
    failedAttempts.set(id, attempts);
    if (attempts < 3) setTimeout(() => {
      if (document.visibilityState === 'visible') evaluateSensors(sensorLsRead(), Date.now());
    }, 2000 * attempts);
  }
  function addVisibleDuration(data, startMs, endMs) {
    let cursor = startMs;
    while (cursor < endMs) {
      const bucketStartMs = Math.floor(cursor / SENSOR_BUCKET_MS) * SENSOR_BUCKET_MS;
      const sliceEnd = Math.min(endMs, bucketStartMs + SENSOR_BUCKET_MS);
      const durationMs = Math.max(0, sliceEnd - cursor);
      const bucketSeconds = bucketStartMs / 1000;
      runtimeSensors.forEach(sensor => {
        if (sensor.metric === 'views' || completedSensors.has(sensor.id)) return;
        sensor.entries.forEach(entry => addMetric(data, sensor.id, entry.storageKey, bucketSeconds, 0, durationMs, cursor));
      });
      cursor = sliceEnd;
    }
  }
  function flushVisibleDuration(continueSegment, shouldEvaluate) {
    if (segmentStartedAt === null || segmentWallStartedAt === null) return null;
    const endedAt = performanceNow();
    const elapsed = Math.max(0, endedAt - segmentStartedAt);
    const wallEndedAt = segmentWallStartedAt + elapsed;
    if (continueSegment) {
      segmentStartedAt = endedAt;
      segmentWallStartedAt = wallEndedAt;
    } else {
      segmentStartedAt = null;
      segmentWallStartedAt = null;
    }
    if (elapsed < 1) return null;
    const data = sensorLsRead();
    addVisibleDuration(data, wallEndedAt - elapsed, wallEndedAt);
    sensorLsWrite(data);
    if (shouldEvaluate) evaluateSensors(data, wallEndedAt);
    return data;
  }
  function clearDurationTimer() {
    if (durationTimer !== null) clearTimeout(durationTimer);
    durationTimer = null;
  }
  function scheduleDurationTimer() {
    clearDurationTimer();
    if (segmentStartedAt === null || document.visibilityState !== 'visible') return;
    const data = sensorLsRead();
    const atMs = Date.now();
    const liveElapsed = Math.max(0, performanceNow() - segmentStartedAt);
    let delay = Infinity;
    runtimeSensors.forEach(sensor => {
      if (sensor.metric === 'views' || pendingSensors.has(sensor.id) || completedSensors.has(sensor.id)) return;
      sensor.entries.forEach(entry => {
        const totals = totalsFor(data, sensor, entry, atMs);
        const remaining = sensor.minDurationMs - totals.durationMs - liveElapsed;
        if (totals.durationMs < sensor.minDurationMs) delay = Math.min(delay, Math.max(50, remaining));
      });
    });
    if (!Number.isFinite(delay)) return;
    const untilBucketBoundary = SENSOR_BUCKET_MS - (atMs % SENSOR_BUCKET_MS) + 25;
    delay = Math.max(50, Math.min(delay, untilBucketBoundary));
    durationTimer = setTimeout(() => {
      durationTimer = null;
      if (document.visibilityState !== 'visible') return;
      flushVisibleDuration(true, true);
      scheduleDurationTimer();
    }, delay);
  }
  function startVisibleDuration() {
    const hasDurationSensor = runtimeSensors.some(sensor => sensor.metric !== 'views' && !completedSensors.has(sensor.id));
    if (!hasDurationSensor || document.visibilityState !== 'visible' || segmentStartedAt !== null) return;
    segmentStartedAt = performanceNow();
    segmentWallStartedAt = Date.now();
    scheduleDurationTimer();
  }
  function stopVisibleDuration(shouldEvaluate) {
    clearDurationTimer();
    flushVisibleDuration(false, shouldEvaluate);
  }
  (async function () {
    const sensors = await checkSensors();
    runtimeSensors = sensors.map(normalizeSensor).filter(sensor => sensor.id > 0 && sensor.entries.length > 0);
    if (!runtimeSensors.length) return;
    currentPath = (ctx && ctx.path) ? ctx.path : pathOnly(location.href);
    const data = sensorLsRead();
    cleanupSensorMetrics(data);
    recordSensorVisits(data, runtimeSensors, Date.now());
    sensorLsWrite(data);
    evaluateSensors(data, Date.now());
    startVisibleDuration();
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') startVisibleDuration();
      else stopVisibleDuration(true);
    });
    window.addEventListener('pagehide', () => stopVisibleDuration(true));
    window.addEventListener('pageshow', () => startVisibleDuration());
    window.addEventListener('storage', event => {
      if (!event.key || !runtimeSensors.some(sensor => sensor.entries.some(entry => metricStorageKey(sensor, entry) === event.key))) return;
      const latest = sensorLsRead();
      evaluateSensors(latest, Date.now());
      scheduleDurationTimer();
    });
  })();
})();
