(function () {
    'use strict';
    const LS_KEY = 'sekianafraz_reminder_active';
    const DISMISSED_KEY = 'sekianafraz_reminder_dismissed_token';
    let activeTimer = null;
    function safeStore(key, value) { try { localStorage.setItem(key, value); } catch (error) {} }
    function safeRemove(key) { try { localStorage.removeItem(key); } catch (error) {} }
    function escapeHtml(value) {
        return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
            return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;'}[char];
        });
    }
    function hexToRgba(hex, alpha) {
        if (!hex) return 'rgba(0,0,0,0)';
        const h = hex.replace('#', '');
        const bigint = parseInt(h, 16);
        const r = (bigint >> 16) & 255;
        const g = (bigint >> 8) & 255;
        const b = bigint & 255;
        return `rgba(${r},${g},${b},${alpha})`;
    }
    function remainingMs(data) {
        if (!data) return null;
        if (typeof data.expires_in_ms === 'number') {
            if (typeof data.expires_at_server_ms === 'number' && typeof data.server_now_ms === 'number' && typeof data.client_now_ms === 'number') {
                const offset = data.server_now_ms - data.client_now_ms;
                const serverNowApprox = Date.now() + offset;
                return data.expires_at_server_ms - serverNowApprox;
            }
            return data.expires_in_ms;
        }
        if (typeof data.expires_at_ms === 'number') {
            return data.expires_at_ms - Date.now();
        }
        return null;
    }
function init() {
        const root = document.getElementById('sekianafraz-reminder-bar-root');
        if (!root) return;
        const data = getActiveData();
        if (!data) return;
        let dismissedToken = '';
        try { dismissedToken = localStorage.getItem(DISMISSED_KEY); } catch (error) {}
        if (dismissedToken === String(data.issued_at_ms || '')) {
            return;
        }
        render(root, data);
        startTimer(data);
    }
    function getActiveData() {
        try {
            const raw = localStorage.getItem(LS_KEY);
            if (!raw) return null;
            const data = JSON.parse(raw);
            const rem = remainingMs(data);
            if (rem !== null && rem <= 0) {
                safeRemove(LS_KEY);
                return null;
            }
            return data;
        } catch (e) {
            return null;
        }
    }
    function render(root, data) {
        const colors = data.colors || {};
        const showTimerPanel = data.show_timer_panel;
        const container = document.createElement('div');
        container.id = 'sekianafraz-reminder-bar-container';
        container.className = 'sekianafraz-reminder-bar';
        container.style.backgroundColor = colors.bg || '#0a0a0a';
        container.style.color = colors.text || '#fff';
        let message = data.message_template || 'فقط {Timer} ساعت برای استفاده از کد تخفیف {coupon_code} باقی مونده!';
        const highlight = colors.coupon_highlight || '#5F0027';
        const couponStyle = `padding:2px 6px; margin:0 2px; cursor:pointer; background:${hexToRgba(highlight, 0.3)}; color:${highlight}; border-radius:4px; transition: all 0.2s`;
        message = message.replace('{coupon_code}', `<strong class="sekianafraz-reminder-coupon" style="${couponStyle}">${escapeHtml(data.coupon_code)}</strong>`);
        const timerHtml = `<span id="sekianafraz-reminder-timer-text" class="sekianafraz-reminder-timer-val" style="color:${colors.timer_value || '#5F0027'}">--:--:--</span>`;
        message = message.replace('{Timer}', timerHtml);
        let html = `<div class="sekianafraz-reminder-content">${message}</div>`;
        if (showTimerPanel) {
            container.classList.add('has-timer');
            html += `
            <div class="sekianafraz-reminder-timer-panel" style="direction:ltr">
                <div class="sekianafraz-timer-unit" style="background:${colors.timer_bg || '#fff'};color:${colors.timer_text || '#000'}"><span id="sekianafraz-h">00</span></div>
                <span class="sekianafraz-sep">:</span>
                <div class="sekianafraz-timer-unit" style="background:${colors.timer_bg || '#fff'};color:${colors.timer_text || '#000'}"><span id="sekianafraz-m">00</span></div>
                <span class="sekianafraz-sep">:</span>
                <div class="sekianafraz-timer-unit" style="background:${colors.timer_bg || '#fff'};color:${colors.timer_text || '#000'}"><span id="sekianafraz-s">00</span></div>
            </div>`;
        }
        html += `
        <button type="button" id="sekianafraz-reminder-close" class="sekianafraz-reminder-close" aria-label="بستن نوار یادآور" style="color:${colors.close_btn || '#fff'}">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>`;
        container.innerHTML = html;
        window.SEKIANAFRAZ_APPLY_REMINDER_STYLES?.(container, data.styles);
        root.appendChild(container);
        document.getElementById('sekianafraz-reminder-close').onclick = function () {
            container.style.display = 'none';
            safeStore(DISMISSED_KEY, String(data.issued_at_ms || ''));
        };
        container.addEventListener('click', (e) => {
            const coupon = e.target.closest('.sekianafraz-reminder-coupon');
            if (coupon) {
                e.preventDefault();
                e.stopPropagation();
                const originalText = data.coupon_code;
                const copy = navigator.clipboard && window.isSecureContext
                    ? navigator.clipboard.writeText(originalText)
                    : Promise.resolve().then(() => {
                        const input = document.createElement('textarea'); input.value = originalText;
                        document.body.appendChild(input); input.select();
                        const copied = document.execCommand('copy'); input.remove();
                        if (!copied) throw new Error('Copy failed');
                    });
                copy.then(() => {
                    coupon.textContent = 'کپی شد';
                    setTimeout(() => {
                        coupon.textContent = originalText;
                    }, 1500);
                }).catch(() => {});
            }
        });
    }
    function startTimer(data) {
        if (activeTimer !== null) clearInterval(activeTimer);
        activeTimer = null;
        const hEl = document.getElementById('sekianafraz-h');
        const mEl = document.getElementById('sekianafraz-m');
        const sEl = document.getElementById('sekianafraz-s');
        const tTextEl = document.getElementById('sekianafraz-reminder-timer-text');
        const rem0 = remainingMs(data);
        if (rem0 === null) return;
        let endPerf = performance.now() + Math.max(0, rem0);
        let timerId = null;
        function stopAndHide() {
            const container = document.getElementById('sekianafraz-reminder-bar-container');
            if (container) container.style.display = 'none';
            safeRemove(LS_KEY);
            if (timerId) clearInterval(timerId);
        }
        function update() {
            const diff = endPerf - performance.now();
            if (diff <= 0) {
                stopAndHide();
                return;
            }
            const h = Math.floor(diff / (1000 * 60 * 60));
            const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
            const s = Math.floor((diff % (1000 * 60)) / 1000);
            const hh = h.toString().padStart(2, '0');
            const mm = m.toString().padStart(2, '0');
            const ss = s.toString().padStart(2, '0');
            if (hEl) hEl.textContent = hh;
            if (mEl) mEl.textContent = mm;
            if (sEl) sEl.textContent = ss;
            if (tTextEl) tTextEl.textContent = `${hh}:${mm}:${ss}`;
        }
        update();
        timerId = setInterval(update, 1000);
        activeTimer = timerId;
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
    window.addEventListener('sekianafraz_reminder_triggered', function (e) {
        const root = document.getElementById('sekianafraz-reminder-bar-root');
        if (!root) return;
        const old = document.getElementById('sekianafraz-reminder-bar-container');
        if (old) old.remove();
        const detail = (e && e.detail) ? e.detail : {};
        try {
            if (typeof detail.server_now_ms === 'number' && typeof detail.expires_in_ms === 'number' && typeof detail.client_now_ms !== 'number') {
                const clientNow = Date.now();
                detail.client_now_ms = clientNow;
                detail.expires_at_server_ms = detail.server_now_ms + detail.expires_in_ms;
                localStorage.setItem(LS_KEY, JSON.stringify(detail));
            }
        } catch (e2) { }
        render(root, detail);
        startTimer(detail);
    });
})();
