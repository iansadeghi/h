(function () {
    'use strict';
    var DISPLAY_MS = 5000;
    var FADE_MS = 500;
    var GLOW_THRESHOLD_PERCENT = 80;
    function boot() {
        var preloader = document.getElementById('sekianafrazPreloader');
        var barWrap = document.getElementById('sekianafrazPreloaderBar');
        var barFill = barWrap ? barWrap.querySelector('.sekianafraz-preloader-bar-fill') : null;
        if (!preloader || !barFill) {
            document.documentElement.classList.add('sekianafraz-preloading-done');
            return;
        }
        var startTime = Number(window.SEKIANAFRAZPreloaderStartedAt) || performance.now();
        var rafId = null;
        var finished = false;
        function easeProgress(t) {
            return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
        }
        function setProgress(percent) {
            percent = Math.max(0, Math.min(100, percent));
            barFill.style.width = percent + '%';
            barFill.classList.toggle('is-glowing', percent >= GLOW_THRESHOLD_PERCENT);
        }
        function finish() {
            if (finished) return;
            finished = true;
            if (rafId) cancelAnimationFrame(rafId);
            setProgress(100);
            preloader.classList.add('is-hidden');
            barWrap.classList.add('is-hidden');
            window.setTimeout(function () {
                preloader.remove();
                barWrap.remove();
                document.documentElement.classList.add('sekianafraz-preloading-done');
            }, FADE_MS);
        }
        function tick(now) {
            var elapsed = now - startTime;
            var target = easeProgress(Math.min(elapsed / DISPLAY_MS, 1)) * 100;
            setProgress(target);
            if (elapsed >= DISPLAY_MS) {
                finish();
                return;
            }
            rafId = requestAnimationFrame(tick);
        }
        rafId = requestAnimationFrame(tick);
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', boot, { once: true });
    } else {
        boot();
    }
}());
