window.SEKIANAFRAZ_APPLY_REMINDER_STYLES = function (container, styles) {
  if (!container || !styles || !Object.keys(styles).length) return;
  const px = (values, keys) => keys.map(key => Math.max(0, Math.min(200, Number(values?.[key]) || 0)) + 'px').join(' ');
  const radius = (el, target) => { if (styles.radii?.[target]) el.style.borderRadius = px(styles.radii[target], ['tl','tr','br','bl']); };
  const spacing = (el, kind, target) => { if (styles[kind]?.[target]) el.style[kind === 'paddings' ? 'padding' : 'margin'] = px(styles[kind][target], ['t','r','b','l']); };
  spacing(container, 'paddings', 'bar');
  container.querySelectorAll('.sekianafraz-reminder-coupon').forEach(el => { radius(el, 'coupon'); spacing(el, 'paddings', 'coupon'); });
  container.querySelectorAll('.sekianafraz-timer-unit').forEach(el => {
    radius(el, 'timer'); spacing(el, 'paddings', 'timer');
    el.style.minWidth = '32px'; el.style.minHeight = '32px'; el.style.width = 'auto'; el.style.height = 'auto'; el.style.boxSizing = 'content-box';
  });
  container.querySelectorAll('.sekianafraz-reminder-content').forEach(el => { spacing(el, 'margins', 'text'); el.style.minWidth = '0'; el.style.width = 'auto'; el.style.flex = '1'; });
  container.querySelectorAll('.sekianafraz-reminder-timer-panel').forEach(el => { spacing(el, 'margins', 'timer'); el.style.width = 'auto'; el.style.height = 'auto'; el.style.flexShrink = '0'; });
};
