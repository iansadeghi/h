(function () {
  const Core = window.SEKIANAFRAZ_ADMIN_CORE;
  const Controls = window.SEKIANAFRAZ_ADMIN_CONTROLS;
  const Fields = window.SEKIANAFRAZ_ADMIN_SENSOR_FIELDS;
  const Preview = window.SEKIANAFRAZ_ADMIN_SENSOR_PREVIEW;
  const Lifecycle = window.SEKIANAFRAZ_ADMIN_SENSOR_LIFECYCLE;
  const Pages = window.SEKIANAFRAZ_ADMIN_PAGES;
  function disableBrowserSuggestions(root) {
    if (!root || root.nodeType !== 1) return;
    const fields = root.matches('input, textarea, select, form') ? [root] : [];
    fields.push(...root.querySelectorAll('input, textarea, select, form'));
    fields.forEach(field => {
      field.setAttribute('autocomplete', 'off');
      if (field.type === 'password') {
        field.setAttribute('data-lpignore', 'true');
        field.setAttribute('data-1p-ignore', 'true');
      }
    });
  }
  window.SEKIANAFRAZ_MODAL_ENGINE = {
    ...(window.SEKIANAFRAZ_MODAL_ENGINE || {}),
    renderModal: Fields.renderModal,
    loadPlacementFields: Fields.loadPlacementFields,
    bindModalClose: Lifecycle.bindModalClose,
    closeModal: Lifecycle.closeSensorModal,
    togglePreviewVisibility: Preview.togglePreviewVisibility,
    mountPreviewArea: Preview.mountPreviewArea,
    bindLiveEvents: Preview.bindLiveEvents,
    mountCustomSelects: Controls.mountCustomSelects,
    applyNumberGuards: Controls.applyNumberGuards,
    enhanceTooltips: Controls.enhanceTooltips,
    mountCustomCouponTemplate: Fields.mountCustomCouponTemplate,
    mountCouponLimit: Fields.mountCouponLimit,
    mountReminder: Fields.mountReminder,
    updatePreview: Preview.updatePreview,
    updateVarsTables: Core.updateVarsTables,
    applyModalCheckboxSkin: Controls.applyModalCheckboxSkin,
    getSensorData: Fields.getSensorData,
    api: Core.api,
    toast: Core.toast,
    notice: Core.toast,
    commitBaseline: Lifecycle.commitModalBaseline,
    scheduleBaseline: Lifecycle.scheduleModalBaseline,
    isDirty: Lifecycle.isModalActuallyDirty,
    getEl(id) { return document.getElementById(id); },
    setFieldValue(id, value, opts) {
      const el = document.getElementById(id);
      if (!el) return false;
      const options = opts || {};
      try {
        const type = (el.getAttribute('type') || '').toLowerCase();
        if (type === 'checkbox' || type === 'radio') el.checked = !!value;
        else el.value = value == null ? '' : String(value);
        if (options.trigger !== false) {
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
        }
      } catch (error) {
        return false;
      }
      return true;
    }
  };
  window.SEKIANAFRAZ_PAGE_MOUNTS = {
    sensors: Pages.mountSensors,
    sms: Pages.mountSms,
    compat: Pages.mountCompat,
    leads: Pages.mountLeads,
    applyNumberGuards: Controls.applyNumberGuards
  };
  window.SEKIANAFRAZ_ADMIN_FUNCS = window.SEKIANAFRAZ_ADMIN_FUNCS || {};
  window.SEKIANAFRAZ_ADMIN_FUNCS.toast = Core.toast;
  document.addEventListener('DOMContentLoaded', function () {
    const admin = document.querySelector('.sekianafraz-admin');
    if (admin) {
      disableBrowserSuggestions(admin);
      new MutationObserver(records => records.forEach(record => record.addedNodes.forEach(disableBrowserSuggestions)))
        .observe(admin, { childList: true, subtree: true });
    }
    Pages.mountSms();
    Pages.mountCompat();
    Pages.mountSensors();
    Pages.mountLeads();
    Controls.mountCustomSelects(document);
    Controls.applyNumberGuards();
    Controls.enhanceTooltips(document);
    Controls.watchInputDirections();
    Controls.bindVariableCopy();
    Controls.mountColorFields(document);
    document.addEventListener('wheel', function () {
      const el = document.activeElement;
      if (el && el.tagName === 'INPUT' && el.type === 'number') el.blur();
    }, { passive: true });
    document.addEventListener('click', (event) => {
      const coupon = event.target.closest('.sekianafraz-preview-coupon');
      if (!coupon) return;
      event.preventDefault();
      event.stopPropagation();
      const originalText = coupon.dataset.code || 'Sensor Coupon';
      navigator.clipboard.writeText(originalText).then(() => {
        coupon.textContent = 'کپی شد';
        setTimeout(() => { coupon.textContent = originalText; }, 1500);
      });
    });
  });
})();
