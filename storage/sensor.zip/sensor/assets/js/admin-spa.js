(function () {
    'use strict';
    var cfg       = window.SEKIANAFRAZ_SPA || {};
    var rest      = (cfg.rest || '').replace(/\/$/, '');
    var nonce     = cfg.nonce || '';
    var currentTab  = '';
    var isLoading   = false;
    var initialReadySignalled = false;
    function signalInitialContentReady() {
        if (initialReadySignalled) return;
        initialReadySignalled = true;
        window.SEKIANAFRAZInitialContentReady = true;
        document.dispatchEvent(new CustomEvent('sekianafraz:initial-content-ready'));
    }
    function getTabFromUrl() {
        try {
            return new URLSearchParams(window.location.search).get('tab') || 'sensors';
        } catch (e) {
            return 'sensors';
        }
    }
    function getTabHref(tab) {
        try {
            var url = new URL(window.location.href);
            url.searchParams.set('tab', tab);
            return url.toString();
        } catch (e) {
            return window.location.href;
        }
    }
    function showSpinner(container) {
        container.innerHTML =
            '<div class="sekianafraz-spa-spinner-wrap" aria-live="polite" aria-label="در حال بارگذاری">' +
                '<div class="sekianafraz-spa-spinner" aria-hidden="true"></div>' +
                '<span class="sekianafraz-spa-spinner-label">در حال بارگذاری\u2026</span>' +
            '</div>';
    }
    function waitForImages(container) {
        return Promise.all(Array.prototype.map.call(container.querySelectorAll('img'), function (img) {
            if (img.complete) return Promise.resolve();
            return new Promise(function (resolve) {
                img.addEventListener('load', resolve, { once: true });
                img.addEventListener('error', resolve, { once: true });
            });
        }));
    }
    function executeInlineScripts(container) {
        var scripts = container.querySelectorAll('script');
        for (var i = 0; i < scripts.length; i++) {
            var old = scripts[i];
            var fresh = document.createElement('script');
            for (var a = 0; a < old.attributes.length; a++) {
                fresh.setAttribute(old.attributes[a].name, old.attributes[a].value);
            }
            if (old.textContent) {
                fresh.textContent = old.textContent;
            }
            old.parentNode.replaceChild(fresh, old);
        }
    }
    function moveTabIndicator(activeTab) {
        var list = document.querySelector('.sekianafraz-tabs-list');
        var indicator = list ? list.querySelector('.sekianafraz-tab-indicator') : null;
        if (!list || !indicator || !activeTab) return;
        indicator.style.left = activeTab.offsetLeft + 'px';
        indicator.style.width = activeTab.offsetWidth + 'px';
        indicator.classList.add('is-ready');
    }
    function updateTabHeaders(tab) {
        var activeTab = null;
        document.querySelectorAll('.sekianafraz-tab').forEach(function (el) {
            var href   = el.getAttribute('href') || '';
            var search = href.indexOf('?') !== -1 ? href.split('?')[1] : '';
            var tabKey;
            try {
                tabKey = new URLSearchParams(search).get('tab') || 'sensors';
            } catch (e) {
                tabKey = 'sensors';
            }
            var isActive = tabKey === tab;
            el.classList.toggle('active', isActive);
            if (isActive) activeTab = el;
        });
        moveTabIndicator(activeTab);
    }
    function mountCommon(container) {
        var engine = window.SEKIANAFRAZ_MODAL_ENGINE || {};
        if (typeof engine.mountCustomSelects === 'function') {
            engine.mountCustomSelects(container);
        }
        if (typeof engine.enhanceTooltips === 'function') {
            engine.enhanceTooltips(container);
        }
        var mounts = window.SEKIANAFRAZ_PAGE_MOUNTS || {};
        if (typeof mounts.applyNumberGuards === 'function') {
            mounts.applyNumberGuards();
        }
    }
    function mountTabModules(tab, container) {
        mountCommon(container);
        var page = window.SEKIANAFRAZ_PAGE_MOUNTS || {};
        switch (tab) {
            case 'sensors':
                if (typeof page.sensors === 'function') page.sensors();
                break;
            case 'sms':
                if (typeof page.sms    === 'function') page.sms();
                if (typeof page.compat === 'function') page.compat();
                break;
            case 'leads':
                if (typeof page.leads === 'function') page.leads();
                break;
            default:
                break;
        }
    }
    function hoistModalsToBody(container) {
        container.querySelectorAll('.sekianafraz-modal, .sekianafraz-bulk-actions').forEach(function (modal) {
            if (!modal.classList.contains('sekianafraz-admin')) {
                modal.classList.add('sekianafraz-admin');
            }
            modal.setAttribute('data-sekianafraz-spa-hoisted', '1');
            document.body.appendChild(modal);
        });
    }
    function removeHoistedModals() {
        document.querySelectorAll('[data-sekianafraz-spa-hoisted="1"]').forEach(function (modal) {
            modal.remove();
        });
        document.body.classList.remove('sekianafraz-sensor-modal-open');
        document.body.style.overflow = '';
    }
    var EXIT_DURATION = 200;
    function loadTab(tab) {
        if (isLoading) return;
        if (!rest || !nonce) {
            signalInitialContentReady();
            return;
        }
        isLoading = true;
        var container = document.getElementById('sekianafraz-spa-content');
        if (!container) {
            isLoading = false;
            signalInitialContentReady();
            return;
        }
        var url = rest + '/admin/tab' + (rest.indexOf('?') === -1 ? '?' : '&') + 'tab=' + encodeURIComponent(tab);
        var existing = container.querySelector('.sekianafraz-spa-tab-content');
        function startFetch() {
            fetch(url, {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'X-WP-Nonce': nonce,
                    'Accept': 'application/json'
                }
            })
            .then(function (res) { return res.json(); })
            .then(function (data) {
                if (!data || !data.success) {
                    throw new Error('REST error');
                }
                var resolvedTab = data.tab || tab;
                var html        = data.html || '';
                removeHoistedModals();
                var wrapper = document.createElement('div');
                wrapper.className = 'sekianafraz-spa-tab-content sekianafraz-spa-enter';
                wrapper.innerHTML = html;
                container.innerHTML = '';
                container.appendChild(wrapper);
                executeInlineScripts(wrapper);
                hoistModalsToBody(wrapper);
                requestAnimationFrame(function () {
                    requestAnimationFrame(function () {
                        wrapper.classList.add('sekianafraz-spa-enter-active');
                    });
                });
                updateTabHeaders(resolvedTab);
                mountTabModules(resolvedTab, wrapper);
                currentTab = resolvedTab;
                return waitForImages(wrapper);
            })
            .catch(function () {
                container.innerHTML =
                    '<div class="sekianafraz-spa-error">' +
                        'خطا در بارگذاری محتوا. لطفاً <a href="' + getTabHref(tab) + '">صفحه را رفرش کنید</a>.' +
                    '</div>';
            })
            .finally(function () {
                isLoading = false;
                signalInitialContentReady();
            });
        }
        if (existing) {
            existing.classList.add('sekianafraz-spa-exit');
            requestAnimationFrame(function () {
                requestAnimationFrame(function () {
                    existing.classList.add('sekianafraz-spa-exit-active');
                });
            });
            setTimeout(function () {
                showSpinner(container);
                startFetch();
            }, EXIT_DURATION);
        } else {
            showSpinner(container);
            startFetch();
        }
    }
    function init() {
        var container = document.getElementById('sekianafraz-spa-content');
        if (!container || !rest || !nonce) {
            signalInitialContentReady();
            return;
        }
        document.addEventListener('click', function (e) {
            var link = e.target.closest ? e.target.closest('.sekianafraz-tab') : null;
            if (!link) return;
            var href = link.getAttribute('href') || '';
            var search = href.indexOf('?') !== -1 ? href.split('?')[1] : '';
            var tab;
            try {
                tab = new URLSearchParams(search).get('tab') || 'sensors';
            } catch (err) {
                return;
            }
            e.preventDefault();
            if (tab === currentTab && !isLoading) return;
            updateTabHeaders(tab);
            try { link.blur(); } catch (ex) {   }
            try {
                history.pushState({ sekianafrazTab: tab }, '', href);
            } catch (ex) {   }
            loadTab(tab);
        });
        window.addEventListener('popstate', function (e) {
            var tab = (e.state && e.state.sekianafrazTab) ? e.state.sekianafrazTab : getTabFromUrl();
            updateTabHeaders(tab);
            loadTab(tab);
        });
        var initialTab = getTabFromUrl();
        try {
            history.replaceState({ sekianafrazTab: initialTab }, '', window.location.href);
        } catch (ex) {   }
        updateTabHeaders(initialTab);
        if (document.fonts && document.fonts.ready) {
            document.fonts.ready.then(function () {
                moveTabIndicator(document.querySelector('.sekianafraz-tab.active'));
            });
        }
        window.addEventListener('resize', function () {
            moveTabIndicator(document.querySelector('.sekianafraz-tab.active'));
        });
        loadTab(initialTab);
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
