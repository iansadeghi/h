<?php
namespace SeKianAfraz\VisitDiscount\Sensors;
if (!defined('ABSPATH')) { exit; }
class SensorCPT
{
    public function register(): void
    {
        register_post_type('sekianafraz_sensor', [
            'label' => 'SeKianAfraz Sensors',
            'public' => false,
            'show_ui' => false,
            'supports' => ['title'],
            'capability_type' => 'sekianafraz_sensor',
            'map_meta_cap' => true,
            'capabilities' => [
                'edit_posts' => 'manage_options',
                'edit_others_posts' => 'manage_options',
                'publish_posts' => 'manage_options',
                'read_private_posts' => 'manage_options',
                'delete_posts' => 'manage_options',
                'delete_private_posts' => 'manage_options',
                'delete_published_posts' => 'manage_options',
                'delete_others_posts' => 'manage_options',
                'edit_private_posts' => 'manage_options',
                'edit_published_posts' => 'manage_options',
                'create_posts' => 'manage_options',
                'read' => 'manage_options',
            ],
        ]);
    }
}
