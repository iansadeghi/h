<?php
namespace SeKianAfraz\VisitDiscount\Sensors;
use SeKianAfraz\VisitDiscount\Helpers\Path;
if (!defined('ABSPATH')) { exit; }
class SensorService
{
    private $lastWrittenSensorId = 0;
    public function lastWrittenSensorId(): int
    {
        return $this->lastWrittenSensorId;
    }
    private function mapMeta(array $meta): array
    {
        $get = function(string $key, $default = '') use ($meta) { return isset($meta[$key][0]) ? maybe_unserialize($meta[$key][0]) : $default; };
        return [
            'placement' => (string)$get('placement'),
            'items' => (array)$get('items', []),
            'min_views' => (int)$get('min_views', 0),
            'min_duration' => (int)$get('min_duration', 1),
            'visit_metric' => (string)$get('visit_metric', 'views'),
            'visit_calculation' => (string)$get('visit_calculation', 'individual'),
            'visit_condition' => (string)$get('visit_condition', 'or') === 'and' ? 'and' : 'or',
            'window' => (string)$get('window', '24h'),
            'coupon_type' => (string)$get('coupon_type', 'mixed'),
            'coupon_custom_prefix' => (string)$get('coupon_custom_prefix', ''),
            'coupon_custom_suffix' => (string)$get('coupon_custom_suffix', ''),
            'coupon_custom_length' => (int)$get('coupon_custom_length', 4),
            'coupon_custom_mid_pattern' => (string)$get('coupon_custom_mid_pattern', 'mixed'),
            'coupon_free_shipping' => (bool)$get('coupon_free_shipping', false),
            'coupon_amount' => (float)$get('coupon_amount', 0),
            'coupon_mode' => (string)$get('coupon_mode', 'fixed'),
            'coupon_valid_hours' => (int)$get('coupon_valid_hours', 72),
            'banner_target_url' => (string)$get('banner_target_url', ''),
            'banner_button_closes' => (bool)$get('banner_button_closes', true),
            'sms_target_url' => (string)$get('sms_target_url', ''),
            'logged_sms_target_url' => (string)$get('logged_sms_target_url', ''),
            'action' => (string)$get('action', 'banner'),
            'hide_banner_for_logged_in' => (bool)$get('hide_banner_for_logged_in', false),
            'sms_mode' => (string)$get('sms_mode', ''),
            'sms_text' => (string)$get('sms_text', ''),
            'sms_pattern' => (string)$get('sms_pattern', ''),
            'banner_title' => (string)$get('banner_title', ''),
            'banner_text' => (string)$get('banner_text', ''),
            'banner_button_color' => (string)$get('banner_button_color', ''),
            'banner_type' => (string)$get('banner_type', 'single'),
            'logged_behavior' => (string)$get('logged_behavior', 'single_sms'),
            'logged_banner' => (array)$get('logged_banner', []),
            'logged_sms_mode' => (string)$get('logged_sms_mode', ''),
            'logged_sms_text' => (string)$get('logged_sms_text', ''),
            'logged_sms_pattern' => (string)$get('logged_sms_pattern', ''),
            'logged_sms_delay_type' => (string)$get('logged_sms_delay_type', 'immediate'),
            'logged_sms_delay_minutes' => (int)$get('logged_sms_delay_minutes', 60),
            'banner_show_close' => (bool)$get('banner_show_close', false),
            'banner_close_hide_bg' => (bool)$get('banner_close_hide_bg', false),
            'banner_close_position' => (string)$get('banner_close_position', 'left'),
            'close_bg_color' => (string)$get('close_bg_color', '#f1f1f1'),
            'close_icon_color' => (string)$get('close_icon_color', '#111111'),
            'banner_button_text_color' => (string)$get('banner_button_text_color', '#ffffff'),
            'discount_bg_color' => (string)$get('discount_bg_color', '#f2f2f2'),
            'discount_border_color' => (string)$get('discount_border_color', '#d1d5db'),
            'copy_bg_color' => (string)$get('copy_bg_color', '#e5e7eb'),
            'copy_text_color' => (string)$get('copy_text_color', '#000000'),
            'coupon_limit_enabled' => (bool)$get('coupon_limit_enabled', false),
            'coupon_limit_type' => (string)$get('coupon_limit_type', ''),
            'coupon_limit_ids' => (array)$get('coupon_limit_ids', []),
            'banner_image' => (string)$get('banner_image', ''),
            'banner_hide_image' => (bool)$get('banner_hide_image', false),
            'banner_svg_color' => (string)$get('banner_svg_color', '#000000'),
            'banner_border_radius' => (int)$get('banner_border_radius', 0),
            'banner_radius_mode' => (string)$get('banner_radius_mode', 'simple'),
            'banner_border_radii' => (array)$get('banner_border_radii', []),
            'banner_paddings' => (array)$get('banner_paddings', []),
            'banner_margins' => (array)$get('banner_margins', []),
            'multi_prompt' => (string)$get('multi_prompt', ''),
            'multi_phone_placeholder' => (string)$get('multi_phone_placeholder', ''),
            'multi_submit_text' => (string)$get('multi_submit_text', ''),
            'multi_sending_text' => (string)$get('multi_sending_text', ''),
            'multi_success_text' => (string)$get('multi_success_text', ''),
            'multi_correction_text' => (string)$get('multi_correction_text', ''),
            'multi_colors' => (array)$get('multi_colors', []),
            'banner_button_text' => (string)$get('banner_button_text', ''),
            'display_name_fallback' => (string)$get('display_name_fallback', 'کاربر'),
            'coupon_usage_limit' => (int)$get('coupon_usage_limit', 3),
            'coupon_restrict_user' => (bool)$get('coupon_restrict_user', false),
            'coupon_restrict_guest' => (bool)$get('coupon_restrict_guest', false),
            'banner_bg_color' => (string)$get('banner_bg_color', '#ffffff'),
            'banner_title_color' => (string)$get('banner_title_color', '#0d0d0d'),
            'banner_text_color' => (string)$get('banner_text_color', '#4b5563'),
            'banner_coupon_color' => (string)$get('banner_coupon_color', '#5c5c5c'),
            'banner_font_type' => (string)$get('banner_font_type', 'arad'),
            'sms_delay_type' => (string)$get('sms_delay_type', 'immediate'),
            'sms_delay_minutes' => (int)$get('sms_delay_minutes', 60),
            'coupon_strategy' => (string)$get('coupon_strategy', 'individual'),
            'fixed_code' => (string)$get('fixed_code', ''),
            'reminder_enabled' => ($get('banner_type', 'single') !== 'multi' || in_array($get('logged_behavior', 'single_sms'), ['single', 'single_sms'], true)) && (bool)$get('reminder_enabled', false),
            'reminder_message_template' => (string)$get('reminder_message_template', 'فقط {Timer} ساعت برای استفاده از کد تخفیف {coupon_code} باقی مونده!'),
            'reminder_show_timer_panel' => (bool)$get('reminder_show_timer_panel', false),
            'reminder_styles' => (array)$get('reminder_styles', []),
            'reminder_colors' => (array)$get('reminder_colors', [
                'bg' => '#ffffff',
                'text' => '#4b5563',
                'timer_value' => '#5F0027',
                'timer_bg' => '#000000',
                'timer_text' => '#ffffff',
                'close_btn' => '#4b5563',
                'coupon_highlight' => '#5F0027',
            ]),
        ];
    }
    public function get(int $id): array
    {
        if (!$this->isSensorPost($id)) return [];
        $meta = $this->mapMeta(get_post_meta($id));
        $item = array_merge(['id' => $id, 'name' => get_the_title($id), 'status' => get_post_status($id)], $meta);
        if (class_exists('SeKianAfraz\VisitDiscount\\Sensors\\SensorCoverageService')) {
            $item['exclusions'] = (new SensorCoverageService())->getExclusions($id, 1, 5);
        }
        return $item;
    }
    public function normalizeItemsForPlacement(string $placement, array $items): array
    {
        $placement = sanitize_key($placement);
        $numericPlacements = [
            'product_single','product_cat','product_tag','product_in_cat','product_in_tag',
            'post_single','post_cat','post_tag','post_in_cat','post_in_tag','page'
        ];
        $out = [];
        foreach ($items as $item) {
            if ((string)$item === '*' && in_array($placement, $numericPlacements, true)) {
                $out[] = '*';
                continue;
            }
            if ($placement === 'custom_url') {
                $path = Path::canonicalize((string)$item, Path::homePath());
                if ($path !== '') $out[] = $path;
                continue;
            }
            if ($placement === 'search_terms') {
                $term = trim(sanitize_text_field((string)$item));
                if ($term !== '') $out[] = $term;
                continue;
            }
            if (in_array($placement, $numericPlacements, true)) {
                $number = $this->normalizeDigits((string)$item);
                if ($number !== '' && ctype_digit($number) && (int)$number > 0) $out[] = (string)((int)$number);
            }
        }
        return array_values(array_unique($out));
    }
    public function list(): array
    {
        $out = $this->listPaged(1, 100);
        return $out['items'];
    }
    public function listPaged(int $page = 1, int $perPage = 20): array
    {
        $q = new \WP_Query([
            'post_type' => 'sekianafraz_sensor',
            'posts_per_page' => $perPage,
            'paged' => max(1, $page),
            'post_status' => ['publish', 'draft'],
            'orderby' => 'ID',
            'order' => 'DESC',
            'fields' => 'ids',
            'no_found_rows' => false,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        ]);
        $ids = $q->posts;
        if (!empty($ids)) {
            update_meta_cache('post', $ids);
            _prime_post_caches($ids, false, false);
        }
        $allMeta = [];
        $res = [];
        $postIds = [];
        $termIds = [];
        foreach ($ids as $id) {
            $metaRaw = get_post_meta($id);
            $m = $this->mapMeta($metaRaw);
            $allMeta[$id] = $m;
            $placement = $m['placement'];
            $items = $m['items'];
            if (empty($items)) continue;
            if (in_array($placement, ['product_single', 'post_single', 'page'], true)) {
                foreach ($items as $itm) {
                    if (ctype_digit((string)$itm)) $postIds[] = (int)$itm;
                }
            } elseif (in_array($placement, ['product_cat', 'product_tag', 'product_in_cat', 'product_in_tag', 'post_cat', 'post_tag', 'post_in_cat', 'post_in_tag'], true)) {
                $tax = '';
                if ($placement === 'product_cat') $tax = 'product_cat';
                elseif ($placement === 'product_tag') $tax = 'product_tag';
                elseif ($placement === 'product_in_cat') $tax = 'product_cat';
                elseif ($placement === 'product_in_tag') $tax = 'product_tag';
                elseif ($placement === 'post_cat') $tax = 'category';
                elseif ($placement === 'post_tag') $tax = 'post_tag';
                elseif ($placement === 'post_in_cat') $tax = 'category';
                elseif ($placement === 'post_in_tag') $tax = 'post_tag';
                if ($tax) {
                    if (!isset($termIds[$tax])) $termIds[$tax] = [];
                    foreach ($items as $itm) {
                        if (ctype_digit((string)$itm)) $termIds[$tax][] = (int)$itm;
                    }
                }
            }
        }
        $labelMap = [];
        if (!empty($postIds)) {
            $postIds = array_unique($postIds);
            $chunked = array_chunk($postIds, 500);
            foreach ($chunked as $chunk) {
                $posts = get_posts([
                    'post_type' => 'any',
                    'post_status' => 'any',
                    'posts_per_page' => -1,
                    'include' => $chunk,
                    'orderby' => 'post__in',
                    'no_found_rows' => true,
                    'suppress_filters' => true,
                    'cache_results' => true,
                ]);
                foreach ($posts as $p) {
                    $labelMap['p_' . $p->ID] = $p->post_title;
                }
            }
        }
        foreach ($termIds as $tax => $tids) {
            $tids = array_unique($tids);
            if (empty($tids)) continue;
            $terms = get_terms([
                'taxonomy' => $tax,
                'include' => $tids,
                'hide_empty' => false,
                'fields' => 'id=>name'
            ]);
            if (!is_wp_error($terms)) {
                foreach ($terms as $tid => $name) {
                    $labelMap['t_'.$tid] = $name;
                }
            }
        }
        foreach ($ids as $id) {
            $m = $allMeta[$id];
            $itemLabels = $this->resolveLabels($m['placement'], $m['items'], $labelMap);
            $res[] = [
                'id' => $id,
                'name' => get_the_title($id),
                'status' => get_post_status($id),
                'placement' => $m['placement'],
                'items' => $m['items'],
                'item_labels' => $itemLabels,
                'min_views' => $m['min_views'],
                'min_duration' => $m['min_duration'],
                'visit_metric' => $m['visit_metric'],
                'visit_calculation' => $m['visit_calculation'],
                'visit_condition' => $m['visit_condition'],
                'window' => $m['window'],
                'action' => $m['action'],
            ];
        }
        return [
            'items' => $res,
            'has_more' => (int)$q->max_num_pages > max(1, $page),
        ];
    }
        public function save(array $data, ?int $id = null): int
        {
            $this->lastWrittenSensorId = 0;
            $title = sanitize_text_field($data['name'] ?? '');
            $post_id = $id ? (int)$id : 0;
            if ($post_id > 0 && !$this->isSensorPost($post_id)) {
                return 0;
            }
            $status = $this->normalizePostStatus($post_id, $data);
            $beforeScope = $this->coverageSpec($post_id);
            $p = ['post_type' => 'sekianafraz_sensor', 'post_status' => $status, 'post_title' => $title];
            if ($post_id > 0) $p['ID'] = $post_id;
            $post_id = $post_id > 0 ? wp_update_post($p, true) : wp_insert_post($p, true);
            if (is_wp_error($post_id) || (int)$post_id <= 0) return 0;
            $this->lastWrittenSensorId = (int)$post_id;
            $this->updateSensorMeta((int)$post_id, $data);
            $this->maybeEnsureFixedCoupon((int)$post_id);
            $this->syncIndexForStatus((int)$post_id, $status, $beforeScope !== $this->coverageSpec((int)$post_id));
            do_action('sekianafraz_sensor_changed', (int)$post_id);
            return (int)$post_id;
        }
        private function normalizePostStatus(int $post_id, array $data): string
        {
            $status = $post_id > 0 ? (get_post_status($post_id) ?: 'publish') : 'publish';
            if (!empty($data['status'])) {
                $candidate = sanitize_text_field((string)$data['status']);
                if (in_array($candidate, ['publish', 'draft'], true)) {
                    $status = $candidate;
                }
            }
            return $status;
        }
        private function updateSensorMeta(int $post_id, array $data): void
        {
            $bannerType = $data['banner_type'] ?? get_post_meta($post_id, 'banner_type', true);
            $loggedBehavior = $data['logged_behavior'] ?? (get_post_meta($post_id, 'logged_behavior', true) ?: 'single_sms');
            if ($bannerType === 'multi' && !in_array($loggedBehavior, ['single', 'single_sms'], true)) $data['reminder_enabled'] = false;
            $fields = [
                'placement','items','min_views','min_duration','visit_metric','visit_calculation','visit_condition','window','coupon_type','coupon_custom_prefix','coupon_custom_suffix','coupon_custom_length','coupon_custom_mid_pattern',
      'coupon_free_shipping','coupon_amount','coupon_mode','coupon_valid_hours','banner_target_url','banner_button_closes','sms_target_url','logged_sms_target_url','action',
                'sms_mode','sms_text','sms_pattern','hide_banner_for_logged_in','banner_type','logged_behavior',
                'logged_banner','logged_sms_mode','logged_sms_text','logged_sms_pattern','logged_sms_delay_type','logged_sms_delay_minutes',
                'banner_title','banner_text','banner_button_color',
                'coupon_limit_enabled','coupon_limit_type','coupon_limit_ids',
                'banner_image','banner_hide_image','banner_svg_color','banner_border_radius','banner_radius_mode','banner_border_radii','banner_paddings','banner_margins','banner_button_text',
                'banner_show_close','banner_close_hide_bg','banner_close_position','close_bg_color','close_icon_color',
                'banner_button_text_color','discount_bg_color','discount_border_color','copy_bg_color','copy_text_color',
                'multi_prompt','multi_phone_placeholder','multi_submit_text','multi_sending_text','multi_success_text','multi_correction_text','multi_colors',
                'display_name_fallback','coupon_usage_limit',
                'coupon_restrict_user','coupon_restrict_guest',
                'banner_bg_color','banner_title_color','banner_text_color','banner_coupon_color','banner_font_type',
                'sms_delay_type','sms_delay_minutes',
                'coupon_strategy','fixed_code',
                'reminder_enabled','reminder_message_template','reminder_show_timer_panel','reminder_colors','reminder_styles'
            ];
            foreach ($fields as $f) {
                $val = $data[$f] ?? '';
                $val = $this->sanitizeMetaValue($post_id, $f, $val, $data);
                update_post_meta($post_id, $f, $val);
            }
        }
        private function sanitizeMetaValue(int $post_id, string $field, $val, array $data)
    {
            if ($field === 'items' && is_array($val)) {
                return $this->normalizeItemsForPlacement((string)($data['placement'] ?? ''), $val);
            }
            if ($field === 'coupon_limit_ids' && is_array($val)) {
                return array_values(array_unique(array_filter(array_map('intval', $val))));
            }
            if ($field === 'placement') {
                $allowed = [
                    'product_single','product_cat','product_tag','product_in_cat','product_in_tag',
                    'post_single','post_cat','post_tag','post_in_cat','post_in_tag',
                    'page','custom_url','search_terms'
                ];
                $value = sanitize_key((string)$val);
                return in_array($value, $allowed, true) ? $value : 'product_single';
            }
            if ($field === 'window') {
                return in_array($val, ['24h','72h','1w'], true) ? $val : '24h';
            }
            if ($field === 'visit_metric') {
                return in_array($val, ['views','duration','both'], true) ? $val : 'views';
            }
            if ($field === 'visit_calculation') {
                return $val === 'aggregate' ? 'aggregate' : 'individual';
            }
            if ($field === 'visit_condition') {
                return $val === 'and' ? 'and' : 'or';
            }
            if ($field === 'action') {
                return in_array($val, ['banner','sms','both'], true) ? $val : 'banner';
            }
            if ($field === 'coupon_mode') {
                return in_array($val, ['fixed','percent'], true) ? $val : 'fixed';
            }
            if ($field === 'sms_mode') {
                return in_array($val, ['promo','pattern'], true) ? $val : '';
            }
            if ($field === 'logged_sms_mode') {
                return in_array($val, ['promo','pattern'], true) ? $val : '';
            }
            if ($field === 'banner_type') return $val === 'multi' ? 'multi' : 'single';
            if ($field === 'logged_behavior') {
                return in_array($val, ['none','single','sms','single_sms'], true) ? $val : 'single_sms';
            }
            if ($field === 'banner_close_position') return $val === 'right' ? 'right' : 'left';
            if ($field === 'logged_banner') {
                $allowed = ['banner_title','banner_button_text','banner_text','banner_button_color',
                    'banner_image','banner_hide_image','banner_svg_color','banner_bg_color','banner_title_color',
                    'banner_text_color','banner_coupon_color','banner_font_type',
                    'banner_border_radius','banner_radius_mode','banner_border_radii','banner_paddings','banner_margins',
                    'banner_show_close','banner_close_hide_bg','banner_close_position','close_bg_color','close_icon_color',
                    'banner_target_url','banner_button_closes',
                    'banner_button_text_color','discount_bg_color','discount_border_color','copy_bg_color','copy_text_color'];
                $source = is_array($val) ? $val : [];
                $clean = [];
                foreach ($allowed as $key) {
                    if (array_key_exists($key, $source)) $clean[$key] = $this->sanitizeMetaValue($post_id, $key, $source[$key], $data);
                }
                return $clean;
            }
            if ($field === 'multi_colors') {
                $clean = [];
                foreach (['phone_bg','phone_text','phone_border','send_bg','send_text','prompt',
                    'sending','loader','success_bg','success','correction_bg','correction','correction_border',
                    'back_bg','back_icon'] as $key) {
                    $name = 'multi_' . $key . '_color';
                    $clean[$name] = sanitize_hex_color((string)((is_array($val) ? $val : [])[$name] ?? '')) ?: '';
                }
                return $clean;
            }
            if (in_array($field, ['sms_delay_type', 'logged_sms_delay_type'], true)) {
                return $val === 'delayed' ? 'delayed' : 'immediate';
            }
            if (in_array($field, ['sms_delay_minutes', 'logged_sms_delay_minutes'], true)) {
                $typeField = $field === 'logged_sms_delay_minutes' ? 'logged_sms_delay_type' : 'sms_delay_type';
                return ($data[$typeField] ?? '') === 'delayed' ? max(1, min(1440, (int)$val)) : 0;
            }
            if ($field === 'coupon_limit_type') {
                return in_array($val, ['product','category'], true) ? $val : '';
            }
            if ($field === 'min_views') {
                return max(1, min(65535, (int)$val));
            }
            if ($field === 'min_duration') {
                return max(1, min(604800, (int)$val));
            }
            if ($field === 'coupon_amount') {
                $amount = (float)$val;
                if (($data['coupon_strategy'] ?? '') === 'fixed') return max(0, $amount);
                $mode = isset($data['coupon_mode']) ? (string)$data['coupon_mode'] : (string)get_post_meta($post_id, 'coupon_mode', true);
                if ($mode === 'percent') {
                    return max(1, min(100, $amount));
                }
                return max(1, min(9999999999.99, $amount));
            }
            if ($field === 'coupon_type') {
                $v = (string)$val;
                $allowed = ['numbers', 'letters', 'mixed', 'custom'];
                if (!in_array($v, $allowed, true)) {
                    $v = 'mixed';
                }
                return $v;
            }
            if ($field === 'coupon_custom_prefix' || $field === 'coupon_custom_suffix') {
                $v = sanitize_text_field((string)$val);
                $v = $this->normalizeDigits($v);
                $v = preg_replace('/[^A-Za-z0-9_]/', '', $v);
                return substr($v, 0, 32);
            }
            if ($field === 'coupon_custom_length') {
                $raw = is_string($val) ? $this->normalizeDigits($val) : (string)$val;
                $n = (int)$raw;
                if ($n < 3) $n = 3;
                if ($n > 64) $n = 64;
                return $n;
            }
            if ($field === 'coupon_custom_mid_pattern') {
                $v = sanitize_key((string)$val);
                $allowed = ['numbers','letters','mixed'];
                if (!in_array($v, $allowed, true)) $v = 'mixed';
                return $v;
            }
            if ($field === 'coupon_valid_hours') {
                return max(1, (int)$val);
            }
            if ($field === 'coupon_usage_limit') {
                return max(0, min(65535, (int)$val));
            }
            if (in_array($field, ['coupon_restrict_user', 'coupon_restrict_guest'], true)) {
                return filter_var($val, FILTER_VALIDATE_BOOLEAN);
            }
            if ($field === 'coupon_limit_enabled' || $field === 'coupon_free_shipping' || $field === 'banner_hide_image' || $field === 'hide_banner_for_logged_in' || $field === 'banner_show_close' || $field === 'banner_close_hide_bg' || $field === 'banner_button_closes' || $field === 'reminder_enabled' || $field === 'reminder_show_timer_panel') {
                return (bool)$val;
            }
            if (in_array($field, ['banner_target_url', 'sms_target_url', 'logged_sms_target_url'], true)) {
                return trim(wp_strip_all_tags((string)$val));
            }
            if ($field === 'sms_text' || $field === 'sms_pattern' || $field === 'logged_sms_text' || $field === 'logged_sms_pattern') {
                return sanitize_textarea_field((string)$val);
            }
            if ($field === 'banner_text') {
                return wp_kses_post((string)$val);
            }
            if ($field === 'display_name_fallback') {
                $v = sanitize_text_field((string)$val);
                return ($v !== '') ? $v : 'کاربر';
            }
            if ($field === 'fixed_code') {
                $code = sanitize_text_field((string)$val);
                return function_exists('wc_sanitize_coupon_code') ? wc_sanitize_coupon_code($code) : $code;
            }
            if (in_array($field, ['banner_title','banner_button_text','display_name_fallback',
                'multi_prompt','multi_phone_placeholder','multi_submit_text','multi_sending_text',
                'multi_success_text','multi_correction_text'], true)) {
                return sanitize_text_field((string)$val);
            }
            if ($field === 'banner_image') {
                return esc_url_raw((string)$val);
            }
            if (in_array($field, ['banner_button_color','banner_svg_color','banner_bg_color','banner_title_color','banner_text_color','banner_coupon_color','close_bg_color','close_icon_color','banner_button_text_color','discount_bg_color','discount_border_color','copy_bg_color','copy_text_color'], true)) {
                return sanitize_hex_color((string)$val) ?: '';
            }
            if ($field === 'banner_border_radius') {
                return max(0, min(64, (int)$val));
            }
            if ($field === 'banner_radius_mode') {
                return $val === 'manual' ? 'manual' : 'simple';
            }
            if ($field === 'banner_border_radii') {
                $clean = [];
                $targets = ['card', 'image', 'discount', 'copy', 'primary', 'close', 'back', 'phone', 'send', 'success', 'correction', 'error'];
                $corners = ['tl', 'tr', 'br', 'bl'];
                $source = is_array($val) ? $val : [];
                foreach ($targets as $target) {
                    $targetValues = isset($source[$target]) && is_array($source[$target]) ? $source[$target] : [];
                    $clean[$target] = [];
                    foreach ($corners as $corner) {
                        $clean[$target][$corner] = max(0, (int)($targetValues[$corner] ?? 0));
                    }
                }
                return $clean;
            }
            if ($field === 'banner_margins') {
                $clean = [];
                $source = is_array($val) ? $val : [];
                foreach (['card', 'close'] as $target) {
                    foreach (['t', 'r', 'b', 'l'] as $side) {
                        $clean[$target][$side] = max(0, min(200, (int)($source[$target][$side] ?? ($target === 'close' && in_array($side, ['t', 'l'], true) ? 24 : 0))));
                    }
                }
                return $clean;
            }
            if ($field === 'banner_paddings') {
                $clean = [];
                $defaults = [
                    'card' => ['t' => 24, 'r' => 24, 'b' => 24, 'l' => 24],
                    'primary' => ['t' => 13, 'r' => 13, 'b' => 13, 'l' => 13],
                    'discount' => ['t' => 10, 'r' => 10, 'b' => 10, 'l' => 10],
                    'copy' => ['t' => 8, 'r' => 12, 'b' => 8, 'l' => 12],
                    'title' => ['t' => 0, 'r' => 0, 'b' => 0, 'l' => 0],
                    'description' => ['t' => 0, 'r' => 0, 'b' => 0, 'l' => 0],
                    'close' => ['t' => 10, 'r' => 10, 'b' => 10, 'l' => 10],
                    'phone' => ['t' => 12, 'r' => 12, 'b' => 12, 'l' => 12],
                    'send' => ['t' => 12, 'r' => 12, 'b' => 12, 'l' => 12],
                    'success' => ['t' => 8, 'r' => 8, 'b' => 8, 'l' => 8],
                    'correction' => ['t' => 8, 'r' => 8, 'b' => 8, 'l' => 8],
                    'prompt' => ['t' => 0, 'r' => 0, 'b' => 0, 'l' => 0],
                    'sending' => ['t' => 8, 'r' => 8, 'b' => 8, 'l' => 8],
                    'error' => ['t' => 8, 'r' => 8, 'b' => 8, 'l' => 8],
                ];
                $source = is_array($val) ? $val : [];
                foreach ($defaults as $target => $fallback) {
                    $targetValues = isset($source[$target]) && is_array($source[$target]) ? $source[$target] : [];
                    $clean[$target] = [];
                    foreach (['t', 'r', 'b', 'l'] as $side) {
                        $clean[$target][$side] = max(0, min(200, (int)($targetValues[$side] ?? $fallback[$side])));
                    }
                }
                return $clean;
            }
            if ($field === 'banner_font_type') {
                return in_array($val, ['arad','inherit'], true) ? $val : 'arad';
            }
            if ($field === 'coupon_strategy') {
                $v = (string)$val;
                $allowed = ['individual', 'virtual', 'fixed'];
                if (!in_array($v, $allowed, true)) {
                    $v = 'individual';
                }
                return $v;
            }
            if ($field === 'reminder_message_template') {
                return wp_kses_post((string)$val);
            }
            if ($field === 'reminder_styles') {
                $source = is_array($val) ? $val : [];
                $clean = [];
                $defaults = [
                    'radii' => ['coupon' => ['tl'=>4,'tr'=>4,'br'=>4,'bl'=>4], 'timer' => ['tl'=>6,'tr'=>6,'br'=>6,'bl'=>6]],
                    'paddings' => ['coupon' => ['t'=>2,'r'=>6,'b'=>2,'l'=>6], 'timer' => ['t'=>0,'r'=>0,'b'=>0,'l'=>0], 'bar' => ['t'=>15,'r'=>15,'b'=>15,'l'=>15]],
                    'margins' => ['text' => ['t'=>0,'r'=>0,'b'=>0,'l'=>0], 'timer' => ['t'=>0,'r'=>15,'b'=>0,'l'=>0]],
                ];
                foreach ($defaults as $kind => $targets) foreach ($targets as $target => $values) foreach ($values as $side => $default) {
                    $clean[$kind][$target][$side] = max(0, min(200, (int)($source[$kind][$target][$side] ?? $default)));
                }
                return $clean;
            }
            if ($field === 'reminder_colors' && is_array($val)) {
                $cleanColors = [];
                foreach (['bg', 'text', 'timer_value', 'timer_bg', 'timer_text', 'close_btn', 'coupon_highlight'] as $ck) {
                    $cleanColors[$ck] = sanitize_hex_color((string)($val[$ck] ?? ''));
                }
                return $cleanColors;
            }
            return $val;
        }
        private function maybeEnsureFixedCoupon(int $post_id): void
        {
            if (get_post_meta($post_id, 'coupon_strategy', true) !== 'fixed') return;
            $code = (string)get_post_meta($post_id, 'fixed_code', true);
            $couponId = $code !== '' && function_exists('wc_get_coupon_id_by_code') ? (int)wc_get_coupon_id_by_code($code) : 0;
            update_post_meta($post_id, 'sekianafraz_linked_coupon_id', $couponId);
        }
        private function coverageSpec(int $id): array
        {
            if ($id <= 0) return [];
            $items = array_map('strval', (array)get_post_meta($id, 'items', true));
            sort($items, SORT_STRING);
            return [get_post_status($id), (string)get_post_meta($id, 'placement', true), $items];
        }
        private function syncIndexForStatus(int $post_id, string $status, bool $syncCoverage = true): void
        {
            $indexer = new SensorIndexService();
            $coverage = new SensorCoverageService();
            if ($status === 'publish') {
                $indexer->rebuildSensorIndex($post_id);
                if ($syncCoverage) $coverage->syncSensor($post_id);
            } else {
                $indexer->deleteSensorIndex($post_id);
                if ($syncCoverage) $coverage->removeSensor($post_id);
            }
        }
    public function updateStatus(int $id, string $status): bool
    {
        if (!$this->isSensorPost($id)) return false;
        if (!in_array($status, ['publish', 'draft'], true)) return false;
        if (get_post_status($id) === $status) return true;
        $res = wp_update_post(['ID' => $id, 'post_status' => $status], true);
        if (is_wp_error($res)) return false;
        $this->syncIndexForStatus($id, $status);
        do_action('sekianafraz_sensor_changed', $id);
        return true;
    }
    public function delete(int $id): bool
    {
        if (!$this->isSensorPost($id)) return false;
        if (class_exists('SeKianAfraz\VisitDiscount\\Logs\\ActionLogger')) {
            (new \SeKianAfraz\VisitDiscount\Logs\ActionLogger())->deleteBySensorId($id);
        }
        if (get_option('sekianafraz_banner_sessions_ready')) {
            global $wpdb;
            $wpdb->delete($wpdb->prefix . 'sekianafraz_banner_sessions', ['sensor_id' => $id], ['%d']);
        }
        (new SensorIndexService())->deleteSensorIndex($id);
        (new SensorCoverageService())->removeSensor($id);
        $r = wp_delete_post($id, true);
        if ($r !== false) do_action('sekianafraz_sensor_changed', $id);
        return $r !== false;
    }
    public function findRelevantForPage(array $ctx): array
    {
        global $wpdb;
        $cacheContext = ['path' => (string)($ctx['path'] ?? ''), 'search_term' => (string)($ctx['search_term'] ?? '')];
        foreach (['product_id', 'post_id', 'page_id'] as $field) $cacheContext[$field] = (int)($ctx[$field] ?? 0);
        foreach (['product_cat_ids', 'product_tag_ids', 'post_cat_ids', 'post_tag_ids'] as $field) {
            $cacheContext[$field] = array_values(array_unique(array_map('intval', (array)($ctx[$field] ?? []))));
            sort($cacheContext[$field], SORT_NUMERIC);
        }
        $cacheKey = \SeKianAfraz\VisitDiscount\Cache\SensorCache::key($cacheContext);
        $cached = \SeKianAfraz\VisitDiscount\Cache\SensorCache::get($cacheKey);
        if ($cached !== null) return $cached;
        $table = $wpdb->prefix . 'sekianafraz_sensor_index';
        $rows = [];
        $owners = (new SensorCoverageReader())->ownersForPageContext($ctx);
        $readFailed = $wpdb->last_error !== '';
        foreach ($owners as $row) {
            $row['_matches'] = [(string)$row['object_id']];
            $rows[] = $row;
        }
        $ctxPath = '';
        if (!empty($ctx['path'])) $ctxPath = Path::canonicalize((string)$ctx['path'], Path::homePath());
        if ($ctxPath !== '') {
            $customRows = $wpdb->get_results($wpdb->prepare(
                "SELECT sensor_id, placement, item, min_views, min_duration, visit_metric, visit_calculation, visit_condition, time_window AS `window`
                 FROM {$table} WHERE placement = %s AND item = %s LIMIT 200",
                'custom_url',
                $ctxPath
            ), ARRAY_A);
            $readFailed = $readFailed || $wpdb->last_error !== '';
            foreach ($customRows ?: [] as $row) {
                $row['_matches'] = [(string)$row['item']];
                $rows[] = $row;
            }
        }
        $searchTerm = (string)($ctx['search_term'] ?? '');
        if ($searchTerm !== '') {
            $searchSql = $wpdb->prepare(
                "SELECT sensor_id, placement, item, min_views, min_duration, visit_metric, visit_calculation, visit_condition, time_window AS `window` FROM {$table} WHERE placement = %s AND item <> '*' AND %s LIKE CONCAT('%%', item, '%%') LIMIT 200",
                'search_terms',
                $searchTerm
            );
            $searchRows = $wpdb->get_results($searchSql, ARRAY_A);
            $readFailed = $readFailed || $wpdb->last_error !== '';
            foreach ($searchRows ?: [] as $row) {
                $row['_matches'] = [(string)$row['item']];
                $rows[] = $row;
            }
        }
        $grouped = [];
        foreach ($rows as $row) {
            $id = (int)($row['sensor_id'] ?? 0);
            if ($id <= 0) continue;
            $placement = (string)($row['placement'] ?? '');
            if (!isset($grouped[$id])) {
                $metric = (string)($row['visit_metric'] ?? 'views');
                $calculation = (string)($row['visit_calculation'] ?? 'individual');
                $grouped[$id] = [
                    'id' => $id,
                    'placement' => $placement,
                    'min' => max(1, (int)($row['min_views'] ?? 1)),
                    'min_views' => max(1, (int)($row['min_views'] ?? 1)),
                    'min_duration' => max(1, (int)($row['min_duration'] ?? 1)),
                    'visit_metric' => in_array($metric, ['views','duration','both'], true) ? $metric : 'views',
                    'visit_calculation' => $calculation === 'aggregate' ? 'aggregate' : 'individual',
                    'visit_condition' => ($row['visit_condition'] ?? 'or') === 'and' ? 'and' : 'or',
                    'window' => (string)($row['window'] ?? '24h'),
                    'matches' => [],
                ];
            }
            $matches = (array)($row['_matches'] ?? []);
            foreach ($matches as $match) {
                $match = (string)$match;
                if ($match !== '' && !in_array($match, $grouped[$id]['matches'], true)) {
                    $grouped[$id]['matches'][] = $match;
                }
            }
        }
        $result = array_values(array_filter($grouped, function(array $sensor): bool {
            return !empty($sensor['matches']);
        }));
        if (!$readFailed) \SeKianAfraz\VisitDiscount\Cache\SensorCache::set($cacheKey, $result);
        return $result;
    }
    public function findCoverageConflict(string $placement, array $items, int $excludeId = 0): array
    {
        global $wpdb;
        $placement = sanitize_key($placement);
        $items = $this->normalizeItemsForPlacement($placement, $items);
        if ($placement === '' || empty($items)) return [];
        $coverage = new SensorCoverageService();
        if ($coverage->supportsPlacement($placement)) {
            $analysis = $coverage->analyzeConflict($placement, $items, $excludeId);
            $first = (array)($analysis['conflicts'][0] ?? []);
            if (empty($first)) return [];
            return [
                'sensor_id' => (int)($first['sensor_id'] ?? 0),
                'sensor_name' => (string)($first['sensor_name'] ?? ''),
            ];
        }
        $table = $wpdb->prefix . 'sekianafraz_sensor_index';
        $postsTable = $wpdb->posts;
        $params = [$placement];
        if (in_array('*', $items, true)) {
            $coverageSql = '1=1';
        } else {
            $placeholders = implode(',', array_fill(0, count($items), '%s'));
            $coverageSql = "(i.item = '*' OR i.item IN ({$placeholders}))";
            $params = array_merge($params, $items);
        }
        $params[] = max(0, $excludeId);
        $sql = "SELECT i.sensor_id, p.post_title
                FROM {$table} i
                JOIN {$postsTable} p ON p.ID = i.sensor_id
                WHERE i.placement = %s
                  AND {$coverageSql}
                  AND p.post_status = 'publish'
                  AND p.post_type = 'sekianafraz_sensor'
                  AND i.sensor_id <> %d
                LIMIT 1";
        $row = $wpdb->get_row($wpdb->prepare($sql, $params), ARRAY_A);
        if (!is_array($row)) return [];
        return [
            'sensor_id' => (int)($row['sensor_id'] ?? 0),
            'sensor_name' => (string)($row['post_title'] ?? ''),
        ];
    }
    private function placementsForContext(array $ctx): array
    {
        $placements = [];
        if (!empty($ctx['product_id'])) $placements[] = 'product_single';
        if (!empty($ctx['post_id'])) $placements[] = 'post_single';
        if (!empty($ctx['page_id'])) $placements[] = 'page';
        if (!empty($ctx['product_cat_ids'])) $placements[] = 'product_cat';
        if (!empty($ctx['product_tag_ids'])) $placements[] = 'product_tag';
        if (!empty($ctx['post_cat_ids'])) $placements[] = 'post_cat';
        if (!empty($ctx['post_tag_ids'])) $placements[] = 'post_tag';
        if (!empty($ctx['search_term'])) $placements[] = 'search_terms';
        if (!empty($ctx['path'])) $placements[] = 'custom_url';
        return array_values(array_unique($placements));
    }
    private function itemLabels(string $placement, array $items): array
    {
        return $this->resolveLabels($placement, $items, []);
    }
    private function resolveLabels(string $placement, array $items, array $preloadedMap): array
    {
        $labels = [];
        foreach ((array)$items as $raw) {
            $label = (string)$raw;
            if ($raw === '*') {
                $allLabels = [
                    'product_single' => 'همه محصولات',
                    'product_cat' => 'همه دسته‌بندی‌های محصولات',
                    'product_tag' => 'همه برچسب‌های محصولات',
                    'post_single' => 'همه مطالب',
                    'post_cat' => 'همه دسته‌بندی‌های مطالب',
                    'post_tag' => 'همه برچسب‌های مطالب',
                    'page' => 'همه برگه‌ها',
                ];
                $labels[] = $allLabels[$placement] ?? 'همه موارد';
                continue;
            }
            if (ctype_digit((string)$raw)) {
                $num = (int)$raw;
                $key = '';
                if (in_array($placement, ['product_single', 'post_single', 'page'], true)) {
                    $key = 'p_'.$num;
                } elseif (in_array($placement, ['product_cat', 'product_tag', 'product_in_cat', 'product_in_tag', 'post_cat', 'post_tag', 'post_in_cat', 'post_in_tag'], true)) {
                    $key = 't_'.$num;
                }
                if ($key && isset($preloadedMap[$key])) {
                    $labels[] = $preloadedMap[$key];
                    continue;
                }
                if ($placement === 'product_single' || $placement === 'post_single' || $placement === 'page') {
                    $p = get_post($num); if ($p) $label = $p->post_title;
                } elseif ($placement === 'product_cat' || $placement === 'product_in_cat') {
                    $t = get_term($num, 'product_cat'); if ($t && !is_wp_error($t)) $label = $t->name;
                } elseif ($placement === 'product_tag' || $placement === 'product_in_tag') {
                    $t = get_term($num, 'product_tag'); if ($t && !is_wp_error($t)) $label = $t->name;
                } elseif ($placement === 'post_cat' || $placement === 'post_in_cat') {
                    $t = get_term($num, 'category'); if ($t && !is_wp_error($t)) $label = $t->name;
                } elseif ($placement === 'post_tag' || $placement === 'post_in_tag') {
                    $t = get_term($num, 'post_tag'); if ($t && !is_wp_error($t)) $label = $t->name;
                }
            }
            $labels[] = $label;
        }
        return $labels;
    }
    private function isSensorPost(int $id): bool
    {
        if ($id <= 0) return false;
        $post = get_post($id);
        return $post instanceof \WP_Post && $post->post_type === 'sekianafraz_sensor';
    }
    private function normalizeDigits(string $s): string
    {
        $map = [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ];
        return strtr($s, $map);
    }
}
