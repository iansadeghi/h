<?php
namespace SeKianAfraz\VisitDiscount\Sensors\Concerns;
use SeKianAfraz\VisitDiscount\Database\Schema;
if (!defined('ABSPATH')) { exit; }
trait CoverageResolution
{
    private function activeSpecsForContext(string $context, int $excludeSensorId = 0): array
    {
        global $wpdb;
        $placements = $this->placementsForContext($context);
        if (empty($placements)) return [];
        $placeholders = implode(',', array_fill(0, count($placements), '%s'));
        $params = array_merge($placements, [max(0, $excludeSensorId)]);
        $index = $wpdb->prefix . 'sekianafraz_sensor_index';
        $sql = "SELECT i.sensor_id, i.placement, i.item
                FROM {$index} i
                INNER JOIN {$wpdb->posts} p ON p.ID = i.sensor_id
                WHERE i.placement IN ({$placeholders})
                  AND p.post_type = 'sekianafraz_sensor'
                  AND p.post_status = 'publish'
                  AND i.sensor_id <> %d
                ORDER BY i.sensor_id ASC LIMIT 5001";
        $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to read sensor rules.');
        if (count($rows) > 5000) {
            $summary = str_replace('SELECT i.sensor_id, i.placement, i.item', "SELECT i.sensor_id, i.placement, MAX(i.item='*') AS wildcard", $sql);
            $summary = str_replace('ORDER BY i.sensor_id ASC LIMIT 5001', 'GROUP BY i.sensor_id,i.placement', $summary);
            unset($rows);
            $rows = $wpdb->get_results($wpdb->prepare($summary, $params), ARRAY_A);
            if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to read sensor rules.');
            $specs = [];
            foreach ($rows as $row) {
                $sensorId = (int)$row['sensor_id'];
                $items = !empty($row['wildcard']) ? ['*'] : [];
                $specs[$sensorId] = ['sensor_id' => $sensorId, 'placement' => $row['placement'], 'items' => $items,
                    'rank' => $this->rankForSpec($row['placement'], $items), 'indexed' => true];
            }
            return $specs;
        }
        $specs = [];
        foreach ($rows as $row) {
            $sensorId = (int)$row['sensor_id'];
            if ($sensorId <= 0) continue;
            if (!isset($specs[$sensorId])) {
                $specs[$sensorId] = [
                    'sensor_id' => $sensorId,
                    'placement' => (string)$row['placement'],
                    'items' => [],
                    'rank' => 0,
                ];
            }
            $specs[$sensorId]['items'][] = (string)$row['item'];
        }
        foreach ($specs as $sensorId => &$spec) {
            $spec['items'] = array_values(array_unique($spec['items']));
            $spec['rank'] = $this->rankForSpec($spec['placement'], $spec['items']);
        }
        unset($spec);
        return $specs;
    }
    private function compileParticipantPlan(array $specs): array
    {
        foreach ($specs as $spec) {
            if (!empty($spec['indexed'])) return ['indexed' => true, 'allowed' => array_fill_keys(array_keys($specs), true)];
        }
        $wildcardSensors = [];
        $explicitSensors = [];
        $groupSensors = [];
        $groupPlacements = ['product_in_cat', 'product_in_tag', 'post_in_cat', 'post_in_tag'];
        $taxMap = [
            'product_in_cat' => 'product_cat',
            'product_in_tag' => 'product_tag',
            'post_in_cat' => 'category',
            'post_in_tag' => 'post_tag',
        ];
        foreach ($specs as $sensorId => $spec) {
            $placement = (string)$spec['placement'];
            $items = array_map('strval', (array)$spec['items']);
            if (in_array($placement, $groupPlacements, true)) {
                $taxonomy = $taxMap[$placement];
                $termId = (int)($items[0] ?? 0);
                $cacheKey = $taxonomy . ':' . $termId;
                if (!isset($this->termScopeCache[$cacheKey])) {
                    $this->termScopeCache[$cacheKey] = $termId > 0 ? [$termId] : [];
                }
                foreach ($this->termScopeCache[$cacheKey] as $allowedTermId) {
                    $groupSensors[$taxonomy][(int)$allowedTermId][] = (int)$sensorId;
                }
                continue;
            }
            if (in_array('*', $items, true)) {
                $wildcardSensors[] = (int)$sensorId;
                continue;
            }
            foreach (array_filter(array_map('intval', $items)) as $objectId) {
                $explicitSensors[$objectId][] = (int)$sensorId;
            }
        }
        return [
            'wildcards' => array_values(array_unique($wildcardSensors)),
            'explicit' => $explicitSensors,
            'groups' => $groupSensors,
        ];
    }
    private function candidateSensorIdsForObjects(string $context, array $objectIds, array $plan): array
    {
        global $wpdb;
        $objectIds = array_values(array_unique(array_filter(array_map('intval', $objectIds))));
        $out = [];
        foreach ($objectIds as $id) $out[$id] = [];
        if (empty($objectIds)) return $out;
        if (!empty($plan['indexed'])) $plan = $this->indexedParticipantPlan($context, $objectIds, $plan['allowed']);
        $termsByObject = [];
        if (($context === 'product' || $context === 'post') && !empty($plan['groups'])) {
            $taxonomies = $context === 'product' ? ['product_cat', 'product_tag'] : ['category', 'post_tag'];
            foreach (array_chunk($objectIds, 500) as $chunk) {
                $idPlaceholders = implode(',', array_fill(0, count($chunk), '%d'));
                $taxPlaceholders = implode(',', array_fill(0, count($taxonomies), '%s'));
                $sql = "SELECT tr.object_id, tt.taxonomy, tt.term_id
                        FROM {$wpdb->term_relationships} tr
                        INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
                        WHERE tr.object_id IN ({$idPlaceholders}) AND tt.taxonomy IN ({$taxPlaceholders})";
                $rows = $wpdb->get_results($wpdb->prepare($sql, array_merge($chunk, $taxonomies)), ARRAY_A);
                foreach ($rows as $row) {
                    $objectId = (int)$row['object_id'];
                    $taxonomy = (string)$row['taxonomy'];
                    $termsByObject[$objectId][$taxonomy][] = (int)$row['term_id'];
                }
            }
        }
        foreach ($objectIds as $objectId) {
            $sensorMap = array_fill_keys((array)($plan['wildcards'] ?? []), true);
            foreach ((array)($plan['explicit'][$objectId] ?? []) as $sensorId) $sensorMap[(int)$sensorId] = true;
            foreach ((array)($termsByObject[$objectId] ?? []) as $taxonomy => $termIds) {
                foreach ((array)$termIds as $termId) {
                    foreach ((array)($plan['groups'][$taxonomy][(int)$termId] ?? []) as $sensorId) {
                        $sensorMap[(int)$sensorId] = true;
                    }
                }
            }
            $out[$objectId] = array_map('intval', array_keys($sensorMap));
        }
        return $out;
    }
    private function indexedParticipantPlan(string $context, array $objectIds, array $allowed): array
    {
        global $wpdb;
        $placements = $this->placementsForContext($context);
        if (!$placements || !$objectIds) return [];
        $holders = implode(',', array_fill(0, count($objectIds) + 1, '%s'));
        $clauses = [$wpdb->prepare("(placement=%s AND item IN ({$holders}))", array_merge([$placements[0], '*'], array_map('strval', $objectIds)))];
        $taxMap = $context === 'product' ? ['product_cat' => 'product_in_cat', 'product_tag' => 'product_in_tag']
            : ($context === 'post' ? ['category' => 'post_in_cat', 'post_tag' => 'post_in_tag'] : []);
        if ($taxMap) {
            $ids = implode(',', array_map('intval', $objectIds));
            $taxHolders = implode(',', array_fill(0, count($taxMap), '%s'));
            $terms = $wpdb->get_results($wpdb->prepare("SELECT DISTINCT tt.taxonomy,tt.term_id FROM {$wpdb->term_relationships} tr
                INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id=tr.term_taxonomy_id
                WHERE tr.object_id IN ({$ids}) AND tt.taxonomy IN ({$taxHolders})", array_keys($taxMap)), ARRAY_A);
            if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to read sensor terms.');
            $byTaxonomy = [];
            foreach ($terms as $term) $byTaxonomy[$term['taxonomy']][] = (string)$term['term_id'];
            foreach ($byTaxonomy as $taxonomy => $termIds) {
                $termHolders = implode(',', array_fill(0, count($termIds), '%s'));
                $clauses[] = $wpdb->prepare("(placement=%s AND item IN ({$termHolders}))", array_merge([$taxMap[$taxonomy]], $termIds));
            }
        }
        $index = $wpdb->prefix . 'sekianafraz_sensor_index';
        $rows = $wpdb->get_results("SELECT sensor_id,placement,item FROM {$index} WHERE " . implode(' OR ', $clauses), ARRAY_A);
        if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to read matching sensor rules.');
        $specs = [];
        foreach ($rows as $row) {
            $sensorId = (int)$row['sensor_id'];
            if (!isset($allowed[$sensorId])) continue;
            if (!isset($specs[$sensorId])) $specs[$sensorId] = ['placement' => $row['placement'], 'items' => []];
            $specs[$sensorId]['items'][] = (string)$row['item'];
        }
        return $this->compileParticipantPlan($specs);
    }
    private function pickWinner(array $sensorIds, array $specs): int
    {
        $winner = 0;
        $rank = -1;
        foreach ($sensorIds as $sensorId) {
            $sensorId = (int)$sensorId;
            if ($sensorId <= 0) continue;
            $candidateRank = (int)($specs[$sensorId]['rank'] ?? 0);
            if ($candidateRank > $rank || ($candidateRank === $rank && $sensorId < $winner)) {
                $winner = $sensorId;
                $rank = $candidateRank;
            }
        }
        return $winner;
    }
    private function resolvedObjectsForSensor(int $sensorId, string $context, array $objectIds): array
    {
        global $wpdb;
        if ($sensorId <= 0 || empty($objectIds)) return [];
        $coverage = Schema::getSensorCoverageTableName();
        $exclusions = Schema::getSensorExclusionsTableName();
        $map = [];
        foreach (array_chunk(array_values(array_unique(array_map('intval', $objectIds))), 500) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));
            $params = array_merge([$context, $sensorId], $chunk, [$context, $sensorId], $chunk);
            $sql = "SELECT object_id, 'owned' AS resolution_state FROM {$coverage}
                    WHERE context_type = %s AND sensor_id = %d AND object_id IN ({$placeholders})
                    UNION ALL
                    SELECT object_id, 'excluded' AS resolution_state FROM {$exclusions}
                    WHERE context_type = %s AND excluded_sensor_id = %d AND object_id IN ({$placeholders})";
            foreach ($wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A) as $row) {
                $map[(int)$row['object_id']] = (string)$row['resolution_state'];
            }
        }
        return $map;
    }
    private function ownersForObjectIds(string $context, array $objectIds): array
    {
        global $wpdb;
        if (empty($objectIds)) return [];
        $table = Schema::getSensorCoverageTableName();
        $placeholders = implode(',', array_fill(0, count($objectIds), '%d'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT object_id, sensor_id FROM {$table} WHERE context_type = %s AND object_id IN ({$placeholders})",
            array_merge([$context], array_map('intval', $objectIds))
        ), ARRAY_A);
        $owners = [];
        foreach ($rows as $row) $owners[(int)$row['object_id']] = (int)$row['sensor_id'];
        return $owners;
    }
    private function recordOwnershipDelta(array &$deltas, int $beforeOwner, int $afterOwner): void
    {
        if ($beforeOwner === $afterOwner) return;
        if ($beforeOwner > 0) $deltas[$beforeOwner] = (int)($deltas[$beforeOwner] ?? 0) - 1;
        if ($afterOwner > 0) $deltas[$afterOwner] = (int)($deltas[$afterOwner] ?? 0) + 1;
    }
    private function coverageCountsForSensors(array $sensorIds): array
    {
        global $wpdb;
        $table = Schema::getSensorCoverageTableName();
        $counts = [];
        foreach (array_chunk(array_values(array_unique(array_filter(array_map('intval', $sensorIds)))), 500) as $chunk) {
            $placeholders = implode(',', array_fill(0, count($chunk), '%d'));
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT sensor_id, COUNT(*) AS total FROM {$table} WHERE sensor_id IN ({$placeholders}) GROUP BY sensor_id",
                $chunk
            ), ARRAY_A);
            foreach ($rows as $row) $counts[(int)$row['sensor_id']] = (int)$row['total'];
        }
        return $counts;
    }
    private function resolveRefs(array $refs): void
    {
        $grouped = [];
        foreach ($refs as $ref) {
            $context = sanitize_key((string)($ref[0] ?? ''));
            $objectId = (int)($ref[1] ?? 0);
            if ($context !== '' && $objectId > 0) $grouped[$context][$objectId] = $objectId;
        }
        foreach ($grouped as $context => $idsMap) {
            $specs = $this->activeSpecsForContext($context, 0);
            $participantPlan = $this->compileParticipantPlan($specs);
            foreach (array_chunk(array_values($idsMap), 500) as $chunk) {
                $valid = $this->validObjectIds($context, $chunk);
                $participants = $this->candidateSensorIdsForObjects($context, $valid, $participantPlan);
                foreach ($chunk as $id) if (!isset($participants[$id])) $participants[$id] = [];
                $this->writeResolvedBatch($context, $chunk, $participants, $specs);
            }
        }
    }
    private function writeResolvedBatch(string $context, array $objectIds, array $participants, array $specs): void
    {
        global $wpdb;
        if (empty($objectIds)) return;
        $coverage = Schema::getSensorCoverageTableName();
        $exclusions = Schema::getSensorExclusionsTableName();
        $placeholders = implode(',', array_fill(0, count($objectIds), '%d'));
        $deleteParams = array_merge([$context], array_map('intval', $objectIds));
        $now = current_time('mysql', true);
        $coverageRows = [];
        $coverageParams = [];
        $exclusionRows = [];
        $exclusionParams = [];
        foreach ($objectIds as $objectId) {
            $sensorIds = array_values(array_unique(array_filter(array_map('intval', $participants[$objectId] ?? []))));
            $winner = $this->pickWinner($sensorIds, $specs);
            if ($winner <= 0) continue;
            $coverageRows[] = '(%s,%d,%d,%s)';
            array_push($coverageParams, $context, (int)$objectId, $winner, $now);
            foreach ($sensorIds as $sensorId) {
                if ($sensorId === $winner) continue;
                $exclusionRows[] = '(%d,%d,%s,%d,%s)';
                array_push($exclusionParams, $sensorId, $winner, $context, (int)$objectId, $now);
            }
        }
        $ownTransaction = !self::$writeTransactionOpen;
        if ($ownTransaction && $wpdb->query('START TRANSACTION') === false) {
            throw new \RuntimeException('Failed to start sensor coverage transaction.');
        }
        $ok = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$coverage} WHERE context_type = %s AND object_id IN ({$placeholders})",
            $deleteParams
        )) !== false;
        $ok = ($wpdb->query($wpdb->prepare(
            "DELETE FROM {$exclusions} WHERE context_type = %s AND object_id IN ({$placeholders})",
            $deleteParams
        )) !== false) && $ok;
        if ($ok && !empty($coverageRows)) {
            $ok = $wpdb->query($wpdb->prepare(
                "INSERT INTO {$coverage} (context_type, object_id, sensor_id, updated_at) VALUES " . implode(',', $coverageRows),
                $coverageParams
            )) !== false;
        }
        if ($ok && !empty($exclusionRows)) {
            foreach (array_chunk($exclusionRows, 500) as $chunkIndex => $rowChunk) {
                $firstRow = (int)$chunkIndex * 500;
                $paramChunk = array_slice($exclusionParams, $firstRow * 5, count($rowChunk) * 5);
                $inserted = $wpdb->query($wpdb->prepare(
                    "INSERT INTO {$exclusions} (excluded_sensor_id, owner_sensor_id, context_type, object_id, updated_at) VALUES " . implode(',', $rowChunk),
                    $paramChunk
                )) !== false;
                $ok = $inserted && $ok;
                if (!$ok) break;
            }
        }
        if (!$ok) {
            if ($ownTransaction) $wpdb->query('ROLLBACK');
            throw new \RuntimeException('Failed to write sensor coverage.');
        }
        if ($ownTransaction && $wpdb->query('COMMIT') === false) {
            $wpdb->query('ROLLBACK');
            throw new \RuntimeException('Failed to commit sensor coverage.');
        }
    }
    private function validObjectIds(string $context, array $objectIds): array
    {
        global $wpdb;
        $objectIds = array_values(array_unique(array_filter(array_map('intval', $objectIds))));
        if (empty($objectIds)) return [];
        $postTypes = ['product' => 'product', 'post' => 'post', 'page' => 'page'];
        if (isset($postTypes[$context])) {
            $placeholders = implode(',', array_fill(0, count($objectIds), '%d'));
            $sql = "SELECT ID FROM {$wpdb->posts} FORCE INDEX (PRIMARY)
                    WHERE post_type = %s AND post_status = 'publish' AND ID IN ({$placeholders})";
            return array_map('intval', $wpdb->get_col($wpdb->prepare($sql, array_merge([$postTypes[$context]], $objectIds))));
        }
        $taxonomy = $this->taxonomyForArchiveContext($context);
        if ($taxonomy === '') return [];
        $terms = get_terms(['taxonomy' => $taxonomy, 'include' => $objectIds, 'hide_empty' => false, 'fields' => 'ids']);
        return is_wp_error($terms) ? [] : array_map('intval', $terms);
    }
    private function placementsForContext(string $context): array
    {
        $map = [
            'product' => ['product_single', 'product_in_cat', 'product_in_tag'],
            'post' => ['post_single', 'post_in_cat', 'post_in_tag'],
            'page' => ['page'],
            'product_cat_archive' => ['product_cat'],
            'product_tag_archive' => ['product_tag'],
            'post_cat_archive' => ['post_cat'],
            'post_tag_archive' => ['post_tag'],
        ];
        return $map[$context] ?? [];
    }
    private function taxonomyForArchiveContext(string $context): string
    {
        $map = [
            'product_cat_archive' => 'product_cat',
            'product_tag_archive' => 'product_tag',
            'post_cat_archive' => 'category',
            'post_tag_archive' => 'post_tag',
        ];
        return $map[$context] ?? '';
    }
    private function labelsForObjects(string $context, array $objectIds): array
    {
        global $wpdb;
        $ids = array_values(array_unique(array_filter(array_map('intval', $objectIds))));
        if (empty($ids)) return [];
        $out = [];
        if (in_array($context, ['product', 'post', 'page'], true)) {
            foreach (array_chunk($ids, 500) as $chunk) {
                $placeholders = implode(',', array_fill(0, count($chunk), '%d'));
                $sql = "SELECT ID, post_title FROM {$wpdb->posts} WHERE ID IN ({$placeholders})";
                foreach ($wpdb->get_results($wpdb->prepare($sql, $chunk), ARRAY_A) as $row) {
                    $out[(int)$row['ID']] = (string)$row['post_title'];
                }
            }
            return $out;
        }
        $taxonomy = $this->taxonomyForArchiveContext($context);
        if ($taxonomy === '') return [];
        $terms = get_terms(['taxonomy' => $taxonomy, 'include' => $ids, 'hide_empty' => false]);
        if (!is_wp_error($terms)) foreach ($terms as $term) $out[(int)$term->term_id] = (string)$term->name;
        return $out;
    }
    private function exclusionTitle(array $contexts): string
    {
        $contexts = array_values(array_unique($contexts));
        if (count($contexts) === 1) {
            if ($contexts[0] === 'product') return 'محصولات استثناشده';
            if ($contexts[0] === 'post') return 'مطالب استثناشده';
            if ($contexts[0] === 'page') return 'برگه‌های استثناشده';
        }
        return 'مکان‌های استثناشده';
    }
}
