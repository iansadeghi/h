<?php
namespace SeKianAfraz\VisitDiscount\Sensors\Concerns;
use SeKianAfraz\VisitDiscount\Database\Schema;
if (!defined('ABSPATH')) { exit; }
trait CoverageSyncAndLocking
{
    public function syncSensor(int $sensorId): void
    {
        if ($sensorId <= 0) return;
        if (!$this->acquireWriteLock(10)) {
            $this->scheduleRetry('syncSensor', [$sensorId]);
            return;
        }
        try {
            $contexts = $this->associatedContexts($sensorId);
            $placement = '';
            $items = [];
            $context = '';
            $post = get_post($sensorId);
            if ($post && $post->post_type === 'sekianafraz_sensor' && $post->post_status === 'publish') {
                $placement = (string)get_post_meta($sensorId, 'placement', true);
                $items = (array)get_post_meta($sensorId, 'items', true);
                $context = $this->contextForPlacement($placement);
                if ($context !== '') $contexts[] = $context;
            }
            foreach (array_unique($contexts) as $affectedContext) {
                $queries = $this->referenceQueries($affectedContext, $sensorId);
                if ($affectedContext === $context) $queries[] = $this->scopeQuery($placement, $items);
                $this->resolveBatches($affectedContext, $queries);
            }
        } finally {
            $this->releaseWriteLock();
        }
    }
    public function removeSensor(int $sensorId): void
    {
        if ($sensorId <= 0) return;
        if (!$this->acquireWriteLock(10)) {
            $this->scheduleRetry('removeSensor', [$sensorId]);
            return;
        }
        try {
            foreach ($this->associatedContexts($sensorId) as $context) {
                $this->resolveBatches($context, $this->referenceQueries($context, $sensorId));
            }
        } finally {
            $this->releaseWriteLock();
        }
    }
    public function syncPostObject(int $postId, string $knownPostType = ''): void
    {
        if ($postId <= 0) return;
        if (!$this->acquireWriteLock(10)) {
            $this->scheduleRetry('syncPostObject', [$postId, $knownPostType]);
            return;
        }
        try {
            $type = $knownPostType !== '' ? sanitize_key($knownPostType) : (string)get_post_type($postId);
            $contexts = [];
            if ($type === 'product') $contexts[] = 'product';
            elseif ($type === 'post') $contexts[] = 'post';
            elseif ($type === 'page') $contexts[] = 'page';
            else $contexts = ['product', 'post', 'page'];
            $refs = [];
            $priorOwners = [];
            foreach ($contexts as $context) $refs[$context . ':' . $postId] = [$context, $postId];
            foreach ($contexts as $context) {
                foreach ($this->ownersForObjectIds($context, [$postId]) as $ownerId) $priorOwners[(int)$ownerId] = (int)$ownerId;
            }
            $this->resolveRefs($refs);
            $this->deactivateEmptySensorIds(array_values($priorOwners));
        } finally {
            $this->releaseWriteLock();
        }
    }
    public function syncTaxonomy(string $taxonomy, int $termId = 0, bool $includeContent = true, ?array $objectIds = null): void
    {
        $map = [
            'product_cat' => ['product', 'product_cat_archive'],
            'product_tag' => ['product', 'product_tag_archive'],
            'category' => ['post', 'post_cat_archive'],
            'post_tag' => ['post', 'post_tag_archive'],
        ];
        if (!isset($map[$taxonomy])) return;
        if (!$this->acquireWriteLock(10)) {
            $this->scheduleRetry('syncTaxonomy', [$taxonomy, $termId, $includeContent, $objectIds]);
            return;
        }
        try {
            if ($includeContent && $objectIds === null) $this->rebuildContext($map[$taxonomy][0]);
            elseif ($includeContent) {
                $context = $map[$taxonomy][0];
                $specs = $this->activeSpecsForContext($context);
                $plan = $this->compileParticipantPlan($specs);
                foreach (array_chunk(array_values(array_unique(array_filter(array_map('intval', $objectIds)))), 500) as $chunk) {
                    $valid = $this->validObjectIds($context, $chunk);
                    $this->writeResolvedBatch($context, $chunk, $this->candidateSensorIdsForObjects($context, $valid, $plan), $specs);
                }
                $this->deactivateEmptyActiveSensors($context);
            }
            if ($termId > 0) $this->resolveRefs([$map[$taxonomy][1] . ':' . $termId => [$map[$taxonomy][1], $termId]]);
            else $this->rebuildContext($map[$taxonomy][1]);
            if ($termId > 0) $this->deactivateEmptyActiveSensors($map[$taxonomy][1]);
        } finally {
            $this->releaseWriteLock();
        }
    }
    public function rebuildContext(string $context): void
    {
        $placements = $this->placementsForContext($context);
        if (!$placements) return;
        if (!$this->acquireWriteLock(10)) {
            $this->scheduleRetry('rebuildContext', [$context]);
            return;
        }
        try {
            $queries = $this->referenceQueries($context);
            $queries[] = $this->scopeQuery($placements[0], ['*']);
            $this->resolveBatches($context, $queries);
            $this->deactivateEmptyActiveSensors($context);
        } finally {
            $this->releaseWriteLock();
        }
    }
    public function getExclusions(int $sensorId, int $page = 1, int $perPage = 5): array
    {
        global $wpdb;
        $page = max(1, $page);
        $perPage = max(1, min(50, $perPage));
        $offset = ($page - 1) * $perPage;
        $table = Schema::getSensorExclusionsTableName();
        $total = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM {$table} WHERE excluded_sensor_id = %d",
            $sensorId
        ));
        if ($total <= 0) {
            return ['title' => 'مکان‌های استثناشده', 'items' => [], 'total' => 0, 'page' => $page, 'has_more' => false];
        }
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT context_type, object_id, owner_sensor_id
             FROM {$table}
             WHERE excluded_sensor_id = %d
             ORDER BY context_type ASC, object_id DESC
             LIMIT %d OFFSET %d",
            $sensorId,
            $perPage,
            $offset
        ), ARRAY_A);
        $byContext = [];
        foreach ($rows as $row) $byContext[(string)$row['context_type']][] = (int)$row['object_id'];
        $labels = [];
        foreach ($byContext as $context => $ids) $labels[$context] = $this->labelsForObjects($context, $ids);
        $items = [];
        foreach ($rows as $row) {
            $context = (string)$row['context_type'];
            $objectId = (int)$row['object_id'];
            $ownerId = (int)$row['owner_sensor_id'];
            $items[] = [
                'id' => $objectId,
                'label' => $labels[$context][$objectId] ?? ('مکان حذف‌شده (#' . $objectId . ')'),
                'context_type' => $context,
                'owner_sensor_id' => $ownerId,
                'owner_sensor_name' => (string)get_the_title($ownerId),
                'owner_sensor_status' => (string)get_post_status($ownerId),
            ];
        }
        return [
            'title' => $this->exclusionTitle(array_keys($byContext)),
            'items' => $items,
            'total' => $total,
            'page' => $page,
            'has_more' => ($offset + count($items)) < $total,
        ];
    }
    public function acquireWriteLock(int $timeoutSeconds = 5): bool
    {
        global $wpdb;
        if (self::$writeLockDepth > 0) {
            self::$writeLockDepth++;
            return true;
        }
        $name = 'sekianafraz_coverage_' . md5(DB_NAME . '|' . $wpdb->prefix);
        $locked = (int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s, %d)', $name, max(0, $timeoutSeconds))) === 1;
        if ($locked) self::$writeLockDepth = 1;
        return $locked;
    }
    public function releaseWriteLock(): void
    {
        global $wpdb;
        if (self::$writeLockDepth <= 0) return;
        self::$writeLockDepth--;
        if (self::$writeLockDepth > 0) return;
        \SeKianAfraz\VisitDiscount\Cache\SensorCache::invalidate();
        $name = 'sekianafraz_coverage_' . md5(DB_NAME . '|' . $wpdb->prefix);
        $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $name));
    }
    public function beginWriteTransaction(): bool
    {
        global $wpdb;
        if (self::$writeTransactionOpen || self::$writeLockDepth <= 0) return false;
        self::$writeTransactionOpen = $wpdb->query('START TRANSACTION') !== false;
        return self::$writeTransactionOpen;
    }
    public function commitWriteTransaction(): bool
    {
        global $wpdb;
        if (!self::$writeTransactionOpen) return false;
        $committed = $wpdb->query('COMMIT') !== false;
        if ($committed) {
            self::$writeTransactionOpen = false;
            \SeKianAfraz\VisitDiscount\Cache\SensorCache::invalidate();
        }
        return $committed;
    }
    public function rollbackWriteTransaction(): void
    {
        global $wpdb;
        if (!self::$writeTransactionOpen) return;
        $wpdb->query('ROLLBACK');
        self::$writeTransactionOpen = false;
        \SeKianAfraz\VisitDiscount\Cache\SensorCache::invalidate();
    }
    public function deactivateEmptyActiveSensors(string $context): array
    {
        $specs = $this->activeSpecsForContext($context);
        return $this->deactivateEmptySensorIds(array_keys($specs));
    }
    private function deactivateEmptySensorIds(array $sensorIds): array
    {
        $sensorIds = array_values(array_unique(array_filter(array_map('intval', $sensorIds))));
        if (empty($sensorIds)) return [];
        global $wpdb;
        $table = Schema::getSensorCoverageTableName();
        $nonempty = [];
        foreach (array_chunk($sensorIds, 500) as $chunk) {
            $ids = implode(',', $chunk);
            $rows = $wpdb->get_col("SELECT p.ID FROM {$wpdb->posts} p WHERE p.ID IN ({$ids})
                AND EXISTS (SELECT 1 FROM {$table} c WHERE c.sensor_id=p.ID LIMIT 1)");
            if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to check effective sensor coverage.');
            foreach ($rows as $id) $nonempty[(int)$id] = true;
        }
        $disabled = [];
        foreach ($sensorIds as $sensorId) {
            if (get_post_status($sensorId) !== 'publish' || isset($nonempty[$sensorId])) continue;
            $updated = wp_update_post(['ID' => $sensorId, 'post_status' => 'draft'], true);
            if (is_wp_error($updated) || !$updated) {
                throw new \RuntimeException('Failed to disable an empty sensor.');
            }
            (new SensorIndexService())->deleteSensorIndex($sensorId);
            $disabled[] = (int)$sensorId;
        }
        return $disabled;
    }
    private function emptyAnalysis(): array
    {
        return [
            'has_conflict' => false,
            'candidate_count' => 0,
            'remaining_count' => 0,
            'smart_allowed' => true,
            'smart_target' => 'candidate',
            'empty_existing_sensor_ids' => [],
            'exclude_from_candidate' => 0,
            'exclude_from_existing' => 0,
            'context_type' => '',
            'conflicts' => [],
        ];
    }
    private function normalizeItems(array $items): array
    {
        $out = [];
        foreach ($items as $item) {
            if ((string)$item === '*') $out[] = '*';
            elseif (ctype_digit((string)$item) && (int)$item > 0) $out[] = (string)(int)$item;
        }
        return array_values(array_unique($out));
    }
    private function sameStoredScope(int $sensorId, string $placement, array $items): bool
    {
        if ($sensorId <= 0 || get_post_status($sensorId) !== 'publish') return false;
        $storedPlacement = sanitize_key((string)get_post_meta($sensorId, 'placement', true));
        $storedItems = $this->normalizeItems((array)get_post_meta($sensorId, 'items', true));
        sort($storedItems, SORT_STRING);
        sort($items, SORT_STRING);
        return $storedPlacement === $placement && $storedItems === $items;
    }
    private function scopeQuery(string $placement, array $items): string
    {
        global $wpdb;
        $items = $this->normalizeItems($items);
        $context = $this->contextForPlacement($placement);
        if ($context === '' || !$items) return '';
        $postTypes = ['product' => 'product', 'post' => 'post', 'page' => 'page'];
        if (isset($postTypes[$context])) {
            $where = $wpdb->prepare("p.post_type=%s AND p.post_status='publish'", $postTypes[$context]);
            $taxonomyMap = ['product_in_cat' => 'product_cat', 'product_in_tag' => 'product_tag', 'post_in_cat' => 'category', 'post_in_tag' => 'post_tag'];
            if (isset($taxonomyMap[$placement])) {
                $termId = (int)($items[0] ?? 0);
                if ($termId <= 0) return '';
                return $wpdb->prepare("SELECT tr.object_id FROM {$wpdb->term_taxonomy} tt
                    INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id=tt.term_taxonomy_id
                    INNER JOIN {$wpdb->posts} p ON p.ID=tr.object_id
                    WHERE {$where} AND tt.taxonomy=%s AND tt.term_id=%d", $taxonomyMap[$placement], $termId);
            }
            if (!in_array('*', $items, true)) $where .= ' AND p.ID IN (' . implode(',', array_map('intval', $items)) . ')';
            return "SELECT p.ID AS object_id FROM {$wpdb->posts} p WHERE {$where}";
        }
        $taxonomy = $this->taxonomyForArchiveContext($context);
        if ($taxonomy === '') return '';
        $where = $wpdb->prepare('tt.taxonomy=%s', $taxonomy);
        if (!in_array('*', $items, true)) $where .= ' AND tt.term_id IN (' . implode(',', array_map('intval', $items)) . ')';
        return "SELECT tt.term_id AS object_id FROM {$wpdb->term_taxonomy} tt WHERE {$where}";
    }
}
