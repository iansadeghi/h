<?php
namespace SeKianAfraz\VisitDiscount\Sensors;
use SeKianAfraz\VisitDiscount\Database\Schema;
if (!defined('ABSPATH')) { exit; }
class SensorCoverageService
{
    private static $writeLockDepth = 0;
    use \SeKianAfraz\VisitDiscount\Sensors\Concerns\CoverageSyncAndLocking;
    use \SeKianAfraz\VisitDiscount\Sensors\Concerns\CoverageResolution;
    private static $writeTransactionOpen = false;
    private $termScopeCache = [];
    public function retry(string $method, array $args): void
    {
        if (!in_array($method, ['syncSensor','removeSensor','syncPostObject','syncTaxonomy','rebuildContext'], true)) return;
        call_user_func_array([$this, $method], $args);
    }
    private function scheduleRetry(string $method, array $args): void
    {
        $eventArgs = [$method, $args];
        if (!wp_next_scheduled('sekianafraz_coverage_retry', $eventArgs)) {
            wp_schedule_single_event(time() + 15, 'sekianafraz_coverage_retry', $eventArgs);
        }
    }
    public function supportsPlacement(string $placement): bool
    {
        return $this->contextForPlacement($placement) !== '';
    }
    public function contextForPlacement(string $placement): string
    {
        $map = [
            'product_single' => 'product',
            'product_in_cat' => 'product',
            'product_in_tag' => 'product',
            'post_single' => 'post',
            'post_in_cat' => 'post',
            'post_in_tag' => 'post',
            'page' => 'page',
            'product_cat' => 'product_cat_archive',
            'product_tag' => 'product_tag_archive',
            'post_cat' => 'post_cat_archive',
            'post_tag' => 'post_tag_archive',
        ];
        return $map[sanitize_key($placement)] ?? '';
    }
    public function rankForSpec(string $placement, array $items): int
    {
        $placement = sanitize_key($placement);
        if (in_array($placement, ['product_in_cat', 'product_in_tag', 'post_in_cat', 'post_in_tag'], true)) {
            return 2;
        }
        return in_array('*', array_map('strval', $items), true) ? 1 : 3;
    }
    public function scopesOverlap(string $placementA, array $itemsA, string $placementB, array $itemsB): bool
    {
        global $wpdb;
        $context = $this->contextForPlacement($placementA);
        if ($context === '' || $context !== $this->contextForPlacement($placementB)) return false;
        $a = $this->scopeQuery($placementA, $itemsA);
        $b = $this->scopeQuery($placementB, $itemsB);
        if ($a === '' || $b === '') return false;
        $found = $wpdb->get_var("SELECT 1 FROM ({$a}) a INNER JOIN ({$b}) b ON b.object_id=a.object_id LIMIT 1");
        if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to compare sensor scopes.');
        return $found !== null;
    }
    private function objectBatches(array $queries): \Generator
    {
        global $wpdb;
        $queries = array_values(array_filter($queries));
        if (!$queries) return;
        $after = 0;
        do {
            $parts = [];
            foreach ($queries as $query) {
                $query = str_replace("FROM {$wpdb->posts} p", "FROM {$wpdb->posts} p FORCE INDEX (PRIMARY)", $query);
                $parts[] = "(SELECT DISTINCT object_id FROM ({$query}) objects WHERE object_id > {$after} ORDER BY object_id ASC LIMIT 500)";
            }
            $sql = 'SELECT DISTINCT object_id FROM (' . implode(' UNION ALL ', $parts) . ') candidates ORDER BY object_id ASC LIMIT 500';
            $ids = array_map('intval', $wpdb->get_col($sql));
            if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to read sensor coverage batch.');
            if (!$ids) return;
            $after = (int)end($ids);
            yield $ids;
        } while (count($ids) === 500);
    }
    private function referenceQueries(string $context, int $sensorId = 0): array
    {
        global $wpdb;
        $coverage = Schema::getSensorCoverageTableName();
        $exclusions = Schema::getSensorExclusionsTableName();
        $where = $wpdb->prepare('context_type=%s', $context);
        if ($sensorId <= 0) return ["SELECT object_id FROM {$coverage} WHERE {$where}", "SELECT object_id FROM {$exclusions} WHERE {$where}"];
        return [
            "SELECT object_id FROM {$coverage} WHERE {$where} AND sensor_id=" . (int)$sensorId,
            "SELECT object_id FROM {$exclusions} WHERE {$where} AND excluded_sensor_id=" . (int)$sensorId,
            "SELECT object_id FROM {$exclusions} WHERE {$where} AND owner_sensor_id=" . (int)$sensorId,
        ];
    }
    private function associatedContexts(int $sensorId): array
    {
        global $wpdb;
        $coverage = Schema::getSensorCoverageTableName();
        $exclusions = Schema::getSensorExclusionsTableName();
        $sql = $wpdb->prepare("SELECT DISTINCT context_type FROM {$coverage} WHERE sensor_id=%d
            UNION SELECT DISTINCT context_type FROM {$exclusions} WHERE excluded_sensor_id=%d
            UNION SELECT DISTINCT context_type FROM {$exclusions} WHERE owner_sensor_id=%d", $sensorId, $sensorId, $sensorId);
        $contexts = $wpdb->get_col($sql);
        if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to read sensor contexts.');
        return $contexts;
    }
    private function resolveBatches(string $context, array $queries): void
    {
        $specs = $this->activeSpecsForContext($context);
        $plan = $this->compileParticipantPlan($specs);
        foreach ($this->objectBatches($queries) as $chunk) {
            $valid = $this->validObjectIds($context, $chunk);
            $participants = $this->candidateSensorIdsForObjects($context, $valid, $plan);
            $this->writeResolvedBatch($context, $chunk, $participants, $specs);
        }
    }
    public function analyzeConflict(string $placement, array $items, int $sensorId = 0, int $sampleLimit = 5): array
    {
        $placement = sanitize_key($placement);
        $items = $this->normalizeItems($items);
        $context = $this->contextForPlacement($placement);
        if ($context === '' || empty($items)) return $this->emptyAnalysis();
        if ($sensorId > 0 && $this->sameStoredScope($sensorId, $placement, $items)) {
            global $wpdb;
            $coverage = Schema::getSensorCoverageTableName();
            $exclusions = Schema::getSensorExclusionsTableName();
            $owned = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$coverage} WHERE sensor_id=%d AND context_type=%s", $sensorId, $context));
            if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to read sensor coverage.');
            $excluded = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$exclusions} WHERE excluded_sensor_id=%d AND context_type=%s", $sensorId, $context));
            if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to read sensor exclusions.');
            $analysis = $this->emptyAnalysis();
            $analysis['candidate_count'] = $owned + $excluded;
            $analysis['remaining_count'] = $owned;
            $analysis['smart_allowed'] = $owned > 0;
            $analysis['context_type'] = $context;
            return $analysis;
        }
        $scopeQuery = $this->scopeQuery($placement, $items);
        if ($scopeQuery === '') {
            $empty = $this->emptyAnalysis();
            $empty['smart_allowed'] = false;
            return $empty;
        }
        $candidateCount = 0;
        $candidateRank = $this->rankForSpec($placement, $items);
        $specs = $this->activeSpecsForContext($context, $sensorId);
        if (empty($specs)) {
            $empty = $this->emptyAnalysis();
            global $wpdb;
            $count = (int)$wpdb->get_var("SELECT COUNT(*) FROM ({$scopeQuery}) candidates");
            if ($wpdb->last_error !== '') throw new \RuntimeException('Failed to count sensor scope.');
            $empty['candidate_count'] = $count;
            $empty['remaining_count'] = $count;
            $empty['smart_allowed'] = $count > 0;
            return $empty;
        }
        $sameScope = $sensorId > 0 && $this->sameStoredScope($sensorId, $placement, $items);
        $groups = [];
        $excludeFromCandidate = 0;
        $excludeFromExisting = 0;
        $candidateOwned = 0;
        $ownershipDeltas = [];
        $candidateKey = $sensorId > 0 ? $sensorId : -1;
        $participantPlan = $this->compileParticipantPlan($specs);
        foreach ($this->objectBatches([$scopeQuery]) as $chunk) {
            $candidateCount += count($chunk);
            $resolved = $sameScope ? $this->resolvedObjectsForSensor($sensorId, $context, $chunk) : [];
            $participants = $this->candidateSensorIdsForObjects($context, $chunk, $participantPlan);
            $currentOwners = $this->ownersForObjectIds($context, $chunk);
            foreach ($chunk as $objectId) {
                $sensorIds = array_values(array_unique(array_filter(array_map('intval', $participants[$objectId] ?? []))));
                $ownerId = $this->pickWinner($sensorIds, $specs);
                $ownerRank = (int)($specs[$ownerId]['rank'] ?? 0);
                $candidateWinsObject = $ownerId === 0 || $candidateRank > $ownerRank
                    || ($candidateRank === $ownerRank && $sensorId > 0 && $sensorId < $ownerId);
                $projectedOwner = $candidateWinsObject ? $candidateKey : $ownerId;
                $this->recordOwnershipDelta($ownershipDeltas, (int)($currentOwners[$objectId] ?? 0), $projectedOwner);
                if ($candidateWinsObject) $candidateOwned++;
                if (isset($resolved[$objectId]) || empty($sensorIds)) continue;
                if ($candidateWinsObject) {
                    $excludeFromExisting++;
                }
                else $excludeFromCandidate++;
                foreach ($sensorIds as $participantId) {
                    $participantRank = (int)($specs[$participantId]['rank'] ?? 0);
                    $candidateWinsPair = $candidateRank > $participantRank
                        || ($candidateRank === $participantRank && $sensorId > 0 && $sensorId < $participantId);
                    if (!isset($groups[$participantId])) {
                        $groups[$participantId] = [
                            'sensor_id' => $participantId,
                            'sensor_name' => (string)get_the_title($participantId),
                            'count' => 0,
                            'sample_ids' => [],
                            'exclusion_side' => $candidateWinsPair ? 'existing' : 'candidate',
                        ];
                    }
                    $groups[$participantId]['count']++;
                    if (count($groups[$participantId]['sample_ids']) < max(1, $sampleLimit)) {
                        $groups[$participantId]['sample_ids'][] = $objectId;
                    }
                }
            }
        }
        $sampleObjectIds = [];
        foreach ($groups as $group) {
            $sampleObjectIds = array_merge($sampleObjectIds, (array)$group['sample_ids']);
        }
        $sampleLabels = $this->labelsForObjects($context, array_values(array_unique($sampleObjectIds)));
        $conflicts = [];
        foreach ($groups as $group) {
            $samples = [];
            foreach ($group['sample_ids'] as $objectId) {
                $samples[] = ['id' => $objectId, 'label' => $sampleLabels[$objectId] ?? ('#' . $objectId)];
            }
            unset($group['sample_ids']);
            $group['items'] = $samples;
            $group['has_more'] = $group['count'] > count($samples);
            $conflicts[] = $group;
        }
        if ($sensorId > 0 && !$sameScope && get_post_status($sensorId) === 'publish') {
            foreach ($this->associatedContexts($sensorId) as $oldContext) {
                $oldSpecs = $oldContext === $context ? $specs : $this->activeSpecsForContext($oldContext, $sensorId);
                $oldPlan = $this->compileParticipantPlan($oldSpecs);
                $queries = $this->referenceQueries($oldContext, $sensorId);
                if ($oldContext === $context) {
                    foreach ($queries as &$query) {
                        $query = "SELECT refs.object_id FROM ({$query}) refs WHERE NOT EXISTS
                            (SELECT 1 FROM ({$scopeQuery}) candidates WHERE candidates.object_id=refs.object_id)";
                    }
                    unset($query);
                }
                foreach ($this->objectBatches($queries) as $oldChunk) {
                    $oldOwners = $this->ownersForObjectIds($oldContext, $oldChunk);
                    $oldParticipants = $this->candidateSensorIdsForObjects($oldContext, $oldChunk, $oldPlan);
                    foreach ($oldChunk as $oldObjectId) {
                        $newOwner = $this->pickWinner((array)($oldParticipants[$oldObjectId] ?? []), $oldSpecs);
                        $this->recordOwnershipDelta($ownershipDeltas, (int)($oldOwners[$oldObjectId] ?? 0), $newOwner);
                    }
                }
            }
        }
        $existingIds = array_values(array_unique(array_filter(array_merge(array_keys($groups), array_keys($ownershipDeltas)), function($id) use ($candidateKey): bool {
            return (int)$id > 0 && (int)$id !== $candidateKey;
        })));
        $existingCounts = $this->coverageCountsForSensors($existingIds);
        $emptyExistingIds = [];
        foreach ($existingIds as $existingId) {
            if ((int)($existingCounts[$existingId] ?? 0) + (int)($ownershipDeltas[$existingId] ?? 0) <= 0) {
                $emptyExistingIds[] = (int)$existingId;
            }
        }
        $remaining = max(0, $candidateOwned);
        $smartTarget = $excludeFromCandidate > 0 && $excludeFromExisting > 0
            ? 'mixed' : ($excludeFromExisting > 0 ? 'existing' : 'candidate');
        return [
            'has_conflict' => !empty($conflicts),
            'candidate_count' => $candidateCount,
            'remaining_count' => $remaining,
            'smart_allowed' => $remaining > 0 && empty($emptyExistingIds),
            'smart_target' => $smartTarget,
            'empty_existing_sensor_ids' => $emptyExistingIds,
            'exclude_from_candidate' => $excludeFromCandidate,
            'exclude_from_existing' => $excludeFromExisting,
            'context_type' => $context,
            'conflicts' => array_values($conflicts),
        ];
    }
    public function listConflictItems(string $placement, array $items, int $sensorId, int $conflictingSensorId, int $page = 1, int $perPage = 20): array
    {
        $placement = sanitize_key($placement);
        $items = $this->normalizeItems($items);
        $context = $this->contextForPlacement($placement);
        $page = max(1, $page);
        $perPage = max(1, min(50, $perPage));
        if ($context === '' || $conflictingSensorId <= 0) {
            return ['items' => [], 'total' => 0, 'page' => $page, 'has_more' => false];
        }
        $scopeQuery = $this->scopeQuery($placement, $items);
        $specs = $this->activeSpecsForContext($context, $sensorId);
        if (!isset($specs[$conflictingSensorId])) {
            return ['items' => [], 'total' => 0, 'page' => $page, 'has_more' => false];
        }
        $sameScope = $sensorId > 0 && $this->sameStoredScope($sensorId, $placement, $items);
        $offset = ($page - 1) * $perPage;
        $matched = [];
        $total = 0;
        $participantPlan = $this->compileParticipantPlan($specs);
        foreach ($this->objectBatches([$scopeQuery]) as $chunk) {
            $resolved = $sameScope ? $this->resolvedObjectsForSensor($sensorId, $context, $chunk) : [];
            $participants = $this->candidateSensorIdsForObjects($context, $chunk, $participantPlan);
            foreach ($chunk as $objectId) {
                if (isset($resolved[$objectId])) continue;
                if (!in_array($conflictingSensorId, array_map('intval', (array)($participants[$objectId] ?? [])), true)) continue;
                if ($total >= $offset && count($matched) < $perPage) $matched[] = $objectId;
                $total++;
            }
        }
        $labels = $this->labelsForObjects($context, $matched);
        $out = [];
        foreach ($matched as $objectId) {
            $out[] = ['id' => $objectId, 'label' => $labels[$objectId] ?? ('#' . $objectId)];
        }
        return [
            'items' => $out,
            'total' => $total,
            'page' => $page,
            'has_more' => ($offset + count($out)) < $total,
        ];
    }
}
