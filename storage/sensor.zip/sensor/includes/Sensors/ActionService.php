<?php
namespace SeKianAfraz\VisitDiscount\Sensors;
use SeKianAfraz\VisitDiscount\SMS\SmsMessageBuilder;
use SeKianAfraz\VisitDiscount\Banners\BannerBuilder;
use SeKianAfraz\VisitDiscount\Coupons\CouponIssuer;
use SeKianAfraz\VisitDiscount\Logs\ActionLogger;
use SeKianAfraz\VisitDiscount\Reminder\ReminderBuilder;
use SeKianAfraz\VisitDiscount\Helpers\TemplateEngine;
use SeKianAfraz\VisitDiscount\Helpers\UrlHelper;
use SeKianAfraz\VisitDiscount\Modules\ModuleManager;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineRunner;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineRegistry;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\ValidateSensorStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\LoadActionMetaStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\ResolveIdentityStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\ResolveBannerAudienceStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\DedupStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\IssueCouponStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\BuildReminderStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\BuildPayloadStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\BuildFallbackUrlStage;
use SeKianAfraz\VisitDiscount\Pipeline\Stages\BuildActionContextStage;
if (!defined('ABSPATH')) { exit; }
class ActionService
{
    private $templateEngine;
    private $urlHelper;
    private $smsMessageBuilder;
    private $bannerBuilder;
    private $couponIssuer;
    private $actionLogger;
    private $reminderBuilder;
    private $moduleManager;
    private $pipelineRunner;
    public function handle(int $sensorId, string $guestId): array
    {
        $ctx = new PipelineContext($sensorId, $guestId);
        try {
            $this->pipelineRunner()->run($ctx);
            if ($ctx->response !== null) return $ctx->response;
            if ($ctx->actionContext === null) return ['success' => false, 'code' => 'PIPELINE', 'message' => ''];
            return $this->moduleManager()->execute($ctx->action, $ctx->actionContext);
        } catch (\Throwable $error) {
            return ['success' => false, 'code' => 'ACTION_FAILED', 'message' => 'اجرای پیشنهاد کامل نشد. دوباره تلاش کنید.'];
        } finally {
            if ($ctx->dedupClaimed) {
                $this->actionLogger()->releaseClaim($ctx->sensorId, $ctx->userId, $ctx->guestId);
            }
        }
    }
    private function pipelineRunner(): PipelineRunner
    {
        if (!$this->pipelineRunner) {
            $defaultStages = [
                new ValidateSensorStage(),
                new LoadActionMetaStage($this->urlHelper()),
                new ResolveIdentityStage(),
                new ResolveBannerAudienceStage(),
                new DedupStage($this->actionLogger()),
                new IssueCouponStage($this->couponIssuer()),
                new BuildReminderStage($this->reminderBuilder()),
                new BuildPayloadStage(),
                new BuildFallbackUrlStage(),
                new BuildActionContextStage(
                    $this->smsMessageBuilder(),
                    $this->bannerBuilder(),
                    $this->actionLogger()
                ),
            ];
            $registry = new PipelineRegistry($defaultStages);
            if (function_exists('do_action')) {
                do_action('sekianafraz_pipeline_register_stages', $registry, $this);
            }
            $stages = $registry->getStages();
            if (function_exists('apply_filters')) {
                $stages = apply_filters('sekianafraz_pipeline_stages', $stages, $this);
            }
            $clean = [];
            foreach ((array)$stages as $s) {
                if ($s instanceof \SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface) {
                    $clean[] = $s;
                }
            }
            $this->pipelineRunner = new PipelineRunner($clean);
        }
        return $this->pipelineRunner;
    }
    private function moduleManager(): ModuleManager
    {
        if (!$this->moduleManager) {
            $this->moduleManager = new ModuleManager();
        }
        return $this->moduleManager;
    }
    private function actionLogger(): ActionLogger
    {
        if (!$this->actionLogger) {
            $this->actionLogger = new ActionLogger();
        }
        return $this->actionLogger;
    }
    private function templateEngine(): TemplateEngine
    {
        if (!$this->templateEngine) {
            $this->templateEngine = new TemplateEngine();
        }
        return $this->templateEngine;
    }
    private function urlHelper(): UrlHelper
    {
        if (!$this->urlHelper) {
            $this->urlHelper = new UrlHelper();
        }
        return $this->urlHelper;
    }
    private function smsMessageBuilder(): SmsMessageBuilder
    {
        if (!$this->smsMessageBuilder) {
            $this->smsMessageBuilder = new SmsMessageBuilder($this->templateEngine(), $this->urlHelper());
        }
        return $this->smsMessageBuilder;
    }
    private function bannerBuilder(): BannerBuilder
    {
        if (!$this->bannerBuilder) {
            $this->bannerBuilder = new BannerBuilder($this->templateEngine());
        }
        return $this->bannerBuilder;
    }
    private function couponIssuer(): CouponIssuer
    {
        if (!$this->couponIssuer) {
            $this->couponIssuer = new CouponIssuer();
        }
        return $this->couponIssuer;
    }
    private function reminderBuilder(): ReminderBuilder
    {
        if (!$this->reminderBuilder) {
            $this->reminderBuilder = new ReminderBuilder();
        }
        return $this->reminderBuilder;
    }
}
