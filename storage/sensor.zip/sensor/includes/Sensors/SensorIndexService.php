<?php
namespace SeKianAfraz\VisitDiscount\Sensors;
use SeKianAfraz\VisitDiscount\Helpers\Path;
if (!defined('ABSPATH')) { exit; }
class SensorIndexService
{
    public function rebuildSensorIndex(int $sensorId): void
    {
        global $wpdb;
        if ($sensorId <= 0) return;
        $post = get_post($sensorId);
        if (!$post || $post->post_type !== 'sekianafraz_sensor' || $post->post_status !== 'publish') {
            $this->deleteSensorIndex($sensorId);
            return;
        }
        $meta = get_post_meta($sensorId);
        $placement = isset($meta['placement'][0]) ? (string)maybe_unserialize($meta['placement'][0]) : '';
        $items = isset($meta['items'][0]) ? (array)maybe_unserialize($meta['items'][0]) : [];
        $minViews = isset($meta['min_views'][0]) ? (int)maybe_unserialize($meta['min_views'][0]) : 1;
        $minDuration = isset($meta['min_duration'][0]) ? (int)maybe_unserialize($meta['min_duration'][0]) : 1;
        $visitMetric = isset($meta['visit_metric'][0]) ? (string)maybe_unserialize($meta['visit_metric'][0]) : 'views';
        $visitCalculation = isset($meta['visit_calculation'][0]) ? (string)maybe_unserialize($meta['visit_calculation'][0]) : 'individual';
        $visitCondition = ($meta['visit_condition'][0] ?? 'or') === 'and' ? 'and' : 'or';
        $window = isset($meta['window'][0]) ? (string)maybe_unserialize($meta['window'][0]) : '24h';
        $minViews = max(1, $minViews);
        $minDuration = max(1, $minDuration);
        if (!in_array($visitMetric, ['views', 'duration', 'both'], true)) $visitMetric = 'views';
        if (!in_array($visitCalculation, ['individual', 'aggregate'], true)) $visitCalculation = 'individual';
        $items = $this->normalizeItems($placement, $items);
        $table = $wpdb->prefix . 'sekianafraz_sensor_index';
        if ($wpdb->delete($table, ['sensor_id' => $sensorId], ['%d']) === false) {
            throw new \RuntimeException('Failed to clear the sensor index.');
        }
        \SeKianAfraz\VisitDiscount\Cache\SensorCache::invalidate();
        if ($placement === '' || empty($items)) return;
        $updatedAt = current_time('mysql', true);
        $rows = [];
        $params = [];
        foreach ($items as $item) {
            $rows[] = '(%d,%s,%s,%d,%d,%s,%s,%s,%s,%s)';
            $params[] = $sensorId;
            $params[] = $placement;
            $params[] = $item;
            $params[] = $minViews;
            $params[] = $minDuration;
            $params[] = $visitMetric;
            $params[] = $visitCalculation;
            $params[] = $visitCondition;
            $params[] = $window;
            $params[] = $updatedAt;
        }
        $sql = "INSERT INTO {$table} (sensor_id, placement, item, min_views, min_duration, visit_metric, visit_calculation, visit_condition, time_window, updated_at) VALUES " . implode(',', $rows);
        if ($wpdb->query($wpdb->prepare($sql, $params)) === false) {
            throw new \RuntimeException('Failed to write the sensor index.');
        }
        \SeKianAfraz\VisitDiscount\Cache\SensorCache::invalidate();
    }
    public function deleteSensorIndex(int $sensorId): void
    {
        global $wpdb;
        if ($sensorId <= 0) return;
        $table = $wpdb->prefix . 'sekianafraz_sensor_index';
        if ($wpdb->delete($table, ['sensor_id' => $sensorId], ['%d']) === false) {
            throw new \RuntimeException('Failed to clear the sensor index.');
        }
        \SeKianAfraz\VisitDiscount\Cache\SensorCache::invalidate();
    }
    public function rebuildAllPublishedSensors(): void
    {
        $ids = get_posts([
            'post_type' => 'sekianafraz_sensor',
            'post_status' => 'publish',
            'posts_per_page' => -1,
            'fields' => 'ids',
        ]);
        foreach ($ids as $id) {
            $this->rebuildSensorIndex((int)$id);
        }
    }
    public function rebuildBatch(int $offset, int $limit): int
    {
        $ids = get_posts([
            'post_type' => 'sekianafraz_sensor',
            'post_status' => 'publish',
            'posts_per_page' => $limit,
            'offset' => $offset,
            'fields' => 'ids',
            'orderby' => 'ID',
            'order' => 'ASC'
        ]);
        foreach ($ids as $id) {
            $this->rebuildSensorIndex((int)$id);
        }
        return count($ids);
    }
    private function normalizeItems(string $placement, array $items): array
    {
        $out = [];
        $numericPlacements = [
            'product_single',
            'post_single',
            'page',
            'product_cat',
            'product_tag',
            'product_in_cat',
            'product_in_tag',
            'post_cat',
            'post_tag',
            'post_in_cat',
            'post_in_tag',
        ];
        foreach ($items as $item) {
            if ($item === '*' && in_array($placement, $numericPlacements, true)) {
                $out[] = '*';
                continue;
            }
            if ($placement === 'custom_url') {
                $path = Path::canonicalize((string)$item, Path::homePath());
                if ($path !== '') $out[] = $path;
                continue;
            }
            if ($placement === 'search_terms') {
                $clean = trim(sanitize_text_field((string)$item));
                if ($clean !== '') $out[] = $clean;
                continue;
            }
            if (in_array($placement, $numericPlacements, true)) {
                $normalized = $this->normalizeDigits((string)$item);
                if ($normalized !== '' && ctype_digit($normalized) && (int)$normalized > 0) {
                    $out[] = (string)((int)$normalized);
                }
                continue;
            }
            $clean = sanitize_text_field((string)$item);
            if ($clean !== '') $out[] = $clean;
        }
        return array_values(array_unique($out));
    }
    private function normalizeDigits(string $value): string
    {
        if ($value === '') return '';
        $map = [
            '۰' => '0', '۱' => '1', '۲' => '2', '۳' => '3', '۴' => '4',
            '۵' => '5', '۶' => '6', '۷' => '7', '۸' => '8', '۹' => '9',
            '٠' => '0', '١' => '1', '٢' => '2', '٣' => '3', '٤' => '4',
            '٥' => '5', '٦' => '6', '٧' => '7', '٨' => '8', '٩' => '9',
        ];
        return strtr($value, $map);
    }
}
