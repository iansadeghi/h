<?php
namespace SeKianAfraz\VisitDiscount\Sensors;
use SeKianAfraz\VisitDiscount\Database\Schema;
if (!defined('ABSPATH')) { exit; }
final class SensorCoverageReader
{
    public function ownersForPageContext(array $ctx): array
    {
        global $wpdb;
        $refs = [];
        if (!empty($ctx['product_id'])) $refs[] = ['product', (int)$ctx['product_id']];
        if (!empty($ctx['post_id'])) $refs[] = ['post', (int)$ctx['post_id']];
        if (!empty($ctx['page_id'])) $refs[] = ['page', (int)$ctx['page_id']];
        foreach ((array)($ctx['product_cat_ids'] ?? []) as $id) if ((int)$id > 0) $refs[] = ['product_cat_archive', (int)$id];
        foreach ((array)($ctx['product_tag_ids'] ?? []) as $id) if ((int)$id > 0) $refs[] = ['product_tag_archive', (int)$id];
        foreach ((array)($ctx['post_cat_ids'] ?? []) as $id) if ((int)$id > 0) $refs[] = ['post_cat_archive', (int)$id];
        foreach ((array)($ctx['post_tag_ids'] ?? []) as $id) if ((int)$id > 0) $refs[] = ['post_tag_archive', (int)$id];
        if (empty($refs)) return [];
        $clauses = [];
        $params = [];
        foreach ($refs as $ref) {
            $clauses[] = '(context_type = %s AND object_id = %d)';
            $params[] = $ref[0];
            $params[] = $ref[1];
        }
        $table = Schema::getSensorCoverageTableName();
        $index = $wpdb->prefix . 'sekianafraz_sensor_index';
        $clauses = array_map(static function ($clause) { return str_replace(['context_type', 'object_id'], ['c.context_type', 'c.object_id'], $clause); }, $clauses);
        $sql = "SELECT c.context_type, c.object_id, c.sensor_id, i.placement, i.min_views, i.min_duration,
                       i.visit_metric, i.visit_calculation, i.visit_condition, i.time_window AS `window`
                FROM {$table} c
                INNER JOIN {$index} i ON i.id = (SELECT id FROM {$index} WHERE sensor_id = c.sensor_id LIMIT 1)
                INNER JOIN {$wpdb->posts} p ON p.ID = c.sensor_id AND p.post_status = 'publish'
                WHERE " . implode(' OR ', $clauses);
        $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        $out = [];
        foreach ($rows as $row) {
            $sensorId = (int)$row['sensor_id'];
            if ($sensorId <= 0) continue;
            $out[$sensorId] = $row;
        }
        return $out;
    }
}
