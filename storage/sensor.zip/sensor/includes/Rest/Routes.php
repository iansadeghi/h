<?php
namespace SeKianAfraz\VisitDiscount\Rest;
use WP_REST_Request;
use WP_REST_Response;
use SeKianAfraz\VisitDiscount\Sensors\SensorService;
use SeKianAfraz\VisitDiscount\Sensors\SensorCoverageService;
use SeKianAfraz\VisitDiscount\SMS\SmsService;
use SeKianAfraz\VisitDiscount\Sensors\ActionService;
use SeKianAfraz\VisitDiscount\Helpers\PhoneResolver;
use SeKianAfraz\VisitDiscount\Helpers\PhoneNormalizer;
use SeKianAfraz\VisitDiscount\Helpers\PhoneMetaDiscovery;
use SeKianAfraz\VisitDiscount\Helpers\Path;
use SeKianAfraz\VisitDiscount\SMS\CredentialsVault;
if (!defined('ABSPATH')) { exit; }
class Routes
{
    public function register(): void
    {
        register_rest_route('sekianafraz/v1', '/admin/tab', [
            'methods' => 'GET',
            'permission_callback' => function () {
                return current_user_can('manage_options');
            },
            'callback' => function (\WP_REST_Request $req) {
                $tab = sanitize_key((string)($req->get_param('tab') ?: 'sensors'));
                if (!in_array($tab, ['sensors', 'sms', 'leads'], true)) {
                    $tab = 'sensors';
                }
                ob_start();
                (new \SeKianAfraz\VisitDiscount\Admin\AdminPage())->renderTabContent($tab);
                $html = (string) ob_get_clean();
                nocache_headers();
                return new \WP_REST_Response([
                    'success' => true,
                    'tab'     => $tab,
                    'html'    => $html,
                ], 200, [
                    'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
                    'Pragma'        => 'no-cache',
                ]);
            },
        ]);
        register_rest_route('sekianafraz/v1', '/leads/list', [
            'methods' => 'GET',
            'permission_callback' => function () { return current_user_can('manage_options'); },
            'callback' => function (WP_REST_Request $req) {
                $before = max(0, (int)$req->get_param('before'));
                if (!\SeKianAfraz\VisitDiscount\Leads\LeadsRepository::ensureReady()) {
                    return $this->json(['success' => false, 'message' => 'جدول شماره‌ها در دسترس نیست.'], 500);
                }
                return $this->json(array_merge(['success' => true],
                    (new \SeKianAfraz\VisitDiscount\Leads\LeadsRepository())->page($before)));
            },
        ]);
        register_rest_route('sekianafraz/v1', '/leads/owners', [
            'methods' => 'POST',
            'permission_callback' => function () { return current_user_can('manage_options'); },
            'callback' => function (WP_REST_Request $req) {
                if (!\SeKianAfraz\VisitDiscount\Leads\LeadsRepository::ensureReady()) {
                    return $this->json(['success' => false], 500);
                }
                $data = (array)$req->get_json_params();
                return $this->json((new \SeKianAfraz\VisitDiscount\Leads\PhoneOwnerIndex())->forLeadIds((array)($data['ids'] ?? [])));
            },
        ]);
        register_rest_route('sekianafraz/v1', '/leads/delete', [
            'methods' => 'POST',
            'permission_callback' => function () { return current_user_can('manage_options'); },
            'callback' => function (WP_REST_Request $req) {
                if (!\SeKianAfraz\VisitDiscount\Leads\LeadsRepository::ensureReady()) return $this->json(['success' => false], 500);
                $data = (array)$req->get_json_params();
                $count = (new \SeKianAfraz\VisitDiscount\Leads\LeadsRepository())->deleteIds((array)($data['ids'] ?? []));
                return $this->json(['success' => $count >= 0, 'deleted' => max(0, $count)], $count >= 0 ? 200 : 500);
            },
        ]);
        register_rest_route('sekianafraz/v1', '/banner/preview-send', [
            'methods' => 'POST',
            'permission_callback' => function () { return current_user_can('manage_options'); },
            'callback' => function (WP_REST_Request $req) {
                $input = (array)$req->get_json_params();
                $result = (new \SeKianAfraz\VisitDiscount\Banners\BannerPreviewSender())->send(
                    (array)($input['draft'] ?? []), (string)($input['phone'] ?? ''),
                    (string)($input['preview_token'] ?? '')
                );
                return $this->json($result, $result['success'] ? 200 : 422);
            },
        ]);
        register_rest_route('sekianafraz/v1', '/sms/fields', [
            'methods' => 'GET',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $p = sanitize_text_field($req->get_param('provider')) ?: 'melipayamak';
                $fields = SmsService::providerFields($p);
                return $this->json(['success' => true, 'fields' => $fields]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sms/save', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $data = (array)$req->get_json_params();
                $provider = sanitize_key((string)($data['provider'] ?? ''));
                if (!in_array($provider, ['melipayamak','kavenegar','ippanel','smsir','smslogin'], true)) {
                    return $this->json(['success' => false, 'message' => 'درگاه پیامک نامعتبر است.'], 422);
                }
                $config = $this->sanitizeConfig($provider, (array)($data['config'] ?? []));
                if (!CredentialsVault::save($provider, $config)) {
                    return $this->json(['success' => false, 'message' => 'ذخیره امن اطلاعات پنل پیامک انجام نشد.'], 500);
                }
                return $this->json(['success' => true]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sms/test', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $settings = CredentialsVault::load();
                $res = SmsService::test($settings);
                return $this->json(array_merge(['success' => $res['success']], $res));
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sms/test_promo', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $phone = PhoneNormalizer::mobile((string)$req->get_param('phone'));
                if ($phone === '') return $this->json(['success' => false, 'message' => 'شماره وارد نشده است'], 422);
                $settings = CredentialsVault::load();
                $provider = sanitize_text_field($settings['provider'] ?? 'melipayamak');
                $config = (array)($settings['config'] ?? []);
                $gateway = SmsService::gateway($provider);
                if (!$gateway) return $this->json(['success' => false, 'message' => 'درگاه نامعتبر'], 422);
                $resp = $gateway->sendText($config, [$phone], 'تبریک؛ وب‌سرویس تبلیغاتی به‌خوبی کار می‌کند.', $config['sender'] ?? null);
                return $this->json([
                    'success' => (bool)($resp['success'] ?? false),
                    'provider' => $provider,
                    'message' => !empty($resp['success'])
                        ? 'ارسال انجام شد.'
                        : (string)($resp['error'] ?? $resp['message'] ?? 'ارسال انجام نشد.'),
                ]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sms/test_pattern', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $phone = PhoneNormalizer::mobile((string)$req->get_param('phone'));
                $template = sanitize_text_field($req->get_param('template'));
                if ($phone === '' || $template === '') return $this->json(['success' => false, 'message' => 'شماره یا کد پترن وارد نشده است'], 422);
                $settings = CredentialsVault::load();
                $provider = sanitize_text_field($settings['provider'] ?? 'melipayamak');
                $config = (array)($settings['config'] ?? []);
                $gateway = SmsService::gateway($provider);
                if (!$gateway) return $this->json(['success' => false, 'message' => 'درگاه نامعتبر'], 422);
                $tokens = SmsService::buildPatternTokens($provider, ['تبریک', 'ارسال وب‌سرویس خدماتی (پترن) موفق']);
                $resp = $gateway->sendPattern($config, $phone, $tokens, $template);
                return $this->json([
                    'success' => (bool)($resp['success'] ?? false),
                    'provider' => $provider,
                    'message' => !empty($resp['success'])
                        ? 'ارسال انجام شد.'
                        : (string)($resp['error'] ?? $resp['message'] ?? 'ارسال انجام نشد.'),
                ]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/phone/resolve', [
            'methods' => 'GET',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $userId = (int)$req->get_param('user_id');
                if ($userId <= 0) return $this->json(['success' => false, 'message' => 'شناسه کاربر نامعتبر است'], 422);
                $phone = (new PhoneResolver())->resolve($userId);
                return $this->json(['success' => $phone !== '', 'phone' => $phone]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/phone/compat/add', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $payload = (array)$req->get_json_params();
                $label = $this->limitText(sanitize_text_field($payload['label'] ?? ''), 100);
                $metaKey = sanitize_key((string)($payload['meta_key'] ?? ''));
                if ($label === '' || $metaKey === '' || !preg_match('/^[a-z0-9_-]{1,191}$/', $metaKey)) {
                    return $this->json(['success' => false, 'message' => 'مقادیر وارد شده ناقص است'], 422);
                }
                $items = get_option('sekianafraz_phone_compat_custom', []);
                if (!is_array($items)) $items = [];
                if (count($items) >= 50) {
                    return $this->json(['success' => false, 'message' => 'حداکثر ۵۰ سازگاری سفارشی قابل ثبت است.'], 422);
                }
                foreach ($items as $item) {
                    if (($item['meta_key'] ?? '') === $metaKey) {
                        return $this->json(['success' => true, 'item' => $item, 'duplicate' => true]);
                    }
                }
                $new = [
                    'id' => wp_generate_uuid4(),
                    'label' => $label,
                    'meta_key' => $metaKey,
                ];
                $items[] = $new;
                update_option('sekianafraz_phone_compat_custom', $items, false);
                return $this->json(['success' => true, 'item' => $new]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/phone/compat/scan', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $lockKey = 'sekianafraz_phone_compat_scan_lock';
                $now = time();
                $existingLock = (int)get_option($lockKey, 0);
                if ($existingLock > 0 && $existingLock < ($now - 600)) {
                    delete_option($lockKey);
                    $existingLock = 0;
                }
                if ($existingLock > 0 || !add_option($lockKey, $now, '', false)) {
                    return $this->json(['success' => false, 'message' => 'شناسایی متا در حال اجراست؛ چند لحظه دیگر دوباره تلاش کنید.'], 409);
                }
                try {
                    $items = get_option('sekianafraz_phone_compat_custom', []);
                    if (!is_array($items)) $items = [];
                    $existingKeys = [];
                    foreach ($items as $item) {
                        $key = isset($item['meta_key']) && is_scalar($item['meta_key']) ? (string)$item['meta_key'] : '';
                        if ($key !== '') $existingKeys[$key] = true;
                    }
                    $capacity = max(0, 50 - count($items));
                    if ($capacity === 0) {
                        return $this->json(['success' => true, 'items' => [], 'limit_reached' => true]);
                    }
                    $resolverKeys = (new PhoneResolver())->metaKeys();
                    $excluded = array_values(array_unique(array_merge($resolverKeys, array_keys($existingKeys))));
                    $scanLimit = min(200, max(50, $capacity * 4));
                    $keys = (new PhoneMetaDiscovery())->discover($excluded, $scanLimit);
                    $latestItems = get_option('sekianafraz_phone_compat_custom', []);
                    if (is_array($latestItems)) $items = $latestItems;
                    $existingKeys = [];
                    foreach ($items as $item) {
                        $key = isset($item['meta_key']) && is_scalar($item['meta_key']) ? (string)$item['meta_key'] : '';
                        if ($key !== '') $existingKeys[$key] = true;
                    }
                    $capacity = max(0, 50 - count($items));
                    $added = [];
                    foreach ($keys as $metaKey) {
                        if (count($added) >= $capacity) break;
                        if (isset($existingKeys[$metaKey])) continue;
                        $new = [
                            'id' => wp_generate_uuid4(),
                            'label' => $metaKey,
                            'meta_key' => $metaKey,
                        ];
                        $items[] = $new;
                        $added[] = $new;
                        $existingKeys[$metaKey] = true;
                    }
                    if ($added) {
                        update_option('sekianafraz_phone_compat_custom', $items, false);
                    }
                    return $this->json([
                        'success' => true,
                        'items' => $added,
                        'limit_reached' => count($items) >= 50,
                    ]);
                } catch (\Throwable $e) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        error_log('[SeKianAfraz] Phone meta discovery failed: ' . $e->getMessage());
                    }
                    return $this->json(['success' => false, 'message' => 'اسکن متای شماره تلفن کاربران انجام نشد.'], 500);
                } finally {
                    delete_option($lockKey);
                }
            }
        ]);
        register_rest_route('sekianafraz/v1', '/phone/compat/remove', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $id = sanitize_text_field((string)$req->get_param('id'));
                if ($id === '') return $this->json(['success' => false, 'message' => 'شناسه نامعتبر است'], 422);
                $items = get_option('sekianafraz_phone_compat_custom', []);
                if (!is_array($items)) $items = [];
                $items = array_values(array_filter($items, function($item) use ($id) {
                    return ($item['id'] ?? '') !== $id;
                }));
                update_option('sekianafraz_phone_compat_custom', $items, false);
                return $this->json(['success' => true]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/labels', [
            'methods' => 'GET',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $placement = sanitize_text_field($req->get_param('placement'));
                $idsParam = (string)$req->get_param('ids');
                $ids = array_values(array_unique(array_filter(array_map('trim', explode(',', $idsParam)))));
                if (empty($ids)) return $this->json(['success' => true, 'items' => []]);
                $labelMap = [];
                if (in_array($placement, ['product_single', 'post_single', 'page'], true)) {
                    $types = 'any';
                    if ($placement === 'product_single') $types = 'product';
                    elseif ($placement === 'post_single') $types = 'post';
                    elseif ($placement === 'page') $types = 'page';
                    $numericIds = array_filter($ids, 'ctype_digit');
                    if (!empty($numericIds)) {
                        $posts = get_posts([
                            'post_type' => $types,
                            'include' => $numericIds,
                            'numberposts' => -1,
                            'post_status' => 'any',
                        ]);
                        foreach ($posts as $p) {
                            $labelMap[$p->ID] = $p->post_title;
                        }
                    }
                } elseif (in_array($placement, ['product_cat', 'product_tag', 'product_in_cat', 'product_in_tag', 'post_cat', 'post_tag', 'post_in_cat', 'post_in_tag'], true)) {
                    $tax = '';
                    if ($placement === 'product_cat' || $placement === 'product_in_cat') $tax = 'product_cat';
                    elseif ($placement === 'product_tag' || $placement === 'product_in_tag') $tax = 'product_tag';
                    elseif ($placement === 'post_cat' || $placement === 'post_in_cat') $tax = 'category';
                    elseif ($placement === 'post_tag' || $placement === 'post_in_tag') $tax = 'post_tag';
                    $numericIds = array_filter($ids, 'ctype_digit');
                    if ($tax && !empty($numericIds)) {
                        $terms = get_terms([
                            'taxonomy' => $tax,
                            'include' => $numericIds,
                            'hide_empty' => false,
                        ]);
                        if (!is_wp_error($terms)) {
                            foreach ($terms as $t) {
                                $labelMap[$t->term_id] = $t->name;
                            }
                        }
                    }
                }
                $out = [];
                foreach ($ids as $id) {
                    $label = (string)$id;
                    if (isset($labelMap[$id])) {
                        $label = $labelMap[$id];
                    } elseif (ctype_digit((string)$id)) {
                    }
                    $out[] = ['id' => $id, 'label' => $label];
                }
                return $this->json(['success' => true, 'items' => $out]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sensors/list', [
            'methods' => 'GET',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $page = max(1, (int)$req->get_param('page'));
                $perPage = max(1, min(100, (int)$req->get_param('per_page') ?: 20));
                $res = (new SensorService())->listPaged($page, $perPage);
                return $this->json(['success' => true, 'items' => $res['items'], 'has_more' => $res['has_more']]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sensors/get', [
            'methods' => 'GET',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $id = (int)$req->get_param('id');
                $item = (new SensorService())->get($id);
                return $this->json(['success' => !empty($item), 'item' => $item]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sensors/exclusions', [
            'methods' => 'GET',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $id = (int)$req->get_param('id');
                $page = max(1, (int)$req->get_param('page'));
                $perPage = max(1, min(50, (int)$req->get_param('per_page') ?: 20));
                return $this->json(array_merge(
                    ['success' => true],
                    (new SensorCoverageService())->getExclusions($id, $page, $perPage)
                ));
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sensors/conflict-items', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $payload = (array)$req->get_json_params();
                $placement = sanitize_key((string)($payload['placement'] ?? ''));
                $items = (array)($payload['items'] ?? []);
                $sensorId = (int)($payload['id'] ?? 0);
                $conflictingId = (int)($payload['conflict_sensor_id'] ?? 0);
                $page = max(1, (int)($payload['page'] ?? 1));
                $perPage = max(1, min(50, (int)($payload['per_page'] ?? 20)));
                $result = (new SensorCoverageService())->listConflictItems(
                    $placement,
                    $items,
                    $sensorId,
                    $conflictingId,
                    $page,
                    $perPage
                );
                return $this->json(array_merge(['success' => true], $result));
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sensors/save', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $payload = (array)$req->get_json_params();
                if (($payload['coupon_strategy'] ?? '') === 'fixed') {
                    $code = is_scalar($payload['fixed_code'] ?? null) ? (string)$payload['fixed_code'] : '';
                    if ($code === '' || !wc_get_coupon_id_by_code($code)) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'fixed_code', 'message' => 'کد تخفیف واردشده در ووکامرس وجود ندارد.'], 422);
                    }
                    $fixedCoupon = new \WC_Coupon($code);
                    $payload['coupon_amount'] = (float)$fixedCoupon->get_amount();
                    $payload['coupon_mode'] = $fixedCoupon->get_discount_type() === 'percent' ? 'percent' : 'fixed';
                    $payload['coupon_type'] = 'mixed';
                }
                foreach ($payload as $key => $value) {
                    if (is_array($value) && !in_array($key, ['items','coupon_limit_ids','logged_banner','multi_colors','banner_border_radii','banner_paddings','banner_margins','reminder_border_radii','reminder_colors','reminder_styles'], true)) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => $key], 422);
                    }
                }
                foreach (['coupon_strategy' => ['individual','fixed','virtual'], 'coupon_mode' => ['fixed','percent'], 'coupon_type' => ['numbers','letters','mixed','custom'], 'window' => ['24h','72h','1w']] as $field => $allowed) {
                    if (isset($payload[$field]) && !in_array($payload[$field], $allowed, true)) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => $field], 422);
                    }
                }
                foreach (['min_views' => 65535, 'min_duration' => 604800, 'coupon_usage_limit' => 65535, 'coupon_valid_hours' => 8760, 'coupon_custom_length' => 64] as $field => $maximum) {
                    if (isset($payload[$field]) && (!is_scalar($payload[$field]) || (float)$payload[$field] > $maximum || (float)$payload[$field] < 0)) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => $field], 422);
                    }
                }
                $amount = $payload['coupon_amount'] ?? null;
                if (($payload['coupon_strategy'] ?? '') !== 'fixed' && (!is_numeric($amount) || !is_finite((float)$amount) || (float)$amount < 1 || (float)$amount > (($payload['coupon_mode'] ?? '') === 'percent' ? 100 : 9999999999.99))) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'coupon_amount'], 422);
                }
                foreach (['coupon_custom_prefix','coupon_custom_suffix'] as $field) {
                    if (strlen((string)($payload[$field] ?? '')) > 32) return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => $field], 422);
                }
                if (strlen((string)($payload['fixed_code'] ?? '')) > 191 || count((array)($payload['items'] ?? [])) > 2000 || count((array)($payload['coupon_limit_ids'] ?? [])) > 2000) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'message' => 'طول کد یا تعداد موارد انتخابی بیش از حد مجاز است.'], 422);
                }
                if (!empty($payload['coupon_limit_enabled'])) {
                    $limitType = sanitize_key((string)($payload['coupon_limit_type'] ?? ''));
                    $limitIds = array_values(array_unique(array_filter(array_map('intval', (array)($payload['coupon_limit_ids'] ?? [])))));
                    if (!in_array($limitType, ['product', 'category'], true) || empty($limitIds)) {
                        return $this->json([
                            'success' => false,
                            'code' => 'VALIDATION',
                            'field' => 'coupon_limit_ids',
                            'message' => 'برای محدودسازی کد تخفیف حداقل یک محصول یا دسته‌بندی انتخاب کنید.',
                        ], 422);
                    }
                    $payload['coupon_limit_type'] = $limitType;
                    $payload['coupon_limit_ids'] = $limitIds;
                } else {
                    $payload['coupon_limit_enabled'] = false;
                    $payload['coupon_limit_type'] = '';
                    $payload['coupon_limit_ids'] = [];
                }
                foreach (['min_views' => 3, 'min_duration' => 120] as $field => $default) {
                    if (!isset($payload[$field]) || (is_string($payload[$field]) && trim($payload[$field]) === '')) {
                        $payload[$field] = $default;
                    }
                }
                $required = ['name','placement','items','visit_metric','visit_calculation','window','coupon_type','coupon_amount','coupon_mode','action'];
                foreach ($required as $k) {
                    if (!isset($payload[$k]) || $payload[$k] === '' || $payload[$k] === [] || $payload[$k] === null) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => $k], 422);
                    }
                }
                $placement = sanitize_key((string)($payload['placement'] ?? ''));
                $allowedPlacements = [
                    'product_single','product_cat','product_tag','product_in_cat','product_in_tag',
                    'post_single','post_cat','post_tag','post_in_cat','post_in_tag',
                    'page','custom_url','search_terms'
                ];
                if (!in_array($placement, $allowedPlacements, true)) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'placement'], 422);
                }
                $payload['placement'] = $placement;
                $sensorService = new SensorService();
                $action = sanitize_key((string)($payload['action'] ?? ''));
                if (!in_array($action, ['banner', 'sms', 'both'], true)) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'action'], 422);
                }
                $payload['action'] = $action;
                $metric = (string)($payload['visit_metric'] ?? 'views');
                if (!in_array($metric, ['views', 'duration', 'both'], true)) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'visit_metric'], 422);
                }
                if (($metric === 'views' || $metric === 'both') && (int)($payload['min_views'] ?? 0) <= 0) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'min_views'], 422);
                }
                if (($metric === 'duration' || $metric === 'both') && (int)($payload['min_duration'] ?? 0) <= 0) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'min_duration'], 422);
                }
                $visitCondition = sanitize_key((string)($payload['visit_condition'] ?? 'or'));
                if (!in_array($visitCondition, ['or', 'and'], true)) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'visit_condition'], 422);
                }
                $payload['visit_condition'] = $visitCondition;
                $minViews = (int)$payload['min_views'];
                $shortVisit = (int)$payload['min_duration'] < 10;
                $fixedOnly = ($metric === 'views' && $minViews === 1)
                    || ($metric === 'duration' && $shortVisit)
                    || ($metric === 'both' && ($visitCondition === 'or' ? ($minViews === 1 || $shortVisit) : ($minViews === 1 && $shortVisit)));
                if ($fixedOnly && ($payload['coupon_strategy'] ?? 'individual') !== 'fixed') {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'coupon_strategy',
                        'message' => 'با این مقادیر بازدید، فقط استفاده از یک کوپن ثابت برای همه کاربران مجاز است.'], 422);
                }
                $items = $sensorService->normalizeItemsForPlacement($placement, (array)($payload['items'] ?? []));
                if (empty($items)) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'items'], 422);
                }
                $allCapable = ['product_single','product_cat','product_tag','post_single','post_cat','post_tag','page'];
                $isAll = in_array('*', $items, true);
                if ($isAll && (!in_array($placement, $allCapable, true) || count($items) !== 1)) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'items'], 422);
                }
                $visitCalculation = (string)($payload['visit_calculation'] ?? 'individual');
                if (!in_array($visitCalculation, ['individual', 'aggregate'], true)) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'visit_calculation'], 422);
                }
                $groupPlacements = ['product_in_cat','product_in_tag','post_in_cat','post_in_tag'];
                if (in_array($placement, $groupPlacements, true) && (count($items) !== 1 || $isAll)) {
                    return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'items'], 422);
                }
                if (!$isAll && count($items) <= 1 && !in_array($placement, $groupPlacements, true)) $visitCalculation = 'individual';
                $payload['items'] = $items;
                $payload['visit_calculation'] = $visitCalculation;
                $couponType = (string)($payload['coupon_type'] ?? '');
                if ($couponType === 'custom') {
                    $prefix = (string)($payload['coupon_custom_prefix'] ?? '');
                    $suffix = (string)($payload['coupon_custom_suffix'] ?? '');
                    $lenRaw = (string)($payload['coupon_custom_length'] ?? '');
                    $lenRaw = $this->normalizeDigits($lenRaw);
                    $len = (int)$lenRaw;
                    $prefix = $this->normalizeDigits($prefix);
                    $suffix = $this->normalizeDigits($suffix);
                    $mid = sanitize_key((string)($payload['coupon_custom_mid_pattern'] ?? 'mixed'));
                    if ($mid === '') $mid = 'mixed';
                    if (!in_array($mid, ['numbers','letters','mixed'], true)) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'coupon_custom_mid_pattern'], 422);
                    }
                    if ($len < 3) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'coupon_custom_length'], 422);
                    }
                    if (!preg_match('/^[A-Za-z0-9_]*$/', $prefix)) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'coupon_custom_prefix'], 422);
                    }
                    if (!preg_match('/^[A-Za-z0-9_]*$/', $suffix)) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'coupon_custom_suffix'], 422);
                    }
                    $payload['coupon_custom_prefix'] = $prefix;
                    $payload['coupon_custom_suffix'] = $suffix;
                    $payload['coupon_custom_length'] = $len;
                    $payload['coupon_custom_mid_pattern'] = $mid;
                }
                if (($payload['banner_type'] ?? '') === 'multi' && !in_array($payload['logged_behavior'] ?? 'single_sms', ['single', 'single_sms'], true)) $payload['reminder_enabled'] = false;
                foreach (['sms_', 'logged_sms_'] as $delayPrefix) {
                    if (($payload[$delayPrefix . 'delay_type'] ?? '') !== 'delayed') continue;
                    $delayMinutes = filter_var($payload[$delayPrefix . 'delay_minutes'] ?? null, FILTER_VALIDATE_INT);
                    if ($delayMinutes === false || $delayMinutes < 1 || $delayMinutes > 1440) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => $delayPrefix . 'delay_minutes',
                            'message' => 'مدت زمان تأخیر باید بین 1 و 1440 دقیقه باشد.'], 422);
                    }
                    $payload[$delayPrefix . 'delay_minutes'] = $delayMinutes;
                }
if (isset($payload['coupon_valid_hours']) && (int)$payload['coupon_valid_hours'] <= 0) {
                    $payload['coupon_valid_hours'] = 72;
                }
                $multi = in_array($payload['action'], ['banner', 'both'], true) && ($payload['banner_type'] ?? '') === 'multi';
                if ($multi) {
                    if (($payload['coupon_strategy'] ?? 'individual') === 'none') {
                        return $this->json(['success' => false, 'code' => 'COUPON_REQUIRED',
                            'field' => 'coupon_strategy', 'message' => 'بنر چندمرحله‌ای باید کد تخفیف داشته باشد.'], 422);
                    }
                    if (!get_option('sekianafraz_banner_sessions_ready')) {
                        if (!\SeKianAfraz\VisitDiscount\Database\Schema::createBannerSessionsTable()) {
                            return $this->json(['success' => false, 'code' => 'SESSION_TABLE_UNAVAILABLE'], 500);
                        }
                        update_option('sekianafraz_banner_sessions_ready', 1, false);
                    }
                    if (!\SeKianAfraz\VisitDiscount\Leads\LeadsRepository::ensureReady()) {
                        return $this->json(['success' => false, 'code' => 'LEADS_TABLE_UNAVAILABLE'], 500);
                    }
                    $behavior = (string)($payload['logged_behavior'] ?? 'single_sms');
                    if (!in_array($behavior, ['none','single','sms','single_sms'], true)) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'logged_behavior'], 422);
                    }
                    if (in_array($behavior, ['single','single_sms'], true) &&
                        empty(((array)($payload['logged_banner'] ?? []))['banner_text'])) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'logged_banner'], 422);
                    }
                    if (in_array($behavior, ['sms','single_sms'], true)) {
                        $loggedMode = (string)($payload['logged_sms_mode'] ?? '');
                        if (!in_array($loggedMode, ['promo','pattern'], true) ||
                            empty($payload[$loggedMode === 'pattern' ? 'logged_sms_pattern' : 'logged_sms_text'])) {
                            return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'logged_sms_mode'], 422);
                        }
                    }
                    $payload['sms_delay_type'] = 'immediate';
                    $payload['sms_delay_minutes'] = 0;
                    $payload['hide_banner_for_logged_in'] = false;
                    if (preg_match('/\{\{(?:coupon_code|coupon_expiry_time)\}\}/', (string)($payload['banner_text'] ?? ''))) {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'banner_text'], 422);
                    }
                }
                if ($payload['action'] === 'sms' || $payload['action'] === 'both' || $multi) {
                    $mode = $payload['sms_mode'] ?? '';
                    if ($mode !== 'promo' && $mode !== 'pattern') return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'sms_mode'], 422);
                    if ($mode === 'promo' && empty($payload['sms_text'])) return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'sms_text'], 422);
                    if ($mode === 'pattern' && empty($payload['sms_pattern'])) return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'sms_pattern'], 422);
                    if ($multi && ($mode === 'promo'
                        ? strpos((string)($payload['sms_text'] ?? ''), '{{coupon_code}}') === false
                        : !preg_match('/(?:^|\R)\s*\{\{coupon_code\}\}\s*(?=$|\R)/', (string)($payload['sms_pattern'] ?? '')))) {
                        return $this->json(['success' => false, 'code' => 'COUPON_VARIABLE_REQUIRED',
                            'field' => $mode === 'promo' ? 'sms_text' : 'sms_pattern',
                            'message' => 'متغیر {{coupon_code}} را در پیامک بنر چندمرحله‌ای قرار دهید.'], 422);
                    }
                }
                if ($payload['action'] === 'banner' || $payload['action'] === 'both') {
                     if (empty($payload['banner_text'])) return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'banner_text'], 422);
                }
                if (in_array($payload['action'], ['banner', 'both'], true)) {
                    if (!$multi && !filter_var($payload['banner_button_closes'] ?? true, FILTER_VALIDATE_BOOLEAN) && trim((string)($payload['banner_target_url'] ?? '')) === '') {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'banner_target_url'], 422);
                    }
                    $loggedBanner = (array)($payload['logged_banner'] ?? []);
                    if ($multi && in_array($payload['logged_behavior'] ?? '', ['single', 'single_sms'], true) &&
                        !filter_var($loggedBanner['banner_button_closes'] ?? true, FILTER_VALIDATE_BOOLEAN) && trim((string)($loggedBanner['banner_target_url'] ?? '')) === '') {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'logged_banner'], 422);
                    }
                }
                foreach (['sms' => in_array($payload['action'], ['sms', 'both'], true) || $multi,
                    'logged_sms' => $multi && in_array($payload['logged_behavior'] ?? '', ['sms', 'single_sms'], true)] as $branch => $enabled) {
                    if (!$enabled) continue;
                    $mode = ($payload[$branch . '_mode'] ?? '') === 'pattern' ? 'pattern' : 'promo';
                    $template = (string)($payload[$branch . ($mode === 'pattern' ? '_pattern' : '_text')] ?? '');
                    if ($visitCalculation === 'aggregate' && strpos($template, '{{target_url}}') !== false && trim((string)($payload[$branch . '_target_url'] ?? '')) === '') {
                        return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => $branch . '_target_url'], 422);
                    }
                }
                if ($visitCalculation === 'aggregate') {
                    $locationVars = [
                        'product_single' => 'product_name',
                        'product_in_cat' => 'product_name',
                        'product_in_tag' => 'product_name',
                        'product_cat' => 'category_name',
                        'product_tag' => 'product_tag_name',
                        'post_single' => 'post_name',
                        'post_in_cat' => 'post_name',
                        'post_in_tag' => 'post_name',
                        'post_cat' => 'post_category_name',
                        'post_tag' => 'post_tag_name',
                        'page' => 'page_name',
                        'search_terms' => 'search_term',
                    ];
                    $locationVar = $locationVars[$placement] ?? '';
                    if ($locationVar !== '') {
                        $token = '{{' . $locationVar . '}}';
                        foreach (['banner_text', 'sms_text', 'sms_pattern', 'logged_sms_text', 'logged_sms_pattern'] as $textField) {
                            if (strpos((string)($payload[$textField] ?? ''), $token) !== false) {
                                return $this->json([
                                    'success' => false,
                                    'code' => 'AGGREGATE_LOCATION_VARIABLE',
                                    'field' => $textField,
                                    'message' => 'متغیر مکان در حالت محاسبه تجمیعی قابل استفاده نیست.',
                                ], 422);
                            }
                        }
                        if (strpos((string)(((array)($payload['logged_banner'] ?? []))['banner_text'] ?? ''), $token) !== false) {
                            return $this->json(['success' => false, 'code' => 'AGGREGATE_LOCATION_VARIABLE', 'field' => 'logged_banner'], 422);
                        }
                    }
                }
                if (isset($payload['coupon_strategy']) && $payload['coupon_strategy'] === 'fixed') {
                    if (empty($payload['fixed_code'])) return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'fixed_code'], 422);
                    if (!wc_get_coupon_id_by_code((string)$payload['fixed_code'])) return $this->json(['success' => false, 'code' => 'VALIDATION', 'field' => 'fixed_code', 'message' => 'کد تخفیف واردشده در ووکامرس وجود ندارد.'], 422);
                    $payload['coupon_free_shipping'] = false;
                    $payload['coupon_limit_enabled'] = false;
                }
                if (($payload['coupon_strategy'] ?? 'individual') !== 'fixed') {
                    $hours = max(1, (int)($payload['coupon_valid_hours'] ?? 72));
                    foreach (['sms', 'logged_sms'] as $branch) {
                        $enabled = $branch === 'sms' ? in_array($payload['action'], ['sms','both'], true) : ($multi && in_array($payload['logged_behavior'] ?? '', ['sms','single_sms'], true));
                        if ($enabled && ($payload[$branch . '_delay_type'] ?? '') === 'delayed' && (int)($payload[$branch . '_delay_minutes'] ?? 0) >= $hours * 60) {
                            return $this->json(['success' => false, 'code' => 'COUPON_EXPIRES_BEFORE_SMS', 'field' => 'coupon_valid_hours', 'message' => 'اعتبار کد تخفیف باید از تأخیر ارسال پیامک بیشتر باشد.'], 422);
                        }
                    }
                }
                $editingId = isset($payload['id']) ? (int)$payload['id'] : 0;
                $resultingStatus = $editingId > 0 ? (get_post_status($editingId) ?: 'publish') : 'publish';
                if (isset($payload['status']) && in_array((string)$payload['status'], ['publish', 'draft'], true)) {
                    $resultingStatus = (string)$payload['status'];
                }
                if (($payload['action'] ?? '') !== 'both') $payload['hide_banner_for_logged_in'] = false;
                $coverageService = new SensorCoverageService();
                if (!$coverageService->acquireWriteLock()) {
                    return $this->json(['success' => false, 'code' => 'SENSOR_WRITE_BUSY', 'message' => 'عملیات دیگری روی سنسورها در حال انجام است.'], 409);
                }
                $transactionOpen = false;
                $changedIds = [$editingId];
                try {
                    $analysis = $this->sensorConflictAnalysis($coverageService, $sensorService, $placement, $items, $editingId, $resultingStatus);
                    $resolution = sanitize_key((string)($payload['conflict_resolution'] ?? ''));
                    if (!empty($analysis['has_conflict'])) {
                        if ($resolution === '') return $this->json($this->conflictPayload($analysis, $placement, $items, $editingId), 409);
                        if ($resolution === 'smart' && empty($analysis['smart_allowed'])) {
                            $blocked = $this->conflictPayload($analysis, $placement, $items, $editingId);
                            $blocked['message'] = 'استثناسازی پوشش مؤثر یکی از سنسورها را صفر می‌کند.';
                            return $this->json($blocked, 409);
                        }
                        if (!in_array($resolution, ['smart', 'deactivate'], true)) {
                            return $this->json(['success' => false, 'code' => 'INVALID_CONFLICT_RESOLUTION'], 422);
                        }
                    }
                    if ($resultingStatus === 'publish' && $coverageService->supportsPlacement($placement)
                        && (int)($analysis['remaining_count'] ?? 0) <= 0
                        && (empty($analysis['has_conflict']) || $resolution !== 'deactivate')) {
                        return $this->json(['success' => false, 'code' => 'NO_EFFECTIVE_LOCATIONS', 'message' => 'این سنسور پس از اعمال مکان‌ها هیچ صفحهٔ مؤثری نخواهد داشت.'], 422);
                    }
                    if (!$coverageService->beginWriteTransaction()) {
                        return $this->json(['success' => false, 'code' => 'SENSOR_TRANSACTION_FAILED'], 500);
                    }
                    $transactionOpen = true;
                    $id = $sensorService->save($payload, $editingId ?: null);
                    if ($id <= 0) return $this->json(['success' => false, 'code' => 'SAVE_FAILED'], 500);
                    $changedIds[] = $id;
                    if (!empty($analysis['has_conflict']) && $resolution === 'deactivate') {
                        foreach ((array)$analysis['conflicts'] as $conflict) {
                            $conflictingId = (int)($conflict['sensor_id'] ?? 0);
                            $changedIds[] = $conflictingId;
                            if ($conflictingId > 0 && !$sensorService->updateStatus($conflictingId, 'draft')) {
                                return $this->json(['success' => false, 'code' => 'DEACTIVATION_FAILED'], 500);
                            }
                        }
                        $coverageService->syncSensor($id);
                    }
                    if ($coverageService->supportsPlacement($placement)) {
                        $disabled = $coverageService->deactivateEmptyActiveSensors($coverageService->contextForPlacement($placement));
                        $changedIds = array_merge($changedIds, $disabled);
                        if (in_array($id, $disabled, true)) {
                            return $this->json(['success' => false, 'code' => 'NO_EFFECTIVE_LOCATIONS'], 409);
                        }
                    }
                    if (!$coverageService->commitWriteTransaction()) {
                        return $this->json(['success' => false, 'code' => 'SENSOR_TRANSACTION_FAILED'], 500);
                    }
                    $transactionOpen = false;
                    return $this->json(['success' => true, 'id' => $id]);
                } catch (\Throwable $error) {
                    return $this->json(['success' => false, 'code' => 'SAVE_FAILED', 'message' => 'ذخیره سنسور کامل نشد.'], 500);
                } finally {
                    if ($transactionOpen) {
                        $coverageService->rollbackWriteTransaction();
                        $changedIds[] = $sensorService->lastWrittenSensorId();
                        foreach (array_unique(array_filter(array_map('intval', $changedIds))) as $changedId) clean_post_cache($changedId);
                    }
                    $coverageService->releaseWriteLock();
                }
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sensors/delete', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $id = (int)$req->get_param('id');
                $coverage = new SensorCoverageService();
                if (!$coverage->acquireWriteLock()) {
                    return $this->json(['success' => false, 'code' => 'SENSOR_WRITE_BUSY', 'message' => 'عملیات دیگری روی سنسورها در حال انجام است.'], 409);
                }
                try {
                    $ok = (new SensorService())->delete($id);
                    return $this->json(['success' => $ok]);
                } finally {
                    $coverage->releaseWriteLock();
                }
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sensors/status', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $id = (int)$req->get_param('id');
                $status = sanitize_text_field((string)$req->get_param('status'));
                $sensorService = new SensorService();
                $coverageService = new SensorCoverageService();
                if (!$coverageService->acquireWriteLock()) {
                    return $this->json(['success' => false, 'code' => 'SENSOR_WRITE_BUSY', 'message' => 'عملیات دیگری روی سنسورها در حال انجام است.'], 409);
                }
                $transactionOpen = false;
                $changedIds = [$id];
                try {
                    $analysis = $this->emptyConflictAnalysis();
                    if ($status === 'publish') {
                        $sensor = $sensorService->get($id);
                        if (empty($sensor)) return $this->json(['success' => false, 'code' => 'INVALID_SENSOR'], 404);
                        $analysis = $this->sensorConflictAnalysis(
                            $coverageService,
                            $sensorService,
                            (string)($sensor['placement'] ?? ''),
                            (array)($sensor['items'] ?? []),
                            $id,
                            'publish'
                        );
                        $resolution = sanitize_key((string)$req->get_param('conflict_resolution'));
                        if (!empty($analysis['has_conflict'])) {
                            if ($resolution === '') return $this->json($this->conflictPayload($analysis, (string)($sensor['placement'] ?? ''), (array)($sensor['items'] ?? []), $id), 409);
                            if ($resolution === 'smart' && empty($analysis['smart_allowed'])) {
                                $blocked = $this->conflictPayload($analysis, (string)($sensor['placement'] ?? ''), (array)($sensor['items'] ?? []), $id);
                                $blocked['message'] = 'استثناسازی پوشش مؤثر یکی از سنسورها را صفر می‌کند.';
                                return $this->json($blocked, 409);
                            }
                            if (!in_array($resolution, ['smart', 'deactivate'], true)) {
                                return $this->json(['success' => false, 'code' => 'INVALID_CONFLICT_RESOLUTION'], 422);
                            }
                        }
                        if ($coverageService->supportsPlacement((string)($sensor['placement'] ?? ''))
                            && (int)($analysis['remaining_count'] ?? 0) <= 0
                            && (empty($analysis['has_conflict']) || $resolution !== 'deactivate')) {
                            return $this->json(['success' => false, 'code' => 'NO_EFFECTIVE_LOCATIONS', 'message' => 'این سنسور هیچ صفحهٔ مؤثری نخواهد داشت.'], 422);
                        }
                    }
                    if (!$coverageService->beginWriteTransaction()) {
                        return $this->json(['success' => false, 'code' => 'SENSOR_TRANSACTION_FAILED'], 500);
                    }
                    $transactionOpen = true;
                    $ok = $sensorService->updateStatus($id, $status);
                    if (!$ok) return $this->json(['success' => false, 'code' => 'STATUS_FAILED'], 500);
                    if ($status === 'publish' && !empty($analysis['has_conflict']) && sanitize_key((string)$req->get_param('conflict_resolution')) === 'deactivate') {
                        foreach ((array)$analysis['conflicts'] as $conflict) {
                            $conflictingId = (int)($conflict['sensor_id'] ?? 0);
                            $changedIds[] = $conflictingId;
                            if ($conflictingId > 0 && !$sensorService->updateStatus($conflictingId, 'draft')) {
                                return $this->json(['success' => false, 'code' => 'DEACTIVATION_FAILED'], 500);
                            }
                        }
                        $coverageService->syncSensor($id);
                    }
                    if ($status === 'publish' && $coverageService->supportsPlacement((string)($sensor['placement'] ?? ''))) {
                        $disabled = $coverageService->deactivateEmptyActiveSensors($coverageService->contextForPlacement((string)$sensor['placement']));
                        $changedIds = array_merge($changedIds, $disabled);
                        if (in_array($id, $disabled, true)) {
                            return $this->json(['success' => false, 'code' => 'NO_EFFECTIVE_LOCATIONS'], 409);
                        }
                    }
                    if (!$coverageService->commitWriteTransaction()) {
                        return $this->json(['success' => false, 'code' => 'SENSOR_TRANSACTION_FAILED'], 500);
                    }
                    $transactionOpen = false;
                    return $this->json(['success' => true]);
                } catch (\Throwable $error) {
                    return $this->json(['success' => false, 'code' => 'STATUS_FAILED', 'message' => 'تغییر وضعیت سنسور کامل نشد.'], 500);
                } finally {
                    if ($transactionOpen) {
                        $coverageService->rollbackWriteTransaction();
                        foreach (array_unique(array_filter(array_map('intval', $changedIds))) as $changedId) clean_post_cache($changedId);
                    }
                    $coverageService->releaseWriteLock();
                }
            }
        ]);
        register_rest_route('sekianafraz/v1', '/sensors/bulk', [
            'methods' => 'POST',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => function(WP_REST_Request $req) {
                $payload = (array)$req->get_json_params();
                $ids = array_map('intval', (array)($payload['ids'] ?? []));
                $ids = array_values(array_unique(array_filter($ids)));
                if (count($ids) > 100) return $this->json(['success' => false, 'code' => 'BULK_LIMIT', 'message' => 'در هر مرحله حداکثر ۱۰۰ سنسور انتخاب کنید.'], 422);
                $action = sanitize_text_field((string)($payload['action'] ?? ''));
                if (!in_array($action, ['enable', 'disable', 'delete'], true)) {
                    return $this->json(['success' => false, 'code' => 'INVALID_BULK_ACTION'], 422);
                }
                $svc = new SensorService();
                $coverage = new SensorCoverageService();
                if (!$coverage->acquireWriteLock()) {
                    return $this->json(['success' => false, 'code' => 'SENSOR_WRITE_BUSY', 'message' => 'عملیات دیگری روی سنسورها در حال انجام است.'], 409);
                }
                try {
                    if ($action === 'enable') {
                        $draftScopes = [];
                        foreach ($ids as $id) {
                            if (get_post_type($id) !== 'sekianafraz_sensor') continue;
                            $placement = sanitize_key((string)get_post_meta($id, 'placement', true));
                            $items = $svc->normalizeItemsForPlacement($placement, (array)get_post_meta($id, 'items', true));
                            if (get_post_status($id) !== 'publish') {
                                $analysis = $this->sensorConflictAnalysis($coverage, $svc, $placement, $items, $id, 'publish');
                                if (!empty($analysis['has_conflict'])) {
                                    return $this->json([
                                        'success' => false,
                                        'code' => 'BULK_CONFLICT_REQUIRES_INDIVIDUAL',
                                        'message' => 'یکی از سنسورهای انتخاب‌شده تداخل مکانی دارد؛ آن را با کلید وضعیت فعال کنید تا روش رفع تداخل را انتخاب کنید.',
                                        'sensor_id' => $id,
                                    ], 409);
                                }
                                if ($coverage->supportsPlacement($placement) && (int)($analysis['remaining_count'] ?? 0) <= 0) {
                                    return $this->json([
                                        'success' => false,
                                        'code' => 'NO_EFFECTIVE_LOCATIONS',
                                        'message' => 'یکی از سنسورهای انتخاب‌شده هیچ مکان مؤثری ندارد.',
                                        'sensor_id' => $id,
                                    ], 409);
                                }
                                $draftScopes[] = ['id' => $id, 'placement' => $placement, 'items' => $items];
                            }
                        }
                        $scopeCount = count($draftScopes);
                        for ($i = 0; $i < $scopeCount; $i++) {
                            for ($j = $i + 1; $j < $scopeCount; $j++) {
                                $a = $draftScopes[$i];
                                $b = $draftScopes[$j];
                                $numericOverlap = $coverage->scopesOverlap($a['placement'], $a['items'], $b['placement'], $b['items']);
                                $legacyOverlap = !$coverage->supportsPlacement($a['placement'])
                                    && $a['placement'] === $b['placement']
                                    && !empty(array_intersect(array_map('strval', $a['items']), array_map('strval', $b['items'])));
                                if ($numericOverlap || $legacyOverlap) {
                                    return $this->json([
                                        'success' => false,
                                        'code' => 'BULK_CONFLICT_REQUIRES_INDIVIDUAL',
                                        'message' => 'دو سنسور انتخاب‌شده با هم تداخل مکانی دارند؛ آن‌ها را جداگانه فعال کنید تا روش رفع تداخل را انتخاب کنید.',
                                        'sensor_id' => (int)$b['id'],
                                    ], 409);
                                }
                            }
                        }
                    }
                    $ok = true;
                    foreach ($ids as $id) {
                        if ($id <= 0) continue;
                        if ($action === 'enable') $ok = $svc->updateStatus($id, 'publish') && $ok;
                        elseif ($action === 'disable') $ok = $svc->updateStatus($id, 'draft') && $ok;
                        elseif ($action === 'delete') $ok = $svc->delete($id) && $ok;
                    }
                    return $this->json(['success' => $ok]);
                } finally {
                    $coverage->releaseWriteLock();
                }
            }
        ]);
        register_rest_route('sekianafraz/v1', '/page/sensors', [
            'methods' => 'POST',
            'permission_callback' => function(WP_REST_Request $req) { return $this->verifyPublicSignature($req); },
            'callback' => function(WP_REST_Request $req) {
                $ctx = $this->sanitizeContext((array)$req->get_json_params());
                $rel = (new SensorService())->findRelevantForPage($ctx);
                return $this->json(['success' => true, 'items' => $rel]);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/trigger', [
            'methods' => 'POST',
            'permission_callback' => function(WP_REST_Request $req) { return $this->verifyPublicSignature($req); },
            'callback' => function(WP_REST_Request $req) {
                $payload = (array)$req->get_json_params();
                $sensorId = (int)($payload['sensor_id'] ?? 0);
                $guestId = substr(sanitize_text_field((string)($payload['guest_id'] ?? '')), 0, 64);
                $trackingKeyRaw = is_scalar($payload['tracking_key'] ?? null) ? wp_unslash((string)$payload['tracking_key']) : '';
                $trackingKey = trim((string)preg_replace('/[\x00-\x1F\x7F]/u', '', $trackingKeyRaw));
                if (strlen($trackingKey) > 600) $trackingKey = '';
                $pagePath = $this->sanitizePublicPath($payload['page_path'] ?? '');
                if ($sensorId <= 0) {
                    return $this->json(['success' => false, 'code' => 'INVALID_SENSOR'], 422);
                }
                if (!is_user_logged_in()) {
                    $cookieGuest = substr(sanitize_text_field((string)($_COOKIE['sekianafraz_guest_id'] ?? '')), 0, 64);
                    if ($guestId === '' || $cookieGuest === '' || !hash_equals($cookieGuest, $guestId) ||
                        !preg_match('/^[A-Za-z0-9_-]{16,64}$/', $guestId)) {
                        return $this->json(['success' => false, 'code' => 'INVALID_GUEST'], 403);
                    }
                }
                if (!$this->consumePublicRateLimit('trigger:' . $sensorId, 60, 10 * MINUTE_IN_SECONDS)) {
                    return $this->json(['success' => false, 'code' => 'RATE_LIMITED'], 429);
                }
                if (!empty($pagePath)) $_SERVER['REQUEST_URI'] = $pagePath;
                $rawCtx = (array)($payload['ctx'] ?? []);
                if ($pagePath !== '') $rawCtx['path'] = $pagePath;
                $ctx = $this->sanitizeContext($rawCtx);
                $relevant = (new SensorService())->findRelevantForPage($ctx);
                $matchedSensor = null;
                foreach ($relevant as $candidate) {
                    if ((int)($candidate['id'] ?? 0) === $sensorId) {
                        $matchedSensor = $candidate;
                        break;
                    }
                }
                if (!is_array($matchedSensor)) {
                    return $this->json(['success' => false, 'code' => 'SENSOR_CONTEXT_MISMATCH'], 403);
                }
                $matches = array_map('strval', (array)($matchedSensor['matches'] ?? []));
                if (($matchedSensor['visit_calculation'] ?? 'individual') === 'individual') {
                    if ($trackingKey === '' || !in_array($trackingKey, $matches, true)) {
                        return $this->json(['success' => false, 'code' => 'SENSOR_ITEM_MISMATCH'], 403);
                    }
                    $ctx['matched_item'] = $trackingKey;
                }
                if (!empty($ctx)) {
                    $_REQUEST['sekianafraz_ctx'] = $ctx;
                    if (!empty($ctx['product_id'])) set_query_var('product', (int)$ctx['product_id']);
                    if (!empty($ctx['post_id'])) set_query_var('p', (int)$ctx['post_id']);
                    if (!empty($ctx['page_id'])) set_query_var('page_id', (int)$ctx['page_id']);
                    if (!empty($ctx['product_cat_ids'])) set_query_var('product_cat', (array)$ctx['product_cat_ids']);
                    if (!empty($ctx['product_tag_ids'])) set_query_var('product_tag', (array)$ctx['product_tag_ids']);
                    if (!empty($ctx['post_cat_ids'])) set_query_var('cat', (array)$ctx['post_cat_ids']);
                    if (!empty($ctx['post_tag_ids'])) set_query_var('tag_id', (array)$ctx['post_tag_ids']);
                    if (!empty($ctx['search_term'])) set_query_var('s', sanitize_text_field($ctx['search_term']));
                }
                $res = (new ActionService())->handle($sensorId, $guestId);
                return $this->json($res);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/banner/send', [
            'methods' => 'POST',
            'permission_callback' => function(WP_REST_Request $req) { return $this->verifyPublicSignature($req); },
            'callback' => function(WP_REST_Request $req) {
                $payload = (array)$req->get_json_params();
                $result = (new \SeKianAfraz\VisitDiscount\Banners\BannerSessions())->send(
                    substr(sanitize_text_field((string)($payload['send_token'] ?? '')), 0, 128),
                    substr(sanitize_text_field((string)($payload['phone'] ?? '')), 0, 40),
                    !empty($payload['correction'])
                );
                return $this->json($result, !empty($result['success']) ? 200 : 422);
            }
        ]);
        register_rest_route('sekianafraz/v1', '/search', [
            'methods' => 'GET',
            'permission_callback' => function() { return current_user_can('manage_options'); },
            'callback' => [$this, 'searchHandler']
        ]);
    }
    public function searchHandler(WP_REST_Request $req): WP_REST_Response
    {
        global $wpdb;
        $placement = sanitize_key((string)$req->get_param('placement'));
        $q = trim(preg_replace('/\s+/u', ' ', sanitize_text_field((string)$req->get_param('q'))));
        $page = min(100, max(1, (int)$req->get_param('page')));
        $perPage = 50;
        $empty = ['success' => true, 'items' => [], 'page' => $page, 'has_more' => false];
        if ($q === '' || strlen($q) > 240) return $this->json($empty);
        $postTypes = ['product_single' => 'product', 'post_single' => 'post', 'page' => 'page'];
        $taxonomies = [
            'product_cat' => ['product_cat', 'product'], 'product_in_cat' => ['product_cat', 'product'],
            'product_tag' => ['product_tag', 'product'], 'product_in_tag' => ['product_tag', 'product'],
            'post_cat' => ['category', 'post'], 'post_in_cat' => ['category', 'post'],
            'post_tag' => ['post_tag', 'post'], 'post_in_tag' => ['post_tag', 'post'],
        ];
        if (!isset($postTypes[$placement]) && !isset($taxonomies[$placement])) return $this->json($empty);
        $words = array_values(array_unique(preg_split('/\s+/u', $q, -1, PREG_SPLIT_NO_EMPTY)));
        $column = isset($postTypes[$placement]) ? 'p.post_title' : 't.name';
        $conditions = array_fill(0, count($words), $column . ' LIKE %s');
        $wordValues = array_map(static fn($word) => '%' . $wpdb->esc_like($word) . '%', $words);
        $rank = "CASE WHEN $column = %s THEN 0 WHEN $column LIKE %s THEN 1 WHEN $column LIKE %s THEN 2 ELSE 3 END";
        $rankValues = [$q, $wpdb->esc_like($q) . '%', '% ' . $wpdb->esc_like($q) . '%'];
        $offset = ($page - 1) * $perPage;
        $limit = $perPage + 1;
        if (isset($postTypes[$placement])) {
            $sql = "SELECT p.ID AS id, p.post_title AS label FROM {$wpdb->posts} p
                WHERE p.post_type = %s AND p.post_status = 'publish' AND " . implode(' AND ', $conditions) . "
                ORDER BY $rank ASC, LOCATE(%s, $column) ASC, p.post_modified_gmt DESC, p.ID DESC
                LIMIT %d OFFSET %d";
            $params = array_merge([$postTypes[$placement]], $wordValues, $rankValues, [$words[0], $limit, $offset]);
        } else {
            [$taxonomy, $relatedType] = $taxonomies[$placement];
            $recent = "(SELECT MAX(related.post_modified_gmt) FROM {$wpdb->term_relationships} relationships
                INNER JOIN {$wpdb->posts} related ON related.ID = relationships.object_id
                WHERE relationships.term_taxonomy_id = tt.term_taxonomy_id
                AND related.post_type = '$relatedType' AND related.post_status = 'publish')";
            $sql = "SELECT t.term_id AS id, t.name AS label FROM {$wpdb->terms} t
                INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = t.term_id
                WHERE tt.taxonomy = %s AND " . implode(' AND ', $conditions) . "
                ORDER BY $rank ASC, LOCATE(%s, $column) ASC, $recent DESC, t.term_id DESC
                LIMIT %d OFFSET %d";
            $params = array_merge([$taxonomy], $wordValues, $rankValues, [$words[0], $limit, $offset]);
        }
        $rows = $wpdb->get_results($wpdb->prepare($sql, $params), ARRAY_A);
        $hasMore = count((array)$rows) > $perPage;
        $items = array_map(static function($row) {
            return ['id' => (string)$row['id'], 'label' => (string)$row['label'], 'disabled' => false, 'conflict_sensor' => ''];
        }, array_slice((array)$rows, 0, $perPage));
        return $this->json(['success' => true, 'items' => $items, 'page' => $page, 'has_more' => $hasMore]);
    }
    private function sensorConflictAnalysis(
        SensorCoverageService $coverageService,
        SensorService $sensorService,
        string $placement,
        array $items,
        int $sensorId,
        string $resultingStatus
    ): array {
        if ($resultingStatus !== 'publish') return $this->emptyConflictAnalysis();
        if ($coverageService->supportsPlacement($placement)) {
            return $coverageService->analyzeConflict($placement, $items, $sensorId);
        }
        $legacy = $sensorService->findCoverageConflict($placement, $items, $sensorId);
        if (empty($legacy)) return $this->emptyConflictAnalysis();
        return [
            'has_conflict' => true,
            'candidate_count' => 1,
            'remaining_count' => 0,
            'smart_allowed' => false,
            'smart_target' => 'candidate',
            'exclude_from_candidate' => 1,
            'exclude_from_existing' => 0,
            'context_type' => '',
            'conflicts' => [[
                'sensor_id' => (int)($legacy['sensor_id'] ?? 0),
                'sensor_name' => (string)($legacy['sensor_name'] ?? ''),
                'count' => 1,
                'items' => [],
                'has_more' => false,
                'exclusion_side' => 'candidate',
            ]],
        ];
    }
    private function emptyConflictAnalysis(): array
    {
        return [
            'has_conflict' => false,
            'candidate_count' => 0,
            'remaining_count' => 0,
            'smart_allowed' => true,
            'smart_target' => 'candidate',
            'exclude_from_candidate' => 0,
            'exclude_from_existing' => 0,
            'context_type' => '',
            'conflicts' => [],
        ];
    }
    private function conflictPayload(array $analysis, string $placement = '', array $items = [], int $sensorId = 0): array
    {
        $conflicts = array_values((array)($analysis['conflicts'] ?? []));
        $first = (array)($conflicts[0] ?? []);
        return [
            'success' => false,
            'code' => 'PLACEMENT_CONFLICT',
            'title' => 'تداخل در مکان سنسورها',
            'message' => 'مکان سنسور تعیین‌شده شامل مکان‌هایی است که سنسورهای فعال دیگر پوشش می‌دهند. این هم‌پوشانی باید برطرف شود.',
            'sensor_id' => (int)($first['sensor_id'] ?? 0),
            'sensor_name' => (string)($first['sensor_name'] ?? ''),
            'conflicts' => $conflicts,
            'candidate_count' => (int)($analysis['candidate_count'] ?? 0),
            'remaining_count' => (int)($analysis['remaining_count'] ?? 0),
            'smart_allowed' => !empty($analysis['smart_allowed']),
            'smart_target' => (string)($analysis['smart_target'] ?? 'candidate'),
            'smart_label' => $this->smartExceptionLabel((string)($analysis['smart_target'] ?? 'candidate')),
            'exclude_from_candidate' => (int)($analysis['exclude_from_candidate'] ?? 0),
            'exclude_from_existing' => (int)($analysis['exclude_from_existing'] ?? 0),
            'context_type' => (string)($analysis['context_type'] ?? ''),
            'scope' => [
                'placement' => sanitize_key($placement),
                'items' => array_values(array_map('strval', $items)),
                'id' => max(0, $sensorId),
            ],
        ];
    }
    private function smartExceptionLabel(string $target): string
    {
        $suffix = $target === 'existing' ? 'سنسور قبلی' : ($target === 'mixed' ? 'سنسور قبلی و فعلی' : 'سنسور فعلی');
        return 'استثناسازی مکان(های) مشترک از ' . $suffix;
    }
    private function json(array $data, int $code = 200): WP_REST_Response
    {
        nocache_headers();
        return new WP_REST_Response($data, $code, [
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache'
        ]);
    }
    private function normalizeDigits(string $s): string
    {
        $map = [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ];
        return strtr($s, $map);
    }
    private function sanitizeConfig(string $provider, array $config): array
    {
        $allowed = [
            'melipayamak' => ['username' => 191, 'api_key' => 512, 'sender' => 64],
            'kavenegar' => ['api_key' => 512, 'sender' => 64],
            'ippanel' => ['api_key' => 512, 'sender' => 64],
            'smsir' => ['api_key' => 512, 'sender' => 64],
            'smslogin' => ['api_key' => 512, 'sender' => 64],
        ];
        $clean = [];
        foreach (($allowed[$provider] ?? []) as $key => $maxLength) {
            $value = isset($config[$key]) && is_scalar($config[$key]) ? (string)$config[$key] : '';
            $value = $key === 'api_key'
                ? trim((string)preg_replace('/[\x00-\x1F\x7F]/u', '', $value))
                : sanitize_text_field($value);
            $clean[$key] = $this->limitText($value, $maxLength);
        }
        return $clean;
    }
    private function consumePublicRateLimit(string $scope, int $limit, int $ttl): bool
    {
        $ip = substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64);
        return \SeKianAfraz\VisitDiscount\Helpers\RateLimiter::consume($scope . '|ip:' . $ip, $limit, $ttl);
    }
    private function limitText(string $value, int $length): string
    {
        return function_exists('mb_substr')
            ? mb_substr($value, 0, $length, 'UTF-8')
            : substr($value, 0, $length);
    }
    private function verifyPublicSignature(WP_REST_Request $req): bool
    {
        $payload = (array)$req->get_json_params();
        $timestamp = isset($payload['_sekianafraz_ts']) ? (int)$payload['_sekianafraz_ts'] : (int)$req->get_header('x-sekianafraz-ts');
        $signature = isset($payload['_sekianafraz_sig']) ? (string)$payload['_sekianafraz_sig'] : (string)$req->get_header('x-sekianafraz-sig');
        if ($timestamp <= 0 || $signature === '') return false;
        $ttl = (int) apply_filters('sekianafraz_public_signature_ttl_seconds', 7 * 24 * 3600);
        if ($ttl < 300) $ttl = 300;
        if (abs(time() - $timestamp) > $ttl) return false;
        $rawContext = isset($payload['ctx']) && is_array($payload['ctx']) ? $payload['ctx'] : $payload;
        $rawPath = $this->extractSignaturePath($payload);
        if ($rawPath !== '') $rawContext['path'] = $rawPath;
        $context = $this->sanitizeContext($rawContext);
        $expected = hash_hmac(
            'sha256',
            $timestamp . '|' . wp_json_encode($context),
            wp_salt('auth')
        );
        return hash_equals($expected, $signature);
    }
    private function extractSignaturePath(array $payload): string
    {
        if (!empty($payload['page_path'])) return (string)$payload['page_path'];
        if (isset($payload['ctx']) && is_array($payload['ctx']) && isset($payload['ctx']['path'])) {
            return (string)$payload['ctx']['path'];
        }
        if (isset($payload['path'])) return (string)$payload['path'];
        return '';
    }
    private function sanitizeContext(array $ctx): array
    {
        $clean = [];
        $clean['path'] = $this->sanitizePublicPath($ctx['path'] ?? '');
        $clean['search_term'] = isset($ctx['search_term']) ? sanitize_text_field((string)$ctx['search_term']) : '';
        $clean['product_id'] = isset($ctx['product_id']) ? (int)$ctx['product_id'] : 0;
        $clean['post_id'] = isset($ctx['post_id']) ? (int)$ctx['post_id'] : 0;
        $clean['page_id'] = isset($ctx['page_id']) ? (int)$ctx['page_id'] : 0;
        $clean['product_cat_ids'] = $this->normalizeIds($ctx['product_cat_ids'] ?? []);
        $clean['product_tag_ids'] = $this->normalizeIds($ctx['product_tag_ids'] ?? []);
        $clean['post_cat_ids'] = $this->normalizeIds($ctx['post_cat_ids'] ?? []);
        $clean['post_tag_ids'] = $this->normalizeIds($ctx['post_tag_ids'] ?? []);
        return $clean;
    }
    private function sanitizePublicPath($value): string
    {
        $rawPath = is_scalar($value) ? (string)$value : '';
        if ($rawPath === '') return '';
        $rawPath = wp_unslash($rawPath);
        $rawPath = preg_replace('/[\x00-\x1F\x7F]/', '', $rawPath);
        if (!is_string($rawPath) || $rawPath === '') return '';
        return Path::canonicalize($rawPath, Path::homePath());
    }
    private function normalizeIds($ids): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)$ids))));
        sort($ids, SORT_NUMERIC);
        return $ids;
    }
}
