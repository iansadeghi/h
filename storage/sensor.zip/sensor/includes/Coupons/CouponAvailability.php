<?php
namespace SeKianAfraz\VisitDiscount\Coupons;
if (!defined('ABSPATH')) { exit; }
class CouponAvailability
{
    public static function usable(string $code, int $at = 0): bool
    {
        if ($code === '') return false;
        $at = $at > 0 ? $at : time();
        $row = (new CouponRegistryRepository())->findByCode($code);
        if ($row && $row['strategy'] === 'virtual') {
            if ($row['status'] !== 'active' || (!empty($row['expires_at']) && strtotime($row['expires_at'] . ' UTC') <= $at)) return false;
            return (int)$row['usage_limit'] <= 0 || (new CouponRedemptionRepository())->countByCode($code) < (int)$row['usage_limit'];
        }
        if (!class_exists('WC_Coupon') || !wc_get_coupon_id_by_code($code)) return false;
        $coupon = new \WC_Coupon($code);
        $expiry = $coupon->get_date_expires();
        return $coupon->get_id() > 0 && (!$expiry || $expiry->getTimestamp() > $at)
            && ($coupon->get_usage_limit() <= 0 || $coupon->get_usage_count() < $coupon->get_usage_limit());
    }
}
