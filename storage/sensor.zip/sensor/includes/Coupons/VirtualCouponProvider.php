<?php
namespace SeKianAfraz\VisitDiscount\Coupons;
if (!defined('ABSPATH')) { exit; }
class VirtualCouponProvider
{
    private static ?string $lastErrorCoupon = null;
    private static ?string $lastErrorMessage = null;
    private array $productRules = [];
    public function register(): void
    {
        if (!function_exists('add_filter') || !class_exists('WooCommerce')) return;
        add_filter('woocommerce_get_shop_coupon_data', [$this, 'getShopCouponData'], 10, 2);
        add_filter('woocommerce_coupon_is_valid', [$this, 'validateCoupon'], 10, 3);
        add_filter('woocommerce_coupon_error', [$this, 'filterCouponError'], 10, 3);
        add_filter('woocommerce_coupon_is_valid_for_cart', [$this, 'validateCartScope'], 10, 2);
        add_filter('woocommerce_coupon_is_valid_for_product', [$this, 'validateProductScope'], 10, 3);
        add_action('woocommerce_checkout_order_created', [$this, 'reserveOrder'], 20);
        add_action('woocommerce_store_api_checkout_order_processed', [$this, 'reserveOrder'], 20);
        add_action('woocommerce_before_pay_action', [$this, 'reserveOrder'], 20);
        add_action('woocommerce_order_status_cancelled', [$this, 'releaseOrder'], 20);
        add_action('woocommerce_order_status_failed', [$this, 'releaseOrder'], 20);
        add_action('woocommerce_delete_order', [$this, 'releaseOrder'], 20);
        add_action('woocommerce_trash_order', [$this, 'releaseOrder'], 20);
        add_action('woocommerce_payment_complete', [$this, 'onOrderSettled'], 10, 1);
        add_action('woocommerce_order_status_processing', [$this, 'onOrderSettled'], 10, 1);
        add_action('woocommerce_order_status_completed', [$this, 'onOrderSettled'], 10, 1);
    }
    public function getShopCouponData($data, string $code)
    {
        if (!empty($data)) return $data;
        $row = (new CouponRegistryRepository())->findByCode($code);
        if (!is_array($row)) return $data;
        if (($row['strategy'] ?? '') !== 'virtual') return $data;
        if (($row['status'] ?? '') !== 'active') return $data;
        if ($this->isExpired($row)) return $data;
        if (!$this->isOwner($row)) return $data;
        $expiresTs = $this->expiresTimestamp($row);
        return [
            'id' => 0,
            'code' => $code,
            'discount_type' => ($row['discount_type'] ?? 'fixed_cart') ?: 'fixed_cart',
            'amount' => (float)($row['amount'] ?? 0),
            'individual_use' => true,
            'product_ids' => ($row['limit_type'] ?? '') === 'product' ? $this->decodeLimitIds($row['limit_ids']) : [],
            'product_categories' => ($row['limit_type'] ?? '') === 'category' ? $this->decodeLimitIds($row['limit_ids']) : [],
            'free_shipping' => !empty($row['free_shipping']),
            'usage_limit' => (int)($row['usage_limit'] ?? 0),
            'date_expires' => $expiresTs > 0 ? $expiresTs : null,
        ];
    }
    public function validateCoupon(bool $valid, $coupon, $discounts = null): bool
    {
        if (!is_object($coupon) || !method_exists($coupon, 'get_code')) return $valid;
        $code = (string)$coupon->get_code();
        if ($code === '') return $valid;
        $row = (new CouponRegistryRepository())->findByCode($code);
        if (!is_array($row)) {
            if (method_exists($coupon, 'get_meta') && $coupon->get_meta('_generated_by', true) === 'sekianafraz') {
                return $this->fail($code, 'اطلاعات اعتبار این کد تخفیف در دسترس نیست.');
            }
            return $valid;
        }
        if (!in_array(($row['strategy'] ?? ''), ['virtual', 'wp_post'], true)) return $valid;
        if (($row['status'] ?? '') !== 'active') {
            return $this->fail($code, 'این کد تخفیف دیگر معتبر نیست.');
        }
        if ($this->isExpired($row)) {
            return $this->fail($code, 'این کد تخفیف منقضی شده است.');
        }
        if (!$this->isOwner($row)) {
            return $this->fail($code, 'این کد تخفیف برای حساب/کاربر فعلی معتبر نیست.');
        }
        $usageLimit = (int)($row['usage_limit'] ?? 0);
        if ($usageLimit > 0) {
            $awaiting = function_exists('WC') && WC()->session ? (int)(WC()->session->get('order_awaiting_payment') ?: WC()->session->get('store_api_draft_order')) : 0;
            if (is_object($discounts) && method_exists($discounts, 'get_object') && $discounts->get_object() instanceof \WC_Order) {
                $awaiting = $discounts->get_object()->get_id();
            }
            $count = (new CouponRedemptionRepository())->countByCode($code, $awaiting);
            if ($count >= $usageLimit) {
                return $this->fail($code, 'سقف استفاده از این کد تخفیف تکمیل شده است.');
            }
        }
        $limitType = (string)($row['limit_type'] ?? '');
        $limitIds = $this->decodeLimitIds($row['limit_ids'] ?? null);
        if ($limitType !== '' && !empty($limitIds)) {
            if (!$this->cartMatchesLimit($limitType, $limitIds, $discounts)) {
                return $this->fail($code, 'این کد تخفیف برای محصولات داخل سبد خرید شما قابل استفاده نیست.');
            }
        }
        return $valid;
    }
    public function validateCartScope(bool $valid, $coupon): bool
    {
        return $this->fixedCartRules($coupon) !== null ? false : $valid;
    }
    public function validateProductScope(bool $valid, $product, $coupon): bool
    {
        $row = $this->fixedCartRules($coupon);
        if ($row === null) return $valid;
        if (!$product instanceof \WC_Product) return false;
        $ids = [$product->get_id(), $product->get_parent_id()];
        $categories = wc_get_product_cat_ids($product->get_parent_id() ?: $product->get_id());
        $allowed = $row['limit_type'] === 'product' ? $ids : $categories;
        return (bool)array_intersect($row['ids'], $allowed)
            && !array_intersect($coupon->get_excluded_product_ids(), $ids)
            && !array_intersect($coupon->get_excluded_product_categories(), $categories)
            && !($coupon->get_exclude_sale_items() && $product->is_on_sale());
    }
    private function fixedCartRules($coupon): ?array
    {
        if (!$coupon instanceof \WC_Coupon || !$coupon->is_type('fixed_cart')) return null;
        $code = $coupon->get_code();
        if (array_key_exists($code, $this->productRules)) return $this->productRules[$code];
        $this->productRules[$code] = null;
        $row = (new CouponRegistryRepository())->findByCode($code);
        if (!$row || !in_array(($row['strategy'] ?? ''), ['virtual', 'wp_post'], true)
            || !in_array(($row['limit_type'] ?? ''), ['product', 'category'], true)) return null;
        $row['ids'] = $this->decodeLimitIds($row['limit_ids'] ?? null);
        if (!$row['ids']) return null;
        $this->productRules[$code] = $row;
        return $row;
    }
    public function filterCouponError(string $message, int $errorCode, $coupon): string
    {
        if (!is_object($coupon) || !method_exists($coupon, 'get_code')) return $message;
        $code = (string)$coupon->get_code();
        if ($code === '') return $message;
        if (self::$lastErrorCoupon === $code && self::$lastErrorMessage) {
            $msg = self::$lastErrorMessage;
            self::$lastErrorCoupon = null;
            self::$lastErrorMessage = null;
            return $msg;
        }
        return $message;
    }
    public function reserveOrder($order): void
    {
        if (is_numeric($order)) $order = wc_get_order((int)$order);
        if (!$order instanceof \WC_Order || !$order->get_id()) return;
        $repository = new CouponRedemptionRepository();
        $userId = (int)$order->get_user_id();
        $guestId = $userId > 0 ? '' : $this->getGuestId();
        foreach ($order->get_coupon_codes() as $code) {
            $row = (new CouponRegistryRepository())->findByCode((string)$code);
            if (!$row || !in_array(($row['strategy'] ?? ''), ['virtual', 'wp_post'], true)) continue;
            if (!$this->isOwner($row) || !$repository->reserve((string)$code, $order->get_id(), $userId, $guestId)) {
                $repository->releaseOrder($order->get_id());
                $message = 'این کد تخفیف دیگر قابل رزرو نیست؛ سبد خرید را بررسی کنید.';
                if (doing_action('woocommerce_store_api_checkout_order_processed') && class_exists('Automattic\\WooCommerce\\StoreApi\\Exceptions\\RouteException')) {
                    throw new \Automattic\WooCommerce\StoreApi\Exceptions\RouteException('sekianafraz_coupon_unavailable', $message, 409);
                }
                throw new \Exception($message);
            }
        }
    }
    public function releaseOrder(int $orderId): void
    {
        (new CouponRedemptionRepository())->releaseOrder($orderId);
        $order = wc_get_order($orderId);
        if (!$order) return;
        foreach ($order->get_coupon_codes() as $code) {
            $row = (new CouponRegistryRepository())->findByCode((string)$code);
            if ($row && ($row['strategy'] ?? '') === 'wp_post') $this->syncPhysicalUsage($row);
        }
    }
    public function onOrderSettled(int $orderId): void
    {
        if (!function_exists('wc_get_order')) return;
        $orderId = (int)$orderId;
        if ($orderId <= 0) return;
        $order = wc_get_order($orderId);
        if (!$order || !is_object($order) || !method_exists($order, 'get_coupon_codes')) return;
        $codes = (array)$order->get_coupon_codes();
        if (empty($codes)) return;
        $userId = (int)$order->get_user_id();
        $regRepo = new CouponRegistryRepository();
        $redRepo = new CouponRedemptionRepository();
        foreach ($codes as $code) {
            $code = (string)$code;
            if ($code === '') continue;
            $row = $regRepo->findByCode($code);
            if (!is_array($row) || !in_array(($row['strategy'] ?? ''), ['virtual', 'wp_post'], true)) continue;
            if (!$redRepo->insertRedemption($code, $orderId, $userId)) {
                $key = '_sekianafraz_redemption_conflict_' . md5(strtolower($code));
                if (!$order->get_meta($key, true)) {
                    $order->update_meta_data($key, 1);
                    $order->save_meta_data();
                    $order->update_status('on-hold', 'ثبت مصرف کد تخفیف سنسور ممکن نشد؛ پیش از انجام سفارش، پرداخت و سقف مصرف را بررسی کنید.');
                } elseif (!$order->has_status('on-hold')) {
                    $order->update_status('on-hold');
                }
                if ($row['strategy'] === 'wp_post') $this->syncPhysicalUsage($row);
                continue;
            }
            if ($row['strategy'] === 'wp_post') $this->syncPhysicalUsage($row);
            $usageLimit = (int)($row['usage_limit'] ?? 0);
            $consumed = false;
            if ($usageLimit > 0) {
                $count = $redRepo->countByCode($code, 0, true);
                $consumed = $count >= $usageLimit;
            }
            $regRepo->markRedeemed($code, $consumed);
        }
    }
    private function syncPhysicalUsage(array $row): void
    {
        global $wpdb;
        $lock = 'sekianafraz_coupon_' . md5(DB_NAME . '|' . $wpdb->prefix . '|' . (int)$row['id']);
        if ((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,5)', $lock)) !== 1) {
            throw new \RuntimeException('Coupon usage storage unavailable.');
        }
        try {
            $coupon = new \WC_Coupon((int)$row['coupon_post_id']);
            if (!$coupon->get_id()) return;
            $count = (new CouponRedemptionRepository())->countByCode((string)$row['code'], 0, true);
            if ($coupon->get_usage_count() !== $count) {
                $coupon->set_usage_count($count);
                $coupon->save();
            }
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }
    private function fail(string $code, string $message): bool
    {
        self::$lastErrorCoupon = $code;
        self::$lastErrorMessage = $message;
        return false;
    }
    private function getGuestId(): string
    {
        $cookie = $_COOKIE['sekianafraz_guest_id'] ?? '';
        return is_string($cookie) ? trim($cookie) : '';
    }
    private function isOwner(array $row): bool
    {
        if (empty($row['restrict_owner'])) return true;
        $userId = (int)($row['user_id'] ?? 0);
        $guestId = (string)($row['guest_id'] ?? '');
        if ($userId > 0) {
            if (!function_exists('is_user_logged_in') || !is_user_logged_in()) return false;
            return (int)get_current_user_id() === $userId;
        }
        if ($guestId !== '') {
            $currentGuest = $this->getGuestId();
            if ($currentGuest === '') return false;
            return hash_equals($guestId, $currentGuest);
        }
        return false;
    }
    private function isExpired(array $row): bool
    {
        $expiresAt = (string)($row['expires_at'] ?? '');
        if ($expiresAt === '') return false;
        $ts = strtotime($expiresAt . ' UTC');
        if (!$ts) return false;
        return $ts < time();
    }
    private function expiresTimestamp(array $row): int
    {
        $expiresAt = (string)($row['expires_at'] ?? '');
        if ($expiresAt === '') return 0;
        $ts = strtotime($expiresAt . ' UTC');
        return $ts ? (int)$ts : 0;
    }
    private function decodeLimitIds($raw): array
    {
        if (!is_string($raw) || trim($raw) === '') return [];
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) return [];
        return array_values(array_filter(array_map('intval', $decoded)));
    }
    private function cartMatchesLimit(string $type, array $limitIds, $discounts = null): bool
    {
        $allowed = array_flip(array_values(array_filter(array_map('intval', $limitIds))));
        if (empty($allowed)) return true;
        if (!is_object($discounts) || !method_exists($discounts, 'get_items_to_validate')) {
            return true;
        }
        $items = $discounts->get_items_to_validate();
        if (!is_array($items) || empty($items)) return false;
        foreach ($items as $item) {
            if (!is_object($item) || empty($item->product) || !is_object($item->product)) continue;
            $product = $item->product;
            if (!method_exists($product, 'get_id')) continue;
            $productId = (int)$product->get_id();
            $parentId = method_exists($product, 'get_parent_id') ? (int)$product->get_parent_id() : 0;
            if ($type === 'product') {
                if ($productId > 0 && isset($allowed[$productId])) return true;
                if ($parentId > 0 && isset($allowed[$parentId])) return true;
                continue;
            }
            if ($type === 'category') {
                $baseProductId = $parentId > 0 ? $parentId : $productId;
                if ($baseProductId <= 0 || !function_exists('wc_get_product_cat_ids')) continue;
                $categoryIds = wc_get_product_cat_ids($baseProductId);
                if (!is_array($categoryIds)) continue;
                foreach ($categoryIds as $categoryId) {
                    $categoryId = (int)$categoryId;
                    if ($categoryId > 0 && isset($allowed[$categoryId])) return true;
                }
            }
        }
        return false;
    }
}
