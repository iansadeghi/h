<?php
namespace SeKianAfraz\VisitDiscount\Coupons;
if (!defined('ABSPATH')) { exit; }
class VirtualCouponIssuer
{
    public function issueForSensor(int $sensorId, int $userId, string $guestId, array $meta): array
    {
        if (!CouponRegistryRepository::ensureReady() || !CouponRedemptionRepository::ensureReady()) {
            return ['success' => false, 'response' => ['success' => false, 'code' => 'COUPON_STORAGE_UNAVAILABLE',
                'message' => 'فضای ذخیره‌سازی کد تخفیف آماده نیست.']];
        }
        $couponType = (string)($meta['coupon_type'] ?? '');
        $couponAmount = (float)($meta['coupon_amount'] ?? 0);
        $couponMode = (string)($meta['coupon_mode'] ?? '');
        $validHours = (int)($meta['coupon_valid_hours'] ?? 72);
        $usageLimit = (int)($meta['coupon_usage_limit'] ?? 3);
        $freeShipping = !empty($meta['coupon_free_shipping']);
        $coupon = $this->createVirtualCoupon(
            $couponType,
            $validHours,
            (string)($meta['coupon_custom_prefix'] ?? ''),
            (string)($meta['coupon_custom_suffix'] ?? ''),
            (int)($meta['coupon_custom_length'] ?? 4),
            (string)($meta['coupon_custom_mid_pattern'] ?? 'mixed')
        );
        if (empty($coupon['code'])) {
            return ['success' => false, 'response' => ['success' => false, 'code' => 'COUPON_CREATE_FAILED',
                'message' => 'ساخت کد یکتا مطابق الگوی انتخاب‌شده انجام نشد.']];
        }
        $couponCode = (string)($coupon['code'] ?? '');
        $couponExpiry = (string)($coupon['expiry'] ?? '');
        $expiryTimestamp = (int)($coupon['expiry_timestamp'] ?? 0);
        $expiresAtMs = $expiryTimestamp > 0 ? $expiryTimestamp * 1000 : 0;
        $limitEnabled = (bool)($meta['coupon_limit_enabled'] ?? false);
        $limitType = '';
        $limitIds = [];
        if ($limitEnabled) {
            $limitType = (string)($meta['coupon_limit_type'] ?? '');
            $limitIds = (array)($meta['coupon_limit_ids'] ?? []);
        }
        $stored = false;
        if (class_exists('SeKianAfraz\VisitDiscount\\Coupons\\CouponRegistryRepository')) {
            $stored = (new CouponRegistryRepository())->insertVirtualIssued(
                $couponCode,
                $sensorId,
                $userId,
                $guestId,
                $expiryTimestamp,
                [
                    'discount_type' => (($couponMode === 'percent') ? 'percent' : 'fixed_cart'),
                    'amount' => $couponAmount,
                    'free_shipping' => $freeShipping,
                    'usage_limit' => $usageLimit,
                    'restrict_owner' => CouponOwnership::restricted($meta, $userId),
                    'limit_type' => $limitEnabled ? $limitType : null,
                    'limit_ids' => $limitEnabled ? $limitIds : null,
                ]
            );
        }
        if (!$stored) {
            return [
                'success' => false,
                'response' => [
                    'success' => false,
                    'code' => 'COUPON_CREATE_FAILED',
                    'message' => 'ثبت کوپن مجازی انجام نشد.',
                ],
            ];
        }
        return [
            'success' => true,
            'coupon_code' => $couponCode,
            'coupon_expiry' => $couponExpiry,
            'expires_at_ms' => $expiresAtMs,
        ];
    }
    private function createVirtualCoupon(string $type, int $validHours, string $prefix = '', string $suffix = '', int $customLength = 4, string $midPattern = 'mixed'): array
    {
        $code = '';
        $isCustom = $type === 'custom';
        $midPattern = sanitize_key((string)$midPattern);
        if ($midPattern === '') $midPattern = 'mixed';
        if (!in_array($midPattern, ['numbers','letters','mixed'], true)) $midPattern = 'mixed';
        for ($i = 0; $i < 20; $i++) {
            if ($isCustom) {
                $p = $this->sanitizeAffix($prefix);
                $s = $this->sanitizeAffix($suffix);
                $len = max(3, min(64, (int)$customLength));
                $candidate = $p . $this->generateCouponCode($midPattern, $len) . $s;
            } else {
                $candidate = $this->generateCouponCode($type, 10);
            }
            if (!$this->codeExists($candidate)) {
                $code = $candidate;
                break;
            }
        }
        if ($code === '') return [];
        $expiry = current_time('timestamp', true) + HOUR_IN_SECONDS * max(1, (int)$validHours);
        return [
            'code' => $code,
            'expiry' => wp_date('Y-m-d H:i', $expiry, wp_timezone()),
            'expiry_timestamp' => $expiry,
        ];
    }
    private function sanitizeAffix(string $s): string
    {
        $s = sanitize_text_field($s);
        $map = [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ];
        $s = strtr($s, $map);
        $s = preg_replace('/[^A-Za-z0-9_]/', '', $s);
        return substr($s, 0, 32);
    }
    private function generateCouponCode(string $type, int $length): string
    {
        $digits = '0123456789';
        $letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        $mix = $letters . $digits;
        $pool = $mix;
        if ($type === 'numbers') $pool = $digits;
        elseif ($type === 'letters') $pool = $letters;
        elseif ($type === 'mixed') $pool = $mix;
        $out = '';
        for ($i = 0; $i < $length; $i++) {
            $out .= $pool[random_int(0, strlen($pool) - 1)];
        }
        return $out;
    }
    private function codeExists(string $code): bool
    {
        $code = trim((string)$code);
        if ($code === '') return true;
        if (class_exists('SeKianAfraz\VisitDiscount\\Coupons\\CouponRegistryRepository')) {
            $row = (new CouponRegistryRepository())->findByCode($code);
            if (is_array($row)) return true;
        }
        if (!function_exists('wc_get_coupon_id_by_code')) return false;
        return (int)wc_get_coupon_id_by_code($code) > 0;
    }
}
