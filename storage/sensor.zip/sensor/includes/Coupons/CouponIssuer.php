<?php
namespace SeKianAfraz\VisitDiscount\Coupons;
if (!defined('ABSPATH')) { exit; }
class CouponIssuer
{
    public function issueForSensor(int $sensorId, int $userId, string $guestId, array $meta): array
    {
        $couponStrategy = (string)($meta['coupon_strategy'] ?? 'individual');
        $fixedCode = (string)($meta['fixed_code'] ?? '');
        $couponCode = '';
        $couponExpiry = '';
        $expiresAtMs = 0;
        if ($couponStrategy === 'none') {
            return [
                'success' => true,
                'coupon_code' => '',
                'coupon_expiry' => '',
                'expires_at_ms' => $expiresAtMs,
            ];
        }
        if ($couponStrategy === 'fixed' && $fixedCode !== '') {
            $fixed = new \WC_Coupon($fixedCode);
            $expiry = $fixed->get_date_expires();
            if (!$fixed->get_id() || ($expiry && $expiry->getTimestamp() <= time()) || ($fixed->get_usage_limit() > 0 && $fixed->get_usage_count() >= $fixed->get_usage_limit())) {
                return ['success' => false, 'response' => ['success' => false, 'code' => 'COUPON_UNAVAILABLE', 'message' => 'کد تخفیف موجود معتبر نیست.']];
            }
            $couponCode = $fixedCode;
            $couponExpiry = $expiry ? wp_date('Y-m-d H:i', $expiry->getTimestamp(), wp_timezone()) : '';
            $expiresAtMs = $expiry ? $expiry->getTimestamp() * 1000 : 0;
            return [
                'success' => true,
                'coupon_code' => $couponCode,
                'coupon_expiry' => $couponExpiry,
                'expires_at_ms' => $expiresAtMs,
            ];
        }
        if (!CouponRegistryRepository::ensureReady()) {
            return ['success' => false, 'response' => ['success' => false, 'code' => 'COUPON_STORAGE_UNAVAILABLE', 'message' => 'ثبت کوپن ممکن نیست.']];
        }
        $existing = (new CouponRegistryRepository())->findActiveForIdentity($sensorId, $userId, $guestId);
        if ($existing && (($couponStrategy === 'virtual') === ($existing['strategy'] === 'virtual')) && $this->matchesRules($existing, $meta)) {
            $expiry = strtotime($existing['expires_at'] . ' UTC');
            return ['success' => true, 'coupon_code' => $existing['code'], 'coupon_expiry' => wp_date('Y-m-d H:i', $expiry, wp_timezone()), 'expires_at_ms' => $expiry * 1000];
        }
        $couponType = (string)($meta['coupon_type'] ?? '');
        $couponAmount = (float)($meta['coupon_amount'] ?? 0);
        $couponMode = (string)($meta['coupon_mode'] ?? '');
        $validHours = (int)($meta['coupon_valid_hours'] ?? 72);
        $usageLimit = (int)($meta['coupon_usage_limit'] ?? 3);
        $freeShipping = !empty($meta['coupon_free_shipping']);
        if ($couponStrategy === 'virtual') {
            $handled = apply_filters('sekianafraz_issue_virtual_coupon', null, $sensorId, $userId, $guestId, $meta);
            if (is_array($handled) && isset($handled['success'])) {
                return $handled;
            }
            return [
                'success' => false,
                'response' => ['success' => false, 'code' => 'COUPON_PROVIDER_UNAVAILABLE', 'message' => 'سرویس کوپن مجازی در دسترس نیست.'],
            ];
        }
        $coupon = $this->createCoupon(
            $couponType,
            $couponAmount,
            $couponMode,
            $validHours,
            $usageLimit,
            (string)($meta['coupon_custom_prefix'] ?? ''),
            (string)($meta['coupon_custom_suffix'] ?? ''),
            (int)($meta['coupon_custom_length'] ?? 4),
            (string)($meta['coupon_custom_mid_pattern'] ?? 'mixed'),
            $freeShipping
        );
        if (empty($coupon['success'])) {
            return [
                'success' => false,
                'response' => [
                    'success' => false,
                    'code' => 'COUPON_CREATE_FAILED',
                    'message' => (string)($coupon['error'] ?? 'ایجاد کد تخفیف انجام نشد.'),
                ],
            ];
        }
        $couponCode = (string)$coupon['code'];
        $couponExpiry = (string)$coupon['expiry'];
        $storedCoupon = new \WC_Coupon((int)$coupon['id']);
        if ($storedCoupon->get_id() > 0) {
            $storedCoupon->update_meta_data('_sekianafraz_sensor_id', $sensorId);
            $storedCoupon->save_meta_data();
        }
        $expiryTimestamp = (int)($coupon['expiry_timestamp'] ?? 0);
        $expiresAtMs = $expiryTimestamp > 0 ? $expiryTimestamp * 1000 : 0;
        $limitEnabled = (bool)($meta['coupon_limit_enabled'] ?? false);
        $limitType = '';
        $limitIds = [];
        if ($limitEnabled) {
            $limitType = (string)($meta['coupon_limit_type'] ?? '');
            $limitIds = (array)($meta['coupon_limit_ids'] ?? []);
            do_action('sekianafraz_apply_coupon_limits', (int)$coupon['id'], $limitType, $limitIds);
        }
        if (class_exists('SeKianAfraz\VisitDiscount\Coupons\CouponRegistryRepository')) {
            $stored = (new CouponRegistryRepository())->insertIssued(
                (string)$coupon['code'],
                $sensorId,
                $userId,
                $guestId,
                (int)$coupon['id'],
                (int)($coupon['expiry_timestamp'] ?? 0),
                [
                    'discount_type' => (($couponMode === 'percent') ? 'percent' : 'fixed_cart'),
                    'amount' => $couponAmount,
                    'free_shipping' => $freeShipping,
                    'usage_limit' => $usageLimit,
                    'restrict_owner' => CouponOwnership::restricted($meta, $userId),
                    'limit_type' => $limitEnabled ? $limitType : null,
                    'limit_ids' => $limitEnabled ? $limitIds : null,
                ]
            );
            if (!$stored) {
                $storedCoupon->delete(true);
                return ['success' => false, 'response' => ['success' => false, 'code' => 'COUPON_STORAGE_FAILED', 'message' => 'ثبت کوپن انجام نشد.']];
            }
        }
        return [
            'success' => true,
            'coupon_code' => $couponCode,
            'coupon_expiry' => $couponExpiry,
            'expires_at_ms' => $expiresAtMs,
        ];
    }
    private function matchesRules(array $row, array $meta): bool
    {
        $limited = !empty($meta['coupon_limit_enabled']);
        $ids = $limited ? array_map('intval', (array)($meta['coupon_limit_ids'] ?? [])) : [];
        $storedIds = json_decode((string)($row['limit_ids'] ?? ''), true) ?: [];
        sort($ids);
        sort($storedIds);
        return (string)$row['discount_type'] === (($meta['coupon_mode'] ?? '') === 'percent' ? 'percent' : 'fixed_cart')
            && wc_format_decimal($row['amount'], 2) === wc_format_decimal($meta['coupon_amount'] ?? 0, 2)
            && (bool)$row['free_shipping'] === !empty($meta['coupon_free_shipping'])
            && (int)$row['usage_limit'] === (int)($meta['coupon_usage_limit'] ?? 3)
            && (bool)($row['restrict_owner'] ?? false) === CouponOwnership::restricted($meta, (int)($row['user_id'] ?? 0))
            && (string)($row['limit_type'] ?? '') === ($limited ? (string)($meta['coupon_limit_type'] ?? '') : '')
            && $ids === $storedIds
            && strtotime($row['expires_at'] . ' UTC') - strtotime($row['created_at'] . ' UTC') === max(1, (int)($meta['coupon_valid_hours'] ?? 72)) * HOUR_IN_SECONDS;
    }
    private function createCoupon(string $type, float $amount, string $mode, int $validHours, int $usageLimit = 3, string $prefix = '', string $suffix = '', int $customLength = 4, string $midPattern = 'mixed', bool $freeShipping = false): array
    {
        $code = '';
        $isCustom = $type === 'custom';
        $midPattern = sanitize_key((string)$midPattern);
        if ($midPattern === '') $midPattern = 'mixed';
        if (!in_array($midPattern, ['numbers','letters','mixed'], true)) $midPattern = 'mixed';
        for ($i = 0; $i < 20; $i++) {
            if ($isCustom) {
                $p = $this->sanitizeAffix($prefix);
                $s = $this->sanitizeAffix($suffix);
                $len = max(3, min(64, (int)$customLength));
                $candidate = $p . $this->generateCouponCode($midPattern, $len) . $s;
            } else {
                $candidate = $this->generateCouponCode($type, 10);
            }
            if (!$this->codeExists($candidate)) {
                $code = $candidate;
                break;
            }
        }
        if ($code === '') return ['success' => false, 'error' => 'ساخت کد یکتا مطابق الگوی انتخاب‌شده انجام نشد.'];
        $expiry = current_time('timestamp', true) + HOUR_IN_SECONDS * max(1, $validHours);
        try {
            $coupon = new \WC_Coupon();
            $coupon->set_code($code);
            $coupon->set_discount_type(($mode === 'percent') ? 'percent' : 'fixed_cart');
            $coupon->set_amount(wc_format_decimal($amount, 2));
            $coupon->set_individual_use(true);
            $coupon->set_usage_limit(max(0, $usageLimit));
            $coupon->set_date_expires($expiry);
            $coupon->set_free_shipping($freeShipping);
            $coupon->update_meta_data('_generated_by', 'sekianafraz');
            $id = (int)$coupon->save();
        } catch (\Throwable $e) {
            return [
                'success' => false,
                'error' => $e->getMessage() !== '' ? $e->getMessage() : 'ایجاد کد تخفیف انجام نشد.',
            ];
        }
        if ($id <= 0) {
            return ['success' => false, 'error' => 'ایجاد کد تخفیف انجام نشد.'];
        }
        return [
            'success' => true,
            'id' => $id,
            'code' => $code,
            'expiry' => wp_date('Y-m-d H:i', $expiry, wp_timezone()),
            'expiry_timestamp' => $expiry,
        ];
    }
    private function sanitizeAffix(string $s): string
    {
        $s = sanitize_text_field($s);
        $map = [
            '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9',
        ];
        $s = strtr($s, $map);
        $s = preg_replace('/[^A-Za-z0-9_]/', '', $s);
        return substr($s, 0, 32);
    }
    private function generateCouponCode(string $type, int $length): string
    {
        $digits = '0123456789';
        $letters = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
        $mix = $letters . $digits;
        $pool = $mix;
        if ($type === 'numbers') $pool = $digits;
        elseif ($type === 'letters') $pool = $letters;
        elseif ($type === 'mixed') $pool = $mix;
        $out = '';
        for ($i = 0; $i < $length; $i++) {
            $out .= $pool[random_int(0, strlen($pool) - 1)];
        }
        return $out;
    }
    private function codeExists(string $code): bool
    {
        $code = trim((string)$code);
        if ($code === '') return true;
        if (class_exists('SeKianAfraz\VisitDiscount\\Coupons\\CouponRegistryRepository')) {
            $row = (new CouponRegistryRepository())->findByCode($code);
            if (is_array($row)) return true;
        }
        if (!function_exists('wc_get_coupon_id_by_code')) return false;
        return (int)wc_get_coupon_id_by_code($code) > 0;
    }
    private function applyWooFreeShippingByCode(string $code): void
    {
        $code = trim((string)$code);
        if ($code === '') return;
        if (!function_exists('wc_get_coupon_id_by_code') || !class_exists('WC_Coupon')) return;
        $cid = (int) wc_get_coupon_id_by_code($code);
        if ($cid <= 0) return;
        try {
            $c = new \WC_Coupon($cid);
            $c->set_free_shipping(true);
            $c->save();
        } catch (\Throwable $e) {
        }
    }
}
