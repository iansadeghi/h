<?php
namespace SeKianAfraz\VisitDiscount\Coupons;
if (!defined('ABSPATH')) { exit; }
class CouponRegistryRepository
{
    public static function ensureReady(): bool
    {
        if (get_option('sekianafraz_coupon_registry_ready')) return true;
        if (!\SeKianAfraz\VisitDiscount\Database\Schema::createCouponRegistryTable()) return false;
        update_option('sekianafraz_coupon_registry_ready', 1, false);
        return true;
    }
    private function tableName(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'sekianafraz_coupon_registry';
    }
    public function findActiveForIdentity(int $sensorId, int $userId, string $guestId): ?array
    {
        global $wpdb;
        if ($sensorId <= 0 || ($userId <= 0 && $guestId === '')) return null;
        $identity = $userId > 0 ? $wpdb->prepare('user_id=%d', $userId) : $wpdb->prepare('guest_id=%s AND (user_id IS NULL OR user_id=0)', $guestId);
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$this->tableName()} WHERE sensor_id=%d AND {$identity} AND status='active' AND expires_at>UTC_TIMESTAMP() ORDER BY id DESC LIMIT 1", $sensorId), ARRAY_A);
        if (!is_array($row) || !CouponAvailability::usable((string)$row['code'])) return null;
        if ($row['strategy'] === 'wp_post') {
            $coupon = new \WC_Coupon((int)$row['coupon_post_id']);
            if (!$coupon->get_id() || ($coupon->get_usage_limit() > 0 && $coupon->get_usage_count() >= $coupon->get_usage_limit())) return null;
        }
        return $row;
    }
    public function insertIssued(string $code, int $sensorId, int $userId, string $guestId, int $couponPostId, int $expiresAtUtcTs = 0, array $rules = []): bool
    {
        global $wpdb;
        $code = trim((string)$code);
        if (!self::ensureReady() || $code === '' || strlen($code) > 191 || $sensorId < 0) return false;
        $createdAt = current_time('mysql', true);
        $expiresAt = $expiresAtUtcTs > 0 ? gmdate('Y-m-d H:i:s', $expiresAtUtcTs) : null;
        $discountType = isset($rules['discount_type']) ? (string)$rules['discount_type'] : null;
        $amount = isset($rules['amount']) ? (float)$rules['amount'] : null;
        $usageLimit = isset($rules['usage_limit']) ? (int)$rules['usage_limit'] : null;
        $limitType = isset($rules['limit_type']) ? (string)$rules['limit_type'] : null;
        $limitIds = isset($rules['limit_ids']) ? (array)$rules['limit_ids'] : null;
        $limitIdsJson = null;
        if (is_array($limitIds) && !empty($limitIds)) {
            $clean = array_values(array_filter(array_map('intval', $limitIds)));
            if (!empty($clean)) $limitIdsJson = wp_json_encode($clean);
        }
        $data = [
            'code' => $code,
            'coupon_post_id' => max(0, (int)$couponPostId),
            'sensor_id' => (int)$sensorId,
            'user_id' => $userId > 0 ? (int)$userId : null,
            'guest_id' => $userId > 0 ? null : (string)$guestId,
            'strategy' => 'wp_post',
            'status' => 'active',
            'discount_type' => $discountType ?: null,
            'amount' => $amount,
            'free_shipping' => !empty($rules['free_shipping']) ? 1 : 0,
            'usage_limit' => $usageLimit,
            'limit_type' => $limitType ?: null,
            'limit_ids' => $limitIdsJson,
            'created_at' => $createdAt,
            'expires_at' => $expiresAt,
            'redeemed_at' => null,
            'closed_at' => null,
            'restrict_owner' => !empty($rules['restrict_owner']) ? 1 : 0,
        ];
        $formats = [
            '%s',
            '%d',
            '%d',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%f',
            '%d',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%d',
        ];
        $res = $wpdb->insert($this->tableName(), $data, $formats);
        return $res !== false;
    }
    public function insertVirtualIssued(string $code, int $sensorId, int $userId, string $guestId, int $expiresAtUtcTs = 0, array $rules = []): bool
    {
        global $wpdb;
        if (!self::ensureReady()) return false;
        $code = trim((string)$code);
        if (!self::ensureReady() || $code === '' || strlen($code) > 191 || $sensorId < 0) return false;
        $createdAt = current_time('mysql', true);
        $expiresAt = $expiresAtUtcTs > 0 ? gmdate('Y-m-d H:i:s', $expiresAtUtcTs) : null;
        $discountType = isset($rules['discount_type']) ? (string)$rules['discount_type'] : null;
        $amount = isset($rules['amount']) ? (float)$rules['amount'] : null;
        $usageLimit = isset($rules['usage_limit']) ? (int)$rules['usage_limit'] : null;
        $limitType = isset($rules['limit_type']) ? (string)$rules['limit_type'] : null;
        $limitIds = isset($rules['limit_ids']) ? (array)$rules['limit_ids'] : null;
        $limitIdsJson = null;
        if (is_array($limitIds) && !empty($limitIds)) {
            $clean = array_values(array_filter(array_map('intval', $limitIds)));
            if (!empty($clean)) $limitIdsJson = wp_json_encode($clean);
        }
        $data = [
            'code' => $code,
            'coupon_post_id' => null,
            'sensor_id' => (int)$sensorId,
            'user_id' => $userId > 0 ? (int)$userId : null,
            'guest_id' => $userId > 0 ? null : (string)$guestId,
            'strategy' => 'virtual',
            'status' => 'active',
            'discount_type' => $discountType ?: null,
            'amount' => $amount,
            'free_shipping' => !empty($rules['free_shipping']) ? 1 : 0,
            'usage_limit' => $usageLimit,
            'limit_type' => $limitType ?: null,
            'limit_ids' => $limitIdsJson,
            'created_at' => $createdAt,
            'expires_at' => $expiresAt,
            'redeemed_at' => null,
            'closed_at' => null,
            'restrict_owner' => !empty($rules['restrict_owner']) ? 1 : 0,
        ];
        $formats = [
            '%s',
            '%d',
            '%d',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%f',
            '%d',
            '%d',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%s',
            '%d',
        ];
        $res = $wpdb->insert($this->tableName(), $data, $formats);
        return $res !== false;
    }
    public function findByCode(string $code): ?array
    {
        global $wpdb;
        $code = trim((string)$code);
        if ($code === '') return null;
        $row = $wpdb->get_row(
            $wpdb->prepare("SELECT * FROM {$this->tableName()} WHERE code=%s LIMIT 1", $code),
            ARRAY_A
        );
        return is_array($row) ? $row : null;
    }
    public function findExpiredWpPostCouponIds(int $limit = 200): array
    {
        global $wpdb;
        $limit = max(1, min(2000, (int)$limit));
        $table = $this->tableName();
        $parts = [];
        foreach (['active', 'redeemed'] as $status) {
            $parts[] = $wpdb->prepare("(SELECT id,coupon_post_id,expires_at FROM {$table}
                WHERE strategy='wp_post' AND status=%s AND coupon_post_id > 0
                  AND expires_at < UTC_TIMESTAMP()
                ORDER BY expires_at ASC,id ASC LIMIT %d)", $status, $limit);
        }
        $sql = 'SELECT coupon_post_id FROM (' . implode(' UNION ALL ', $parts) . ") expired ORDER BY expires_at ASC,id ASC LIMIT {$limit}";
        $rows = $wpdb->get_col($sql);
        if (!is_array($rows) || empty($rows)) return [];
        $out = [];
        foreach ($rows as $v) {
            $id = (int)$v;
            if ($id > 0) $out[] = $id;
        }
        return $out;
    }
    public function markExpiredByCouponPostIds(array $couponPostIds): int
    {
        global $wpdb;
        $ids = array_values(array_filter(array_map('intval', $couponPostIds), static function ($v) {
            return $v > 0;
        }));
        if (empty($ids)) return 0;
        $table = $this->tableName();
        $in = implode(',', $ids);
        $sql = "UPDATE {$table}
                SET status='expired', coupon_post_id=NULL, closed_at=UTC_TIMESTAMP()
                WHERE coupon_post_id IN ({$in})";
        $res = $wpdb->query($sql);
        return is_int($res) ? $res : 0;
    }
    public function expireVirtualCouponsBatch(int $limit = 5000): int
    {
        global $wpdb;
        $limit = max(1, min(50000, (int)$limit));
        $table = $this->tableName();
        $sql = $wpdb->prepare(
            "UPDATE {$table}
             SET status='expired', closed_at=COALESCE(closed_at, UTC_TIMESTAMP())
             WHERE strategy='virtual'
               AND status='active'
               AND expires_at IS NOT NULL
               AND expires_at < UTC_TIMESTAMP()
             ORDER BY expires_at ASC,id ASC
             LIMIT %d",
            $limit
        );
        $res = $wpdb->query($sql);
        return (int)$res;
    }
    public function markRedeemed(string $code, bool $consumed = false): int
    {
        global $wpdb;
        $code = trim((string)$code);
        if ($code === '') return 0;
        $setStatus = $consumed ? ", status='redeemed', closed_at=COALESCE(closed_at, UTC_TIMESTAMP())" : '';
        $sql = $wpdb->prepare(
            "UPDATE {$this->tableName()}
             SET redeemed_at = COALESCE(redeemed_at, UTC_TIMESTAMP()){$setStatus}
             WHERE code=%s AND status IN ('active','redeemed')",
            $code
        );
        $res = $wpdb->query($sql);
        return (int)$res;
    }
    public function purgeHistoryOlderThanDays(int $olderThanDays, int $batchSize = 5000): int
    {
        global $wpdb;
        $olderThanDays = max(1, (int)$olderThanDays);
        $batchSize = max(1, min(50000, (int)$batchSize));
        $table = $this->tableName();
        $sql = $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE status <> 'active'
               AND coupon_post_id IS NULL
               AND (
                   (closed_at IS NOT NULL AND closed_at < (UTC_TIMESTAMP() - INTERVAL %d DAY))
                   OR
                   (closed_at IS NULL AND created_at < (UTC_TIMESTAMP() - INTERVAL %d DAY))
               )
             LIMIT %d",
            $olderThanDays,
            $olderThanDays,
            $batchSize
        );
        $res = $wpdb->query($sql);
        return (int)$res;
    }
}
