<?php
namespace SeKianAfraz\VisitDiscount\Coupons;
if (!defined('ABSPATH')) { exit; }
class CouponRedemptionRepository
{
    public static function ensureReady(): bool
    {
        if (get_option('sekianafraz_coupon_redemptions_ready')) return true;
        if (!\SeKianAfraz\VisitDiscount\Database\Schema::createCouponRedemptionsTable()) return false;
        update_option('sekianafraz_coupon_redemptions_ready', 1, false);
        return true;
    }
    private function tableName(): string
    {
        global $wpdb;
        return $wpdb->prefix . 'sekianafraz_coupon_redemptions';
    }
    public function insertRedemption(string $code, int $orderId, int $userId = 0, string $guestId = ''): bool
    {
        global $wpdb;
        $code = trim((string)$code);
        $orderId = (int)$orderId;
        if ($code === '' || $orderId <= 0) return false;
        $lock = $this->lock($code);
        if ($lock === '') return false;
        try {
            $existing = $wpdb->get_var($wpdb->prepare("SELECT state FROM {$this->tableName()} WHERE code=%s AND order_id=%d", $code, $orderId));
            if ($wpdb->last_error !== '') return false;
            if ($existing === 'redeemed') return true;
            $row = (new CouponRegistryRepository())->findByCode($code);
            if (!$row) return false;
            if ($existing !== 'reserved' && ($row['status'] !== 'active'
                || (!empty($row['expires_at']) && strtotime($row['expires_at'] . ' UTC') <= time()))) return false;
            if ((int)$row['usage_limit'] > 0 && $this->countByCode($code, $orderId) >= (int)$row['usage_limit']) return false;
            $sql = $wpdb->prepare(
                "INSERT INTO {$this->tableName()} (code,order_id,user_id,guest_id,redeemed_at,state) VALUES (%s,%d,%d,%s,UTC_TIMESTAMP(),'redeemed') ON DUPLICATE KEY UPDATE state='redeemed'",
                $code, $orderId, $userId, $guestId
            );
            return $wpdb->query($sql) !== false;
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }
    public function reserve(string $code, int $orderId, int $userId = 0, string $guestId = ''): bool
    {
        global $wpdb;
        $code = trim($code);
        if ($orderId <= 0 || !self::ensureReady()) return false;
        $lock = $this->lock($code);
        if ($lock === '') return false;
        try {
            $existing = $wpdb->get_var($wpdb->prepare("SELECT state FROM {$this->tableName()} WHERE code=%s AND order_id=%d", $code, $orderId));
            if (in_array($existing, ['reserved', 'redeemed'], true)) return true;
            $row = (new CouponRegistryRepository())->findByCode($code);
            if (!$row || $row['status'] !== 'active' || (!empty($row['expires_at']) && strtotime($row['expires_at'] . ' UTC') <= time())) return false;
            if ((int)$row['usage_limit'] > 0 && $this->countByCode($code) >= (int)$row['usage_limit']) return false;
            return $wpdb->query($wpdb->prepare(
                "INSERT INTO {$this->tableName()} (code,order_id,user_id,guest_id,redeemed_at,state) VALUES (%s,%d,%d,%s,UTC_TIMESTAMP(),'reserved') ON DUPLICATE KEY UPDATE state='reserved',redeemed_at=UTC_TIMESTAMP()",
                $code, $orderId, $userId, $guestId
            )) !== false;
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }
    public function releaseOrder(int $orderId): void
    {
        global $wpdb;
        $wpdb->query($wpdb->prepare("UPDATE {$this->tableName()} SET state='released' WHERE order_id=%d AND state='reserved'", $orderId));
    }
    public function countByCode(string $code, int $excludeOrderId = 0, bool $redeemedOnly = false): int
    {
        global $wpdb;
        $code = trim($code);
        $states = $redeemedOnly ? "state='redeemed'" : "state IN ('reserved','redeemed')";
        $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$this->tableName()} WHERE code=%s AND order_id<>%d AND {$states}", $code, $excludeOrderId));
        if ($wpdb->last_error !== '') throw new \RuntimeException('Coupon usage storage unavailable.');
        return (int)$count;
    }
    private function lock(string $code): string
    {
        global $wpdb;
        $row = (new CouponRegistryRepository())->findByCode($code);
        if (!$row || (int)$row['id'] <= 0) return '';
        $name = 'sekianafraz_coupon_' . md5(DB_NAME . '|' . $wpdb->prefix . '|' . (int)$row['id']);
        return (int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,5)', $name)) === 1 ? $name : '';
    }
    public function existsForOrder(string $code, int $orderId): bool
    {
        global $wpdb;
        $code = trim((string)$code);
        $orderId = (int)$orderId;
        if ($code === '' || $orderId <= 0) return false;
        $found = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$this->tableName()} WHERE code=%s AND order_id=%d LIMIT 1",
                $code,
                $orderId
            )
        );
        return $found !== null;
    }
    public function purgeOlderThanDays(int $olderThanDays, int $batchSize = 5000): int
    {
        global $wpdb;
        $olderThanDays = max(1, (int)$olderThanDays);
        $batchSize = max(1, min(50000, (int)$batchSize));
        $table = $this->tableName();
        $sql = $wpdb->prepare(
            "DELETE FROM {$table}
             WHERE redeemed_at < (UTC_TIMESTAMP() - INTERVAL %d DAY)
               AND state <> 'reserved'
               AND NOT EXISTS (SELECT 1 FROM {$wpdb->prefix}sekianafraz_coupon_registry r WHERE r.code={$table}.code AND r.status='active')
             LIMIT %d",
            $olderThanDays,
            $batchSize
        );
        $res = $wpdb->query($sql);
        return (int)$res;
    }
}
