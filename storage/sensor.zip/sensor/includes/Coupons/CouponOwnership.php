<?php
namespace SeKianAfraz\VisitDiscount\Coupons;
if (!defined('ABSPATH')) { exit; }
class CouponOwnership
{
    public static function audiences(array $meta): array
    {
        if (!in_array(($meta['coupon_strategy'] ?? 'individual'), ['individual', 'virtual'], true)) {
            return ['user' => false, 'guest' => false];
        }
        $action = $meta['action'] ?? 'banner';
        if ($action === 'sms') return ['user' => true, 'guest' => false];
        if (!in_array($action, ['banner', 'both'], true)) return ['user' => false, 'guest' => false];
        return [
            'user' => ($meta['banner_type'] ?? 'single') !== 'multi'
                || in_array(($meta['logged_behavior'] ?? 'single_sms'), ['single', 'sms', 'single_sms'], true),
            'guest' => true,
        ];
    }
    public static function restricted(array $meta, int $userId): bool
    {
        return filter_var($meta[$userId > 0 ? 'coupon_restrict_user' : 'coupon_restrict_guest'] ?? false, FILTER_VALIDATE_BOOLEAN);
    }
}
