<?php
namespace SeKianAfraz\VisitDiscount\Admin\Views;
if (!defined('ABSPATH')) { exit; }
class LeadsView
{
    public function output(): void
    {
        $page = \SeKianAfraz\VisitDiscount\Leads\LeadsRepository::ensureReady()
            ? (new \SeKianAfraz\VisitDiscount\Leads\LeadsRepository())->page()
            : ['items' => [], 'has_more' => false, 'next_before' => 0];
        $items = $page['items'];
        $statuses = ['sent' => 'ارسال‌شده', 'failed' => 'ناموفق', 'pending' => 'در انتظار'];
        echo '<div class="sekianafraz-card"><div class="sekianafraz-card-body sekianafraz-leads">';
        echo '<div class="sekianafraz-actions"><div class="hint"><svg class="sekianafraz-hint-icon" width="10" height="10" viewBox="0 0 10 10" aria-hidden="true"><rect width="10" height="10" fill="var(--sekianafraz-black)"/></svg><span>شماره‌های جمع‌آوری‌شده</span></div><div class="sekianafraz-actions-right">';
        echo '<div class="sekianafraz-bulk-actions" id="sekianafraz-leads-bulk" hidden>';
        foreach (['csv' => 'خروجی CSV', 'xlsx' => 'خروجی اکسل'] as $format => $label) {
            $url = add_query_arg(['action' => 'sekianafraz_export_leads', 'format' => $format,
                '_wpnonce' => wp_create_nonce('sekianafraz_export_leads')], admin_url('admin-post.php'));
            echo '<a class="sekianafraz-btn sekianafraz-export-btn" data-leads-export="selected" data-export-base="' . esc_url($url) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
        }
        echo '<button class="sekianafraz-btn danger" id="sekianafraz-leads-delete">حذف</button></div>';
        foreach (['csv' => 'خروجی CSV', 'xlsx' => 'خروجی اکسل'] as $format => $label) {
            $url = add_query_arg(['action' => 'sekianafraz_export_leads', 'format' => $format,
                '_wpnonce' => wp_create_nonce('sekianafraz_export_leads')], admin_url('admin-post.php'));
            echo '<a class="sekianafraz-btn primary sekianafraz-export-btn" data-leads-export="all" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
        }
        echo '</div></div><div class="sekianafraz-listing">';
        ListingTable::open('<th class="sekianafraz-select-col"><label class="checkBox"><input type="checkbox" id="sekianafraz-leads-select-all" aria-label="انتخاب همه شماره‌ها"><div class="transition"></div></label></th><th>شماره تلفن</th><th>سنسور</th><th>وضعیت پیامک</th><th>زمان ثبت</th><th>وجود در اطلاعات کاربران</th><th class="rsad-actions-td"><span class="rsad-actions-heading">عملیات</span></th>', 'sekianafraz-leads-table', !$items);
        echo '<tbody id="sekianafraz-leads-body" data-next-before="' . (int)$page['next_before'] . '" data-has-more="' . ($page['has_more'] ? '1' : '0') . '">';
        foreach ($items as $item) {
            $id = (int)$item['id'];
            echo '<tr data-id="' . $id . '"><td class="sekianafraz-select-col"><label class="checkBox"><input type="checkbox" class="sekianafraz-lead-select" data-id="' . $id . '" aria-label="انتخاب شماره"><div class="transition"></div></label></td>';
            echo '<td dir="ltr">' . esc_html($item['phone']) . '</td><td>' . esc_html($item['sensor_name'] . ' #' . $item['sensor_id']) . '</td><td>' . esc_html($statuses[$item['sms_status']] ?? 'در انتظار') . '</td><td dir="ltr">' . esc_html($item['created_local']) . '</td>';
            echo '<td data-owner-cell data-owner-status="' . esc_attr($item['owner_status']) . '">';
            if ($item['owner_status'] === 'pending') {
                echo 'در انتظار تطبیق';
            } elseif (!$item['owners']) {
                echo 'ناموجود';
            } else {
                echo 'بله · ';
                foreach ($item['owners'] as $index => $owner) {
                    if ($index) echo '، ';
                    echo '<a href="' . esc_url(add_query_arg(['user_id' => (int)$owner['id']], admin_url('user-edit.php'))) . '">' . esc_html($owner['name']) . '</a>';
                }
            }
            echo '</td><td class="rsad-actions-td"><div class="rsad-actions"><button type="button" class="rsad-btn rsad-btn--delete" data-lead-delete><span class="dashicons dashicons-trash"></span>حذف</button></div></td></tr>';
        }
        echo '</tbody></table>';
        ListingTable::emptyState('هنوز شماره‌ای جمع‌آوری نشده است!', 'شماره‌هایی که کاربران در بنر وارد می‌کنند، اینجا نمایش داده می‌شوند.', 'sekianafraz-leads-empty', (bool)$items);
        echo '<div class="sekianafraz-leads-more"><button type="button" id="sekianafraz-leads-load-more" class="sekianafraz-btn"' . ($page['has_more'] ? '' : ' hidden') . '>نمایش بیشتر</button></div></div></div></div>';
    }
}
