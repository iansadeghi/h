<?php
namespace SeKianAfraz\VisitDiscount\Admin\Views;
use SeKianAfraz\VisitDiscount\Sensors\SensorService;
if (!defined('ABSPATH')) { exit; }
class SensorsView
{
    public function output(): void
    {
        echo '<div class="sekianafraz-card"><div class="sekianafraz-card-body">';
        echo '<div class="sekianafraz-actions"><div class="hint"><svg class="sekianafraz-hint-icon" width="10" height="10" viewBox="0 0 10 10" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect width="10" height="10" fill="var(--sekianafraz-black)"></rect></svg><span>لیست سنسورها</span></div><div class="sekianafraz-actions-right"><div class="sekianafraz-bulk-actions" id="sekianafraz-bulk-actions" hidden><button class="sekianafraz-btn" id="sekianafraz-bulk-enable">فعال کردن همه</button><button class="sekianafraz-btn" id="sekianafraz-bulk-disable">غیرفعال کردن همه</button><button class="sekianafraz-btn danger" id="sekianafraz-bulk-delete">حذف همه</button></div><button id="sekianafraz-add-sensor" class="sekianafraz-btn primary"><svg class="sekianafraz-btn-icon-plus" width="13" height="13" viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" overflow="visible"><line class="sekianafraz-plus-line sekianafraz-plus-line--v" x1="6" y1="1.1" x2="6" y2="10.9" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></line><line class="sekianafraz-plus-line sekianafraz-plus-line--h" x1="1.1" y1="6" x2="10.9" y2="6" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"></line></svg><span>افزودن سنسور جدید</span></button></div></div>';
        $page = 1;
        $perPage = 20;
        $paged = (new SensorService())->listPaged($page, $perPage);
        $sensors = $paged['items'];
        $hasMore = $paged['has_more'];
        echo '<div class="sekianafraz-listing">';
        if (empty($sensors)) {
            ListingTable::emptyState('هیچ سنسوری ساخته نشده است!', 'برای افزودن سنسور بازدید، روی «افزودن سنسور جدید» کلیک کنید.');
        } else {
            ListingTable::open('<th class="sekianafraz-select-col"><label class="checkBox"><input type="checkbox" id="sekianafraz-select-all"><div class="transition"></div></label></th><th>نام</th><th>وضعیت</th><th>شرط اکشن</th><th>بازه</th><th>آیتم‌ها</th><th class="rsad-actions-td"><span class="rsad-actions-heading">عملیات</span></th>');
            echo '<tbody id="sekianafraz-sensors-body" data-page="'.$page.'" data-has-more="'.($hasMore ? '1' : '0').'">';
            foreach ($sensors as $s) {
                $edit = esc_attr($s['id']);
                $status = ($s['status'] ?? 'publish') === 'publish' ? 'publish' : 'draft';
                echo '<tr>';
                echo '<td class="sekianafraz-select-col"><label class="checkBox"><input type="checkbox" class="sekianafraz-sensor-select" data-id="'.$edit.'"><div class="transition"></div></label></td>';
                echo '<td>'.esc_html($s['name']).'</td>';
                echo '<td class="sekianafraz-sensor-status">'.($status === 'publish' ? 'فعال' : 'غیرفعال').'</td>';
                echo '<td>'.esc_html($this->visitConditionLabel($s)).'</td>';
                echo '<td>'.esc_html($s['window']).'</td>';
                echo '<td>';
                $labels = (array)($s['item_labels'] ?? []);
                foreach ($labels as $lab) {
                    echo '<span class="sekianafraz-chip" style="cursor:default">'.esc_html($lab).'</span> ';
                }
                echo '</td>';
                echo '<td class="rsad-actions-td"><div class="rsad-actions"><button type="button" class="rsad-btn rsad-btn--status sekianafraz-status-toggle" data-id="'.$edit.'" aria-pressed="'.($status === 'publish' ? 'true' : 'false').'"><span class="rsad-status-radio" aria-hidden="true"></span><span class="rsad-status-label">'.($status === 'publish' ? 'غیرفعال‌سازی' : 'فعال‌سازی').'</span></button><button type="button" class="rsad-btn rsad-btn--edit" data-edit="'.$edit.'"><span class="dashicons dashicons-edit"></span>ویرایش</button><button type="button" class="rsad-btn rsad-btn--delete" data-delete="'.$edit.'"><span class="dashicons dashicons-trash"></span>حذف</button></div></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
            if ($hasMore) {
                echo '<div id="sekianafraz-sensor-loader" class="sekianafraz-sensor-loader" hidden><span class="sekianafraz-sensor-spinner" aria-hidden="true"></span><span>در حال بارگذاری…</span></div>';
            }
        }
        echo '</div>';
        echo '</div></div>';
        echo '<div id="sekianafraz-sensor-modal" class="sekianafraz-modal" hidden></div>';
    }
    private function visitConditionLabel(array $sensor): string
    {
        $metric = (string)($sensor['visit_metric'] ?? 'views');
        $views = max(1, (int)($sensor['min_views'] ?? 1));
        $duration = max(1, (int)($sensor['min_duration'] ?? 1));
        if ($metric === 'duration') return $duration . ' ثانیه بازدید';
        if ($metric === 'both') return $views . ' بار بازدید ' . (($sensor['visit_condition'] ?? 'or') === 'and' ? 'و' : 'یا') . ' ' . $duration . ' ثانیه بازدید';
        return $views . ' بار بازدید';
    }
}
