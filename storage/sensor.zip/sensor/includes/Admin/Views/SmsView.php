<?php
namespace SeKianAfraz\VisitDiscount\Admin\Views;
if (!defined('ABSPATH')) { exit; }
class SmsView
{
    public function output(): void
    {
        $options = \SeKianAfraz\VisitDiscount\SMS\CredentialsVault::load();
        $providerRaw = $options['provider'] ?? 'melipayamak';
        $provider = is_array($providerRaw) ? 'melipayamak' : sanitize_text_field((string) $providerRaw);
        $hint = static function (string $title): void {
            echo '<div class="hint"><svg class="sekianafraz-hint-icon" width="10" height="10" viewBox="0 0 10 10" aria-hidden="true"><rect width="10" height="10" fill="var(--sekianafraz-black)"/></svg><span>'.esc_html($title).'</span></div>';
        };
        echo '<div class="sekianafraz-card sekianafraz-card-transparent"><div class="sekianafraz-sms-layout">';
        echo '<section class="sekianafraz-sms-panel">';
        $hint('تنظیم پنل پیامک');
        echo '<div class="sekianafraz-sms-box">';
        echo '<div class="sekianafraz-card-body sekianafraz-sms-fields">';
        echo '<div class="sekianafraz-sms-fields-top">';
        echo '<div class="sekianafraz-field"><label>درگاه پیامکی</label>';
        echo '<select id="sekianafraz-sms-provider">';
        $items = [
            'melipayamak' => 'ملی پیامک',
            'kavenegar' => 'کاوه‌نگار',
            'ippanel' => 'IPPanel',
            'smsir' => 'SMS.ir',
            'smslogin' => 'SMSLogin',
        ];
        foreach ($items as $key => $label) {
            $sel = $provider === $key ? 'selected' : '';
            echo '<option value="'.esc_attr($key).'" '.$sel.'>'.esc_html($label).'</option>';
        }
        echo '</select></div>';
        echo '<div id="sekianafraz-sms-provider-fields"></div>';
        echo '</div>';
        echo '<div class="sekianafraz-sms-fields-bottom">';
        echo '<div class="sekianafraz-actions">';
        echo '<button id="sekianafraz-sms-save" class="sekianafraz-btn primary">'.esc_html__('ذخیره', 'sekianafraz-visit-discount').'</button>';
        echo '<button id="sekianafraz-sms-test" class="sekianafraz-btn">'.esc_html__('تست اتصال و نمایش موجودی', 'sekianafraz-visit-discount').'</button>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div></section>';
        echo '<section class="sekianafraz-sms-panel sekianafraz-sms-panel--compat">';
        echo '<div class="hint sekianafraz-compat-heading"><svg class="sekianafraz-hint-icon" width="10" height="10" viewBox="0 0 10 10" aria-hidden="true"><rect width="10" height="10" fill="var(--sekianafraz-black)"/></svg><span>سازگاری با افزونه‌ها و قالب‌ها</span><button type="button" id="sekianafraz-compat-scan" class="sekianafraz-compat-scan" aria-label="شناسایی خودکار متای شماره تلفن کاربران" title="شناسایی خودکار متای شماره تلفن کاربران"><svg class="sekianafraz-compat-scan-icon" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16"/><path d="M16 16h5v5"/></svg></button></div>';
        echo '<div class="sekianafraz-sms-box">';
        echo '<div class="sekianafraz-compat sekianafraz-sms-fields">';
        echo '<div class="sekianafraz-compat-inner">';
        echo '<div class="sekianafraz-compat-top">';
        echo '<ul class="sekianafraz-list" id="sekianafraz-compat-list">';
        $compat = ['دیجیتس','احراز','کراسنو','پنل کاربری ویرا','هدهد','ایزی لاگین','قالب آموزشیار','قالب استادشو'];
        foreach ($compat as $c) {
            echo '<li><span>'.esc_html($c).'</span></li>';
        }
        $customCompat = get_option('sekianafraz_phone_compat_custom', []);
        if (is_array($customCompat)) {
            foreach ($customCompat as $item) {
                $label = isset($item['label']) ? sanitize_text_field($item['label']) : '';
                $id = isset($item['id']) ? sanitize_text_field($item['id']) : '';
                if ($label === '' || $id === '') continue;
                $metaKey = isset($item['meta_key']) ? sanitize_text_field($item['meta_key']) : '';
                echo '<li class="sekianafraz-compat-item is-custom" data-id="'.esc_attr($id).'" data-meta-key="'.esc_attr($metaKey).'"><span>'.esc_html($label).'</span><button type="button" class="sekianafraz-compat-remove" aria-label="حذف سازگاری"><svg viewBox="0 0 20 20" aria-hidden="true"><path d="M5 5l10 10M15 5L5 15" fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="1.5"/></svg></button></li>';
            }
        }
        echo '</ul>';
        echo '</div>';
        echo '<div class="sekianafraz-compat-bottom">';
        echo '<div class="sekianafraz-compat-form">';
        echo '<div class="sekianafraz-compat-fields">';
        echo '<div class="sekianafraz-field"><input id="sekianafraz-compat-name" type="text" placeholder="نام" /></div>';
        echo '<div class="sekianafraz-field"><input id="sekianafraz-compat-meta" type="text" placeholder="کلید متا" /></div>';
        echo '</div>';
        echo '<div class="sekianafraz-compat-action">';
        echo '<button id="sekianafraz-compat-save" type="button" class="sekianafraz-btn primary">ذخیره</button>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</section>';
        echo '</div>';
        echo '<section class="sekianafraz-tests" dir="rtl" lang="fa">';
        echo '<div class="sekianafraz-tests__grid">';
        echo '<article class="sekianafraz-test">';
        echo '<header class="sekianafraz-test__head">';
        $hint('تست شناسایی کاربر');
        echo '</header><div class="sekianafraz-test-box">';
        echo '<div class="sekianafraz-test-row">';
        echo '<div class="sekianafraz-test-fields">';
        echo '<div class="sekianafraz-field">';
        echo '<input id="sekianafraz-user-id" type="text" inputmode="numeric" placeholder="آیدی یوزر (User ID)" />';
        echo '</div>';
        echo '</div>';
        echo '<div class="sekianafraz-test-action">';
        echo '<button class="sekianafraz-btn" id="sekianafraz-test-resolve" type="button">تست شناسایی</button>';
        echo '</div>';
        echo '</div></div>';
        echo '</article>';
        echo '<article class="sekianafraz-test">';
        echo '<header class="sekianafraz-test__head">';
        $hint('تست ارسال پیام');
        echo '</header><div class="sekianafraz-test-box">';
        echo '<div class="sekianafraz-test-row">';
        echo '<div class="sekianafraz-test-fields">';
        echo '<div class="sekianafraz-field">';
        echo '<input id="sekianafraz-dest-1" type="tel" inputmode="tel" placeholder="شماره مقصد" />';
        echo '</div>';
        echo '</div>';
        echo '<div class="sekianafraz-test-action">';
        echo '<button class="sekianafraz-btn" id="sekianafraz-test-promo" type="button">تست ارسال</button>';
        echo '</div>';
        echo '</div></div>';
        echo '</article>';
        echo '<article class="sekianafraz-test">';
        echo '<header class="sekianafraz-test__head">';
        $hint('تست وب‌سرویس خدماتی (پترن)');
        echo '</header><div class="sekianafraz-test-box">';
        echo '<div class="sekianafraz-test-row">';
        echo '<div class="sekianafraz-test-fields">';
        echo '<div class="sekianafraz-test-fields-grid">';
        echo '<div class="sekianafraz-field">';
        echo '<input id="sekianafraz-pattern-code" type="text" placeholder="کد پترن" />';
        echo '</div>';
        echo '<div class="sekianafraz-field">';
        echo '<input id="sekianafraz-dest-2" type="tel" inputmode="tel" placeholder="شماره مقصد" />';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '<div class="sekianafraz-test-action">';
        echo '<button class="sekianafraz-btn" id="sekianafraz-test-pattern" type="button">تست ارسال</button>';
        echo '</div>';
        echo '</div>';
        echo '</div>';
        echo '</article>';
        echo '</div>';
        echo '</section>';
        echo '</div>';
    }
}
