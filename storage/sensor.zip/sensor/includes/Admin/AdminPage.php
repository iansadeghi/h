<?php
namespace SeKianAfraz\VisitDiscount\Admin;
use SeKianAfraz\VisitDiscount\Admin\Views\SensorsView;
use SeKianAfraz\VisitDiscount\Admin\Views\SmsView;
use SeKianAfraz\VisitDiscount\Admin\Views\LeadsView;
if (!defined('ABSPATH')) { exit; }
class AdminPage
{
    public function render(): void
    {
        $tabs = $this->buildTabs();
        $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'sensors';
        if (!isset($tabs[$tab])) {
            $tab = 'sensors';
        }
        echo '<div class="sekianafraz-admin">';
        echo '<div class="sekianafraz-tabs">';
        echo '<div class="sekianafraz-tabs-list">';
        foreach ($tabs as $key => $label) {
            $active = $tab === $key ? 'active' : '';
            $url = esc_url(add_query_arg(['page' => 'sekianafraz', 'tab' => $key], admin_url('admin.php')));
            echo '<a class="sekianafraz-tab ' . esc_attr($active) . '" href="' . $url . '">' . esc_html($label) . '</a>';
        }
        echo '<span class="sekianafraz-tab-indicator" aria-hidden="true"></span>';
        echo '</div>';
        $logoPath = SEKIANAFRAZ_PATH . 'assets/img/sensor.svg';
        $logo = is_readable($logoPath) ? file_get_contents($logoPath) : '';
        echo '<div class="sekianafraz-brand" aria-hidden="true">';
        if (is_string($logo) && $logo !== '') {
            $logo = preg_replace('/<svg\b/', '<svg class="sekianafraz-brand-svg"', $logo, 1);
            echo $logo;
        }
        echo '</div>';
        echo '</div>';
        echo '<div class="sekianafraz-tab-content" id="sekianafraz-spa-content"></div>';
        echo '</div>';
    }
    public function renderTabContent(string $tab): void
    {
        $tabs = $this->buildTabs();
        if (!isset($tabs[$tab])) {
            $tab = 'sensors';
        }
        if ($tab === 'sensors') {
            (new SensorsView())->output();
        } elseif ($tab === 'sms') {
            (new SmsView())->output();
        } elseif ($tab === 'leads') {
            (new LeadsView())->output();
        }
    }
    public function enqueueVars(): void
    {
        $placements = [
            'product_single','product_cat','product_tag','product_in_cat','product_in_tag',
            'post_single','post_cat','post_tag','post_in_cat','post_in_tag',
            'page','custom_url','search_terms'
        ];
        $actions = [
            ['key' => 'banner', 'label' => 'نمایش بنر'],
        ];
        $actionsFiltered = apply_filters('sekianafraz_sensor_action_options', $actions);
        if (is_array($actionsFiltered) && !empty($actionsFiltered)) {
            $actions = $actionsFiltered;
        }
        wp_localize_script('sekianafraz-admin-core', 'SEKIANAFRAZAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sekianafraz_admin_nonce'),
            'restUrl' => esc_url_raw(rest_url('sekianafraz/v1/')),
            'placements' => $placements,
            'actions' => $actions,
            'currency' => $this->currencyLabel(),
        ]);
    }
    private function currencyLabel(): string
    {
        $code = function_exists('get_woocommerce_currency') ? get_woocommerce_currency() : '';
        $names = [
            'IRR' => 'ریال',
            'IRT' => 'تومان',
            'USD' => 'دلار',
            'EUR' => 'یورو',
            'GBP' => 'پوند',
            'TRY' => 'لیر ترکیه',
            'AED' => 'درهم امارات',
            'SAR' => 'ریال سعودی',
        ];
        if ($code === '') {
            return 'تومان';
        }
        return $names[$code] ?? $code;
    }
    private function buildTabs(): array
    {
        return [
            'sensors' => 'سنسورهای بازدید',
            'leads'   => 'شماره‌های جمع‌آوری‌شده',
            'sms'     => 'تنظیمات ارسال پیامک',
        ];
    }
}
