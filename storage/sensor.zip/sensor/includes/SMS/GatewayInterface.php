<?php
namespace SeKianAfraz\VisitDiscount\SMS;
if (!defined('ABSPATH')) { exit; }
interface GatewayInterface
{
    public function sendPattern(array $config, string $mobile, array $tokens, string $template): array;
    public function sendText(array $config, array $mobiles, string $message, ?string $sender = null): array;
}
