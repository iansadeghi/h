<?php
namespace SeKianAfraz\VisitDiscount\SMS;
if (!defined('ABSPATH')) { exit; }
class SMSCronService {
    const HOOK_PROCESS_QUEUE = 'sekianafraz_process_sms_queue';
    const HOOK_CONTINUE_QUEUE = 'sekianafraz_continue_sms_queue';
    const HOOK_CLEANUP_QUEUE = 'sekianafraz_cleanup_sms_queue';
    const SCHEDULE_INTERVAL = 'sekianafraz_every_minute';
    public static function registerSchedules($schedules) {
        if (!isset($schedules[self::SCHEDULE_INTERVAL])) {
            $schedules[self::SCHEDULE_INTERVAL] = [
                'interval' => 60,
                'display' => __('Every Minute', 'sekianafraz-visit-discount')
            ];
        }
        if (!isset($schedules['daily'])) {
            $schedules['daily'] = [
                'interval' => 86400,
                'display' => __('Once Daily', 'sekianafraz-visit-discount')
            ];
        }
        return $schedules;
    }
    public static function scheduleEvents() {
        if (wp_next_scheduled(self::HOOK_PROCESS_QUEUE) && wp_get_schedule(self::HOOK_PROCESS_QUEUE) !== self::SCHEDULE_INTERVAL) {
            wp_clear_scheduled_hook(self::HOOK_PROCESS_QUEUE);
        }
        if (!wp_next_scheduled(self::HOOK_PROCESS_QUEUE)) {
            wp_schedule_event(time(), self::SCHEDULE_INTERVAL, self::HOOK_PROCESS_QUEUE);
        }
        if (!wp_next_scheduled(self::HOOK_CLEANUP_QUEUE)) {
            $tomorrow_3am = strtotime('tomorrow 3:00 AM');
            wp_schedule_event($tomorrow_3am, 'daily', self::HOOK_CLEANUP_QUEUE);
        }
    }
    public static function unscheduleEvents() {
        wp_clear_scheduled_hook(self::HOOK_PROCESS_QUEUE);
        wp_clear_scheduled_hook(self::HOOK_CLEANUP_QUEUE);
        wp_clear_scheduled_hook(self::HOOK_CONTINUE_QUEUE);
        if (function_exists('as_unschedule_all_actions') && did_action('action_scheduler_init')) {
            as_unschedule_all_actions(self::HOOK_CONTINUE_QUEUE, [], 'sekianafraz');
        }
    }
    public static function processQueue() {
        $started = microtime(true);
        $budget = max(1, min(20, (int)apply_filters('sekianafraz_sms_queue_time_budget', 10)));
        $maximum = max(1, min(500, (int)apply_filters('sekianafraz_sms_queue_max_jobs', 100)));
        $batchSize = max(1, min(50, (int)apply_filters('sekianafraz_sms_queue_batch_size', 10)));
        $processed = 0;
        $settings = null;
        while ($processed < $maximum && microtime(true) - $started < $budget) {
            $jobs = SMSQueueService::claimJobs(min($batchSize, $maximum - $processed));
            if (!$jobs) return;
            if ($settings === null) $settings = CredentialsVault::load();
            _prime_post_caches(array_values(array_unique(array_map(static function ($job) { return (int)$job->sensor_id; }, $jobs))), false, false);
            $claim = (string)$jobs[0]->claimed_by;
            try {
                foreach ($jobs as $job) {
                    if (microtime(true) - $started >= $budget) break;
                    $processed++;
                    try {
                        if (get_post_type((int)$job->sensor_id) !== 'sekianafraz_sensor' || get_post_status((int)$job->sensor_id) !== 'publish'
                            || !\SeKianAfraz\VisitDiscount\Coupons\CouponAvailability::usable((string)$job->coupon_code)) {
                            SMSQueueService::cancelJob((int)$job->id, $claim, 'سنسور غیرفعال است یا کد تخفیف دیگر معتبر نیست.');
                            continue;
                        }
                        if (!SMSQueueService::beginDelivery((int)$job->id, $claim)) continue;
                        $result = self::sendSMS($job, $settings);
                        if ($result['success']) SMSQueueService::markAsSent($job->id, $claim);
                        elseif (!empty($result['delivery_uncertain'])) SMSQueueService::cancelJob((int)$job->id, $claim, SMSQueueService::DELIVERY_PENDING);
                        else SMSQueueService::markAsFailed($job->id, $result['error'] ?? 'Unknown error', $claim);
                        usleep(100000);
                    } catch (\Throwable $error) {
                        SMSQueueService::cancelJob((int)$job->id, $claim, SMSQueueService::DELIVERY_PENDING);
                        self::debugLog('Queue error: ' . $error->getMessage());
                    }
                }
            } finally {
                SMSQueueService::releaseClaimedJobsByRunId($claim);
            }
        }
        if (SMSQueueService::getPendingJobs(1)) self::scheduleContinuation();
    }
    private static function scheduleContinuation(): void
    {
        global $wpdb;
        $lock = 'sekianafraz_sms_schedule_' . md5(DB_NAME . '|' . $wpdb->prefix);
        if ((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)', $lock)) !== 1) return;
        try {
            if (function_exists('as_get_scheduled_actions') && did_action('action_scheduler_init')) {
                $pending = as_get_scheduled_actions([
                    'hook' => self::HOOK_CONTINUE_QUEUE, 'group' => 'sekianafraz', 'status' => 'pending', 'per_page' => 1,
                ], 'ids');
                if ($pending || as_schedule_single_action(time() + 1, self::HOOK_CONTINUE_QUEUE, [], 'sekianafraz')) return;
            }
            if (!wp_next_scheduled(self::HOOK_CONTINUE_QUEUE)) wp_schedule_single_event(time() + 5, self::HOOK_CONTINUE_QUEUE);
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }
    private static function sendSMS($job, array $settings) {
        try {
            $phone = sanitize_text_field($job->phone);
            $message = sanitize_textarea_field((string)$job->message);
            $configuredProvider = sanitize_key((string)($settings['provider'] ?? 'melipayamak'));
            $queuedProvider = sanitize_key((string)($job->provider ?? ''));
            $provider = $queuedProvider !== '' ? $queuedProvider : $configuredProvider;
            if ($provider !== $configuredProvider) {
                return ['success' => false, 'error' => 'درگاه پیامک پس از زمان‌بندی این پیام تغییر کرده است.'];
            }
            $gateway = SmsService::gateway($provider);
            if (!$gateway) {
                return ['success' => false, 'error' => 'درگاه پیامک معتبر نیست.'];
            }
            $config = (array)($settings['config'] ?? []);
            $mode = (($job->mode ?? 'promo') === 'pattern') ? 'pattern' : 'promo';
            if ($mode === 'pattern') {
                $tokens = json_decode((string)($job->tokens ?? ''), true);
                if (!is_array($tokens)) $tokens = [];
                $templateId = sanitize_text_field((string)($job->template_id ?? ''));
                if ($templateId === '') {
                    return ['success' => false, 'error' => 'شناسه پترن در صف موجود نیست.'];
                }
                $result = $gateway->sendPattern($config, $phone, $tokens, $templateId);
            } else {
                $result = $gateway->sendText($config, [$phone], $message, $config['sender'] ?? null);
            }
            return [
                'success' => $result['success'] ?? false,
                'delivery_uncertain' => SmsService::deliveryUncertain($result),
                'error' => $result['error'] ?? $result['message'] ?? 'Unknown error'
            ];
        } catch (\Throwable $e) {
            return [
                'success' => false,
                'delivery_uncertain' => true,
                'error' => $e->getMessage()
            ];
        }
    }
    public static function cleanupQueue() {
        (new \SeKianAfraz\VisitDiscount\Cron\Cleanup())->run();
    }
    public static function getNextRun() {
        return wp_next_scheduled(self::HOOK_PROCESS_QUEUE);
    }
    public static function triggerNow() {
        self::processQueue();
    }
    private static function debugLog(string $message): void
    {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('SeKianAfraz SMS: ' . sanitize_text_field($message));
        }
    }
}
