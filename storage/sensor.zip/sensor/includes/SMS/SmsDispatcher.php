<?php
namespace SeKianAfraz\VisitDiscount\SMS;
use SeKianAfraz\VisitDiscount\SMS\SmsService;
use SeKianAfraz\VisitDiscount\SMS\SMSQueueService;
if (!defined('ABSPATH')) { exit; }
class SmsDispatcher
{
    private $logger;
    public function __construct(?callable $logger = null)
    {
        $this->logger = $logger;
    }
    public function dispatch(
        int $sensorId,
        int $userId,
        string $guestId,
        string $phone,
        string $provider,
        array $config,
        string $mode,
        string $message,
        array $vars,
        string $delayType,
        int $delayMinutes,
        string $couponCode,
        ?string $patternOverride = null
    ): array
    {
        if ($delayType === 'delayed' && $delayMinutes > 0) {
            if (!class_exists('SeKianAfraz\VisitDiscount\\SMS\\SMSQueueService')) {
                $response = ['success' => false, 'code' => 'QUEUE_UNAVAILABLE', 'message' => 'صف ارسال پیامک در دسترس نیست.'];
                $status = ['success' => false, 'error' => 'QUEUE_UNAVAILABLE'];
                return ['status' => $status, 'response' => $response];
            }
            $templateId = '';
            $tokens = [];
            if ($mode === 'pattern') {
                $patternString = $patternOverride ?? (string)get_post_meta($sensorId, 'sms_pattern', true);
                $pattern = $this->parsePattern($patternString, $vars, $provider);
                $templateId = (string)$pattern['template_id'];
                $tokens = (array)$pattern['tokens'];
            }
            $queueId = SMSQueueService::enqueue(
                $phone,
                $message,
                $couponCode,
                $sensorId,
                $delayMinutes,
                $provider,
                $mode,
                $templateId,
                $tokens
            );
            if ($queueId) {
                $this->log($sensorId, $userId, $guestId, 'sms_queued', $couponCode);
                $status = ['success' => true, 'queued' => true, 'delay_minutes' => $delayMinutes];
                $response = ['success' => true, 'code' => 'SMS_QUEUED', 'message' => '', 'data' => ['queued' => true, 'delay_minutes' => $delayMinutes]];
                return ['status' => $status, 'response' => $response];
            }
            $response = ['success' => false, 'code' => 'QUEUE_FAILED', 'message' => ''];
            $status = ['success' => false, 'error' => 'Queue failed'];
            return ['status' => $status, 'response' => $response];
        }
        $gateway = SmsService::gateway($provider);
        if ($gateway === null) {
            $response = ['success' => false, 'code' => 'NO_GATEWAY', 'message' => ''];
            $status = ['success' => false, 'error' => 'NO_GATEWAY'];
            return ['status' => $status, 'response' => $response];
        }
        $attemptLogger = new \SeKianAfraz\VisitDiscount\Logs\ActionLogger();
        $attemptLogger->log($sensorId, $userId, $guestId, 'sms_attempt', $couponCode);
        $res = [];
        if ($mode === 'pattern') {
            $pattern_string = $patternOverride ?? (string)get_post_meta($sensorId, 'sms_pattern', true);
            $pattern = $this->parsePattern($pattern_string, $vars, $provider);
            $res = $gateway->sendPattern($config, $phone, $pattern['tokens'], $pattern['template_id']);
        } else {
            $res = $gateway->sendText($config, [$phone], $message, $config['sender'] ?? null);
        }
        if (empty($res['success']) && !SmsService::deliveryUncertain($res)) {
            global $wpdb;
            $wpdb->delete($wpdb->prefix . 'sekianafraz_action_log', array_filter([
                'sensor_id' => $sensorId, 'user_id' => $userId, 'guest_id' => $guestId ?: null,
                'action_type' => 'sms_attempt', 'coupon_code' => $couponCode,
            ], static function ($value) { return $value !== null; }));
        }
        if (($res['success'] ?? false)) {
            $this->log($sensorId, $userId, $guestId, 'sms_sent', $couponCode);
        }
        if (SmsService::deliveryUncertain($res)) $res['delivery_uncertain'] = true;
        $response = ['success' => $res['success'] ?? false, 'code' => 'SMS', 'message' => '', 'data' => ['sent' => $res]];
        return ['status' => $res, 'response' => $response];
    }
    private function parsePattern(string $pattern_string, array $vars, string $provider): array
    {
        $lines = array_map('trim', explode("\n", $pattern_string));
        $template_id = array_shift($lines) ?: '';
        $ordered_values = [];
        $named = [];
        foreach ($lines as $line) {
            $var_name = trim($line, ' {}');
            $val = $vars[$var_name] ?? '';
            $ordered_values[] = $val;
            $named[$var_name] = $val;
        }
        if (in_array($provider, ['ippanel','smsir'], true)) {
            $tokens = $named;
        } else {
            $tokens = ['_ordered' => $ordered_values];
        }
        return [
            'template_id' => $template_id,
            'tokens' => $tokens,
        ];
    }
    private function log(int $sensorId, int $userId, string $guestId, string $type, string $couponCode): void
    {
        if (is_callable($this->logger)) {
            call_user_func($this->logger, $sensorId, $userId, $guestId, $type, $couponCode);
        }
    }
}
