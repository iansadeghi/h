<?php
namespace SeKianAfraz\VisitDiscount\SMS\Providers;
use SeKianAfraz\VisitDiscount\SMS\GatewayInterface;
if (!defined('ABSPATH')) { exit; }
class MeliPayamak implements GatewayInterface
{
	public function sendPattern(array $config, string $mobile, array $tokens, string $bodyId): array
	{
		$username = trim($config['username'] ?? ($config['originator'] ?? ''));
		$password = trim($config['api_key'] ?? '');
		if ($username === '' || $password === '') return ['success' => false, 'error' => 'Missing username or api_key'];
		$text = '';
		if (isset($tokens['_ordered']) && is_array($tokens['_ordered'])) {
			$vals = array_map(function($v){
				$s = (string)$v;
				$s = str_replace(["\r","\n"], ' ', $s);
				$s = str_replace(';', '%3B', $s);
				return trim($s);
			}, array_values($tokens['_ordered']));
			$text = implode(';', $vals);
		} elseif (isset($tokens['code'])) {
			$text = (string)$tokens['code'];
		} elseif (isset($tokens['token']) || isset($tokens['token2']) || isset($tokens['token3'])) {
			$vals = [];
			if (isset($tokens['token'])) $vals[] = (string)$tokens['token'];
			if (isset($tokens['token2'])) $vals[] = (string)$tokens['token2'];
			if (isset($tokens['token3'])) $vals[] = (string)$tokens['token3'];
			$text = implode(';', $vals);
		} elseif (isset($tokens['username']) || isset($tokens['password'])) {
			$text = ($tokens['username'] ?? '') . ';' . ($tokens['password'] ?? '');
		}
		$data = http_build_query(['username' => $username, 'password' => $password, 'to' => $mobile, 'text' => $text, 'bodyId' => $bodyId]);
		$r = $this->request('https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber', $data);
		return $this->normalize($r);
	}
	public function sendText(array $config, array $mobiles, string $message, ?string $sender = null): array
	{
		$username = trim($config['username'] ?? ($config['originator'] ?? ''));
		$password = trim($config['api_key'] ?? '');
		if ($username === '' || $password === '') return ['success' => false, 'error' => 'Missing username or api_key'];
		$to = array_values(array_filter(array_map('trim', $mobiles)));
		if (empty($to)) return ['success' => false, 'error' => 'No recipient provided'];
		$params = ['username' => $username, 'password' => $password, 'to' => implode(',', $to), 'text' => $message];
		$line = (string)($sender ?? ($config['sender'] ?? ''));
		if ($line !== '') $params['from'] = $line;
		$params['isFlash'] = false;
		$data = http_build_query($params);
		$r = $this->request('https://rest.payamak-panel.com/api/SendSMS/SendSMS', $data);
		return $this->normalize($r);
	}
	private function request(string $url, string $body): array
	{
		$response = wp_remote_post($url, [
			'timeout' => 15,
			'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
			'body' => $body,
		]);
		if (is_wp_error($response)) {
			return ['code' => 0, 'body' => '', 'error' => $response->get_error_message()];
		}
		return [
			'code' => (int)wp_remote_retrieve_response_code($response),
			'body' => (string)wp_remote_retrieve_body($response),
			'error' => '',
		];
	}
	private function normalize(array $raw): array
	{
		$body = $raw['body'] ?? '';
		$decoded = json_decode($body, true);
		$httpOk = ($raw['code'] ?? 0) >= 200 && ($raw['code'] ?? 0) < 300;
        $success = $httpOk && is_array($decoded) && isset($decoded['RetStatus']) && (int)$decoded['RetStatus'] === 1;
        $error = '';
        if (!$success) {
            $detail = is_array($decoded) ? ($decoded['StrRetStatus'] ?? $decoded['Message'] ?? '') : '';
            $error = is_scalar($detail) ? trim((string)$detail) : '';
            if ($error === '') $error = !empty($raw['error']) ? (string)$raw['error'] : 'پاسخ معتبر تأیید ارسال از ملی پیامک دریافت نشد.';
        }
		return ['success' => $success, 'status' => $raw['code'] ?? 0, 'provider_response' => $decoded ?: ($body ?? ''), 'error' => $error];
	}
}
