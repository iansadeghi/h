<?php
namespace SeKianAfraz\VisitDiscount\SMS\Providers;
use SeKianAfraz\VisitDiscount\SMS\GatewayInterface;
if (!defined('ABSPATH')) { exit; }
class Kavenegar implements GatewayInterface
{
    public function sendPattern(array $config, string $mobile, array $tokens, string $template): array
    {
        $apiKey = trim($config['api_key'] ?? '');
        if ($apiKey === '') return ['success' => false, 'error' => 'Missing api_key'];
        if (isset($tokens['_ordered']) && is_array($tokens['_ordered'])) {
            $ord = array_values($tokens['_ordered']);
            $tokens = [
                'token' => $ord[0] ?? '',
                'token2' => $ord[1] ?? '',
                'token3' => $ord[2] ?? '',
                'token10' => $ord[3] ?? '',
                'token20' => $ord[4] ?? '',
            ];
        }
        $url = sprintf('https://api.kavenegar.com/v1/%s/verify/lookup.json', urlencode($apiKey));
        $payload = [
            'receptor' => $mobile,
            'token' => $tokens['token'] ?? ($tokens['code'] ?? ''),
            'token2' => $tokens['token2'] ?? ($tokens['username'] ?? ''),
            'token3' => $tokens['token3'] ?? ($tokens['password'] ?? ''),
            'token10' => $tokens['token10'] ?? '',
            'token20' => $tokens['token20'] ?? '',
            'template' => $template,
            'type' => 'sms'
        ];
        $r = $this->request($url.'?'.http_build_query($payload), null);
        return $this->normalize($r);
    }
    public function sendText(array $config, array $mobiles, string $message, ?string $sender = null): array
    {
        $apiKey = trim($config['api_key'] ?? '');
        if ($apiKey === '') return ['success' => false, 'error' => 'Missing api_key'];
        $clean = array_values(array_filter(array_map('trim', $mobiles)));
        if (empty($clean)) return ['success' => false, 'error' => 'No recipient provided'];
        $url = sprintf('https://api.kavenegar.com/v1/%s/sms/send.json', urlencode($apiKey));
        $payload = ['receptor' => implode(',', $clean), 'message' => $message];
        $line = trim((string)($sender ?: ($config['sender'] ?? '')));
        if ($line !== '') $payload['sender'] = $line;
        $r = $this->request($url, http_build_query($payload));
        return $this->normalize($r);
    }
    private function request(string $url, ?string $postForm): array
    {
        $args = ['timeout' => 15];
        $response = $postForm === null
            ? wp_remote_get($url, $args)
            : wp_remote_post($url, $args + [
                'headers' => ['Content-Type' => 'application/x-www-form-urlencoded'],
                'body' => $postForm,
            ]);
        if (is_wp_error($response)) {
            return ['code' => 0, 'body' => '', 'error' => $response->get_error_message()];
        }
        return [
            'code' => (int)wp_remote_retrieve_response_code($response),
            'body' => (string)wp_remote_retrieve_body($response),
            'error' => '',
        ];
    }
    private function normalize(array $raw): array
    {
        $decoded = json_decode($raw['body'] ?? '', true);
        $httpOk = ($raw['code'] ?? 0) >= 200 && ($raw['code'] ?? 0) < 300;
        $apiStatus = is_array($decoded) ? (int)($decoded['return']['status'] ?? 0) : 0;
        $ok = $httpOk && $apiStatus === 200;
        $error = $ok ? null : (is_array($decoded) ? (string)($decoded['return']['message'] ?? '') : '');
        if ($error === '') $error = (string)($raw['error'] ?? 'Unknown Kavenegar error');
        return ['success' => $ok, 'status' => $raw['code'] ?? 0, 'provider_response' => $decoded ?: ($raw['body'] ?? ''), 'error' => $error];
    }
}
