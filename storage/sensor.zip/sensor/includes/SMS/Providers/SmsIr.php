<?php
namespace SeKianAfraz\VisitDiscount\SMS\Providers;
use SeKianAfraz\VisitDiscount\SMS\GatewayInterface;
if (!defined('ABSPATH')) { exit; }
class SmsIr implements GatewayInterface
{
    public function sendPattern(array $config, string $mobile, array $tokens, string $templateId): array
    {
        $apiKey = trim($config['api_key'] ?? '');
        if ($apiKey === '') return ['success' => false, 'error' => 'Missing api_key'];
        $templateId = trim($templateId);
        if ($templateId === '' || !ctype_digit($templateId)) {
            return ['success' => false, 'error' => 'Template ID must be numeric'];
        }
        if (isset($tokens['_ordered'])) unset($tokens['_ordered']);
        $parameters = [];
        foreach ($tokens as $name => $value) $parameters[] = ['name' => (string)$name, 'value' => (string)$value];
        $payload = wp_json_encode(['templateId' => (int)$templateId, 'mobile' => $mobile, 'parameters' => $parameters]);
        $r = $this->request('https://api.sms.ir/v1/send/verify', $payload, $apiKey);
        return $this->normalize($r);
    }
    public function sendText(array $config, array $mobiles, string $message, ?string $sender = null): array
    {
        $apiKey = trim($config['api_key'] ?? '');
        if ($apiKey === '') return ['success' => false, 'error' => 'Missing api_key'];
        $lineNumber = trim((string)($sender ?: ($config['sender'] ?? '')));
        if ($lineNumber === '' || !ctype_digit($lineNumber)) {
            return ['success' => false, 'error' => 'Sender line number must be numeric'];
        }
        $to = array_values(array_filter(array_map('trim', $mobiles)));
        if (empty($to)) return ['success' => false, 'error' => 'No recipient provided'];
        $payload = wp_json_encode(['lineNumber' => (int)$lineNumber, 'messageText' => $message, 'mobiles' => $to]);
        $r = $this->request('https://api.sms.ir/v1/send/bulk', $payload, $apiKey);
        return $this->normalize($r);
    }
    private function request(string $url, string $body, string $apiKey): array
    {
        $response = wp_remote_post($url, [
            'timeout' => 15,
            'headers' => ['x-api-key' => $apiKey, 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
            'body' => $body,
            'data_format' => 'body',
        ]);
        if (is_wp_error($response)) {
            return ['code' => 0, 'body' => '', 'error' => $response->get_error_message()];
        }
        return [
            'code' => (int)wp_remote_retrieve_response_code($response),
            'body' => (string)wp_remote_retrieve_body($response),
            'error' => '',
        ];
    }
    private function normalize(array $raw): array
    {
        $decoded = json_decode($raw['body'] ?? '', true);
        $httpOk = ($raw['code'] ?? 0) >= 200 && ($raw['code'] ?? 0) < 300;
        $apiOk = is_array($decoded) && isset($decoded['status']) && (int)$decoded['status'] === 1;
        $ok = $httpOk && $apiOk;
        $error = $ok ? null : (is_array($decoded) ? (string)($decoded['message'] ?? '') : '');
        if ($error === '') $error = (string)($raw['error'] ?? 'Unknown SMS.ir error');
        return ['success' => $ok, 'status' => $raw['code'] ?? 0, 'provider_response' => $decoded ?: ($raw['body'] ?? ''), 'error' => $error];
    }
}
