<?php
namespace SeKianAfraz\VisitDiscount\SMS\Providers;
use SeKianAfraz\VisitDiscount\SMS\GatewayInterface;
if (!defined('ABSPATH')) { exit; }
class IPPanel implements GatewayInterface
{
    private const ENDPOINT = 'https://edge.ippanel.com/v1/api/send';
    public function sendPattern(array $config, string $mobile, array $tokens, string $template): array
    {
        $apiKey = trim((string)($config['api_key'] ?? ''));
        $sender = trim((string)($config['sender'] ?? ''));
        $mobile = $this->normalizePhone($mobile);
        $template = trim($template);
        if ($apiKey === '' || $sender === '' || $mobile === '' || $template === '') {
            return ['success' => false, 'error' => 'api_key، sender، شماره و کد پترن الزامی هستند.'];
        }
        return $this->request($apiKey, [
            'sending_type' => 'pattern',
            'from_number' => $sender,
            'code' => $template,
            'recipients' => [$mobile],
            'params' => $tokens,
        ]);
    }
    public function sendText(array $config, array $mobiles, string $message, ?string $sender = null): array
    {
        $apiKey = trim((string)($config['api_key'] ?? ''));
        $from = trim((string)($sender ?: ($config['sender'] ?? '')));
        $recipients = array_values(array_unique(array_filter(array_map([$this, 'normalizePhone'], $mobiles))));
        if ($apiKey === '' || $from === '') {
            return ['success' => false, 'error' => 'api_key و sender الزامی هستند.'];
        }
        if (empty($recipients) || trim($message) === '') {
            return ['success' => false, 'error' => 'شماره گیرنده و متن پیام الزامی هستند.'];
        }
        return $this->request($apiKey, [
            'sending_type' => 'webservice',
            'from_number' => $from,
            'message' => $message,
            'params' => ['recipients' => $recipients],
        ]);
    }
    private function request(string $apiKey, array $payload): array
    {
        $response = wp_remote_post(self::ENDPOINT, [
            'timeout' => 15,
            'headers' => [
                'Authorization' => $apiKey,
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ],
            'body' => wp_json_encode($payload),
            'data_format' => 'body',
        ]);
        if (is_wp_error($response)) {
            return ['success' => false, 'status' => 0, 'error' => $response->get_error_message()];
        }
        $status = (int)wp_remote_retrieve_response_code($response);
        $body = (string)wp_remote_retrieve_body($response);
        $decoded = json_decode($body, true);
        $metaOk = is_array($decoded) && in_array($decoded['meta']['status'] ?? false, [true, 1], true);
        $success = $status === 200 && $metaOk;
        if ($success) {
            return ['success' => true, 'status' => $status, 'response' => $decoded ?: $body];
        }
        $error = '';
        if (is_array($decoded)) {
            $detail = $decoded['meta']['message'] ?? $decoded['message'] ?? $decoded['error'] ?? '';
            $error = is_scalar($detail) ? (string)$detail : '';
        }
        if ($error === '') $error = 'خطای سرویس IPPanel با کد ' . $status;
        return ['success' => false, 'status' => $status, 'error' => $error, 'response' => $decoded ?: $body];
    }
    private function normalizePhone($phone): string
    {
        $phone = preg_replace('/\D+/', '', (string)$phone);
        if ($phone === '') return '';
        if (strpos($phone, '0098') === 0) return '+98' . substr($phone, 4);
        if (strpos($phone, '98') === 0) return '+' . $phone;
        if (strpos($phone, '0') === 0) return '+98' . substr($phone, 1);
        if (strpos($phone, '9') === 0) return '+98' . $phone;
        return '+' . $phone;
    }
}
