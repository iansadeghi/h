<?php
namespace SeKianAfraz\VisitDiscount\SMS\Providers;
use SeKianAfraz\VisitDiscount\SMS\GatewayInterface;
if (!defined('ABSPATH')) { exit; }
class SmsLogin implements GatewayInterface
{
    public function sendPattern(array $config, string $mobile, array $tokens, string $otpId): array
    {
        $apiKey = trim($config['api_key'] ?? '');
        if ($apiKey === '') return ['success' => false, 'error' => 'Missing api_key'];
        $replace = [];
        if (isset($tokens['_ordered']) && is_array($tokens['_ordered'])) {
            $replace = array_values($tokens['_ordered']);
        } elseif (isset($tokens['code'])) $replace = [$tokens['code']];
        elseif (isset($tokens['username']) || isset($tokens['password'])) $replace = [($tokens['username'] ?? ''), ($tokens['password'] ?? '')];
        $payload = wp_json_encode(['OtpId' => $otpId, 'ReplaceToken' => $replace, 'MobileNumber' => $mobile]);
        $r = $this->request('https://api.limosms.com/api/sendpatternmessage', $payload, $apiKey);
        return $this->normalize($r);
    }
    public function sendText(array $config, array $mobiles, string $message, ?string $sender = null): array
    {
        $apiKey = trim($config['api_key'] ?? '');
        if ($apiKey === '') return ['success' => false, 'error' => 'Missing api_key'];
        $line = trim((string)($sender ?: ($config['sender'] ?? '')));
        if ($line === '') return ['success' => false, 'error' => 'Missing sender number'];
        $to = array_values(array_filter(array_map('trim', $mobiles)));
        if (empty($to)) return ['success' => false, 'error' => 'No recipient provided'];
        $payload = wp_json_encode(['Message' => $message, 'SenderNumber' => $line, 'MobileNumber' => $to, 'SendToBlocksNumber' => true]);
        $r = $this->request('https://api.limosms.com/api/sendsms', $payload, $apiKey);
        return $this->normalize($r);
    }
    private function request(string $url, string $body, string $apiKey): array
    {
        $response = wp_remote_post($url, [
            'timeout' => 15,
            'headers' => ['ApiKey' => $apiKey, 'Content-Type' => 'application/json', 'Accept' => 'application/json'],
            'body' => $body,
            'data_format' => 'body',
        ]);
        if (is_wp_error($response)) {
            return ['code' => 0, 'body' => '', 'error' => $response->get_error_message()];
        }
        return [
            'code' => (int)wp_remote_retrieve_response_code($response),
            'body' => (string)wp_remote_retrieve_body($response),
            'error' => '',
        ];
    }
    private function normalize(array $raw): array
    {
        $decoded = json_decode($raw['body'] ?? '', true);
        $httpOk = ($raw['code'] ?? 0) >= 200 && ($raw['code'] ?? 0) < 300;
        $apiOk = is_array($decoded) && array_key_exists('Success', $decoded) && (bool)$decoded['Success'];
        $ok = $httpOk && $apiOk;
        $error = $ok ? null : (is_array($decoded) ? (string)($decoded['Message'] ?? '') : '');
        if ($error === '') $error = (string)($raw['error'] ?? 'Unknown SMSLogin error');
        return ['success' => $ok, 'status' => $raw['code'] ?? 0, 'provider_response' => $decoded ?: ($raw['body'] ?? ''), 'error' => $error];
    }
}
