<?php
namespace SeKianAfraz\VisitDiscount\SMS;
use SeKianAfraz\VisitDiscount\Database\Schema;
if (!defined('ABSPATH')) { exit; }
class SMSQueueService {
    private static $tableReady = null;
    const DELIVERY_PENDING = 'وضعیت تحویل مشخص نیست؛ پیش از ارسال دوباره، نتیجه را در پنل پیامک بررسی کنید.';
    public static function enqueue($phone, $message, $couponCode, $sensorId, $delayMinutes, $provider = '', $mode = 'promo', $templateId = '', array $tokens = []) {
        global $wpdb;
        $mode = $mode === 'pattern' ? 'pattern' : 'promo';
        if (empty($phone) || empty($sensorId)) {
            return false;
        }
        if (($mode === 'pattern' && trim((string)$templateId) === '') || ($mode === 'promo' && trim((string)$message) === '')) {
            return false;
        }
        self::ensureTable();
        $delayMinutes = max(0, min(1440, intval($delayMinutes)));
        $table_name = Schema::getSMSQueueTableName();
        $now = gmdate('Y-m-d H:i:s');
        if ($couponCode && !\SeKianAfraz\VisitDiscount\Coupons\CouponAvailability::usable((string)$couponCode, time() + $delayMinutes * MINUTE_IN_SECONDS)) return false;
        $scheduled_time = gmdate('Y-m-d H:i:s', time() + ($delayMinutes * MINUTE_IN_SECONDS));
        $result = $wpdb->insert(
            $table_name,
            [
                'phone' => sanitize_text_field($phone),
                'message' => sanitize_textarea_field((string)$message),
                'provider' => sanitize_key((string)$provider),
                'mode' => $mode,
                'template_id' => $mode === 'pattern' ? sanitize_text_field((string)$templateId) : null,
                'tokens' => $mode === 'pattern' ? wp_json_encode($tokens) : null,
                'coupon_code' => $couponCode ? sanitize_text_field($couponCode) : null,
                'sensor_id' => intval($sensorId),
                'scheduled_time' => $scheduled_time,
                'status' => 'pending',
                'attempts' => 0,
                'created_at' => $now
            ],
            [
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%s',
                '%d',
                '%s',
                '%s',
                '%d',
                '%s'
            ]
        );
        return $result ? $wpdb->insert_id : false;
    }
    public static function claimJobs($limit = 100) {
        global $wpdb;
        self::ensureTable();
        $table_name = Schema::getSMSQueueTableName();
        $now = gmdate('Y-m-d H:i:s');
        $stale = gmdate('Y-m-d H:i:s', time() - (15 * MINUTE_IN_SECONDS));
        $limit = max(1, min(100, intval($limit)));
        $run_id = function_exists('wp_generate_uuid4') ? wp_generate_uuid4() : uniqid('sekianafraz_sms_', true);
        $wpdb->query($wpdb->prepare(
            "UPDATE $table_name SET status='failed',attempts=3,claimed_at=NULL,claimed_by=NULL
             WHERE status='processing' AND claimed_at < %s AND last_error=%s LIMIT %d",
            $stale, self::DELIVERY_PENDING, $limit
        ));
        $recovered = $wpdb->query($wpdb->prepare(
            "UPDATE $table_name SET status='pending', claimed_at=NULL, claimed_by=NULL
             WHERE status='processing' AND claimed_at < %s AND scheduled_time <= %s AND attempts < 3 AND (last_error IS NULL OR last_error<>%s)
             ORDER BY claimed_at ASC LIMIT %d", $stale, $now, self::DELIVERY_PENDING, $limit
        ));
        if ($recovered === false) return [];
        $claimed = $wpdb->query($wpdb->prepare(
            "UPDATE $table_name
             SET status = 'processing', claimed_at = %s, claimed_by = %s
             WHERE status = 'pending'
             AND scheduled_time <= %s
             AND attempts < 3
             ORDER BY scheduled_time ASC, id ASC
             LIMIT %d",
            $now,
            $run_id,
            $now,
            $limit
        ));
        if (!$claimed) return [];
        $jobs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name
             WHERE status = 'processing'
             AND claimed_by = %s
             ORDER BY scheduled_time ASC",
            $run_id
        ));
        return $jobs ?: [];
    }
    public static function releaseClaimedJobsByRunId($runId) {
        global $wpdb;
        if (empty($runId)) {
            return false;
        }
        self::ensureTable();
        $table_name = Schema::getSMSQueueTableName();
        $result = $wpdb->query($wpdb->prepare(
            "UPDATE $table_name
             SET status = 'pending', claimed_at = NULL, claimed_by = NULL
             WHERE status = 'processing' AND claimed_by = %s AND (last_error IS NULL OR last_error<>%s)",
            sanitize_text_field($runId), self::DELIVERY_PENDING
        ));
        return ($result !== false);
    }
    public static function getPendingJobs($limit = 100) {
        global $wpdb;
        self::ensureTable();
        $table_name = Schema::getSMSQueueTableName();
        $now = gmdate('Y-m-d H:i:s');
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table_name 
            WHERE status = 'pending' 
            AND scheduled_time <= %s 
            AND attempts < 3
            ORDER BY scheduled_time ASC 
            LIMIT %d",
            $now,
            max(1, min(100, intval($limit)))
        )) ?: [];
    }
    public static function beginDelivery(int $id, string $claim): bool
    {
        global $wpdb;
        return $wpdb->update(Schema::getSMSQueueTableName(), ['last_error' => self::DELIVERY_PENDING],
            ['id' => $id, 'status' => 'processing', 'claimed_by' => $claim]) === 1;
    }
    public static function markAsSent($id, string $claim = '') {
        global $wpdb;
        self::ensureTable();
        $table_name = Schema::getSMSQueueTableName();
        $now = gmdate('Y-m-d H:i:s');
        $result = $wpdb->update(
            $table_name,
            [
                'status' => 'sent',
                'sent_at' => $now,
                'last_error' => null,
                'claimed_at' => null,
                'claimed_by' => null
            ],
            ['id' => intval($id), 'status' => 'processing', 'claimed_by' => $claim],
            ['%s', '%s', '%s', '%s', '%s'],
            ['%d', '%s', '%s']
        );
        return ($result !== false);
    }
    public static function markAsFailed($id, $error, string $claim = '') {
        global $wpdb;
        self::ensureTable();
        $table = Schema::getSMSQueueTableName();
        return $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET status=IF(attempts>=2,'failed','pending'),attempts=attempts+1,last_error=%s,scheduled_time=DATE_ADD(UTC_TIMESTAMP(),INTERVAL 1 MINUTE),claimed_at=NULL,claimed_by=NULL WHERE id=%d AND status='processing' AND claimed_by=%s",
            sanitize_text_field((string)$error), (int)$id, $claim
        )) !== false;
    }
    public static function cancelJob(int $id, string $claim, string $reason): void
    {
        global $wpdb;
        $wpdb->update(Schema::getSMSQueueTableName(), ['status' => 'failed', 'attempts' => 3, 'last_error' => $reason, 'claimed_at' => null, 'claimed_by' => null],
            ['id' => $id, 'status' => 'processing', 'claimed_by' => $claim]);
    }
    public static function cleanupOldJobs($daysOld = 30, $limit = 5000) {
        global $wpdb;
        self::ensureTable();
        $table_name = Schema::getSMSQueueTableName();
        $daysOld = intval($daysOld);
        $limit = max(100, min(20000, intval($limit)));
        $cutoff_date = gmdate('Y-m-d H:i:s', time() - (max(1, $daysOld) * DAY_IN_SECONDS));
        $result = $wpdb->query($wpdb->prepare(
            "DELETE FROM $table_name 
            WHERE status IN ('sent', 'failed') 
            AND created_at < %s
            LIMIT %d",
            $cutoff_date,
            $limit
        ));
        return $result;
    }
    public static function releaseAllProcessingJobs(): int
    {
        global $wpdb;
        if (!get_option('sekianafraz_sms_queue_ready')) return 0;
        $tableName = Schema::getSMSQueueTableName();
        $result = $wpdb->query($wpdb->prepare(
            "UPDATE {$tableName}
             SET status=IF(last_error=%s,'failed','pending'), claimed_at=NULL, claimed_by=NULL
             WHERE status='processing'", self::DELIVERY_PENDING
        ));
        return is_int($result) ? $result : 0;
    }
    public static function getStats() {
        global $wpdb;
        self::ensureTable();
        $table_name = Schema::getSMSQueueTableName();
        $stats = ['pending' => 0, 'processing' => 0, 'sent' => 0, 'failed' => 0, 'total' => 0];
        foreach ($wpdb->get_results("SELECT status,COUNT(*) AS total FROM $table_name GROUP BY status", ARRAY_A) as $row) {
            $stats[$row['status']] = (int)$row['total'];
            $stats['total'] += (int)$row['total'];
        }
        return $stats;
    }
    private static function ensureTable(): void
    {
        if (self::$tableReady) {
            return;
        }
        if (get_option('sekianafraz_sms_queue_ready')) {
            self::$tableReady = true;
            return;
        }
        if (class_exists('SeKianAfraz\VisitDiscount\\Database\\Schema')) {
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createSMSQueueTable()) {
                update_option('sekianafraz_sms_queue_ready', 1, false);
                self::$tableReady = true;
            }
        }
    }
}
