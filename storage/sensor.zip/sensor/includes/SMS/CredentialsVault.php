<?php
namespace SeKianAfraz\VisitDiscount\SMS;
if (!defined('ABSPATH')) { exit; }
class CredentialsVault
{
    private const OPTION = 'sekianafraz_sms_settings';
    private const CIPHER = 'aes-256-gcm';
    public static function load(): array
    {
        $stored = get_option(self::OPTION, []);
        if (!is_array($stored)) return [];
        $provider = sanitize_key((string)($stored['provider'] ?? 'melipayamak'));
        if (!empty($stored['encrypted']) && is_array($stored['encrypted'])) {
            $config = self::decrypt((array)$stored['encrypted']);
            return ['provider' => $provider, 'config' => is_array($config) ? $config : []];
        }
        return ['provider' => $provider, 'config' => is_array($stored['config'] ?? null) ? $stored['config'] : []];
    }
    public static function save(string $provider, array $config): bool
    {
        $payload = [
            'provider' => sanitize_key($provider),
            'encrypted' => self::encrypt($config),
        ];
        if (!$payload['encrypted']) return false;
        return update_option(self::OPTION, $payload, false);
    }
    public static function migrateLegacy(): bool
    {
        $stored = get_option(self::OPTION, null);
        if ($stored === null || !is_array($stored) || !empty($stored['encrypted'])) return true;
        return self::save(
            sanitize_key((string)($stored['provider'] ?? 'melipayamak')),
            is_array($stored['config'] ?? null) ? $stored['config'] : []
        );
    }
    private static function encrypt(array $config): array
    {
        if (!function_exists('openssl_encrypt')) return [];
        try {
            $nonce = random_bytes(12);
        } catch (\Throwable $error) {
            return [];
        }
        $tag = '';
        $json = wp_json_encode($config);
        if (!is_string($json)) return [];
        $ciphertext = openssl_encrypt(
            $json,
            self::CIPHER,
            self::key(),
            OPENSSL_RAW_DATA,
            $nonce,
            $tag,
            'sekianafraz_sms_settings_v1'
        );
        if (!is_string($ciphertext) || strlen($tag) !== 16) return [];
        return [
            'version' => 1,
            'nonce' => base64_encode($nonce),
            'tag' => base64_encode($tag),
            'data' => base64_encode($ciphertext),
        ];
    }
    private static function decrypt(array $payload): array
    {
        if (!function_exists('openssl_decrypt') || (int)($payload['version'] ?? 0) !== 1) return [];
        $nonce = base64_decode((string)($payload['nonce'] ?? ''), true);
        $tag = base64_decode((string)($payload['tag'] ?? ''), true);
        $ciphertext = base64_decode((string)($payload['data'] ?? ''), true);
        if (!is_string($nonce) || strlen($nonce) !== 12 || !is_string($tag) || strlen($tag) !== 16 || !is_string($ciphertext)) {
            return [];
        }
        $json = openssl_decrypt(
            $ciphertext,
            self::CIPHER,
            self::key(),
            OPENSSL_RAW_DATA,
            $nonce,
            $tag,
            'sekianafraz_sms_settings_v1'
        );
        if (!is_string($json)) return [];
        $decoded = json_decode($json, true);
        return is_array($decoded) ? $decoded : [];
    }
    private static function key(): string
    {
        return hash('sha256', wp_salt('auth') . '|sekianafraz|sms|v1', true);
    }
}
