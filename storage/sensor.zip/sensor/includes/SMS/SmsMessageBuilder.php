<?php
namespace SeKianAfraz\VisitDiscount\SMS;
use SeKianAfraz\VisitDiscount\Helpers\TemplateEngine;
use SeKianAfraz\VisitDiscount\Helpers\UrlHelper;
if (!defined('ABSPATH')) { exit; }
class SmsMessageBuilder
{
    private $templateEngine;
    private $urlHelper;
    public function __construct(?TemplateEngine $templateEngine = null, ?UrlHelper $urlHelper = null)
    {
        $this->templateEngine = $templateEngine ?: new TemplateEngine();
        $this->urlHelper = $urlHelper ?: new UrlHelper();
    }
    public function build(int $sensorId, array $payload, string $fallbackUrl, string $audience = ''): array
    {
        $settings = CredentialsVault::load();
        $provider = sanitize_text_field($settings['provider'] ?? 'melipayamak');
        $config = (array)($settings['config'] ?? []);
        $prefix = $audience === 'logged' ? 'logged_sms_' : 'sms_';
        $mode = (string)get_post_meta($sensorId, $prefix . 'mode', true);
        $text = (string)get_post_meta($sensorId, $prefix . 'text', true);
        $smsPayload = $payload;
        $target = trim((string)get_post_meta($sensorId, $prefix . 'target_url', true));
        $pageUrl = $this->canonicalTargetUrl($sensorId, $fallbackUrl);
        $smsPayload['target_url'] = $target !== '' ? $target : ($mode === 'pattern' ? $this->patternPath($pageUrl) : $this->plainUrl($pageUrl));
        $vars = $this->templateEngine->buildVars($sensorId, $smsPayload);
        $vars['target_url'] = $smsPayload['target_url'];
        $message = $this->templateEngine->render($text, $vars, false);
        $delayType = (string)get_post_meta($sensorId, $prefix . 'delay_type', true);
        $storedMinutes = get_post_meta($sensorId, $prefix . 'delay_minutes', true);
        $delayMinutes = $storedMinutes === '' ? 60 : (int)$storedMinutes;
        $delayMinutes = $delayType === 'delayed' ? max(1, min(1440, $delayMinutes)) : 0;
        return [
            'success' => true,
            'provider' => $provider,
            'config' => $config,
            'mode' => $mode,
            'vars' => $vars,
            'message' => $message,
            'delay_type' => $delayType,
            'delay_minutes' => $delayMinutes,
            'pattern' => (string)get_post_meta($sensorId, $prefix . 'pattern', true),
        ];
    }
    private function plainUrl(string $url): string
    {
        return preg_replace('~^www\.~i', '', preg_replace('~^https?://~i', '', $url));
    }
    private function patternPath(string $url): string
    {
        $home = rtrim(home_url('/'), '/');
        if (stripos($url, $home . '/') === 0) return substr($url, strlen($home) + 1);
        if (strcasecmp($url, $home) === 0) return '';
        $path = (string)parse_url($url, PHP_URL_PATH);
        $homePath = rtrim((string)parse_url($home, PHP_URL_PATH), '/');
        if ($homePath !== '' && strpos($path, $homePath . '/') === 0) $path = substr($path, strlen($homePath));
        return ltrim($path, '/') . (parse_url($url, PHP_URL_QUERY) !== null ? '?' . parse_url($url, PHP_URL_QUERY) : '');
    }
    private function canonicalTargetUrl(int $sensorId, string $fallback): string
    {
        $placement = (string)get_post_meta($sensorId, 'placement', true);
        $ctx = isset($_REQUEST['sekianafraz_ctx']) && is_array($_REQUEST['sekianafraz_ctx']) ? (array)$_REQUEST['sekianafraz_ctx'] : [];
        $postId = 0;
        if (in_array($placement, ['product_single', 'product_in_cat', 'product_in_tag'], true)) $postId = (int)($ctx['product_id'] ?? 0);
        if (in_array($placement, ['post_single', 'post_in_cat', 'post_in_tag'], true)) $postId = (int)($ctx['post_id'] ?? 0);
        if ($placement === 'page') $postId = (int)($ctx['page_id'] ?? 0);
        if ($postId > 0 && get_post($postId)) {
            $url = get_permalink($postId);
            if ($url) return (string)$url;
        }
        $taxonomies = ['product_cat' => ['product_cat_ids', 'product_cat'], 'product_tag' => ['product_tag_ids', 'product_tag'], 'post_cat' => ['post_cat_ids', 'category'], 'post_tag' => ['post_tag_ids', 'post_tag']];
        if (isset($taxonomies[$placement])) {
            [$key, $taxonomy] = $taxonomies[$placement];
            $ids = isset($ctx[$key]) && is_array($ctx[$key]) ? $ctx[$key] : [];
            $matched = (string)($ctx['matched_item'] ?? '');
            $id = ctype_digit($matched) && in_array((int)$matched, array_map('intval', $ids), true) ? (int)$matched : (int)($ids[0] ?? 0);
            if ($id > 0) {
                $url = get_term_link($id, $taxonomy);
                if (!is_wp_error($url)) return (string)$url;
            }
        }
        if ($placement === 'search_terms' && isset($ctx['search_term'])) {
            return (string)get_search_link((string)$ctx['search_term']);
        }
        return $this->urlHelper->absoluteUrlForMessaging($fallback);
    }
}
