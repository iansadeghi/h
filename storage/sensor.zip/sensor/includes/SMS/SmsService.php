<?php
namespace SeKianAfraz\VisitDiscount\SMS;
use SeKianAfraz\VisitDiscount\SMS\Providers\MeliPayamak;
use SeKianAfraz\VisitDiscount\SMS\Providers\Kavenegar;
use SeKianAfraz\VisitDiscount\SMS\Providers\IPPanel;
use SeKianAfraz\VisitDiscount\SMS\Providers\SmsIr;
use SeKianAfraz\VisitDiscount\SMS\Providers\SmsLogin;
if (!defined('ABSPATH')) { exit; }
class SmsService
{
    public static function deliveryUncertain(array $result): bool
    {
        if (!empty($result['success']) || !array_key_exists('status', $result)) return false;
        $status = (int)$result['status'];
        return $status === 0 || $status >= 500 || ($status >= 200 && $status < 300
            && empty($result['provider_response']) && empty($result['response']));
    }
    public static function providerFields(string $provider): array
    {
        $map = [
            'melipayamak' => [
                ['key' => 'username', 'label' => 'نام کاربری', 'type' => 'text'],
                ['key' => 'api_key', 'label' => 'رمز عبور', 'type' => 'password'],
                ['key' => 'sender', 'label' => 'شماره فرستنده (اختیاری)', 'type' => 'text'],
            ],
            'kavenegar' => [
                ['key' => 'api_key', 'label' => 'کلید API', 'type' => 'password'],
                ['key' => 'sender', 'label' => 'شماره فرستنده (اختیاری)', 'type' => 'text'],
            ],
            'ippanel' => [
                ['key' => 'api_key', 'label' => 'کلید API', 'type' => 'password'],
                ['key' => 'sender', 'label' => 'خط خدماتی/تبلیغاتی', 'type' => 'text'],
            ],
            'smsir' => [
                ['key' => 'api_key', 'label' => 'کلید API', 'type' => 'password'],
                ['key' => 'sender', 'label' => 'خط خدماتی/تبلیغاتی', 'type' => 'text'],
            ],
            'smslogin' => [
                ['key' => 'api_key', 'label' => 'کلید API', 'type' => 'password'],
                ['key' => 'sender', 'label' => 'شماره فرستنده', 'type' => 'text'],
            ],
        ];
        if (!isset($map[$provider])) $provider = 'melipayamak';
        $current = CredentialsVault::load();
        $values = (($current['provider'] ?? '') === $provider && is_array($current['config'] ?? null))
            ? $current['config']
            : [];
        foreach ($map[$provider] as &$f) $f['value'] = (string)($values[$f['key']] ?? '');
        return $map[$provider];
    }
    public static function variablesForAction(string $placement, string $action, string $mode = ''): array
    {
        $common = [
            ['key' => 'display_name', 'label' => 'نام نمایشی کاربر'],
            ['key' => 'coupon_code', 'label' => 'کد تخفیف'],
            ['key' => 'coupon_expiry_time', 'label' => 'زمان انقضای کد تخفیف'],
            ['key' => 'coupon_value', 'label' => 'مقدار کد تخفیف'],
            ['key' => 'coupon_valid_hours', 'label' => 'مهلت استفاده از کد تخفیف'],
            ['key' => 'target_url', 'label' => 'لینک صفحه هدف'],
        ];
        $byPlace = [
            'product_single' => [['key' => 'product_name', 'label' => 'نام محصول']],
            'product_in_cat' => [['key' => 'product_name', 'label' => 'نام محصول']],
            'product_in_tag' => [['key' => 'product_name', 'label' => 'نام محصول']],
            'product_cat' => [['key' => 'category_name', 'label' => 'نام دسته‌بندی محصول']],
            'product_tag' => [['key' => 'product_tag_name', 'label' => 'نام برچسب محصول']],
            'post_single' => [['key' => 'post_name', 'label' => 'عنوان مطلب']],
            'post_in_cat' => [['key' => 'post_name', 'label' => 'عنوان مطلب']],
            'post_in_tag' => [['key' => 'post_name', 'label' => 'عنوان مطلب']],
            'post_cat' => [['key' => 'post_category_name', 'label' => 'نام دسته‌بندی مطلب']],
            'post_tag' => [['key' => 'post_tag_name', 'label' => 'نام برچسب مطلب']],
            'page' => [['key' => 'page_name', 'label' => 'عنوان برگه']],
            'custom_url' => [['key' => 'page_name', 'label' => 'عنوان صفحه']],
            'search_terms' => [['key' => 'search_term', 'label' => 'عبارت جستجو']],
        ];
        $vars = array_merge($common, $byPlace[$placement] ?? []);
        if ($action === 'sms' && $mode === 'pattern') {
            return array_map(function($v){ return ['key' => $v['key'], 'label' => $v['label']]; }, $vars);
        }
        if ($action === 'both') {
            return $vars;
        }
        return $vars;
    }
    public static function buildPatternTokens(string $provider, array $ordered): array
    {
        if ($provider === 'kavenegar') return ['_ordered' => array_slice($ordered, 0, 5)];
        if ($provider === 'smslogin') return ['_ordered' => $ordered];
        if ($provider === 'smsir') return ['Code' => $ordered[0] ?? ''];
        if ($provider === 'ippanel') return ['code' => $ordered[0] ?? ''];
        if ($provider === 'melipayamak') return ['code' => $ordered[0] ?? ''];
        return [];
    }
    public static function test(array $settings): array
    {
        $p = sanitize_key((string)($settings['provider'] ?? 'melipayamak'));
        $cfg = (array)($settings['config'] ?? []);
        $g = self::gateway($p);
        if (!$g) return ['success' => false, 'message' => 'درگاه نامعتبر'];
        $balance = self::providerBalance($p, $cfg);
        return [
            'success' => $balance['success'],
            'message' => $balance['message'],
            'balance' => $balance['balance'],
        ];
    }
    public static function gateway(string $provider): ?GatewayInterface
    {
        if ($provider === 'melipayamak') return new MeliPayamak();
        if ($provider === 'kavenegar') return new Kavenegar();
        if ($provider === 'ippanel') return new IPPanel();
        if ($provider === 'smsir') return new SmsIr();
        if ($provider === 'smslogin') return new SmsLogin();
        return null;
    }
    private static function providerBalance(string $provider, array $config): array
    {
        if ($provider === 'kavenegar') {
            $api = trim($config['api_key'] ?? '');
            if ($api === '') return ['success' => false, 'message' => 'کلید API وارد نشده', 'balance' => null];
            $url = sprintf('https://api.kavenegar.com/v1/%s/account/info.json', urlencode($api));
            $r = self::curlGet($url);
            $dec = json_decode($r['body'] ?? '', true);
            $credit = $dec['entries']['remaincredit'] ?? null;
            $apiOk = is_array($dec) && (int)($dec['return']['status'] ?? 0) === 200;
            return ['success' => $apiOk && is_numeric($credit), 'message' => $apiOk && is_numeric($credit) ? 'OK' : (string)($dec['return']['message'] ?? 'نامشخص'), 'balance' => is_numeric($credit) ? $credit : null, 'raw' => $dec];
        }
        if ($provider === 'smsir') {
            $api = trim($config['api_key'] ?? '');
            if ($api === '') return ['success' => false, 'message' => 'کلید API وارد نشده', 'balance' => null];
            $r = self::curlGet('https://api.sms.ir/v1/credit', ['x-api-key: '.$api, 'Accept: application/json']);
            $dec = json_decode($r['body'] ?? '', true);
            $credit = is_array($dec) && is_numeric($dec['data'] ?? null) ? $dec['data'] : null;
            $apiOk = is_array($dec) && (int)($dec['status'] ?? 0) === 1;
            return ['success' => $apiOk && $credit !== null, 'message' => $apiOk && $credit !== null ? 'OK' : (string)($dec['message'] ?? 'نامشخص'), 'balance' => $credit, 'raw' => $dec];
        }
        if ($provider === 'melipayamak') {
            $username = trim($config['username'] ?? ($config['originator'] ?? ''));
            $password = trim($config['api_key'] ?? '');
            if ($username === '' || $password === '') return ['success' => false, 'message' => 'نام کاربری/رمز خالی', 'balance' => null];
            $r = self::curlPost('https://rest.payamak-panel.com/api/SendSMS/GetCredit', http_build_query([
                'username' => $username,
                'password' => $password,
            ]), ['Content-Type: application/x-www-form-urlencoded']);
            $dec = json_decode($r['body'] ?? '', true);
            $credit = is_numeric(trim((string)($r['body'] ?? ''))) ? (float)$r['body'] : ($dec['Value'] ?? null);
            $apiOk = !is_array($dec) || !array_key_exists('RetStatus', $dec) || (int)$dec['RetStatus'] === 1;
            return ['success' => $apiOk && is_numeric($credit) && (float)$credit >= 0, 'message' => $apiOk && is_numeric($credit) ? 'OK' : (string)($dec['StrRetStatus'] ?? 'نامشخص'), 'balance' => is_numeric($credit) ? (float)$credit : null, 'raw' => $dec ?: ($r['body'] ?? null)];
        }
        if ($provider === 'smslogin') {
            $api = trim($config['api_key'] ?? '');
            if ($api === '') return ['success' => false, 'message' => 'کلید API وارد نشده', 'balance' => null];
            $r = self::curlPost('https://api.limosms.com/api/getcurrentcredit', '{}', [
                'ApiKey: '.$api,
                'Content-Type: application/json',
                'Accept: application/json',
            ]);
            $dec = json_decode($r['body'] ?? '', true);
            $apiOk = is_array($dec) && (bool)($dec['Success'] ?? false);
            $credit = self::limoCredit($dec['Result'] ?? null);
            return ['success' => $apiOk, 'message' => $apiOk ? 'OK' : (string)($dec['Message'] ?? 'نامشخص'), 'balance' => $credit, 'raw' => $dec ?: ($r['body'] ?? null)];
        }
        if ($provider === 'ippanel') {
            $api = trim($config['api_key'] ?? '');
            if ($api === '') return ['success' => false, 'message' => 'کلید API وارد نشده', 'balance' => null];
            $r = self::curlGet('https://edge.ippanel.com/v1/api/payment/credit/mine', [
                'Authorization' => $api,
                'Accept' => 'application/json',
            ]);
            $dec = json_decode((string)($r['body'] ?? ''), true);
            $credit = $dec['data']['credit'] ?? null;
            $message = (string)($dec['meta']['message'] ?? ($r['error'] ?? 'نامشخص'));
            $apiOk = is_array($dec) && (bool)($dec['meta']['status'] ?? false);
            return ['success' => $apiOk && is_numeric($credit), 'message' => $apiOk && is_numeric($credit) ? 'OK' : $message, 'balance' => is_numeric($credit) ? $credit : null, 'raw' => $dec];
        }
        return ['success' => false, 'message' => 'نامشخص', 'balance' => null];
    }
    private static function limoCredit($result)
    {
        if (is_numeric($result)) return $result + 0;
        if (!is_array($result)) return null;
        foreach (['Credit', 'credit', 'CurrentCredit', 'currentCredit', 'Balance', 'balance', 'Amount', 'amount'] as $key) {
            if (isset($result[$key]) && is_numeric($result[$key])) return $result[$key] + 0;
        }
        return null;
    }
    private static function curlGet(string $url, array $headers = []): array
    {
        $response = wp_remote_get($url, [
            'timeout' => 30,
            'headers' => self::normalizeHeaders($headers),
        ]);
        if (is_wp_error($response)) {
            return ['code' => 0, 'body' => '', 'error' => $response->get_error_message()];
        }
        return [
            'code' => (int)wp_remote_retrieve_response_code($response),
            'body' => (string)wp_remote_retrieve_body($response),
            'error' => '',
        ];
    }
    private static function curlPost(string $url, string $body, array $headers = []): array
    {
        $response = wp_remote_post($url, [
            'timeout' => 30,
            'headers' => self::normalizeHeaders($headers),
            'body' => $body,
        ]);
        if (is_wp_error($response)) {
            return ['code' => 0, 'body' => '', 'error' => $response->get_error_message()];
        }
        return [
            'code' => (int)wp_remote_retrieve_response_code($response),
            'body' => (string)wp_remote_retrieve_body($response),
            'error' => '',
        ];
    }
    private static function normalizeHeaders(array $headers): array
    {
        $normalized = [];
        foreach ($headers as $key => $value) {
            if (is_string($key)) {
                $normalized[$key] = (string)$value;
                continue;
            }
            $parts = explode(':', (string)$value, 2);
            if (count($parts) === 2) {
                $normalized[trim($parts[0])] = trim($parts[1]);
            }
        }
        return $normalized;
    }
}
