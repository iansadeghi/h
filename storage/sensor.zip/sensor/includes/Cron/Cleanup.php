<?php
namespace SeKianAfraz\VisitDiscount\Cron;
use SeKianAfraz\VisitDiscount\Coupons\CouponRegistryRepository;
if (!defined('ABSPATH')) { exit; }
class Cleanup
{
    private const CONTINUE_HOOK = 'sekianafraz_cleanup_continue';
    private const PENDING_OPTION = 'sekianafraz_cleanup_pending';
    public function register(): void
    {
        add_action('sekianafraz_daily_cleanup_event', [$this, 'run']);
        add_action(self::CONTINUE_HOOK, [$this, 'run']);
    }
    public function run(): void
    {
        global $wpdb;
        $lock = 'sekianafraz_cleanup_' . md5(DB_NAME . '|' . $wpdb->prefix);
        if ((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)', $lock)) !== 1) return;
        $pending = (array)get_option(self::PENDING_OPTION, []);
        if (!$pending) {
            foreach (['actions', 'coupons', 'expire', 'registry', 'redemptions', 'claims', 'sessions', 'owners', 'sms'] as $stage) {
                $pending[] = ['stage' => $stage, 'after' => ''];
            }
        }
        $started = microtime(true);
        $budget = max(1, min(20, (int)apply_filters('sekianafraz_cleanup_time_budget', 10)));
        $steps = 0;
        try {
            while ($pending && $steps++ < 32 && microtime(true) - $started < $budget) {
                $job = array_shift($pending);
                try {
                    $next = $this->processStage($job);
                    if ($next !== null) $pending[] = $next;
                } catch (\Throwable $error) {
                    $pending[] = $job;
                    break;
                }
            }
        } finally {
            if ($pending) {
                update_option(self::PENDING_OPTION, $pending, false);
                if (!wp_next_scheduled(self::CONTINUE_HOOK)) wp_schedule_single_event(time() + 15, self::CONTINUE_HOOK);
            } else {
                delete_option(self::PENDING_OPTION);
            }
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }
    private function retention(string $name, int $default, int $minimum = 1): int
    {
        $key = 'sekianafraz_retention_' . $name;
        return max($minimum, (int)apply_filters($key, (int)get_option($key, $default)));
    }
    private function processStage(array $job): ?array
    {
        global $wpdb;
        $limit = 500;
        $repository = new CouponRegistryRepository();
        $stage = (string)($job['stage'] ?? '');
        if ($stage === 'coupons') return $this->purgeCoupons() ? $job : null;
        if ($stage === 'expire') $affected = $repository->expireVirtualCouponsBatch($limit);
        elseif ($stage === 'registry') $affected = $repository->purgeHistoryOlderThanDays($this->retention('coupon_registry_days', 30), $limit);
        elseif ($stage === 'redemptions') {
            $affected = (new \SeKianAfraz\VisitDiscount\Coupons\CouponRedemptionRepository())->purgeOlderThanDays($this->retention('coupon_redemptions_days', 90), $limit);
        } elseif ($stage === 'actions') {
            $affected = $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}sekianafraz_action_log
                WHERE timestamp < (UTC_TIMESTAMP() - INTERVAL %d DAY) LIMIT %d", $this->retention('action_log_days', 7), $limit));
        } elseif ($stage === 'claims') {
            $affected = $wpdb->query($wpdb->prepare("DELETE FROM {$wpdb->prefix}sekianafraz_dedup_claims
                WHERE claimed_at < (UTC_TIMESTAMP() - INTERVAL %d MINUTE) LIMIT %d", $this->retention('dedup_claims_minutes', 60, 5), $limit));
        } elseif ($stage === 'sessions') {
            if (!get_option('sekianafraz_banner_sessions_ready')) return null;
            $affected = $wpdb->query("DELETE FROM {$wpdb->prefix}sekianafraz_banner_sessions WHERE created_at < (UTC_TIMESTAMP() - INTERVAL 1 DAY) LIMIT {$limit}");
        } elseif ($stage === 'owners') {
            return $this->purgeOwners($job, $limit);
        } elseif ($stage === 'sms') {
            if (!get_option('sekianafraz_sms_queue_ready')) return null;
            $affected = \SeKianAfraz\VisitDiscount\SMS\SMSQueueService::cleanupOldJobs(30, $limit);
        } else return null;
        if ($affected === false || $wpdb->last_error !== '') throw new \RuntimeException('Cleanup storage unavailable.');
        return $affected >= $limit ? $job : null;
    }
    private function purgeCoupons(): bool
    {
        $repository = new CouponRegistryRepository();
        $ids = $repository->findExpiredWpPostCouponIds(25);
        $deleted = [];
        foreach ($ids as $id) {
            try {
                $coupon = class_exists('WC_Coupon') ? new \WC_Coupon($id) : null;
                if ($coupon instanceof \WC_Coupon && $coupon->get_id() > 0 && $coupon->delete(true)) {
                    $deleted[] = $id;
                    continue;
                }
            } catch (\Throwable $error) {
            }
            if (!get_post($id)) $deleted[] = $id;
        }
        if ($deleted) $repository->markExpiredByCouponPostIds($deleted);
        return count($ids) === 25 && !empty($deleted);
    }
    private function purgeOwners(array $job, int $limit): ?array
    {
        if (!get_option('sekianafraz_phone_owner_cache_ready') || !get_option('sekianafraz_collected_leads_ready')) return null;
        global $wpdb;
        $cache = $wpdb->prefix . 'sekianafraz_phone_owner_cache';
        $leads = $wpdb->prefix . 'sekianafraz_collected_leads';
        $phones = $wpdb->get_col($wpdb->prepare("SELECT phone FROM {$cache} WHERE pending=0 AND phone>%s ORDER BY phone LIMIT %d", (string)($job['after'] ?? ''), $limit));
        if ($wpdb->last_error !== '') throw new \RuntimeException('Cleanup storage unavailable.');
        if (!$phones) return null;
        $holders = implode(',', array_fill(0, count($phones), '%s'));
        if ($wpdb->query($wpdb->prepare("DELETE FROM {$cache} WHERE pending=0 AND phone IN ({$holders})
            AND NOT EXISTS (SELECT 1 FROM {$leads} l WHERE l.phone={$cache}.phone)", $phones)) === false) {
            throw new \RuntimeException('Cleanup storage unavailable.');
        }
        $job['after'] = (string)end($phones);
        return count($phones) === $limit ? $job : null;
    }
}
