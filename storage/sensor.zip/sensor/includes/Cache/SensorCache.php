<?php
namespace SeKianAfraz\VisitDiscount\Cache;
if (!defined('ABSPATH')) { exit; }
class SensorCache
{
    private const GROUP = 'sekianafraz_sensors';
    public static function key(array $context): string
    {
        $generation = wp_cache_get('generation', self::GROUP);
        if (!$generation) {
            wp_cache_add('generation', wp_generate_uuid4(), self::GROUP);
            $generation = wp_cache_get('generation', self::GROUP);
        }
        return (string)$generation . ':' . md5(wp_json_encode($context));
    }
    public static function get(string $key): ?array
    {
        $value = wp_cache_get($key, self::GROUP);
        return is_array($value) ? $value : null;
    }
    public static function set(string $key, array $value): void
    {
        wp_cache_set($key, $value, self::GROUP, MINUTE_IN_SECONDS);
    }
    public static function invalidate(): void
    {
        wp_cache_set('generation', wp_generate_uuid4(), self::GROUP);
    }
}
