<?php
namespace SeKianAfraz\VisitDiscount\Cache;
if (!defined('ABSPATH')) { exit; }
class CacheCompatibility
{
    private $purgePending = false;
    private const SCRIPT_MARKERS = [
        'sekianafraz-tracker',
        'sekianafraz-banner-view',
        'sekianafraz-reminder-bar',
        'sekianafraz-reminder-style',
        'assets/js/tracker.js',
        'assets/js/banner-view.js',
        'assets/js/reminder-bar.js',
        'assets/js/reminder-style.js',
        'SEKIANAFRAZ_CTX',
    ];
    private const STYLE_MARKERS = [
        'assets/css/reminder-bar.css',
        'sekianafraz-reminder-bar-inline-css',
    ];
    public function register(): void
    {
        add_action('wp', [$this, 'tagFrontendPage'], 99);
        add_filter('script_loader_tag', [$this, 'markRuntimeScript'], 10, 3);
        add_filter('rocket_delay_js_exclusions', [$this, 'appendExclusions']);
        add_filter('rocket_exclude_defer_js', [$this, 'appendExclusions']);
        add_filter('rocket_exclude_js', [$this, 'appendRocketScriptExclusions']);
        add_filter('rocket_excluded_inline_js_content', [$this, 'appendExclusions']);
        add_filter('rocket_exclude_css', [$this, 'appendRocketStyleExclusions']);
        add_filter('rocket_rucss_external_exclusions', [$this, 'appendStyleExclusions']);
        add_filter('rocket_rucss_inline_atts_exclusions', [$this, 'appendStyleExclusions']);
        add_filter('litespeed_optimize_js_excludes', [$this, 'appendExclusions']);
        add_filter('litespeed_optm_js_defer_exc', [$this, 'appendExclusions']);
        add_filter('litespeed_optm_gm_js_exc', [$this, 'appendExclusions']);
        add_filter('litespeed_optimize_css_excludes', [$this, 'appendStyleExclusions']);
        add_action('sekianafraz_sensor_changed', [$this, 'purgePageCaches']);
        add_action('shutdown', [$this, 'flushPageCaches']);
    }
    public function tagFrontendPage(): void
    {
        if (is_admin()) return;
        do_action('litespeed_tag_add', 'sekianafraz-sensor');
    }
    public function markRuntimeScript(string $tag, string $handle, string $src): string
    {
        if (!in_array($handle, ['sekianafraz-tracker', 'sekianafraz-banner-view', 'sekianafraz-reminder-bar', 'sekianafraz-reminder-style'], true)) {
            return $tag;
        }
        if (strpos($tag, ' nowprocket') === false) {
            $tag = str_replace('<script ', '<script nowprocket data-no-defer="1" ', $tag);
        }
        return $tag;
    }
    public function appendExclusions($exclusions): array
    {
        $exclusions = is_array($exclusions) ? $exclusions : [];
        return array_values(array_unique(array_merge($exclusions, self::SCRIPT_MARKERS)));
    }
    public function appendRocketScriptExclusions($exclusions): array
    {
        $exclusions = is_array($exclusions) ? $exclusions : [];
        foreach (['tracker', 'banner-view', 'reminder-bar', 'reminder-style'] as $file) {
            $exclusions[] = preg_quote((string)wp_parse_url(SEKIANAFRAZ_URL . 'assets/js/' . $file . '.js', PHP_URL_PATH), '#');
        }
        return array_values(array_unique($exclusions));
    }
    public function appendRocketStyleExclusions($exclusions): array
    {
        $exclusions = is_array($exclusions) ? $exclusions : [];
        $exclusions[] = preg_quote((string)wp_parse_url(SEKIANAFRAZ_URL . 'assets/css/reminder-bar.css', PHP_URL_PATH), '#');
        return array_values(array_unique($exclusions));
    }
    public function appendStyleExclusions($exclusions): array
    {
        $exclusions = is_array($exclusions) ? $exclusions : [];
        return array_values(array_unique(array_merge($exclusions, self::STYLE_MARKERS)));
    }
    public function purgePageCaches(int $sensorId = 0): void
    {
        SensorCache::invalidate();
        $this->purgePending = true;
    }
    public function flushPageCaches(): void
    {
        if (!$this->purgePending) return;
        $this->purgePending = false;
        if (function_exists('rocket_clean_domain')) {
            rocket_clean_domain();
        }
        do_action('litespeed_purge', 'sekianafraz-sensor');
    }
}
