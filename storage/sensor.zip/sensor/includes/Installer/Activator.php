<?php
namespace SeKianAfraz\VisitDiscount\Installer;
if (!defined('ABSPATH')) { exit; }
class Activator
{
    public static function activate(bool $networkWide = false): void
    {
        if ($networkWide) wp_die('سنسور را در هر سایت شبکه به‌صورت جداگانه فعال کنید.');
        if (!class_exists('WooCommerce')) wp_die('ووکامرس باید پیش از فعال‌سازی سنسور فعال باشد.');
        add_option('sekianafraz_phone_index_complete', 0, '', true);
        add_option('sekianafraz_phone_owner_work_pending', 0, '', true);
        if (!wp_next_scheduled('sekianafraz_daily_cleanup_event')) {
            $firstCleanup = (new \DateTimeImmutable('tomorrow 03:15', wp_timezone()))->getTimestamp();
            wp_schedule_event($firstCleanup ?: time() + HOUR_IN_SECONDS, 'daily', 'sekianafraz_daily_cleanup_event');
        }
        if (class_exists('SeKianAfraz\VisitDiscount\\Database\\Schema')) {
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createSMSQueueTable()) {
                update_option('sekianafraz_sms_queue_ready', 1, false);
            }
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createSensorIndexTable()) {
                update_option('sekianafraz_sensor_index_ready', 1, true);
            }
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createSensorCoverageTables()) {
                update_option('sekianafraz_sensor_coverage_ready', 1, true);
            }
            \SeKianAfraz\VisitDiscount\Database\Schema::createActionLogTable();
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createCouponRegistryTable()) {
                update_option('sekianafraz_coupon_registry_ready', 1, false);
            }
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createCouponRedemptionsTable()) {
                update_option('sekianafraz_coupon_redemptions_ready', 1, false);
            }
            \SeKianAfraz\VisitDiscount\Database\Schema::createDedupClaimsTable();
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createBannerSessionsTable()) {
                update_option('sekianafraz_banner_sessions_ready', 1, false);
            }
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createCollectedLeadsTable()) {
                update_option('sekianafraz_collected_leads_ready', 1, false);
            }
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createPhoneIndexTable()) {
                update_option('sekianafraz_phone_index_ready', 1, false);
            }
            if (\SeKianAfraz\VisitDiscount\Database\Schema::createPhoneOwnerCacheTable()) {
                update_option('sekianafraz_phone_owner_cache_ready', 1, false);
            }
        }
        global $wpdb;
        foreach (['sms_queue','sensor_index','sensor_coverage','sensor_exclusions','action_log','coupon_registry','coupon_redemptions','dedup_claims','banner_sessions','collected_leads','phone_index','phone_owner_cache'] as $suffix) {
            $table = $wpdb->prefix . 'sekianafraz_' . $suffix;
            if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) !== $table) {
                Deactivator::deactivate();
                wp_die('ساخت جدول‌های سنسور کامل نشد. دسترسی ساخت جدول در پایگاه داده را بررسی کنید.');
            }
        }
        if (class_exists('SeKianAfraz\VisitDiscount\\SMS\\SMSCronService')) {
            add_filter('cron_schedules', [\SeKianAfraz\VisitDiscount\SMS\SMSCronService::class, 'registerSchedules']);
            \SeKianAfraz\VisitDiscount\SMS\SMSCronService::scheduleEvents();
        }
        if (class_exists('SeKianAfraz\VisitDiscount\\SMS\\CredentialsVault')) {
            \SeKianAfraz\VisitDiscount\SMS\CredentialsVault::migrateLegacy();
        }
        self::disableAutoloadForPrivateOptions();
        \SeKianAfraz\VisitDiscount\Cache\SensorCache::invalidate();
        delete_option('sekianafraz_phone_strategy');
        if (function_exists('rocket_clean_domain')) {
            rocket_clean_domain();
        }
        do_action('litespeed_purge_all', 'Sensor plugin activated');
    }
    private static function disableAutoloadForPrivateOptions(): void
    {
        $options = [
            'sekianafraz_sms_settings' => false,
            'sekianafraz_phone_compat_custom' => false,
        ];
        if (function_exists('wp_set_option_autoload_values')) {
            wp_set_option_autoload_values($options);
            return;
        }
        global $wpdb;
        foreach (array_keys($options) as $option) {
            $wpdb->update($wpdb->options, ['autoload' => 'no'], ['option_name' => $option], ['%s'], ['%s']);
        }
    }
}
