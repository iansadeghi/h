<?php
namespace SeKianAfraz\VisitDiscount\Installer;
if (!defined('ABSPATH')) { exit; }
class Deactivator
{
    public static function deactivate(): void
    {
        \SeKianAfraz\VisitDiscount\Cache\SensorCache::invalidate();
        wp_clear_scheduled_hook('sekianafraz_coverage_retry');
        wp_clear_scheduled_hook('sekianafraz_phone_index_batch');
        wp_clear_scheduled_hook('sekianafraz_phone_owner_cache_batch');
        wp_clear_scheduled_hook('sekianafraz_daily_cleanup_event');
        wp_clear_scheduled_hook('sekianafraz_cleanup_continue');
        if (class_exists('SeKianAfraz\VisitDiscount\\SMS\\SMSCronService')) {
            \SeKianAfraz\VisitDiscount\SMS\SMSCronService::unscheduleEvents();
        }
        if (class_exists('SeKianAfraz\VisitDiscount\SMS\SMSQueueService')) {
            \SeKianAfraz\VisitDiscount\SMS\SMSQueueService::releaseAllProcessingJobs();
        }
        foreach (['sekianafraz_phone_index_lock', 'sekianafraz_phone_owner_cache_lock'] as $lockOption) {
            delete_option($lockOption);
        }
        if (function_exists('rocket_clean_domain')) rocket_clean_domain();
        do_action('litespeed_purge_all', 'Sensor plugin deactivated');
    }
}
