<?php
namespace SeKianAfraz\VisitDiscount\Pipeline;
if (!defined('ABSPATH')) { exit; }
class PipelineRegistry
{
    private array $stages = [];
    public function __construct(array $stages = [])
    {
        $this->setStages($stages);
    }
    public function getStages(): array
    {
        return $this->stages;
    }
    public function setStages(array $stages): void
    {
        $clean = [];
        foreach ($stages as $stage) {
            if ($stage instanceof PipelineStageInterface) {
                $clean[] = $stage;
            }
        }
        $this->stages = array_values($clean);
    }
    public function append(PipelineStageInterface $stage): void
    {
        $this->stages[] = $stage;
    }
    public function prepend(PipelineStageInterface $stage): void
    {
        array_unshift($this->stages, $stage);
    }
    public function insertAfter(string $afterClass, PipelineStageInterface $stage): void
    {
        $afterClass = ltrim($afterClass, '\\');
        $idx = $this->findIndexByClass($afterClass);
        if ($idx === null) {
            $this->append($stage);
            return;
        }
        array_splice($this->stages, $idx + 1, 0, [$stage]);
    }
    public function insertBefore(string $beforeClass, PipelineStageInterface $stage): void
    {
        $beforeClass = ltrim($beforeClass, '\\');
        $idx = $this->findIndexByClass($beforeClass);
        if ($idx === null) {
            $this->prepend($stage);
            return;
        }
        array_splice($this->stages, $idx, 0, [$stage]);
    }
    public function remove(string $class): void
    {
        $class = ltrim($class, '\\');
        $idx = $this->findIndexByClass($class);
        if ($idx === null) return;
        array_splice($this->stages, $idx, 1);
        $this->stages = array_values($this->stages);
    }
    public function replace(string $class, PipelineStageInterface $stage): void
    {
        $class = ltrim($class, '\\');
        $idx = $this->findIndexByClass($class);
        if ($idx === null) {
            $this->append($stage);
            return;
        }
        $this->stages[$idx] = $stage;
    }
    private function findIndexByClass(string $class): ?int
    {
        foreach ($this->stages as $i => $stage) {
            if (ltrim(get_class($stage), '\\') === $class) {
                return (int)$i;
            }
        }
        return null;
    }
}
