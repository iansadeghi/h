<?php
namespace SeKianAfraz\VisitDiscount\Pipeline;
use WP_Post;
use SeKianAfraz\VisitDiscount\Modules\ActionContext;
if (!defined('ABSPATH')) { exit; }
class PipelineContext
{
    public int $sensorId;
    public string $guestId;
    public int $userId = 0;
    public ?WP_Post $post = null;
    public array $meta = [];
    public string $action = '';
    public int $issuedAtMs = 0;
    public string $couponCode = '';
    public string $couponExpiry = '';
    public int $expiresAtMs = 0;
    public ?array $reminderData = null;
    public array $payload = [];
    public string $fallbackUrl = '';
    public ?ActionContext $actionContext = null;
        public bool $dedupClaimed = false;
    public ?array $response = null;
    public function __construct(int $sensorId, string $guestId)
    {
        $this->sensorId = $sensorId;
        $this->guestId = (string)$guestId;
    }
}
