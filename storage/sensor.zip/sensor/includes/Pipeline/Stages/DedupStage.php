<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
use SeKianAfraz\VisitDiscount\Logs\ActionLogger;
if (!defined('ABSPATH')) { exit; }
class DedupStage implements PipelineStageInterface
{
    private ActionLogger $actionLogger;
    public function __construct(ActionLogger $actionLogger)
    {
        $this->actionLogger = $actionLogger;
    }
    public function handle(PipelineContext $ctx): void
    {
        if ($this->actionLogger->alreadyDone($ctx->sensorId, $ctx->userId, $ctx->guestId)) {
            $ctx->response = ['success' => true, 'code' => 'ALREADY', 'message' => ''];
            return;
        }
        $acquired = $this->actionLogger->acquireClaim($ctx->sensorId, $ctx->userId, $ctx->guestId, 120);
        if (!$acquired) {
            $ctx->response = ['success' => false, 'code' => 'BUSY', 'message' => ''];
            return;
        }
        $ctx->dedupClaimed = true;
        if ($this->actionLogger->alreadyDone($ctx->sensorId, $ctx->userId, $ctx->guestId)) {
            $ctx->response = ['success' => true, 'code' => 'ALREADY', 'message' => ''];
        }
    }
}
