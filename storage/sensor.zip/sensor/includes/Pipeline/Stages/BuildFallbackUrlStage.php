<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
if (!defined('ABSPATH')) { exit; }
class BuildFallbackUrlStage implements PipelineStageInterface
{
    public function handle(PipelineContext $ctx): void
    {
        $ctx->fallbackUrl = $this->currentUrlFromPath();
    }
    private function currentUrlFromPath(): string
    {
        $home = rtrim(home_url('/'), '/');
        $path = isset($_SERVER['REQUEST_URI']) ? (string)$_SERVER['REQUEST_URI'] : '/';
        if ($path === '') $path = '/';
        $homePath = parse_url($home, PHP_URL_PATH) ?: '';
        if ($homePath === '') $homePath = '/';
        if ($homePath !== '/' && strpos($path, $homePath) === 0) {
            $trimmed = substr($path, strlen(rtrim($homePath, '/')));
            if ($trimmed === '') $trimmed = '/';
            $path = $trimmed;
        }
        return $home . ($path[0] === '/' ? '' : '/') . $path;
    }
}
