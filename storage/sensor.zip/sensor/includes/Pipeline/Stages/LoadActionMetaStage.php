<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
use SeKianAfraz\VisitDiscount\Helpers\UrlHelper;
if (!defined('ABSPATH')) { exit; }
class LoadActionMetaStage implements PipelineStageInterface
{
    private UrlHelper $urlHelper;
    public function __construct(UrlHelper $urlHelper)
    {
        $this->urlHelper = $urlHelper;
    }
    public function handle(PipelineContext $ctx): void
    {
        $sensorId = $ctx->sensorId;
        $action = (string)get_post_meta($sensorId, 'action', true);
        $couponStrategy = (string)get_post_meta($sensorId, 'coupon_strategy', true) ?: 'individual';
        $fixedCode = (string)get_post_meta($sensorId, 'fixed_code', true);
        $couponType = (string)get_post_meta($sensorId, 'coupon_type', true);
        $couponCustomPrefix = (string)get_post_meta($sensorId, 'coupon_custom_prefix', true);
        $couponCustomSuffix = (string)get_post_meta($sensorId, 'coupon_custom_suffix', true);
        $couponCustomLength = (int)get_post_meta($sensorId, 'coupon_custom_length', true);
        if ($couponCustomLength <= 0) $couponCustomLength = 4;
        $couponCustomMidPattern = (string)get_post_meta($sensorId, 'coupon_custom_mid_pattern', true);
        if ($couponCustomMidPattern === '') $couponCustomMidPattern = 'mixed';
        $couponAmount = (float)get_post_meta($sensorId, 'coupon_amount', true);
        $couponMode = (string)get_post_meta($sensorId, 'coupon_mode', true);
        $couponFreeShipping = (bool)get_post_meta($sensorId, 'coupon_free_shipping', true);
        $validHours = (int)get_post_meta($sensorId, 'coupon_valid_hours', true);
        if ($validHours <= 0) $validHours = 72;
        $storedUsageLimit = get_post_meta($sensorId, 'coupon_usage_limit', true);
        $usageLimit = $storedUsageLimit === '' ? 3 : max(0, (int)$storedUsageLimit);
        if ($couponStrategy === 'fixed' && $fixedCode !== '') {
            $coupon = new \WC_Coupon($fixedCode);
            if ($coupon->get_id() > 0) {
                $couponAmount = (float)$coupon->get_amount();
                $couponMode = $coupon->get_discount_type() === 'percent' ? 'percent' : 'fixed';
                $couponFreeShipping = $coupon->get_free_shipping();
                $expiry = $coupon->get_date_expires();
                $validHours = $expiry ? max(0, (int)ceil(($expiry->getTimestamp() - time()) / HOUR_IN_SECONDS)) : 0;
            }
        }
        $bannerText = (string)get_post_meta($sensorId, 'banner_text', true);
        $buttonColor = (string)get_post_meta($sensorId, 'banner_button_color', true);
        $hideBannerForLoggedIn = (bool)get_post_meta($sensorId, 'hide_banner_for_logged_in', true);
        $limitEnabled = (bool)get_post_meta($sensorId, 'coupon_limit_enabled', true);
        $limitType = (string)get_post_meta($sensorId, 'coupon_limit_type', true);
        $limitIds = (array)get_post_meta($sensorId, 'coupon_limit_ids', true);
        $reminderEnabled = (bool)get_post_meta($sensorId, 'reminder_enabled', true);
        $reminderMessageTemplate = (string)get_post_meta($sensorId, 'reminder_message_template', true) ?: 'فقط {Timer} ساعت برای استفاده از کد تخفیف {coupon_code} باقی مونده!';
        $reminderShowTimerPanel = (bool)get_post_meta($sensorId, 'reminder_show_timer_panel', true);
        $reminderColors = get_post_meta($sensorId, 'reminder_colors', true);
        if (!is_array($reminderColors)) {
            $reminderColors = [
                'bg' => '#ffffff',
                'text' => '#4b5563',
                'timer_value' => '#5F0027',
                'timer_bg' => '#000000',
                'timer_text' => '#ffffff',
                'close_btn' => '#4b5563',
                'coupon_highlight' => '#5F0027',
            ];
        }
        $ctx->meta = [
            'action' => $action,
            'coupon_strategy' => $couponStrategy,
            'fixed_code' => $fixedCode,
            'coupon_type' => $couponType,
            'coupon_custom_prefix' => $couponCustomPrefix,
            'coupon_custom_suffix' => $couponCustomSuffix,
            'coupon_custom_length' => $couponCustomLength,
            'coupon_custom_mid_pattern' => $couponCustomMidPattern,
            'coupon_amount' => $couponAmount,
            'coupon_mode' => $couponMode,
            'coupon_free_shipping' => $couponFreeShipping,
            'coupon_valid_hours' => $validHours,
            'coupon_usage_limit' => $usageLimit,
            'coupon_restrict_user' => (bool)get_post_meta($sensorId, 'coupon_restrict_user', true),
            'coupon_restrict_guest' => (bool)get_post_meta($sensorId, 'coupon_restrict_guest', true),
            'banner_text' => $bannerText,
            'button_color' => $buttonColor,
            'hide_banner_for_logged_in' => $hideBannerForLoggedIn,
            'banner_type' => get_post_meta($sensorId, 'banner_type', true) === 'multi' ? 'multi' : 'single',
            'logged_behavior' => (string)get_post_meta($sensorId, 'logged_behavior', true) ?: 'single_sms',
            'coupon_limit_enabled' => $limitEnabled,
            'coupon_limit_type' => $limitType,
            'coupon_limit_ids' => $limitIds,
            'reminder_enabled' => $reminderEnabled,
            'reminder_message_template' => $reminderMessageTemplate,
            'reminder_show_timer_panel' => $reminderShowTimerPanel,
            'reminder_colors' => $reminderColors,
            'reminder_styles' => (array)get_post_meta($sensorId, 'reminder_styles', true),
        ];
        $ctx->action = $action;
    }
}
