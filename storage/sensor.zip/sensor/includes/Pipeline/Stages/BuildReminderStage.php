<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
use SeKianAfraz\VisitDiscount\Reminder\ReminderBuilder;
if (!defined('ABSPATH')) { exit; }
class BuildReminderStage implements PipelineStageInterface
{
    private ReminderBuilder $reminderBuilder;
    public function __construct(ReminderBuilder $reminderBuilder)
    {
        $this->reminderBuilder = $reminderBuilder;
    }
    public function handle(PipelineContext $ctx): void
    {
        if ($ctx->couponCode === '') return;
        $ctx->reminderData = $this->reminderBuilder->build(
            $ctx->sensorId,
            $ctx->meta,
            $ctx->couponCode,
            $ctx->expiresAtMs,
            $ctx->issuedAtMs
        );
    }
}
