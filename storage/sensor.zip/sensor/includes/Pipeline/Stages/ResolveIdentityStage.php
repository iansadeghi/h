<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
if (!defined('ABSPATH')) { exit; }
class ResolveIdentityStage implements PipelineStageInterface
{
    public function handle(PipelineContext $ctx): void
    {
        $ctx->userId = (int)get_current_user_id();
    }
}
