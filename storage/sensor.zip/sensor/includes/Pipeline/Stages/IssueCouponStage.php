<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
use SeKianAfraz\VisitDiscount\Coupons\CouponIssuer;
if (!defined('ABSPATH')) { exit; }
class IssueCouponStage implements PipelineStageInterface
{
    private CouponIssuer $couponIssuer;
    public function __construct(CouponIssuer $couponIssuer)
    {
        $this->couponIssuer = $couponIssuer;
    }
    public function handle(PipelineContext $ctx): void
    {
        $smsOnly = $ctx->action === 'sms' || ($ctx->action === 'both' && $ctx->userId > 0 && !empty($ctx->meta['hide_banner_for_logged_in']) && ($ctx->meta['audience'] ?? '') !== 'logged');
        if ($smsOnly && $ctx->userId <= 0) {
            $ctx->response = ['success' => false, 'code' => 'LOGIN_REQUIRED', 'message' => ''];
            return;
        }
        if ($smsOnly && (new \SeKianAfraz\VisitDiscount\Helpers\PhoneResolver())->resolve($ctx->userId) === '') {
            $ctx->response = ['success' => false, 'code' => 'NO_PHONE', 'message' => ''];
            return;
        }
        if ($ctx->userId <= 0 && ($ctx->meta['banner_type'] ?? '') === 'multi' &&
            in_array($ctx->action, ['banner', 'both'], true)) return;
        $ctx->issuedAtMs = (int)(microtime(true) * 1000);
        $couponIssue = $this->couponIssuer->issueForSensor($ctx->sensorId, $ctx->userId, $ctx->guestId, $ctx->meta);
        if (!($couponIssue['success'] ?? false)) {
            $ctx->response = $couponIssue['response'] ?? ['success' => false, 'code' => 'COUPON', 'message' => ''];
            return;
        }
        $ctx->couponCode = (string)($couponIssue['coupon_code'] ?? '');
        $ctx->couponExpiry = (string)($couponIssue['coupon_expiry'] ?? '');
        $ctx->expiresAtMs = (int)($couponIssue['expires_at_ms'] ?? 0);
        if ($ctx->couponCode === '') {
            $ctx->response = ['success' => false, 'code' => 'COUPON', 'message' => ''];
        }
    }
}
