<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
if (!defined('ABSPATH')) { exit; }
class ValidateSensorStage implements PipelineStageInterface
{
    public function handle(PipelineContext $ctx): void
    {
        if ($ctx->sensorId <= 0) {
            $ctx->response = ['success' => false, 'code' => 'INVALID', 'message' => ''];
            return;
        }
        $post = get_post($ctx->sensorId);
        if (!$post || $post->post_type !== 'sekianafraz_sensor' || $post->post_status !== 'publish') {
            $ctx->response = ['success' => false, 'code' => 'FORBIDDEN', 'message' => ''];
            return;
        }
        $ctx->post = $post;
    }
}
