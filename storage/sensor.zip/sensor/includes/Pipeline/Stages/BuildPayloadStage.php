<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
if (!defined('ABSPATH')) { exit; }
class BuildPayloadStage implements PipelineStageInterface
{
    public function handle(PipelineContext $ctx): void
    {
        $couponAmount = (float)($ctx->meta['coupon_amount'] ?? 0);
        $couponStrategy = (string)($ctx->meta['coupon_strategy'] ?? 'individual');
        $validHours = (int)($ctx->meta['coupon_valid_hours'] ?? 72);
        $ctx->payload = [
            'coupon_code' => $ctx->couponCode,
            'coupon_value' => $couponAmount,
            'coupon_expiry_time' => $ctx->couponExpiry,
            'coupon_valid_hours' => $couponStrategy === 'fixed' ? 0 : $validHours,
            'coupon_strategy' => $couponStrategy,
            'coupon_is_virtual' => ($couponStrategy === 'virtual'),
        ];
    }
}
