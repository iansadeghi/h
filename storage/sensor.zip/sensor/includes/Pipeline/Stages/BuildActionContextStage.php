<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
use SeKianAfraz\VisitDiscount\Modules\ActionContext;
use SeKianAfraz\VisitDiscount\SMS\SmsMessageBuilder;
use SeKianAfraz\VisitDiscount\Banners\BannerBuilder;
use SeKianAfraz\VisitDiscount\Logs\ActionLogger;
if (!defined('ABSPATH')) { exit; }
class BuildActionContextStage implements PipelineStageInterface
{
    private SmsMessageBuilder $smsMessageBuilder;
    private BannerBuilder $bannerBuilder;
    private ActionLogger $actionLogger;
    public function __construct(
        SmsMessageBuilder $smsMessageBuilder,
        BannerBuilder $bannerBuilder,
        ActionLogger $actionLogger
    )
    {
        $this->smsMessageBuilder = $smsMessageBuilder;
        $this->bannerBuilder = $bannerBuilder;
        $this->actionLogger = $actionLogger;
    }
    public function handle(PipelineContext $ctx): void
    {
        $ctx->actionContext = new ActionContext(
            $ctx->sensorId,
            $ctx->userId,
            $ctx->guestId,
            $ctx->couponCode,
            $ctx->payload,
            $ctx->meta,
            $ctx->reminderData,
            $ctx->fallbackUrl,
            $this->smsMessageBuilder,
            $this->bannerBuilder,
            $this->actionLogger
        );
    }
}
