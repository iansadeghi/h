<?php
namespace SeKianAfraz\VisitDiscount\Pipeline\Stages;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineContext;
use SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface;
if (!defined('ABSPATH')) { exit; }
class ResolveBannerAudienceStage implements PipelineStageInterface
{
    public function handle(PipelineContext $ctx): void
    {
        if (!in_array($ctx->action, ['banner', 'both'], true) || ($ctx->meta['banner_type'] ?? '') !== 'multi') return;
        if ($ctx->userId <= 0) return;
        $behavior = $ctx->meta['logged_behavior'] ?? 'single_sms';
        if ($behavior === 'none') {
            $ctx->response = ['success' => true, 'code' => 'SKIPPED', 'message' => ''];
            return;
        }
        $ctx->meta['audience'] = 'logged';
        if ($behavior === 'sms') $ctx->action = 'sms';
        elseif ($behavior === 'single_sms') $ctx->action = 'both';
        else $ctx->action = 'banner';
    }
}
