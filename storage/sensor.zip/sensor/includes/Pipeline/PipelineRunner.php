<?php
namespace SeKianAfraz\VisitDiscount\Pipeline;
if (!defined('ABSPATH')) { exit; }
class PipelineRunner
{
    private array $stages;
    public function __construct(array $stages)
    {
        $this->stages = $stages;
    }
    public function run(PipelineContext $ctx): PipelineContext
    {
        $stages = $this->stages;
if (function_exists('apply_filters')) {
    $stages = apply_filters('sekianafraz_pipeline_stages_runtime', $stages, $ctx);
}
$clean = [];
foreach ($stages as $s) {
    if ($s instanceof \SeKianAfraz\VisitDiscount\Pipeline\PipelineStageInterface) {
        $clean[] = $s;
    }
}
$stages = $clean;
foreach ($stages as $stage) {
            $stage->handle($ctx);
            if ($ctx->response !== null) {
                break;
            }
        }
        return $ctx;
    }
}
