<?php
namespace SeKianAfraz\VisitDiscount\Pipeline;
if (!defined('ABSPATH')) { exit; }
interface PipelineStageInterface
{
    public function handle(PipelineContext $ctx): void;
}
