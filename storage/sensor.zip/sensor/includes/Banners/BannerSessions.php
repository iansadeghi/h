<?php
namespace SeKianAfraz\VisitDiscount\Banners;
use SeKianAfraz\VisitDiscount\Modules\ActionContext;
use SeKianAfraz\VisitDiscount\SMS\SmsDispatcher;
use SeKianAfraz\VisitDiscount\Logs\ActionLogger;
use SeKianAfraz\VisitDiscount\Coupons\CouponIssuer;
use SeKianAfraz\VisitDiscount\SMS\SmsMessageBuilder;
use SeKianAfraz\VisitDiscount\Reminder\ReminderBuilder;
use SeKianAfraz\VisitDiscount\Leads\LeadsRepository;
use SeKianAfraz\VisitDiscount\Helpers\PhoneNormalizer;
if (!defined('ABSPATH')) { exit; }
class BannerSessions
{
    public function create(ActionContext $ctx): string
    {
        if ($ctx->guestId === '') return '';
        $mode = (string)get_post_meta($ctx->sensorId, 'sms_mode', true);
        if (!in_array($mode, ['promo','pattern'], true)) return '';
        try { $token = bin2hex(random_bytes(32)); } catch (\Throwable $error) { return ''; }
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_banner_sessions';
        $data = ['payload' => $ctx->payload, 'meta' => $ctx->meta,
            'revision' => hash('sha256', wp_json_encode(get_post_meta($ctx->sensorId))),
            'fallback_url' => $ctx->fallbackUrl,
            'page_context' => (array)($_REQUEST['sekianafraz_ctx'] ?? [])];
        $ok = $wpdb->insert($table, [
            'token_hash' => hash('sha256', $token), 'sensor_id' => $ctx->sensorId,
            'guest_id' => $ctx->guestId, 'coupon_code' => $ctx->couponCode,
            'sms_data' => wp_json_encode($data), 'created_at' => current_time('mysql', true),
        ], ['%s','%d','%s','%s','%s','%s']);
        return $ok ? $token : '';
    }
    public function send(string $token, string $rawPhone, bool $correction = false): array
    {
        $phone = PhoneNormalizer::mobile($rawPhone);
        if ($phone === '') return ['success' => false, 'code' => 'INVALID_PHONE', 'message' => 'شماره تلفن معتبر نیست.'];
        if (!preg_match('/^[a-f0-9]{64}$/', $token)) return ['success' => false, 'code' => 'INVALID_SESSION', 'message' => 'نشست بنر معتبر نیست.'];
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_banner_sessions';
        $hash = hash('sha256', $token);
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table} WHERE token_hash=%s LIMIT 1", $hash), ARRAY_A);
        $guestCookie = sanitize_text_field((string)($_COOKIE['sekianafraz_guest_id'] ?? ''));
        if (!$row || !hash_equals((string)$row['guest_id'], $guestCookie) || is_user_logged_in() ||
            get_post_status((int)$row['sensor_id']) !== 'publish' ||
            get_post_meta((int)$row['sensor_id'], 'banner_type', true) !== 'multi' ||
            time() - strtotime((string)$row['created_at'] . ' UTC') > 900) {
            return ['success' => false, 'code' => 'SESSION_EXPIRED', 'message' => 'نشست بنر منقضی شده است.'];
        }
        $storedData = json_decode((string)$row['sms_data'], true);
        if (!empty($storedData['delivery_pending'])) {
            return ['success' => false, 'code' => 'DELIVERY_UNKNOWN', 'message' => 'وضعیت ارسال مشخص نیست؛ برای جلوگیری از ارسال تکراری، با پشتیبانی فروشگاه تماس بگیرید.'];
        }
        $phoneHash = hash_hmac('sha256', $phone, wp_salt('auth'));
        if ($row['sent_at'] && !$correction) {
            return ['success' => true, 'code' => 'ALREADY_SENT', 'message' => '',
                'reminder' => $this->reminderFor($row)];
        }
        if ($correction && (!$row['sent_at'] || $row['corrected_at'] || $row['phone_hash'] === $phoneHash)) {
            return ['success' => false, 'code' => 'CORRECTION_UNAVAILABLE', 'message' => 'اصلاح شماره در این نشست ممکن نیست.'];
        }
        if ((int)$row['attempts'] >= 3) return ['success' => false, 'code' => 'TOO_MANY_ATTEMPTS', 'message' => 'دفعات ارسال بیش از حد است.'];
        $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
        if (!LeadsRepository::ensureReady()) {
            return ['success' => false, 'code' => 'LEADS_UNAVAILABLE', 'message' => 'ثبت شماره انجام نشد. دوباره تلاش کنید.'];
        }
        $claimed = $wpdb->query($wpdb->prepare(
            "UPDATE {$table} SET attempts=attempts+1, claimed_at=UTC_TIMESTAMP()
             WHERE token_hash=%s AND attempts<3 AND " .
            ($correction ? "sent_at IS NOT NULL AND corrected_at IS NULL AND phone_hash<>%s" : "sent_at IS NULL") . "
             AND (claimed_at IS NULL OR claimed_at < (UTC_TIMESTAMP() - INTERVAL 2 MINUTE))",
            ...($correction ? [$hash, $phoneHash] : [$hash])
        ));
        if ($claimed !== 1) return ['success' => false, 'code' => 'SENDING', 'message' => 'درحال ارسال است.'];
        try {
            foreach (['sms:ip:' . $ip, 'sms:phone:' . $phone] as $scope) {
                if (!\SeKianAfraz\VisitDiscount\Helpers\RateLimiter::consume($scope, 5, 10 * MINUTE_IN_SECONDS)) {
                    return ['success' => false, 'code' => 'RATE_LIMITED', 'message' => 'کمی بعد دوباره تلاش کنید.'];
                }
            }
            $leads = new LeadsRepository();
            if (!$leads->record($hash, (int)$row['sensor_id'], $phone)) {
                return ['success' => false, 'code' => 'LEAD_FAILED', 'message' => 'ثبت شماره انجام نشد. دوباره تلاش کنید.'];
            }
            $data = json_decode((string)$row['sms_data'], true);
            if (!is_array($data) || !is_array($data['meta'] ?? null) || !is_array($data['payload'] ?? null)) {
                throw new \RuntimeException('Invalid banner session');
            }
            if (!hash_equals((string)($data['revision'] ?? ''), hash('sha256', wp_json_encode(get_post_meta((int)$row['sensor_id']))))) {
                return ['success' => false, 'code' => 'SESSION_CHANGED', 'message' => 'پیشنهاد به‌روز شده است؛ صفحه را تازه کنید.'];
            }
            $_REQUEST['sekianafraz_ctx'] = (array)($data['page_context'] ?? []);
            $mode = (string)get_post_meta((int)$row['sensor_id'], 'sms_mode', true);
            $template = (string)get_post_meta((int)$row['sensor_id'],
                $mode === 'pattern' ? 'sms_pattern' : 'sms_text', true);
            if (!in_array($mode, ['promo', 'pattern'], true) ||
                ($mode === 'promo' && strpos($template, '{{coupon_code}}') === false) ||
                ($mode === 'pattern' && !preg_match('/(?:^|\R)\s*\{\{coupon_code\}\}\s*(?=$|\R)/', $template))) {
                $leads->markStatus($hash, 'failed');
                return ['success' => false, 'code' => 'SMS_TEMPLATE_INVALID', 'message' => 'متن پیامک کد تخفیف را ندارد.'];
            }
            if ($row['coupon_code'] === '') {
                $issuedAtMs = (int)(microtime(true) * 1000);
                $coupon = (new CouponIssuer())->issueForSensor((int)$row['sensor_id'], 0,
                    (string)$row['guest_id'], (array)$data['meta']);
                if (empty($coupon['success']) || empty($coupon['coupon_code'])) {
                    $leads->markStatus($hash, 'failed');
                    $failure = is_array($coupon['response'] ?? null) ? $coupon['response'] : [];
                    return [
                        'success' => false,
                        'code' => (string)($failure['code'] ?? 'COUPON_FAILED'),
                        'message' => (string)($failure['message'] ?? 'ایجاد کد تخفیف انجام نشد.'),
                    ];
                }
                $row['coupon_code'] = (string)$coupon['coupon_code'];
                $data['payload']['coupon_code'] = $row['coupon_code'];
                $data['payload']['coupon_expiry_time'] = (string)($coupon['coupon_expiry'] ?? '');
                $data['issued_at_ms'] = $issuedAtMs;
                $data['expires_at_ms'] = (int)($coupon['expires_at_ms'] ?? 0);
                $persisted = $wpdb->update($table,
                    ['coupon_code' => $row['coupon_code'], 'sms_data' => wp_json_encode($data)],
                    ['token_hash' => $hash]);
                if ($persisted === false) throw new \RuntimeException('Unable to retain coupon');
            } else {
                $data['payload']['coupon_code'] = (string)$row['coupon_code'];
            }
            if (!\SeKianAfraz\VisitDiscount\Coupons\CouponAvailability::usable((string)$row['coupon_code'])) {
                return ['success' => false, 'code' => 'COUPON_UNAVAILABLE', 'message' => 'کد تخفیف دیگر معتبر نیست.'];
            }
            $prepared = (new SmsMessageBuilder())->build((int)$row['sensor_id'], (array)$data['payload'],
                (string)($data['fallback_url'] ?? ''));
            if (!in_array((string)($prepared['mode'] ?? ''), ['promo','pattern'], true) ||
                ($prepared['mode'] === 'pattern' ? empty($prepared['pattern']) : empty($prepared['message']))) {
                throw new \RuntimeException('SMS template unavailable');
            }
            $settings = \SeKianAfraz\VisitDiscount\SMS\CredentialsVault::load();
            $provider = sanitize_text_field((string)($settings['provider'] ?? ''));
            $logger = new ActionLogger();
            $dispatcher = new SmsDispatcher(static function(int $sensorId, int $userId, string $guestId, string $type, string $couponCode) use ($logger): void {
                $logger->log($sensorId, $userId, $guestId, $type, $couponCode);
            });
            $data['delivery_pending'] = true;
            if ($wpdb->update($table, ['sms_data' => wp_json_encode($data)], ['token_hash' => $hash]) === false) {
                throw new \RuntimeException('Unable to retain delivery state');
            }
            $result = $dispatcher->dispatch(
                (int)$row['sensor_id'], 0, (string)$row['guest_id'], $phone,
                $provider, (array)($settings['config'] ?? []), (string)$prepared['mode'],
                (string)$prepared['message'], (array)$prepared['vars'], 'immediate', 0,
                (string)$row['coupon_code'], (string)($prepared['pattern'] ?? '')
            );
            if (!empty($result['status']['delivery_uncertain'])) {
                $leads->markStatus($hash, 'failed');
                return ['success' => false, 'code' => 'DELIVERY_UNKNOWN', 'message' => 'وضعیت ارسال مشخص نیست؛ برای جلوگیری از ارسال تکراری، با پشتیبانی فروشگاه تماس بگیرید.'];
            }
            $data['delivery_pending'] = false;
            if (!empty($result['status']['success'])) {
                $updated = $correction
                    ? ['corrected_at' => current_time('mysql', true), 'phone_hash' => $phoneHash, 'claimed_at' => null]
                    : ['sent_at' => current_time('mysql', true), 'phone_hash' => $phoneHash, 'claimed_at' => null];
                $updated['sms_data'] = wp_json_encode($data);
                if ($wpdb->update($table, $updated, ['token_hash' => $hash]) === false) throw new \RuntimeException('Unable to retain delivery result');
                $leads->markStatus($hash, 'sent');
                $reminder = (new ReminderBuilder())->build((int)$row['sensor_id'], (array)$data['meta'],
                    (string)$row['coupon_code'], (int)($data['expires_at_ms'] ?? 0),
                    (int)($data['issued_at_ms'] ?? 0));
                return ['success' => true, 'code' => 'SENT', 'message' => '', 'reminder' => $reminder];
            }
            $wpdb->update($table, ['sms_data' => wp_json_encode($data)], ['token_hash' => $hash]);
            $leads->markStatus($hash, 'failed');
            return ['success' => false, 'code' => 'SEND_FAILED', 'message' => 'ارسال انجام نشد. دوباره تلاش کنید.'];
        } catch (\Throwable $error) {
            if (isset($leads)) $leads->markStatus($hash, 'failed');
            return ['success' => false, 'code' => 'SEND_FAILED', 'message' => 'ارسال انجام نشد. دوباره تلاش کنید.'];
        } finally {
            $wpdb->update($table, ['claimed_at' => null], ['token_hash' => $hash], ['%s'], ['%s']);
        }
    }
    private function reminderFor(array $row): ?array
    {
        $data = json_decode((string)$row['sms_data'], true);
        if (!is_array($data)) return null;
        return (new ReminderBuilder())->build((int)$row['sensor_id'], (array)($data['meta'] ?? []),
            (string)$row['coupon_code'], (int)($data['expires_at_ms'] ?? 0),
            (int)($data['issued_at_ms'] ?? 0));
    }
}
