<?php
namespace SeKianAfraz\VisitDiscount\Banners;
use SeKianAfraz\VisitDiscount\Helpers\TemplateEngine;
if (!defined('ABSPATH')) { exit; }
class BannerBuilder
{
    private $templateEngine;
    public function __construct(?TemplateEngine $templateEngine = null)
    {
        $this->templateEngine = $templateEngine ?: new TemplateEngine();
    }
    public function build(int $sensorId, array $payload, array $meta, ?array $reminderData): array
    {
        $vars = $this->templateEngine->buildVars($sensorId, $payload);
        $logged = ($meta['audience'] ?? '') === 'logged';
        $storedAppearance = get_post_meta($sensorId, 'logged_banner', true);
        $appearance = $logged && is_array($storedAppearance) ? $storedAppearance : [];
        $get = static function(string $key, $default = '') use ($sensorId, $appearance) {
            if (array_key_exists($key, $appearance)) return $appearance[$key];
            $value = get_post_meta($sensorId, $key, true);
            if ($key === 'banner_button_closes' && $value === '') {
                return metadata_exists('post', $sensorId, $key) ? false : $default;
            }
            return $value === '' ? $default : $value;
        };
        $multi = !$logged && ($meta['banner_type'] ?? '') === 'multi';
        $title = (string)$get('banner_title');
        if ($title === '') $title = 'تبریک میگم!';
        $html = $this->templateEngine->render((string)$get('banner_text'), $vars, true);
        $buttonColor = (string)$get('banner_button_color');
        if ($buttonColor === '') $buttonColor = '#000000';
        $buttonText = (string)$get('banner_button_text');
        if ($buttonText === '' || ($multi && $buttonText === 'بزن بریم!')) $buttonText = $multi ? 'دریافت تخفیف' : 'بزن بریم!';
        $brMeta = $get('banner_border_radius', 0);
        $borderRadius = $brMeta !== '' ? (int)$brMeta : 0;
        $radiusMode = $get('banner_radius_mode') === 'manual' ? 'manual' : 'simple';
        $borderRadii = $get('banner_border_radii', []);
        if (!is_array($borderRadii)) $borderRadii = [];
        $paddings = $get('banner_paddings', []);
        if (!is_array($paddings)) $paddings = [];
        $result = [
            'html' => $html,
            'title' => $title,
            'coupon_code' => $multi ? '' : (string)($payload['coupon_code'] ?? ''),
            'banner_type' => $multi ? 'multi' : 'single',
            'target_url' => $multi || (bool)$get('banner_button_closes', true) ? '' : (string)$get('banner_target_url'),
            'banner_button_closes' => $multi || (bool)$get('banner_button_closes', true),
            'button_color' => $buttonColor,
            'banner_image' => (string)$get('banner_image'),
            'banner_hide_image' => (bool)$get('banner_hide_image', false),
            'banner_svg_color' => (string)$get('banner_svg_color', '#000000'),
            'banner_border_radius' => $borderRadius,
            'banner_radius_mode' => $radiusMode,
            'banner_border_radii' => $borderRadii,
            'banner_paddings' => $paddings,
            'banner_margins' => (array)$get('banner_margins', []),
            'banner_button_text' => $buttonText,
            'banner_bg_color' => (string)$get('banner_bg_color', '#ffffff'),
            'banner_title_color' => (string)$get('banner_title_color', '#0d0d0d'),
            'banner_text_color' => (string)$get('banner_text_color', '#4b5563'),
            'banner_coupon_color' => (string)$get('banner_coupon_color', '#5c5c5c'),
            'banner_font_type' => (string)$get('banner_font_type', 'arad'),
            'banner_show_close' => (bool)$get('banner_show_close', false),
            'banner_close_hide_bg' => (bool)$get('banner_close_hide_bg', false),
            'banner_close_position' => (string)$get('banner_close_position', 'left'),
            'close_bg_color' => (string)$get('close_bg_color', '#f1f1f1'),
            'close_icon_color' => (string)$get('close_icon_color', '#111111'),
            'banner_button_text_color' => (string)$get('banner_button_text_color', '#ffffff'),
            'discount_bg_color' => (string)$get('discount_bg_color', '#f2f2f2'),
            'discount_border_color' => (string)$get('discount_border_color', '#d1d5db'),
            'copy_bg_color' => (string)$get('copy_bg_color', '#e5e7eb'),
            'copy_text_color' => (string)$get('copy_text_color', '#000000'),
            'reminder' => $reminderData,
        ];
        if ($multi) {
            foreach (['multi_prompt','multi_phone_placeholder','multi_submit_text','multi_sending_text',
                'multi_success_text','multi_correction_text'] as $field) {
                $result[$field] = (string)get_post_meta($sensorId, $field, true);
            }
            $colors = get_post_meta($sensorId, 'multi_colors', true);
            if (is_array($colors)) $result = array_merge($result, $colors);
        }
        return $result;
    }
}
