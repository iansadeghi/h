<?php
namespace SeKianAfraz\VisitDiscount\Banners;
use SeKianAfraz\VisitDiscount\Coupons\CouponIssuer;
use SeKianAfraz\VisitDiscount\Helpers\PhoneNormalizer;
use SeKianAfraz\VisitDiscount\Helpers\TemplateEngine;
use SeKianAfraz\VisitDiscount\SMS\SmsDispatcher;
use SeKianAfraz\VisitDiscount\SMS\SmsService;
if (!defined('ABSPATH')) { exit; }
class BannerPreviewSender
{
    public function send(array $draft, string $rawPhone, string $reuseToken = ''): array
    {
        $phone = PhoneNormalizer::mobile($rawPhone);
        if ($phone === '') return $this->error('شماره تلفن معتبر نیست.');
        if (!in_array((string)($draft['action'] ?? ''), ['banner', 'both'], true) ||
            ($draft['banner_type'] ?? '') !== 'multi') return $this->error('بنر چندمرحله‌ای انتخاب نشده است.');
        $sensorId = max(0, (int)($draft['id'] ?? 0));
        if ($sensorId && get_post_type($sensorId) !== 'sekianafraz_sensor') return $this->error('سنسور معتبر نیست.');
        $mode = sanitize_key((string)($draft['sms_mode'] ?? ''));
        if (!in_array($mode, ['promo', 'pattern'], true)) return $this->error('نوع پیامک را انتخاب کنید.');
        $template = (string)($draft[$mode === 'pattern' ? 'sms_pattern' : 'sms_text'] ?? '');
        if (strlen($template) > 4000) return $this->error('متن پیامک بیش از حد طولانی است.');
        if (($mode === 'promo' && strpos($template, '{{coupon_code}}') === false) ||
            ($mode === 'pattern' && !preg_match('/(?:^|\R)\s*\{\{coupon_code\}\}\s*(?=$|\R)/', $template))) {
            return $this->error('متغیر {{coupon_code}} را در پیامک قرار دهید.');
        }
        if ($mode === 'pattern' && trim((string)strtok($template, "\r\n")) === '') {
            return $this->error('کد پترن را وارد کنید.');
        }
        if (($draft['visit_calculation'] ?? 'individual') === 'aggregate' && strpos($template, '{{target_url}}') !== false && trim((string)($draft['sms_target_url'] ?? '')) === '') {
            return $this->error('لینک مقصد پیامک را وارد کنید.');
        }
        $strategy = sanitize_key((string)($draft['coupon_strategy'] ?? 'individual'));
        if (!in_array($strategy, ['individual', 'fixed', 'virtual'], true)) return $this->error('کد تخفیف را تنظیم کنید.');
        $meta = $this->couponMeta($draft, $strategy);
        if ($strategy === 'fixed' && $meta['fixed_code'] === '') return $this->error('کد تخفیف ثابت را وارد کنید.');
        if ($strategy === 'fixed') {
            $coupon = new \WC_Coupon($meta['fixed_code']);
            $meta['coupon_amount'] = (float)$coupon->get_amount();
            $meta['coupon_mode'] = $coupon->get_discount_type() === 'percent' ? 'percent' : 'fixed';
            $expiry = $coupon->get_date_expires();
            $meta['coupon_valid_hours'] = $expiry ? max(0, (int)ceil(($expiry->getTimestamp() - time()) / HOUR_IN_SECONDS)) : 0;
        }
        if ($strategy !== 'fixed' && ($meta['coupon_amount'] <= 0 || !in_array($meta['coupon_mode'], ['fixed', 'percent'], true))) {
            return $this->error('مبلغ و نوع تخفیف را تنظیم کنید.');
        }
        $settings = \SeKianAfraz\VisitDiscount\SMS\CredentialsVault::load();
        $provider = sanitize_key((string)($settings['provider'] ?? ''));
        if (!SmsService::gateway($provider)) return $this->error('درگاه پیامک در تنظیمات فعال نیست.');
        if (!\SeKianAfraz\VisitDiscount\Helpers\RateLimiter::consume('preview:user:' . get_current_user_id(), 8, 10 * MINUTE_IN_SECONDS)) {
            return $this->error('تعداد ارسال‌های آزمایشی زیاد است. کمی بعد تلاش کنید.');
        }
        try {
            $newToken = $reuseToken === '' ? bin2hex(random_bytes(16)) : '';
            $code = '';
            $expiry = '';
            if ($reuseToken !== '') {
                if (!preg_match('/^[a-f0-9]{32}$/', $reuseToken)) return $this->error('نشست آزمایش معتبر نیست.');
                $saved = get_transient($this->tokenKey($reuseToken));
                if (!is_array($saved) || (int)($saved['sensor_id'] ?? -1) !== $sensorId) {
                    return $this->error('نشست آزمایش منقضی شده است.');
                }
                $code = (string)($saved['code'] ?? '');
                $expiry = (string)($saved['expiry'] ?? '');
                if ($code === '') return $this->error('کد تخفیف آزمایشی معتبر نیست.');
                if (hash_equals((string)($saved['phone'] ?? ''), $phone)) {
                    return $this->error('برای اصلاح، شمارهٔ دیگری وارد کنید.');
                }
            } else {
                $issued = (new CouponIssuer())->issueForSensor($sensorId, get_current_user_id(), '', $meta);
                if (empty($issued['success']) || empty($issued['coupon_code'])) {
                    return $this->error('ساخت کد تخفیف آزمایشی انجام نشد.');
                }
                $code = (string)$issued['coupon_code'];
                $expiry = (string)($issued['coupon_expiry'] ?? '');
            }
            $vars = ['display_name' => wp_get_current_user()->display_name,
                'coupon_code' => $code, 'coupon_expiry_time' => $expiry,
                'coupon_value' => $meta['coupon_amount'], 'coupon_valid_hours' => $meta['coupon_valid_hours'],
                'target_url' => $this->previewTarget($draft, $mode)];
            $locations = ['product_name', 'category_name', 'product_tag_name', 'post_name',
                'post_category_name', 'post_tag_name', 'page_name', 'search_term'];
            foreach ($locations as $key) {
                $vars[$key] = sanitize_text_field((string)($draft['preview_vars'][$key] ?? ''));
            }
            $message = (new TemplateEngine())->render($template, $vars, false);
            $result = (new SmsDispatcher())->dispatch($sensorId, get_current_user_id(), '', $phone,
                $provider, (array)($settings['config'] ?? []), $mode, $message, $vars,
                'immediate', 0, $code, $mode === 'pattern' ? $template : null);
            if (empty($result['status']['success'])) return $this->error('ارسال آزمایشی انجام نشد. تنظیمات درگاه را بررسی کنید.');
            if ($reuseToken !== '') {
                delete_transient($this->tokenKey($reuseToken));
                $token = '';
            } else {
                $token = $newToken;
                set_transient($this->tokenKey($token), [
                    'code' => $code, 'expiry' => $expiry, 'sensor_id' => $sensorId, 'phone' => $phone,
                ], 10 * MINUTE_IN_SECONDS);
            }
            return ['success' => true, 'message' => 'پیامک آزمایشی ارسال شد.', 'preview_token' => $token];
        } catch (\Throwable $error) {
            return $this->error('ارسال آزمایشی انجام نشد. تنظیمات درگاه را بررسی کنید.');
        }
    }
    private function tokenKey(string $token): string
    {
        return 'sekianafraz_preview_coupon_' . get_current_user_id() . '_' . $token;
    }
    private function previewTarget(array $draft, string $mode): string
    {
        $target = trim((string)($draft['sms_target_url'] ?? ''));
        if ($target !== '') return $target;
        $placement = (string)($draft['placement'] ?? '');
        $items = (array)($draft['items'] ?? []);
        $item = (string)($items[0] ?? '');
        $url = home_url('/');
        if ($item !== '' && $item !== '*') {
            if (in_array($placement, ['product_single', 'post_single', 'page'], true) && ctype_digit($item)) {
                $url = (string)get_permalink((int)$item) ?: $url;
            } elseif (in_array($placement, ['product_cat', 'product_tag', 'post_cat', 'post_tag'], true) && ctype_digit($item)) {
                $taxonomy = ['product_cat' => 'product_cat', 'product_tag' => 'product_tag', 'post_cat' => 'category', 'post_tag' => 'post_tag'][$placement];
                $termUrl = get_term_link((int)$item, $taxonomy);
                if (!is_wp_error($termUrl)) $url = (string)$termUrl;
            } elseif ($placement === 'search_terms') {
                $url = (string)get_search_link($item);
            } elseif ($placement === 'custom_url') {
                $url = home_url('/' . ltrim($item, '/'));
            }
        }
        if ($mode === 'promo') return preg_replace('~^www\\.~i', '', preg_replace('~^https?://~i', '', $url));
        $home = rtrim(home_url('/'), '/');
        return stripos($url, $home . '/') === 0 ? substr($url, strlen($home) + 1) : ltrim((string)parse_url($url, PHP_URL_PATH), '/');
    }
    private function couponMeta(array $draft, string $strategy): array
    {
        $type = sanitize_key((string)($draft['coupon_type'] ?? 'mixed'));
        $mode = sanitize_key((string)($draft['coupon_mode'] ?? ''));
        return ['coupon_strategy' => $strategy,
            'fixed_code' => sanitize_text_field((string)($draft['fixed_code'] ?? '')),
            'coupon_type' => in_array($type, ['numbers', 'letters', 'mixed', 'custom'], true) ? $type : 'mixed',
            'coupon_mode' => $mode,
            'coupon_amount' => $mode === 'percent' ? min(100, max(0, (float)($draft['coupon_amount'] ?? 0)))
                : min(9999999999.99, max(0, (float)($draft['coupon_amount'] ?? 0))),
            'coupon_valid_hours' => min(8760, max(1, (int)($draft['coupon_valid_hours'] ?? 72))),
            'coupon_usage_limit' => min(65535, max(0, (int)($draft['coupon_usage_limit'] ?? 3))),
            'coupon_free_shipping' => !empty($draft['coupon_free_shipping']),
            'coupon_restrict_user' => filter_var($draft['coupon_restrict_user'] ?? false, FILTER_VALIDATE_BOOLEAN),
            'coupon_restrict_guest' => filter_var($draft['coupon_restrict_guest'] ?? false, FILTER_VALIDATE_BOOLEAN),
            'coupon_custom_prefix' => sanitize_text_field((string)($draft['coupon_custom_prefix'] ?? '')),
            'coupon_custom_suffix' => sanitize_text_field((string)($draft['coupon_custom_suffix'] ?? '')),
            'coupon_custom_length' => min(64, max(3, (int)($draft['coupon_custom_length'] ?? 4))),
            'coupon_custom_mid_pattern' => sanitize_key((string)($draft['coupon_custom_mid_pattern'] ?? 'mixed')),
            'coupon_limit_enabled' => !empty($draft['coupon_limit_enabled']),
            'coupon_limit_type' => sanitize_key((string)($draft['coupon_limit_type'] ?? '')),
            'coupon_limit_ids' => array_map('intval', (array)($draft['coupon_limit_ids'] ?? [])),
        ];
    }
    private function error(string $message): array
    {
        return ['success' => false, 'message' => $message];
    }
}
