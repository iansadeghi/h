<?php
namespace SeKianAfraz\VisitDiscount\Logs;
if (!defined('ABSPATH')) { exit; }
class ActionLogger
{
    public function alreadyDone(int $sensorId, int $userId, string $guestId): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_action_log';
        if ($sensorId <= 0) return false;
        if ($userId > 0) {
            $exists = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT 1 FROM {$table} WHERE sensor_id=%d AND user_id=%d LIMIT 1",
                    $sensorId,
                    $userId
                )
            );
            if ($wpdb->last_error !== '') throw new \RuntimeException('Action log unavailable.');
            return $exists !== null;
        }
        if ($guestId !== '') {
            $exists = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT 1 FROM {$table} WHERE sensor_id=%d AND guest_id=%s LIMIT 1",
                    $sensorId,
                    $guestId
                )
            );
            if ($wpdb->last_error !== '') throw new \RuntimeException('Action log unavailable.');
            return $exists !== null;
        }
        return false;
    }
    public function log(int $sensorId, int $userId, string $guestId, string $type, string $couponCode): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_action_log';
        $inserted = $wpdb->insert(
            $table,
            [
                'user_id' => $userId ?: 0,
                'guest_id' => $guestId ?: null,
                'sensor_id' => $sensorId,
                'action_type' => $type,
                'coupon_code' => $couponCode,
                'timestamp' => current_time('mysql', true),
            ],
            ['%d','%s','%d','%s','%s','%s']
        );
        if ($inserted === false) throw new \RuntimeException('Action log write failed.');
    }
    public function acquireClaim(int $sensorId, int $userId, string $guestId, int $ttlSeconds = 120): bool
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_dedup_claims';
        if ($sensorId <= 0) return false;
        if ($userId <= 0 && $guestId === '') return false;
        $now = current_time('mysql', true);
        $cutoff = gmdate('Y-m-d H:i:s', time() - max(1, (int)$ttlSeconds));
        if ($userId > 0) {
            $sql = $wpdb->prepare(
                "INSERT INTO {$table} (sensor_id, user_id, guest_id, claimed_at)
                 VALUES (%d, %d, NULL, %s)
                 ON DUPLICATE KEY UPDATE
                   claimed_at = IF(claimed_at < %s, VALUES(claimed_at), claimed_at)",
                $sensorId,
                $userId,
                $now,
                $cutoff
            );
        } else {
            $sql = $wpdb->prepare(
                "INSERT INTO {$table} (sensor_id, user_id, guest_id, claimed_at)
                 VALUES (%d, NULL, %s, %s)
                 ON DUPLICATE KEY UPDATE
                   claimed_at = IF(claimed_at < %s, VALUES(claimed_at), claimed_at)",
                $sensorId,
                $guestId,
                $now,
                $cutoff
            );
        }
        $affected = $wpdb->query($sql);
        if ($affected === false) {
            return false;
        }
        return ((int)$affected > 0);
    }
    public function releaseClaim(int $sensorId, int $userId, string $guestId): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_dedup_claims';
        if ($sensorId <= 0) return;
        if ($userId > 0) {
            $wpdb->delete($table, ['sensor_id' => (int)$sensorId, 'user_id' => (int)$userId], ['%d','%d']);
            return;
        }
        if ($guestId !== '') {
            $wpdb->delete($table, ['sensor_id' => (int)$sensorId, 'guest_id' => (string)$guestId], ['%d','%s']);
            return;
        }
    }
public function deleteBySensorId(int $sensorId): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_action_log';
        $wpdb->delete($table, ['sensor_id' => (int)$sensorId], ['%d']);
    }
}
