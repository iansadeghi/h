<?php
namespace SeKianAfraz\VisitDiscount\Orders;
if (!defined('ABSPATH')) { exit; }
class OrderReferral
{
    private const META_KEY = '_sekianafraz_attributed';
    private const SENSOR_IDS_META_KEY = '_sekianafraz_sensor_ids';
    private const COUPON_CODES_META_KEY = '_sekianafraz_coupon_codes';
    private const COLUMN_KEY = 'sekianafraz_referral';
    private array $attribution_cache = [];
    public function register(): void
    {
        add_action('woocommerce_checkout_create_order', [$this, 'storeOrderAttribution'], 10, 2);
        add_action('woocommerce_checkout_order_created', [$this, 'storeOrderAttribution'], 10, 1);
        add_action('woocommerce_store_api_checkout_order_created', [$this, 'storeOrderAttribution'], 10, 1);
        add_action('woocommerce_store_api_checkout_order_processed', [$this, 'storeOrderAttribution'], 10, 1);
        add_filter('manage_edit-shop_order_columns', [$this, 'addOrderColumn'], 20);
        add_action('manage_shop_order_posts_custom_column', [$this, 'renderOrderColumn'], 20, 2);
        add_filter('manage_woocommerce_page_wc-orders_columns', [$this, 'addOrderColumn'], 20);
        add_action('manage_woocommerce_page_wc-orders_custom_column', [$this, 'renderHposOrderColumn'], 20, 2);
        add_action('admin_enqueue_scripts', [$this, 'enqueueStyles']);
    }
    public function storeOrderAttribution($order, $data = null): void
    {
        if (!$order instanceof \WC_Order) {
            return;
        }
        if ($order->get_meta(self::META_KEY) === 'yes') {
            return;
        }
        $attribution = $this->resolveAttribution($order);
        if (empty($attribution['coupon_codes'])) {
            return;
        }
        $order->update_meta_data(self::META_KEY, 'yes');
        $order->update_meta_data(self::COUPON_CODES_META_KEY, $attribution['coupon_codes']);
        $order->update_meta_data(self::SENSOR_IDS_META_KEY, $attribution['sensor_ids']);
        if ($order->get_id() > 0) {
            $order->save_meta_data();
        }
    }
    public function addOrderColumn(array $columns): array
    {
        $new_columns = [];
        foreach ($columns as $key => $label) {
            $new_columns[$key] = $label;
            if ($key === 'order_total') {
                $new_columns[self::COLUMN_KEY] = esc_html__('ارجاع‌دهنده سفارش', 'sekianafraz-visit-discount');
            }
        }
        if (!isset($new_columns[self::COLUMN_KEY])) {
            $new_columns[self::COLUMN_KEY] = esc_html__('ارجاع‌دهنده سفارش', 'sekianafraz-visit-discount');
        }
        return $new_columns;
    }
    public function renderOrderColumn(string $column, int $post_id): void
    {
        if ($column !== self::COLUMN_KEY) {
            return;
        }
        $order = wc_get_order($post_id);
        if (!$order instanceof \WC_Order || !$this->isAttributed($order)) {
            echo '<span aria-hidden="true">—</span>';
            return;
        }
        echo $this->labelMarkup();
    }
    public function renderHposOrderColumn(string $column, $order): void
    {
        if ($column !== self::COLUMN_KEY) {
            return;
        }
        if (!$order instanceof \WC_Order) {
            $order = wc_get_order($order);
        }
        if (!$order instanceof \WC_Order || !$this->isAttributed($order)) {
            echo '<span aria-hidden="true">—</span>';
            return;
        }
        echo $this->labelMarkup();
    }
    public function enqueueStyles(): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || !in_array($screen->id, ['edit-shop_order', 'woocommerce_page_wc-orders'], true)) {
            return;
        }
        wp_register_style('sekianafraz-orders-admin', false);
        wp_enqueue_style('sekianafraz-orders-admin');
        $css = 'td.column-sekianafraz_referral{position:relative;padding:5px!important;box-sizing:border-box;vertical-align:middle}'
            .'.sekianafraz-order-referral{position:absolute;inset:15px;display:flex;align-items:center;justify-content:center;color:#111;pointer-events:none}'
            .'.sekianafraz-order-referral svg{display:block;width:100%;height:100%;max-width:100%;max-height:100%}';
        wp_add_inline_style('sekianafraz-orders-admin', $css);
    }
    private function resolveAttribution(\WC_Order $order): array
    {
        $codes = $order->get_coupon_codes();
        if (empty($codes)) {
            return ['coupon_codes' => [], 'sensor_ids' => []];
        }
        $matchedCodes = [];
        $sensorIds = [];
        $registry = class_exists('SeKianAfraz\VisitDiscount\\Coupons\\CouponRegistryRepository')
            ? new \SeKianAfraz\VisitDiscount\Coupons\CouponRegistryRepository()
            : null;
        foreach ($codes as $code) {
            $code = wc_format_coupon_code($code);
            if ($code === '') continue;
            $coupon_id = wc_get_coupon_id_by_code($code);
            if ($coupon_id) {
                $coupon = new \WC_Coupon($coupon_id);
                if ($coupon->get_id() > 0 && $coupon->get_meta('_generated_by', true) === 'sekianafraz') {
                    $matchedCodes[$code] = $code;
                    $sensorId = (int)$coupon->get_meta('_sekianafraz_sensor_id', true);
                    if ($sensorId > 0) $sensorIds[$sensorId] = $sensorId;
                }
            }
            if ($registry) {
                $row = $registry->findByCode($code);
                if (is_array($row) && in_array(($row['status'] ?? ''), ['active','redeemed','expired'], true)) {
                    $matchedCodes[$code] = $code;
                    $sensorId = (int)($row['sensor_id'] ?? 0);
                    if ($sensorId > 0) $sensorIds[$sensorId] = $sensorId;
                }
            }
            foreach ($this->sensorIdsForFixedCode($code) as $sensorId) {
                $matchedCodes[$code] = $code;
                $sensorIds[$sensorId] = $sensorId;
            }
        }
        return [
            'coupon_codes' => array_values($matchedCodes),
            'sensor_ids' => array_values($sensorIds),
        ];
    }
    private function sensorIdsForFixedCode(string $code): array
    {
        $ids = get_posts([
            'post_type' => 'sekianafraz_sensor',
            'post_status' => 'publish',
            'fields' => 'ids',
            'posts_per_page' => -1,
            'no_found_rows' => true,
            'meta_query' => [
                'relation' => 'AND',
                ['key' => 'coupon_strategy', 'value' => 'fixed'],
                ['key' => 'fixed_code', 'value' => $code],
            ],
        ]);
        return array_values(array_filter(array_map('intval', $ids)));
    }
    private function isAttributed(\WC_Order $order): bool
    {
        $order_id = $order->get_id();
        if ($order_id <= 0) {
            return false;
        }
        if (array_key_exists($order_id, $this->attribution_cache)) {
            return $this->attribution_cache[$order_id];
        }
        if ($order->get_meta(self::META_KEY, true) === 'yes') {
            $this->attribution_cache[$order_id] = true;
            return true;
        }
        $attribution = $this->resolveAttribution($order);
        if (empty($attribution['coupon_codes'])) {
            $this->attribution_cache[$order_id] = false;
            return false;
        }
        $order->update_meta_data(self::META_KEY, 'yes');
        $order->update_meta_data(self::COUPON_CODES_META_KEY, $attribution['coupon_codes']);
        $order->update_meta_data(self::SENSOR_IDS_META_KEY, $attribution['sensor_ids']);
        $order->save_meta_data();
        $this->attribution_cache[$order_id] = true;
        return true;
    }
    private function labelMarkup(): string
    {
        return '<span class="sekianafraz-order-referral">'
            . '<svg xmlns="http://www.w3.org/2000/svg" viewBox="536.16 86.89 1422.83 280.7" role="img" aria-label="Sensor" preserveAspectRatio="xMidYMid meet" fill="currentColor"><path d="M740.52,351.96h-0.02c-0.04,0.02-0.06,0.04-0.1,0.06l-0.12,0.08c-18.94,10.92-42.48,15.48-64.49,15.48c-15.57,0-30.37-2.28-42.22-6.23c-52.15-17.4-77.26-55.95-89.14-85.24l-0.84-2.1l48.9-14.87l0.72,1.69c0.12,0.29,12.5,28.32,36.64,52.95c21.89,22.32,45.85,34.82,71.6,37.38c37.57,3.74,72.49-21.79,77.64-59.19c0.15-1.07,0.27-2.16,0.38-3.25h-0.02c-0.49-14.64-4.28-34.79-19.49-47.54c-18.08-15.2-41.72-9.52-71.66-2.34c-20.95,5.02-44.68,10.69-72.03,10.82h-0.62c-33.7,0-52.99-12.52-63.85-25.09c-10.88-12.56-13.33-25.21-13.37-25.46c-5.37-17.87-1.28-41.35,13.49-59.33c22.7-30.74,50.52-48.26,82.75-52.09c65.68-7.83,127.93,44.79,128.54,45.32l1.62,1.38l-35.84,39.15l-1.52-1.65c-0.78-0.84-79.05-84.27-153.53-45.24c-7.44,4.15-13.59,9.4-18.53,15.3c-0.45,0.62-0.9,1.21-1.34,1.83l-0.1-0.06c-13.9,17.87-16.99,40.98-10.45,57.56c8.76,22.29,31.98,30.62,63.71,22.85c55.13-13.51,117.62-28.81,151.39-4.11c15.18,11.13,23.38,29.02,25.11,54.7C786.52,316.24,761.76,339.62,740.52,351.96z"/><path d="M1006.22,262.66l39.46,21.49l-0.58,1.64c-16.45,47.61-63.97,79.6-118.2,79.6c-68.42,0-124.08-51.31-124.08-114.4c0-63.09,55.67-114.4,124.08-114.4c31.09,0,60.85,10.65,83.76,30c22.83,19.27,36.93,45.47,39.75,73.76l0.23,2.26H867.49v-4.11h138.6c-4.48-55.03-38.95-97.8-79.19-97.8c-43.97,0-79.75,49.48-79.75,110.28c0,60.81,35.78,110.28,79.75,110.28c39.77,0,73.74-41.07,79-95.54L1006.22,262.66z"/><path d="M1266.73,216.33v149.07h-42.5V201.83c0-15.55-6.17-30.19-16.94-40.16c-13.26-12.28-29.22-14.65-47.62-7.12c-13.02,5.33-23.99,14.75-31.87,26.41c-4.17,6.16-7.38,12.13-9.74,17.1v167.33h-38.23V137.67h38.23v51.41c4.52-8.25,10.88-17.79,19.35-26.42l-0.06-0.08c0.17-0.12,0.33-0.25,0.51-0.37c13.39-13.47,32.02-24.53,57.04-24.53C1265.91,137.67,1266.73,215.55,1266.73,216.33z"/><path d="M1508.93,287.97c2.42,32.77-19.04,51.23-37.45,60.97h-0.02c-0.04,0.02-0.05,0.03-0.09,0.05l-0.11,0.07c-16.42,8.62-36.83,12.22-55.9,12.22c-13.49,0-26.33-1.8-36.59-4.92c-45.2-13.73-66.97-44.17-77.27-67.28l-0.73-1.66l42.39-11.74l0.62,1.33c0.11,0.23,10.84,22.35,31.76,41.8c21.62,20.08,45.59,30.09,71.52,29.89c17.27-0.13,34.06-7.02,45.31-20.12c6.6-7.68,11.59-17.39,12.86-29.56h-0.02c-0.43-11.56-3.71-27.46-16.9-37.53c-15.67-12-36.17-7.52-62.12-1.85c-18.16,3.96-38.73,8.44-62.44,8.54h-0.53c-29.21,0-45.93-9.88-55.34-19.8c-9.43-9.92-11.55-19.9-11.59-20.09c-4.65-14.11-1.1-32.64,11.69-46.83c19.68-24.27,43.79-38.1,71.72-41.12c56.93-6.19,110.89,35.35,111.42,35.77l1.41,1.09l-31.07,30.91l-1.32-1.3c-0.68-0.67-68.52-66.52-133.08-35.71c-6.45,3.28-11.78,7.42-16.06,12.08c-0.39,0.49-0.78,0.96-1.16,1.45l-0.09-0.05c-12.05,14.1-14.72,32.35-9.05,45.43c7.59,17.6,25.45,19.01,52.95,12.88c47.79-10.66,101.96-22.74,131.22-3.25C1498.06,248.42,1507.44,267.7,1508.93,287.97L1508.93,287.97z"/><path d="M1772.54,251.53c0,62.16-53.69,112.85-120.09,113.84c-0.66,0-1.32,0.02-1.99,0.02s-1.34-0.02-2-0.02c-66.4-0.99-120.09-51.66-120.09-113.84s53.69-112.85,120.09-113.84c0.66,0,1.32-0.02,2-0.02s1.34,0.02,1.99,0.02C1718.85,138.68,1772.54,189.37,1772.54,251.53z M1727.61,251.53c0-59.57-33.54-108.21-75.16-109.71c-0.66-0.02-1.34-0.04-1.99-0.04c-0.66,0-1.34,0.02-2,0.04c-41.6,1.5-75.16,50.15-75.16,109.71c0,59.55,33.56,108.21,75.16,109.71c0.66,0.02,1.34,0.04,2,0.04c0.66,0,1.34,0,1.99-0.04C1694.07,359.74,1727.61,311.11,1727.61,251.53z"/><path d="M1958.98,152.54l-14.54,38.78l-2.26-2.34c-1.15-1.19-18.53-18.88-42.33-23.79c-23.71-4.89-47.75,7.23-58.61,28.87l-0.03,0.06v171.28h-38.23V137.67h38.23v47.87c7.3-12.28,24.78-36.58,52.31-44.95c20.13-6.13,41.66-2.39,63.97,11.08L1958.98,152.54z"/></svg>'
            . '</span>';
    }
}
