<?php
namespace SeKianAfraz\VisitDiscount\Modules;
if (!defined('ABSPATH')) { exit; }
class ModuleLoader
{
    public static function boot(): void
    {
        $modules = self::defaultModules();
        $modules = apply_filters('sekianafraz_builtin_modules', $modules);
        if (!is_array($modules)) {
            $modules = self::defaultModules();
        }
        foreach ($modules as $m) {
            if (!is_array($m)) continue;
            $file = isset($m['file']) ? (string)$m['file'] : '';
            $abs = '';
            if ($file !== '') {
                if (strpos($file, '/') === 0 || preg_match('#^[A-Za-z]:[\\/]#', $file)) {
                    $abs = $file;
                } else {
                    $abs = SEKIANAFRAZ_PATH . ltrim($file, '/');
                }
            }
            if ($abs === '' || !is_readable($abs)) {
                continue;
            }
            require_once $abs;
            $bootstrap = isset($m['bootstrap']) ? $m['bootstrap'] : null;
            if (is_string($bootstrap) && function_exists($bootstrap)) {
                call_user_func($bootstrap);
            }
        }
    }
    private static function defaultModules(): array
    {
        return
        [
            [
                'id' => 'reminder_bar',
                'file' => 'includes/Modules/Builtin/reminder_bar.php',
                'bootstrap' => 'sekianafraz_boot_reminder_bar_module',
            ],
            [
                'id' => 'sms_core',
                'file' => 'includes/Modules/Builtin/sms_core.php',
                'bootstrap' => 'sekianafraz_boot_sms_core_module',
            ],
            [
                'id' => 'sms_queue',
                'file' => 'includes/Modules/Builtin/sms_queue.php',
                'bootstrap' => 'sekianafraz_boot_sms_queue_module',
            ],
            [
                'id' => 'coupon_virtual',
                'file' => 'includes/Modules/Builtin/coupon_virtual.php',
                'bootstrap' => 'sekianafraz_boot_coupon_virtual_module',
            ],
        ];
    }
}
