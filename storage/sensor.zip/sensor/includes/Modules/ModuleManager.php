<?php
namespace SeKianAfraz\VisitDiscount\Modules;
use SeKianAfraz\VisitDiscount\Modules\Actions\BannerAction;
if (!defined('ABSPATH')) { exit; }
class ModuleManager
{
    private array $executors = [];
    public function __construct()
    {
        $this->register(new BannerAction());
        if (function_exists('do_action')) {
            do_action('sekianafraz_modules_register_executors', $this);
        }
    }
    public function register(ActionExecutorInterface $executor): void
    {
        $this->executors[$executor->key()] = $executor;
    }
    public function execute(string $actionKey, ActionContext $ctx): array
    {
        $actionKey = (string)$actionKey;
        if ($actionKey === '') {
            return ['success' => false, 'code' => 'NO_ACTION', 'message' => ''];
        }
        $executor = $this->executors[$actionKey] ?? null;
        if (!$executor) {
            return ['success' => false, 'code' => 'NO_ACTION', 'message' => ''];
        }
        return $executor->execute($ctx);
    }
}
