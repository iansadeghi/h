<?php
namespace SeKianAfraz\VisitDiscount\Modules\Actions;
use SeKianAfraz\VisitDiscount\Modules\ActionContext;
use SeKianAfraz\VisitDiscount\Modules\ActionExecutorInterface;
use SeKianAfraz\VisitDiscount\Helpers\PhoneResolver;
use SeKianAfraz\VisitDiscount\SMS\SmsDispatcher;
use SeKianAfraz\VisitDiscount\Banners\BannerSessions;
if (!defined('ABSPATH')) { exit; }
class BothAction implements ActionExecutorInterface
{
    public function key(): string
    {
        return 'both';
    }
    public function requiredFeatures(): array
    {
        return [];
    }
    public function execute(ActionContext $ctx): array
    {
        $loggedIn = is_user_logged_in();
        if (!$loggedIn) {
            return $this->bannerResponse($ctx, null);
        }
        try {
            $smsStatus = $this->attemptSms($ctx);
        } catch (\Throwable $error) {
            $smsStatus = null;
        }
        $hideBanner = !empty($ctx->meta['hide_banner_for_logged_in']) && ($ctx->meta['audience'] ?? '') !== 'logged';
        if ($hideBanner) {
            if (!is_array($smsStatus) || empty($smsStatus['success'])) {
                return ['success' => false, 'code' => 'SMS_FAILED', 'message' => 'ارسال پیامک انجام نشد.'];
            }
            return [
                'success' => true,
                'code' => 'SMS',
                'message' => '',
                'data' => [
                    'sms' => $smsStatus,
                    'reminder' => $ctx->reminderData,
                ],
            ];
        }
        return $this->bannerResponse($ctx, $smsStatus);
    }
    private function bannerResponse(ActionContext $ctx, $smsStatus): array
    {
        $bannerData = $ctx->bannerBuilder->build($ctx->sensorId, $ctx->payload, $ctx->meta, $ctx->reminderData);
        if (($ctx->meta['banner_type'] ?? '') === 'multi' && ($ctx->meta['audience'] ?? '') !== 'logged') {
            $token = (new BannerSessions())->create($ctx);
            if ($token === '') return ['success' => false, 'code' => 'SESSION_UNAVAILABLE', 'message' => 'بنر موقتاً آماده نیست.'];
            $bannerData['send_token'] = $token;
        }
        $ctx->actionLogger->log($ctx->sensorId, $ctx->userId, $ctx->guestId, 'modal_shown', $ctx->couponCode);
        return [
            'success' => true,
            'code' => 'BOTH',
            'message' => '',
            'data' => array_merge($bannerData, ['sms' => $smsStatus]),
        ];
    }
    private function attemptSms(ActionContext $ctx)
    {
        $phoneRaw = (new PhoneResolver())->resolve($ctx->userId);
        $phone = $this->normalizeIranPhone($phoneRaw);
        if ($phone === '') {
            return null;
        }
        $logged = ($ctx->meta['audience'] ?? '') === 'logged';
        $smsPrepared = $ctx->smsMessageBuilder->build($ctx->sensorId, $ctx->payload, $ctx->fallbackUrl, $logged ? 'logged' : '');
        if (!($smsPrepared['success'] ?? false)) {
            return null;
        }
        $logger = function(int $sensorId, int $userId, string $guestId, string $type, string $couponCode) use ($ctx): void {
            $ctx->actionLogger->log($sensorId, $userId, $guestId, $type, $couponCode);
        };
        $dispatcher = new SmsDispatcher($logger);
        $dispatch = $dispatcher->dispatch(
            $ctx->sensorId,
            $ctx->userId,
            $ctx->guestId,
            $phone,
            (string)($smsPrepared['provider'] ?? ''),
            (array)($smsPrepared['config'] ?? []),
            (string)($smsPrepared['mode'] ?? ''),
            (string)($smsPrepared['message'] ?? ''),
            (array)($smsPrepared['vars'] ?? []),
            (string)($smsPrepared['delay_type'] ?? ''),
            (int)($smsPrepared['delay_minutes'] ?? 0),
            $ctx->couponCode,
            $logged ? (string)$smsPrepared['pattern'] : null
        );
        $response = $dispatch['response'] ?? [];
        $code = (string)($response['code'] ?? '');
        if ($code === 'NO_GATEWAY') {
            return null;
        }
        return $dispatch['status'] ?? null;
    }
    private function normalizeIranPhone(string $raw): string
    {
        return \SeKianAfraz\VisitDiscount\Helpers\PhoneNormalizer::mobile($raw);
    }
}
