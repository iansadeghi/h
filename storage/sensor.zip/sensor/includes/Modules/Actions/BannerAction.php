<?php
namespace SeKianAfraz\VisitDiscount\Modules\Actions;
use SeKianAfraz\VisitDiscount\Modules\ActionContext;
use SeKianAfraz\VisitDiscount\Modules\ActionExecutorInterface;
use SeKianAfraz\VisitDiscount\Banners\BannerSessions;
if (!defined('ABSPATH')) { exit; }
class BannerAction implements ActionExecutorInterface
{
    public function key(): string
    {
        return 'banner';
    }
    public function requiredFeatures(): array
    {
        return ['banner'];
    }
    public function execute(ActionContext $ctx): array
    {
        $bannerData = $ctx->bannerBuilder->build($ctx->sensorId, $ctx->payload, $ctx->meta, $ctx->reminderData);
        if (($ctx->meta['banner_type'] ?? '') === 'multi' && ($ctx->meta['audience'] ?? '') !== 'logged') {
            $token = (new BannerSessions())->create($ctx);
            if ($token === '') return ['success' => false, 'code' => 'SESSION_UNAVAILABLE', 'message' => 'بنر موقتاً آماده نیست.'];
            $bannerData['send_token'] = $token;
        }
        $ctx->actionLogger->log($ctx->sensorId, $ctx->userId, $ctx->guestId, 'modal_shown', $ctx->couponCode);
        return ['success' => true, 'code' => 'BANNER', 'message' => '', 'data' => $bannerData];
    }
}
