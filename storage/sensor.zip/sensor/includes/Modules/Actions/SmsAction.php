<?php
namespace SeKianAfraz\VisitDiscount\Modules\Actions;
use SeKianAfraz\VisitDiscount\Modules\ActionContext;
use SeKianAfraz\VisitDiscount\Modules\ActionExecutorInterface;
use SeKianAfraz\VisitDiscount\Helpers\PhoneResolver;
use SeKianAfraz\VisitDiscount\SMS\SmsDispatcher;
if (!defined('ABSPATH')) { exit; }
class SmsAction implements ActionExecutorInterface
{
    public function key(): string
    {
        return 'sms';
    }
    public function requiredFeatures(): array
    {
        return [];
    }
    public function execute(ActionContext $ctx): array
    {
        if (!is_user_logged_in()) {
            return ['success' => false, 'code' => 'LOGIN_REQUIRED', 'message' => ''];
        }
        $phoneRaw = (new PhoneResolver())->resolve($ctx->userId);
        $phone = $this->normalizeIranPhone($phoneRaw);
        if ($phone === '') {
            return ['success' => false, 'code' => 'NO_PHONE', 'message' => ''];
        }
        $logged = ($ctx->meta['audience'] ?? '') === 'logged';
        $smsPrepared = $ctx->smsMessageBuilder->build($ctx->sensorId, $ctx->payload, $ctx->fallbackUrl, $logged ? 'logged' : '');
        if (!($smsPrepared['success'] ?? false)) {
            return $smsPrepared['response'] ?? ['success' => false, 'code' => 'SMS_BUILD_FAILED', 'message' => ''];
        }
        $logger = function(int $sensorId, int $userId, string $guestId, string $type, string $couponCode) use ($ctx): void {
            $ctx->actionLogger->log($sensorId, $userId, $guestId, $type, $couponCode);
        };
        $dispatcher = new SmsDispatcher($logger);
        $dispatch = $dispatcher->dispatch(
            $ctx->sensorId,
            $ctx->userId,
            $ctx->guestId,
            $phone,
            (string)($smsPrepared['provider'] ?? ''),
            (array)($smsPrepared['config'] ?? []),
            (string)($smsPrepared['mode'] ?? ''),
            (string)($smsPrepared['message'] ?? ''),
            (array)($smsPrepared['vars'] ?? []),
            (string)($smsPrepared['delay_type'] ?? ''),
            (int)($smsPrepared['delay_minutes'] ?? 0),
            $ctx->couponCode,
            $logged ? (string)$smsPrepared['pattern'] : null
        );
        return $dispatch['response'] ?? ['success' => false, 'code' => 'SMS', 'message' => ''];
    }
    private function normalizeIranPhone(string $raw): string
    {
        return \SeKianAfraz\VisitDiscount\Helpers\PhoneNormalizer::mobile($raw);
    }
}
