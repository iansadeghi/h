<?php
namespace SeKianAfraz\VisitDiscount\Modules;
use SeKianAfraz\VisitDiscount\SMS\SmsMessageBuilder;
use SeKianAfraz\VisitDiscount\Banners\BannerBuilder;
use SeKianAfraz\VisitDiscount\Logs\ActionLogger;
if (!defined('ABSPATH')) { exit; }
class ActionContext
{
    public int $sensorId;
    public int $userId;
    public string $guestId;
    public string $couponCode;
    public array $payload;
    public array $meta;
    public ?array $reminderData;
    public string $fallbackUrl;
    public SmsMessageBuilder $smsMessageBuilder;
    public BannerBuilder $bannerBuilder;
    public ActionLogger $actionLogger;
    public function __construct(
        int $sensorId,
        int $userId,
        string $guestId,
        string $couponCode,
        array $payload,
        array $meta,
        ?array $reminderData,
        string $fallbackUrl,
        SmsMessageBuilder $smsMessageBuilder,
        BannerBuilder $bannerBuilder,
        ActionLogger $actionLogger
    )
    {
        $this->sensorId = $sensorId;
        $this->userId = $userId;
        $this->guestId = $guestId;
        $this->couponCode = $couponCode;
        $this->payload = $payload;
        $this->meta = $meta;
        $this->reminderData = $reminderData;
        $this->fallbackUrl = $fallbackUrl;
        $this->smsMessageBuilder = $smsMessageBuilder;
        $this->bannerBuilder = $bannerBuilder;
        $this->actionLogger = $actionLogger;
    }
}
