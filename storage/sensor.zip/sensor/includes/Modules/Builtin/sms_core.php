<?php
use SeKianAfraz\VisitDiscount\Modules\ModuleManager;
use SeKianAfraz\VisitDiscount\Modules\Actions\SmsAction;
use SeKianAfraz\VisitDiscount\Modules\Actions\BothAction;
if (!defined('ABSPATH')) { exit; }
function sekianafraz_boot_sms_core_module(): void
{
    add_action('sekianafraz_modules_register_executors', function($manager) {
        if ($manager instanceof ModuleManager) {
            $manager->register(new SmsAction());
            $manager->register(new BothAction());
            return;
        }
        if (is_object($manager) && method_exists($manager, 'register')) {
            $manager->register(new SmsAction());
            $manager->register(new BothAction());
        }
    });
    add_filter('sekianafraz_sensor_action_options', function($actions) {
        $actions[] = ['key' => 'sms', 'label' => __('ارسال پیامک', 'sekianafraz-visit-discount')];
        $actions[] = ['key' => 'both', 'label' => __('نمایش بنر + ارسال پیامک', 'sekianafraz-visit-discount')];
        return $actions;
    });
}
