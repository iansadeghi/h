<?php
use SeKianAfraz\VisitDiscount\SMS\SMSCronService;
if (!defined('ABSPATH')) { exit; }
function sekianafraz_boot_sms_queue_module(): void
{
    add_filter('cron_schedules', [SMSCronService::class, 'registerSchedules']);
    add_action(SMSCronService::HOOK_PROCESS_QUEUE, [SMSCronService::class, 'processQueue']);
    add_action(SMSCronService::HOOK_CONTINUE_QUEUE, [SMSCronService::class, 'processQueue']);
    add_action(SMSCronService::HOOK_CLEANUP_QUEUE, [SMSCronService::class, 'cleanupQueue']);
    SMSCronService::scheduleEvents();
}
