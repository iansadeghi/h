<?php
use SeKianAfraz\VisitDiscount\Frontend\ReminderBar;
if (!defined('ABSPATH')) { exit; }
function sekianafraz_boot_reminder_bar_module(): void
{
    add_action('init', function() {
        (new ReminderBar())->register();
    });
}
