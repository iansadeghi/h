<?php
use SeKianAfraz\VisitDiscount\Coupons\VirtualCouponProvider;
if (!defined('ABSPATH')) { exit; }
function sekianafraz_boot_coupon_virtual_module(): void
{
    add_action('init', function() {
        (new VirtualCouponProvider())->register();
    });
}
