<?php
namespace SeKianAfraz\VisitDiscount\Modules;
if (!defined('ABSPATH')) { exit; }
interface ActionExecutorInterface
{
    public function key(): string;
    public function requiredFeatures(): array;
    public function execute(ActionContext $ctx): array;
}
