<?php
namespace SeKianAfraz\VisitDiscount\Database;
if (!defined('ABSPATH')) { exit; }
class Schema {
    public static function createPhoneIndexTable(): bool
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = $wpdb->prefix . 'sekianafraz_phone_index';
        dbDelta("CREATE TABLE {$table} (
            meta_id bigint(20) unsigned NOT NULL,
            user_id bigint(20) unsigned NOT NULL,
            phone varchar(20) NOT NULL,
            PRIMARY KEY (meta_id),
            KEY phone_user (phone,user_id),
            KEY user_id (user_id)
        ) ENGINE=InnoDB " . $wpdb->get_charset_collate() . ';');
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) !== $table) return false;
        return true;
    }
    public static function createPhoneOwnerCacheTable(): bool
    {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $table = $wpdb->prefix . 'sekianafraz_phone_owner_cache';
        dbDelta("CREATE TABLE {$table} (
            phone varchar(20) NOT NULL,
            revision bigint(20) unsigned NOT NULL DEFAULT 1,
            pending tinyint(1) unsigned NOT NULL DEFAULT 1,
            owners longtext NOT NULL,
            PRIMARY KEY (phone),
            KEY pending_phone (pending,phone)
        ) ENGINE=InnoDB " . $wpdb->get_charset_collate() . ';');
        if ($wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) !== $table) return false;
        return true;
    }
    public static function createCollectedLeadsTable(): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_collected_leads';
        $sql = "CREATE TABLE $table (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            session_hash char(64) NOT NULL,
            sensor_id bigint(20) unsigned NOT NULL,
            sensor_name varchar(191) NOT NULL,
            phone varchar(20) NOT NULL,
            sms_status varchar(16) NOT NULL DEFAULT 'pending',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY uniq_session (session_hash),
            KEY idx_sensor (sensor_id),
            KEY idx_phone (phone)
        ) ENGINE=InnoDB {$wpdb->get_charset_collate()};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table;
    }
    public static function createBannerSessionsTable(): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_banner_sessions';
        $sql = "CREATE TABLE $table (
            token_hash char(64) NOT NULL,
            sensor_id bigint(20) unsigned NOT NULL,
            guest_id varchar(64) NOT NULL,
            coupon_code varchar(191) NOT NULL,
            sms_data longtext NOT NULL,
            created_at datetime NOT NULL,
            sent_at datetime DEFAULT NULL,
            corrected_at datetime DEFAULT NULL,
            phone_hash char(64) DEFAULT NULL,
            claimed_at datetime DEFAULT NULL,
            attempts tinyint(3) unsigned NOT NULL DEFAULT 0,
            PRIMARY KEY  (token_hash),
            KEY idx_created_at (created_at),
            KEY idx_sensor_guest (sensor_id, guest_id)
        ) ENGINE=InnoDB {$wpdb->get_charset_collate()};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        return $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table))) === $table;
    }
    public static function createSMSQueueTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sekianafraz_sms_queue';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            phone varchar(20) NOT NULL,
            message text NOT NULL,
            provider varchar(32) NOT NULL DEFAULT '',
            mode varchar(16) NOT NULL DEFAULT 'promo',
            template_id varchar(191) DEFAULT NULL,
            tokens longtext DEFAULT NULL,
            coupon_code varchar(191) DEFAULT NULL,
            sensor_id bigint(20) unsigned NOT NULL,
            scheduled_time datetime NOT NULL,
            status enum('pending', 'processing', 'sent', 'failed') DEFAULT 'pending',
            attempts tinyint(3) unsigned DEFAULT 0,
            last_error text DEFAULT NULL,
            created_at datetime NOT NULL,
            sent_at datetime DEFAULT NULL,
            claimed_at datetime DEFAULT NULL,
            claimed_by varchar(36) DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY idx_status_scheduled (status, scheduled_time),
            KEY idx_status_created (status, created_at),
            KEY idx_status_claimed_scheduled (status, claimed_at, scheduled_time),
            KEY idx_sensor (sensor_id),
            KEY idx_claimed_by (claimed_by)
        
        ) ENGINE=InnoDB $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        return (
            $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name))) === $table_name
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'claimed_by'") === 'claimed_by'
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'mode'") === 'mode'
        );
        }
    public static function createSensorIndexTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sekianafraz_sensor_index';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            sensor_id bigint(20) unsigned NOT NULL,
            placement varchar(32) NOT NULL,
            item varchar(150) NOT NULL,
            min_views smallint(5) unsigned NOT NULL DEFAULT 1,
            min_duration int(10) unsigned NOT NULL DEFAULT 1,
            visit_metric varchar(16) NOT NULL DEFAULT 'views',
            visit_calculation varchar(16) NOT NULL DEFAULT 'individual',
            visit_condition varchar(3) NOT NULL DEFAULT 'or',
            time_window varchar(8) NOT NULL DEFAULT '24h',
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY uniq_sensor_placement_item (sensor_id, placement, item),
            KEY idx_placement_item (placement, item),
            KEY idx_placement_sensor (placement, sensor_id)
        ) ENGINE=InnoDB $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        return (
            $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name))) === $table_name
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'sensor_id'") === 'sensor_id'
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'min_duration'") === 'min_duration'
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'visit_metric'") === 'visit_metric'
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'visit_calculation'") === 'visit_calculation'
        );
        }
    public static function createSensorCoverageTables() {
        global $wpdb;
        $coverage = $wpdb->prefix . 'sekianafraz_sensor_coverage';
        $exclusions = $wpdb->prefix . 'sekianafraz_sensor_exclusions';
        $charset_collate = $wpdb->get_charset_collate();
        $coverageSql = "CREATE TABLE $coverage (
            context_type varchar(32) NOT NULL,
            object_id bigint(20) unsigned NOT NULL,
            sensor_id bigint(20) unsigned NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (context_type, object_id),
            KEY idx_sensor_context (sensor_id, context_type)
        ) ENGINE=InnoDB $charset_collate;";
        $exclusionsSql = "CREATE TABLE $exclusions (
            excluded_sensor_id bigint(20) unsigned NOT NULL,
            owner_sensor_id bigint(20) unsigned NOT NULL,
            context_type varchar(32) NOT NULL,
            object_id bigint(20) unsigned NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (excluded_sensor_id, context_type, object_id),
            KEY idx_context_object (context_type, object_id),
            KEY idx_owner_context (owner_sensor_id, context_type, object_id)
        ) ENGINE=InnoDB $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($coverageSql);
        dbDelta($exclusionsSql);
        return (
            $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($coverage))) === $coverage
            && $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($exclusions))) === $exclusions
        );
    }
    public static function dropSMSQueueTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sekianafraz_sms_queue';
        $result = $wpdb->query("DROP TABLE IF EXISTS $table_name");
        return ($result !== false);
    }
    public static function createActionLogTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sekianafraz_action_log';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NULL,
            guest_id VARCHAR(191) NULL,
            sensor_id BIGINT(20) UNSIGNED NOT NULL,
            action_type VARCHAR(50) NOT NULL,
            coupon_code VARCHAR(191) NULL,
            timestamp DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY guest_id (guest_id),
            KEY idx_sensor_user (sensor_id, user_id),
            KEY idx_sensor_guest (sensor_id, guest_id),
            KEY idx_action_ts (action_type, timestamp),
            KEY idx_ts_user (timestamp, user_id),
            KEY idx_ts_guest (timestamp, guest_id)
        ) ENGINE=InnoDB $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        return (
            $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name))) === $table_name
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'sensor_id'") === 'sensor_id'
        );
        }
    public static function createCouponRegistryTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sekianafraz_coupon_registry';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(191) NOT NULL,
            coupon_post_id BIGINT(20) UNSIGNED NULL,
            sensor_id BIGINT(20) UNSIGNED NOT NULL,
            user_id BIGINT(20) UNSIGNED NULL,
            guest_id VARCHAR(64) NULL,
            strategy VARCHAR(16) NOT NULL DEFAULT 'wp_post',
            restrict_owner TINYINT(1) NOT NULL DEFAULT 0,
            status VARCHAR(16) NOT NULL DEFAULT 'active',
            discount_type VARCHAR(16) NULL,
            amount DECIMAL(12,2) NULL,
            free_shipping TINYINT(1) NOT NULL DEFAULT 0,
            usage_limit SMALLINT(5) UNSIGNED NULL,
            limit_type VARCHAR(16) NULL,
            limit_ids TEXT NULL,
            created_at DATETIME NOT NULL,
            expires_at DATETIME NULL,
            redeemed_at DATETIME NULL,
            closed_at DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_code (code),
            KEY idx_coupon_post (coupon_post_id),
            KEY idx_status_expires (status, expires_at),
            KEY idx_status_created (status, created_at),
            KEY idx_strategy_status_expires (strategy, status, expires_at),
            KEY idx_status_closed (status, closed_at),
            KEY idx_sensor_created (sensor_id, created_at),
            KEY idx_user_sensor (user_id, sensor_id),
            KEY idx_guest_sensor (guest_id, sensor_id)
        ) ENGINE=InnoDB $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        return (
            $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name))) === $table_name
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'code'") === 'code'
        );
        }
    public static function createCouponRedemptionsTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sekianafraz_coupon_redemptions';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            code VARCHAR(191) NOT NULL,
            order_id BIGINT(20) UNSIGNED NOT NULL,
            user_id BIGINT(20) UNSIGNED NULL,
            guest_id VARCHAR(64) NULL,
            redeemed_at DATETIME NOT NULL,
            state VARCHAR(16) NOT NULL DEFAULT 'redeemed',
            PRIMARY KEY (id),
            UNIQUE KEY uniq_code_order (code, order_id),
            KEY idx_code (code),
            KEY idx_order (order_id),
            KEY idx_user (user_id),
            KEY idx_guest (guest_id),
            KEY idx_redeemed_at (redeemed_at)
        ) ENGINE=InnoDB $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        return (
            $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name))) === $table_name
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'code'") === 'code'
        );
    }
public static function createDedupClaimsTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'sekianafraz_dedup_claims';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            sensor_id BIGINT(20) UNSIGNED NOT NULL,
            user_id BIGINT(20) UNSIGNED NULL,
            guest_id VARCHAR(64) NULL,
            claimed_at DATETIME NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY uniq_sensor_user (sensor_id, user_id),
            UNIQUE KEY uniq_sensor_guest (sensor_id, guest_id),
            KEY idx_claimed_at (claimed_at)
        ) ENGINE=InnoDB $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        return (
            $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $wpdb->esc_like($table_name))) === $table_name
            && $wpdb->get_var("SHOW COLUMNS FROM $table_name LIKE 'claimed_at'") === 'claimed_at'
        );
        }
    public static function getDedupClaimsTableName() {
        global $wpdb;
        return $wpdb->prefix . 'sekianafraz_dedup_claims';
    }
    public static function getSensorCoverageTableName() {
        global $wpdb;
        return $wpdb->prefix . 'sekianafraz_sensor_coverage';
    }
    public static function getSensorExclusionsTableName() {
        global $wpdb;
        return $wpdb->prefix . 'sekianafraz_sensor_exclusions';
    }
    public static function getCouponRedemptionsTableName() {
        global $wpdb;
        return $wpdb->prefix . 'sekianafraz_coupon_redemptions';
    }
public static function getCouponRegistryTableName() {
        global $wpdb;
        return $wpdb->prefix . 'sekianafraz_coupon_registry';
    }
    public static function getSMSQueueTableName() {
        global $wpdb;
        return $wpdb->prefix . 'sekianafraz_sms_queue';
    }
}
