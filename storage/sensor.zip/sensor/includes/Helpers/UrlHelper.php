<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
class UrlHelper
{
    public function normalizeTargetUrl(string $url): string
    {
        $u = trim($url);
        if ($u === '') return '';
        if (preg_match('~^[a-z][a-z0-9+.-]*://~i', $u)) return $u;
        if (strpos($u, '//') === 0) return $u;
        if ($u[0] === '/') return $u;
        return 'https://' . $u;
    }
    public function absoluteUrlForMessaging(string $url): string
    {
        $u = trim($url);
        if ($u === '') return '';
        if (preg_match('~^[a-z][a-z0-9+.-]*://~i', $u)) return $u;
        if (strpos($u, '//') === 0) return $u;
        if ($u[0] === '/') {
            $home = rtrim(home_url('/'), '/');
            return $home . $u;
        }
        return $u;
    }
}
