<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
class PhoneNormalizer
{
    public static function mobile(string $raw): string
    {
        $raw = strtr($raw, ['۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9',
            '٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9']);
        $digits = preg_replace('/\D+/', '', $raw);
        if (strpos($digits, '0098') === 0) $digits = substr($digits, 4);
        if (strpos($digits, '98') === 0) $digits = substr($digits, 2);
        if (strlen($digits) === 10) $digits = '0' . $digits;
        return preg_match('/^09\d{9}$/', $digits) ? $digits : '';
    }
}
