<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
class RateLimiter
{
    public static function consume(string $scope, int $limit, int $ttl): bool
    {
        global $wpdb;
        $key = 'sekianafraz_action_rate_' . hash_hmac('sha256', $scope, wp_salt('auth'));
        $lock = 'sekianafraz_rate_' . md5(DB_NAME . '|' . $wpdb->prefix . '|' . $key);
        if ((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,2)', $lock)) !== 1) return false;
        try {
            if (!wp_using_ext_object_cache()) {
                wp_cache_delete('_transient_' . $key, 'options');
                wp_cache_delete('_transient_timeout_' . $key, 'options');
                wp_cache_delete('notoptions', 'options');
            }
            $count = (int)get_transient($key);
            if ($wpdb->last_error !== '' || $count >= max(1, $limit)) return false;
            return set_transient($key, $count + 1, max(MINUTE_IN_SECONDS, $ttl));
        } finally {
            $wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)', $lock));
        }
    }
}
