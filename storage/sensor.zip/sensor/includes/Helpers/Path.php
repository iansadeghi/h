<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
class Path
{
    public static function homePath(): string
    {
        $homePath = (string)wp_parse_url(home_url('/'), PHP_URL_PATH);
        if ($homePath === '') $homePath = '/';
        return $homePath;
    }
    public static function canonicalize(string $value, ?string $homePath = null): string
    {
        $path = (string)wp_parse_url($value, PHP_URL_PATH);
        if ($path === '') $path = '/';
        $homePath = $homePath ?? '';
        if ($homePath !== '' && $homePath !== '/' && strpos($path, $homePath) === 0) {
            $path = substr($path, strlen(rtrim($homePath, '/')));
            if ($path === '') $path = '/';
        }
        $path = '/' . ltrim($path, '/');
        $path = rtrim($path, '/');
        return $path === '' ? '/' : $path;
    }
}
