<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
class AdminVars
{
    public static function catalog(): array
    {
        $base = [
            ['key' => 'display_name', 'label' => 'نام کاربر'],
            ['key' => 'coupon_code', 'label' => 'کد تخفیف'],
            ['key' => 'coupon_value', 'label' => 'مقدار تخفیف'],
            ['key' => 'coupon_valid_hours', 'label' => 'اعتبار (ساعت)'],
            ['key' => 'coupon_expiry_time', 'label' => 'زمان انقضا'],
        ];
        $placements = [
            'product_single' => array_merge([['key'=>'product_name','label'=>'نام محصول']], $base),
            'product_in_cat' => array_merge([['key'=>'product_name','label'=>'نام محصول']], $base),
            'product_in_tag' => array_merge([['key'=>'product_name','label'=>'نام محصول']], $base),
            'product_cat'    => array_merge([['key'=>'category_name','label'=>'نام دسته‌بندی محصول']], $base),
            'product_tag'    => array_merge([['key'=>'product_tag_name','label'=>'نام برچسب محصول']], $base),
            'post_single'    => array_merge([['key'=>'post_name','label'=>'نام نوشته']], $base),
            'post_in_cat'    => array_merge([['key'=>'post_name','label'=>'نام نوشته']], $base),
            'post_in_tag'    => array_merge([['key'=>'post_name','label'=>'نام نوشته']], $base),
            'post_cat'       => array_merge([['key'=>'post_category_name','label'=>'نام دسته‌بندی نوشته']], $base),
            'post_tag'       => array_merge([['key'=>'post_tag_name','label'=>'نام برچسب نوشته']], $base),
            'page'           => array_merge([['key'=>'page_name','label'=>'نام صفحه']], $base),
            'custom_url'     => array_merge([['key'=>'page_name','label'=>'نام صفحه']], $base),
            'search_terms'   => array_merge([['key'=>'search_term','label'=>'عبارت جستجو']], $base),
        ];
        $out = [];
        foreach ($placements as $placement => $vars) {
            $out[$placement] = [
                'banner' => $vars,
                'promo'  => array_merge($vars, [['key' => 'target_url', 'label' => 'لینک مقصد']]),
                'pattern'=> array_merge($vars, [['key' => 'target_url', 'label' => 'مسیر لینک مقصد']]),
            ];
        }
        return $out;
    }
}
