<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
class Shortener
{
	public function register(): void
	{
		add_action('init', [$this, 'addRewrite']);
		add_filter('query_vars', [$this, 'addQueryVar']);
		add_action('template_redirect', [$this, 'maybeRedirect']);
	}
	public function addRewrite(): void
	{
		add_rewrite_rule('^go/([0-9]{1,4})/?$', 'index.php?sekianafraz_go=$matches[1]', 'top');
	}
	public function addQueryVar(array $vars): array
	{
		$vars[] = 'sekianafraz_go';
		return $vars;
	}
	public function maybeRedirect(): void
	{
		$token = get_query_var('sekianafraz_go');
		if (!$token) return;
		$code = preg_replace('/[^0-9]/', '', (string)$token);
		if ($code === '') return;
		$optKey = $this->optionKey($code);
		$url = get_option($optKey, '');
		if ($url) {
			wp_redirect($url, 301);
			exit;
		}
		wp_redirect(home_url('/'), 302);
		exit;
	}
	public static function shorten(string $url): string
	{
		$u = trim($url);
		if ($u === '') return '';
		$start = self::numericCode($u);
		$code = self::claimCode($start, $u);
		$base = rtrim(home_url('/'), '/');
		return $base . '/go/' . $code;
	}
	private static function numericCode(string $url): int
	{
		$hash = hexdec(substr(md5($url), 0, 8));
		$code = ($hash % 9999) + 1;
		return (int)$code;
	}
	private static function claimCode(int $start, string $url): string
	{
		$code = $start;
		for ($i=0; $i<9999; $i++) {
			$optKey = self::optionKey((string)$code);
			$stored = get_option($optKey, '');
			if ($stored === '') {
				add_option($optKey, $url, '', 'no');
				return (string)$code;
			}
			if ($stored === $url) return (string)$code;
			$code = ($code % 9999) + 1;
		}
		return (string)$start;
	}
	private static function optionKey(string $code): string
	{
		return 'sekianafraz_short_' . $code;
	}
}
