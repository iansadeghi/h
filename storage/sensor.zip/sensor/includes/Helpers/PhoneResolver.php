<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
class PhoneResolver
{
    private $map = [
        'sync_with_sitologin' => ['key' => '_sitologin_user_phone', 'value' => 'phone'],
        'sync_with_digits' => ['key' => 'digits_phone', 'value' => 'getPhoneWithPlus98'],
        'sync_with_amozshyar' => ['key' => 'amzshyar_phone', 'value' => 'getPhoneWithoutZero'],
        'sync_with_ehraz' => ['key' => 'eh_user_phone', 'value' => 'phone'],
        'sync_with_ostadsho' => ['key' => 'phone_number', 'value' => 'phone'],
        'sync_with_easylogin' => ['key' => 'biger_phone', 'value' => 'phone'],
        'sync_with_vira' => ['key' => 'mobile_user', 'value' => 'phone'],
        'sync_with_hoopi' => ['key' => 'hoopi_phoneno', 'value' => 'getPhoneWithoutZero'],
        'sync_with_kerasno' => ['key' => 'mreeir_phone', 'value' => 'phone'],
        'woocommerce_billing' => ['key' => 'billing_phone', 'value' => 'phone'],
        'generic_phone' => ['key' => 'phone', 'value' => 'phone'],
        'generic_mobile' => ['key' => 'mobile', 'value' => 'phone'],
        'generic_user_mobile' => ['key' => 'user_mobile', 'value' => 'phone'],
        'generic_user_phone' => ['key' => 'user_phone', 'value' => 'phone'],
        'generic_mobile_number' => ['key' => 'mobile_number', 'value' => 'phone'],
    ];
    public function resolve(int $userId): string
    {
        $map = array_merge($this->map, $this->customMap());
        foreach ($map as $item) {
            $val = get_user_meta($userId, $item['key'], true);
            $phone = is_scalar($val) ? PhoneNormalizer::mobile((string)$val) : '';
            if ($phone !== '') return $phone;
        }
        return '';
    }
    public function metaKeys(): array
    {
        $map = array_merge($this->map, $this->customMap());
        return array_values(array_unique(array_map(static function (array $item): string {
            return (string)$item['key'];
        }, $map)));
    }
    private function customMap(): array
    {
        $items = get_option('sekianafraz_phone_compat_custom', []);
        if (!is_array($items)) return [];
        $map = [];
        foreach ($items as $item) {
            $metaKey = isset($item['meta_key']) ? sanitize_text_field($item['meta_key']) : '';
            if ($metaKey === '') continue;
            $map['custom_'.$metaKey] = ['key' => $metaKey, 'value' => 'phone'];
        }
        return $map;
    }
}
