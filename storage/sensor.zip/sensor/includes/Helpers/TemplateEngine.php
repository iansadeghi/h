<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
class TemplateEngine
{
    public function buildVars(int $sensorId, array $payload): array
    {
        $fallback = (string)get_post_meta($sensorId, 'display_name_fallback', true);
        if ($fallback === '') $fallback = 'کاربر';
        $vars = [
            'display_name' => is_user_logged_in() ? wp_get_current_user()->display_name : $fallback,
            'coupon_code' => $payload['coupon_code'] ?? '',
            'coupon_expiry_time' => $payload['coupon_expiry_time'] ?? '',
            'coupon_value' => $payload['coupon_value'] ?? '',
            'coupon_valid_hours' => $payload['coupon_valid_hours'] ?? '',
        ];
        $p = get_post_meta($sensorId, 'placement', true);
        $visitCalculation = (string)get_post_meta($sensorId, 'visit_calculation', true);
        $ctx = isset($_REQUEST['sekianafraz_ctx']) && is_array($_REQUEST['sekianafraz_ctx']) ? (array)$_REQUEST['sekianafraz_ctx'] : [];
        $matchedItem = isset($ctx['matched_item']) ? sanitize_text_field((string)$ctx['matched_item']) : '';
        $firstId = function($key) use ($ctx, $matchedItem): int {
            if ($matchedItem !== '' && ctype_digit($matchedItem)) return (int)$matchedItem;
            $arr = isset($ctx[$key]) && is_array($ctx[$key]) ? $ctx[$key] : [];
            $id = $arr[0] ?? 0;
            return (int)$id;
        };
        $getTitleById = function(int $id): string { if ($id > 0) { $p = get_post($id); return $p ? (string)$p->post_title : ''; } return ''; };
        if ($visitCalculation !== 'aggregate' && in_array($p, ['product_single', 'product_in_cat', 'product_in_tag'], true)) {
            $id = ($matchedItem !== '' && ctype_digit($matchedItem)) ? (int)$matchedItem : (int)($ctx['product_id'] ?? 0);
            if (!$id) { $id = function_exists('get_the_ID') ? (int)get_the_ID() : 0; }
            if (!$id && function_exists('get_queried_object_id')) $id = (int)get_queried_object_id();
            if ($id) $vars['product_name'] = $getTitleById($id);
        }
        if ($visitCalculation !== 'aggregate' && $p === 'product_cat') {
            $tid = $firstId('product_cat_ids');
            if ($tid) { $t = get_term($tid, 'product_cat'); $vars['category_name'] = ($t && !is_wp_error($t)) ? (string)$t->name : ''; }
        }
        if ($visitCalculation !== 'aggregate' && $p === 'product_tag') {
            $tid = $firstId('product_tag_ids');
            if ($tid) { $t = get_term($tid, 'product_tag'); $vars['product_tag_name'] = ($t && !is_wp_error($t)) ? (string)$t->name : ''; }
        }
        if ($visitCalculation !== 'aggregate' && in_array($p, ['post_single', 'post_in_cat', 'post_in_tag'], true)) {
            $id = ($matchedItem !== '' && ctype_digit($matchedItem)) ? (int)$matchedItem : (int)($ctx['post_id'] ?? 0);
            if (!$id) { $id = function_exists('get_the_ID') ? (int)get_the_ID() : 0; }
            if (!$id && function_exists('get_queried_object_id')) $id = (int)get_queried_object_id();
            if ($id) $vars['post_name'] = $getTitleById($id);
        }
        if ($visitCalculation !== 'aggregate' && $p === 'post_cat') {
            $tid = $firstId('post_cat_ids');
            if ($tid) { $t = get_term($tid, 'category'); $vars['post_category_name'] = ($t && !is_wp_error($t)) ? (string)$t->name : ''; }
        }
        if ($visitCalculation !== 'aggregate' && $p === 'post_tag') {
            $tid = $firstId('post_tag_ids');
            if ($tid) { $t = get_term($tid, 'post_tag'); $vars['post_tag_name'] = ($t && !is_wp_error($t)) ? (string)$t->name : ''; }
        }
        if ($visitCalculation !== 'aggregate' && $p === 'page') {
            $id = ($matchedItem !== '' && ctype_digit($matchedItem)) ? (int)$matchedItem : (int)($ctx['page_id'] ?? 0);
            if (!$id) { $id = function_exists('get_the_ID') ? (int)get_the_ID() : 0; }
            if (!$id && function_exists('get_queried_object_id')) $id = (int)get_queried_object_id();
            if ($id) $vars['page_name'] = $getTitleById($id);
        }
        if ($visitCalculation !== 'aggregate' && $p === 'custom_url') {
            $id = (int)($ctx['page_id'] ?? 0);
            if (!$id) $id = (int)($ctx['post_id'] ?? 0);
            if (!$id) $id = (int)($ctx['product_id'] ?? 0);
            if ($id) $vars['page_name'] = $getTitleById($id);
        }
        if ($visitCalculation !== 'aggregate' && $p === 'search_terms') {
            $term = isset($ctx['search_term']) ? sanitize_text_field((string)$ctx['search_term']) : '';
            if ($term !== '') $vars['search_term'] = $term;
        }
        return $vars;
    }
    public function render(string $text, array $vars, bool $allowHtml): string
    {
        $out = $allowHtml ? wp_kses_post($text) : wp_strip_all_tags($text);
        foreach ($vars as $k => $v) {
            $safe = $allowHtml ? esc_html((string)$v) : ($k === 'target_url' ? wp_strip_all_tags((string)$v) : sanitize_text_field((string)$v));
            $out = str_replace('{{'.$k.'}}', $safe, $out);
        }
        return $out;
    }
}
