<?php
namespace SeKianAfraz\VisitDiscount\Helpers;
if (!defined('ABSPATH')) { exit; }
final class PhoneMetaDiscovery
{
    public function discover(array $excludedKeys = [], int $limit = 50): array
    {
        global $wpdb;
        $limit = max(1, min(200, $limit));
        $excluded = [];
        foreach ($excludedKeys as $key) {
            if (!is_scalar($key)) continue;
            $key = (string)$key;
            if ($key !== '') $excluded[$key] = true;
        }
        $expr = 'TRIM(meta_value)';
        $replacements = [
            ["' '", "''"],
            ["CHAR(9)", "''"],
            ["'-'", "''"],
            ["'('", "''"],
            ["')'", "''"],
            ["'.'", "''"],
            ["'/'", "''"],
            ["'+'", "''"],
            ["'۰'", "'0'"], ["'۱'", "'1'"], ["'۲'", "'2'"], ["'۳'", "'3'"], ["'۴'", "'4'"],
            ["'۵'", "'5'"], ["'۶'", "'6'"], ["'۷'", "'7'"], ["'۸'", "'8'"], ["'۹'", "'9'"],
            ["'٠'", "'0'"], ["'١'", "'1'"], ["'٢'", "'2'"], ["'٣'", "'3'"], ["'٤'", "'4'"],
            ["'٥'", "'5'"], ["'٦'", "'6'"], ["'٧'", "'7'"], ["'٨'", "'8'"], ["'٩'", "'9'"],
        ];
        foreach ($replacements as [$from, $to]) {
            $expr = "REPLACE({$expr}, {$from}, {$to})";
        }
        $nineDigits = '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]';
        $pattern = '^(09' . $nineDigits . '|9' . $nineDigits . '|989' . $nineDigits . '|00989' . $nineDigits . ')$';
        $sql = $wpdb->prepare(
            "SELECT meta_key, COUNT(*) AS phone_hits
             FROM {$wpdb->usermeta}
             WHERE meta_key <> ''
               AND CHAR_LENGTH(meta_key) <= 191
               AND CHAR_LENGTH(TRIM(meta_value)) BETWEEN 10 AND 32
               AND {$expr} REGEXP %s
             GROUP BY meta_key
             ORDER BY phone_hits DESC, meta_key ASC
             LIMIT %d",
            $pattern,
            $limit
        );
        $rows = $wpdb->get_results($sql, ARRAY_A);
        if ($rows === null || $wpdb->last_error) {
            throw new \RuntimeException('User meta discovery query failed.');
        }
        $keys = [];
        foreach ($rows as $row) {
            $key = isset($row['meta_key']) ? (string)$row['meta_key'] : '';
            if ($key === '' || isset($excluded[$key]) || isset($keys[$key])) continue;
            if (strlen($key) > 191 || preg_match('/[\x00-\x1F\x7F]/', $key)) continue;
            if (sanitize_text_field($key) !== $key) continue;
            $keys[$key] = $key;
        }
        return array_values($keys);
    }
}
