<?php
namespace SeKianAfraz\VisitDiscount;
use SeKianAfraz\VisitDiscount\Helpers\AdminVars;
if (!defined('ABSPATH')) { exit; }
final class Plugin
{
    private static $instance;
    public static function instance(): self
    {
        if (!self::$instance) self::$instance = new self();
        return self::$instance;
    }
    public function boot(): void
    {
        (new Leads\PhoneOwnerIndex())->register();
        (new Leads\PhoneOwnerCache())->register();
        add_action('init', [$this, 'init']);
        add_action('sekianafraz_coverage_retry', static function (string $method, array $args): void {
            (new Sensors\SensorCoverageService())->retry($method, $args);
        }, 10, 2);
        add_action('admin_menu', [$this, 'adminMenu']);
        add_action('rest_api_init', [$this, 'registerRoutes']);
        add_action('wp_ajax_sekianafraz_context', [new Frontend\SessionContext(), 'bootstrap']);
        add_action('wp_ajax_nopriv_sekianafraz_context', [new Frontend\SessionContext(), 'bootstrap']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueFrontend']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAdmin']);
        if (is_admin()) {
            add_action('admin_post_sekianafraz_export_leads', static function (): void {
                (new Leads\LeadsExporter())->download();
            });
        }
        add_action('admin_head', [$this, 'suppressOtherNotices']);
        add_action('admin_head', [$this, 'addAdminMenuStyles']);
        add_action('admin_head', [$this, 'renderFavicon']);
        add_action('in_admin_header', [$this, 'renderAdminPreloader'], 0);
        add_action('admin_bar_menu', [$this, 'trimAdminBar'], 999);
        add_filter('admin_footer_text', [$this, 'adminFooterText']);
        add_filter('update_footer', [$this, 'adminFooterVersion'], 11);
        add_action('wp_after_insert_post', [$this, 'syncCoverageForPostTransition'], 30, 4);
        add_action('set_object_terms', [$this, 'syncCoverageForTerms'], 30, 6);
        add_action('deleted_post', [$this, 'syncCoverageForDeletedPost'], 30, 2);
        add_action('created_term', [$this, 'syncCoverageForNewTaxonomy'], 30, 3);
        add_action('delete_term', [$this, 'syncCoverageForTaxonomy'], 30, 5);
        if (class_exists('SeKianAfraz\VisitDiscount\Modules\ModuleLoader')) {
            \SeKianAfraz\VisitDiscount\Modules\ModuleLoader::boot();
        }
        if (class_exists('SeKianAfraz\VisitDiscount\Orders\OrderReferral')) {
            (new Orders\OrderReferral())->register();
        }
        if (class_exists('SeKianAfraz\VisitDiscount\Cache\CacheCompatibility')) {
            (new Cache\CacheCompatibility())->register();
        }
    }
    public function init(): void
    {
        (new Sensors\SensorCPT())->register();
        (new Cron\Cleanup())->register();
        $this->ensureSensorIndexReady();
        $this->ensureSensorCoverageReady();
        load_plugin_textdomain('sekianafraz-visit-discount', false, dirname(plugin_basename(SEKIANAFRAZ_FILE)) . '/languages');
    }
    public function adminMenu(): void
    {
        add_menu_page('سنسور | تخفیف براساس بازدید', 'سنسور', 'manage_options', 'sekianafraz', [new Admin\AdminPage(), 'render'], $this->menuIconDataUri(), 56);
    }
    private function menuIconDataUri(): string
    {
        $iconPath = SEKIANAFRAZ_PATH . 'assets/img/faw.svg';
        if (!is_readable($iconPath)) {
            return 'dashicons-chart-line';
        }
        $svg = file_get_contents($iconPath);
        if (!is_string($svg) || $svg === '') {
            return 'dashicons-chart-line';
        }
        $svg = preg_replace(
            '/<rect\s+fill=["\']#5F0027["\']\s+width=["\']449\.3["\']\s+height=["\']449\.3["\']\s*\/>/i',
            '',
            $svg,
            1
        );
        return 'data:image/svg+xml;base64,' . base64_encode($svg);
    }
    public function trimAdminBar(\WP_Admin_Bar $adminBar): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->id !== 'toplevel_page_sekianafraz') {
            return;
        }
        $nodes = $adminBar->get_nodes();
        if (!is_array($nodes)) {
            return;
        }
        foreach ($nodes as $node) {
            $parent = (string) ($node->parent ?? '');
            if ($parent === '' && !in_array($node->id, ['site-name', 'my-account', 'root-default', 'top-secondary'], true)) {
                $adminBar->remove_node($node->id);
                continue;
            }
            if ($parent === 'root-default' && $node->id !== 'site-name') {
                $adminBar->remove_node($node->id);
                continue;
            }
            if ($parent === 'top-secondary' && $node->id !== 'my-account') {
                $adminBar->remove_node($node->id);
            }
        }
    }
    public function registerRoutes(): void
    {
        (new Rest\Routes())->register();
    }
    public function enqueueFrontend(): void
    {
        if (!$this->shouldEnqueueFrontend()) {
            return;
        }
        $context = (new Frontend\Tracker())->getPageContext();
        $relevant = (new Sensors\SensorService())->findRelevantForPage($context);
        if (empty($relevant)) {
            return;
        }
        $context['sensors'] = $relevant;
        $context['arad_font_url'] = SEKIANAFRAZ_URL . 'assets/fonts/AradFD-VF.woff2';
        $assets = [
            'script' => 'assets/js/banner-view.js',
            'styles' => ['assets/css/banner.css', 'assets/css/frontend.css'],
        ];
        $versionedUrl = static function (string $path): string {
            return add_query_arg('ver', (string)filemtime(SEKIANAFRAZ_PATH . $path), SEKIANAFRAZ_URL . $path);
        };
        $context['banner_assets'] = [
            'script' => $versionedUrl($assets['script']),
            'styles' => array_map($versionedUrl, $assets['styles']),
        ];
        $jsVer = (string)filemtime(SEKIANAFRAZ_PATH . 'assets/js/tracker.js');
        wp_register_script('sekianafraz-tracker', SEKIANAFRAZ_URL . 'assets/js/tracker.js', [], $jsVer, true);
        wp_localize_script('sekianafraz-tracker', 'SEKIANAFRAZ_CTX', $context);
        wp_enqueue_script('sekianafraz-tracker');
    }
    public function enqueueAdmin(string $hook): void
    {
        if (strpos($hook, 'sekianafraz') === false) return;
        wp_enqueue_media();
        $preloaderCssVer = file_exists(SEKIANAFRAZ_PATH . 'assets/css/preloader.css') ? (string) filemtime(SEKIANAFRAZ_PATH . 'assets/css/preloader.css') : SEKIANAFRAZ_VERSION;
        wp_register_style('sekianafraz-preloader', SEKIANAFRAZ_URL . 'assets/css/preloader.css', [], $preloaderCssVer);
        $adminStyles = [
            'sekianafraz-banner-view' => ['assets/css/banner.css', []],
            'sekianafraz-admin-base'     => ['assets/css/admin/base.css', []],
            'sekianafraz-admin-modal'    => ['assets/css/admin/modal.css', ['sekianafraz-admin-base', 'sekianafraz-banner-view']],
            'sekianafraz-admin-pages'    => ['assets/css/admin/pages.css', ['sekianafraz-admin-modal']],
            'sekianafraz-admin-controls' => ['assets/css/admin/controls.css', ['sekianafraz-admin-pages']],
            'sekianafraz-admin-sections' => ['assets/css/admin/sections.css', ['sekianafraz-admin-controls']],
            'sekianafraz-admin'          => ['assets/css/admin/spa.css', ['sekianafraz-admin-sections']],
        ];
        foreach ($adminStyles as $handle => [$path, $dependencies]) {
            $version = file_exists(SEKIANAFRAZ_PATH . $path) ? (string) filemtime(SEKIANAFRAZ_PATH . $path) : SEKIANAFRAZ_VERSION;
            wp_register_style($handle, SEKIANAFRAZ_URL . $path, $dependencies, $version);
        }
        wp_register_script('sekianafraz-lottie', 'https://cdnjs.cloudflare.com/ajax/libs/bodymovin/5.12.2/lottie_light.min.js', [], '5.12.2', true);
        $adminScripts = [
            'sekianafraz-banner-view' => ['assets/js/banner-view.js', []],
            'sekianafraz-reminder-style' => ['assets/js/reminder-style.js', []],
            'sekianafraz-admin-core'             => ['assets/js/admin/core.js', ['jquery', 'wp-api-fetch']],
            'sekianafraz-admin-controls'         => ['assets/js/admin/controls.js', ['sekianafraz-admin-core', 'sekianafraz-lottie']],
            'sekianafraz-admin-sms-guide'        => ['assets/js/admin/sms-guide.js', ['sekianafraz-admin-controls']],
            'sekianafraz-admin-sensor-sections'  => ['assets/js/admin/sensor-sections.js', ['sekianafraz-admin-controls']],
            'sekianafraz-admin-sensor-actions'   => ['assets/js/admin/sensor-actions.js', ['sekianafraz-admin-sensor-sections', 'sekianafraz-admin-sms-guide']],
            'sekianafraz-admin-sensor-fields'    => ['assets/js/admin/sensor-fields.js', ['sekianafraz-admin-sensor-actions']],
            'sekianafraz-admin-sensor-preview'   => ['assets/js/admin/sensor-preview.js', ['sekianafraz-admin-sensor-fields', 'sekianafraz-banner-view', 'sekianafraz-reminder-style']],
            'sekianafraz-admin-sensor-lifecycle' => ['assets/js/admin/sensor-lifecycle.js', ['sekianafraz-admin-sensor-preview']],
            'sekianafraz-admin-pages'            => ['assets/js/admin/pages.js', ['sekianafraz-admin-sensor-lifecycle']],
            'sekianafraz-admin'                  => ['assets/js/admin.js', ['sekianafraz-admin-pages']],
        ];
        foreach ($adminScripts as $handle => [$path, $dependencies]) {
            $version = file_exists(SEKIANAFRAZ_PATH . $path) ? (string) filemtime(SEKIANAFRAZ_PATH . $path) : SEKIANAFRAZ_VERSION;
            wp_register_script($handle, SEKIANAFRAZ_URL . $path, $dependencies, $version, true);
        }
        wp_localize_script('sekianafraz-admin-core', 'SEKIANAFRAZ_ADMIN', [
            'nonce' => wp_create_nonce('wp_rest'),
            'rest' => esc_url_raw(rest_url('sekianafraz/v1/')),
            'base_path' => (string)(wp_parse_url(home_url('/'), PHP_URL_PATH) ?: '/'),
            'home_url' => esc_url_raw(home_url('/')),
            'assets_url' => esc_url_raw(SEKIANAFRAZ_URL . 'assets/'),
        ]);
        $varsCatalog = AdminVars::catalog();
        wp_localize_script('sekianafraz-admin-core', 'SEKIANAFRAZ_ADMIN_VARS', $varsCatalog);
        wp_add_inline_script('sekianafraz-admin', 'window.$ = window.$ || window.jQuery || undefined;');
        wp_enqueue_style('sekianafraz-preloader');
        wp_enqueue_style('sekianafraz-admin');
        wp_enqueue_script('sekianafraz-admin');
        $css = ".sekianafraz-brand { height: 65px !important; }";
        wp_add_inline_style('sekianafraz-admin', $css);
        (new \SeKianAfraz\VisitDiscount\Admin\AdminPage())->enqueueVars();
        $spaVer = file_exists(SEKIANAFRAZ_PATH . 'assets/js/admin-spa.js') ? (string) filemtime(SEKIANAFRAZ_PATH . 'assets/js/admin-spa.js') : SEKIANAFRAZ_VERSION;
        wp_register_script('sekianafraz-admin-spa', SEKIANAFRAZ_URL . 'assets/js/admin-spa.js', ['sekianafraz-admin'], $spaVer, true);
        wp_localize_script('sekianafraz-admin-spa', 'SEKIANAFRAZ_SPA', [
            'rest'  => esc_url_raw(rest_url('sekianafraz/v1/')),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);
        wp_enqueue_script('sekianafraz-admin-spa');
        $preloaderJsVer = file_exists(SEKIANAFRAZ_PATH . 'assets/js/preloader.js') ? (string) filemtime(SEKIANAFRAZ_PATH . 'assets/js/preloader.js') : SEKIANAFRAZ_VERSION;
        wp_register_script('sekianafraz-preloader', SEKIANAFRAZ_URL . 'assets/js/preloader.js', ['sekianafraz-admin-spa'], $preloaderJsVer, true);
        wp_add_inline_script(
            'sekianafraz-preloader',
            '(function(){window.setTimeout(function(){var p=document.getElementById("sekianafrazPreloader");var b=document.getElementById("sekianafrazPreloaderBar");if(p)p.classList.add("is-hidden");if(b)b.classList.add("is-hidden");window.setTimeout(function(){if(p)p.remove();if(b)b.remove();document.documentElement.classList.add("sekianafraz-preloading-done");},500);},5500);}());',
            'after'
        );
        wp_enqueue_script('sekianafraz-preloader');
    }
    public function renderAdminPreloader(): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->id !== 'toplevel_page_sekianafraz') {
            return;
        }
        $logoPath = SEKIANAFRAZ_PATH . 'assets/img/sensor.svg';
        if (!is_readable($logoPath)) {
            return;
        }
        $logo = file_get_contents($logoPath);
        if (!is_string($logo) || $logo === '') {
            return;
        }
        $logo = preg_replace('/<svg\b/', '<svg class="sekianafraz-preloader-logo"', $logo, 1);
        echo '<div id="sekianafrazPreloaderBar" aria-hidden="true"><div class="sekianafraz-preloader-bar-fill"></div></div>';
        echo '<div id="sekianafrazPreloader" role="status" aria-label="در حال بارگذاری صفحه">';
        echo $logo;
        echo '</div>';
        echo '<script>(function(){window.SEKIANAFRAZPreloaderStartedAt=performance.now();window.setTimeout(function(){var p=document.getElementById("sekianafrazPreloader");var b=document.getElementById("sekianafrazPreloaderBar");if(p)p.classList.add("is-hidden");if(b)b.classList.add("is-hidden");window.setTimeout(function(){if(p)p.remove();if(b)b.remove();document.documentElement.classList.add("sekianafraz-preloading-done");},500);},5000);}());</script>';
    }
    public function suppressOtherNotices(): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if ($screen && $screen->id === 'toplevel_page_sekianafraz') {
            remove_all_actions('admin_notices');
            remove_all_actions('all_admin_notices');
        }
    }
    public function renderFavicon(): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->id !== 'toplevel_page_sekianafraz') return;
        $faviconUrl = esc_url(SEKIANAFRAZ_URL . 'assets/img/faw.webp');
        echo '<link rel="icon" type="image/webp" href="' . $faviconUrl . '" sizes="32x32">' . "\n";
        echo '<link rel="shortcut icon" type="image/webp" href="' . $faviconUrl . '">' . "\n";
    }
    public function addAdminMenuStyles(): void
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->id !== 'toplevel_page_sekianafraz') return;
        echo '<style>
            body.toplevel_page_sekianafraz{--wp-admin-theme-color:var(--sekianafraz-primary);--wp-admin-theme-color--rgb:var(--sekianafraz-primary-rgb);--wp-admin-theme-color-darker-10:var(--sekianafraz-primary);--wp-admin-theme-color-darker-20:var(--sekianafraz-primary);background:var(--sekianafraz-white);}
            body.toplevel_page_sekianafraz #wpadminbar,
            body.toplevel_page_sekianafraz #adminmenuback,
            body.toplevel_page_sekianafraz #adminmenuwrap,
            body.toplevel_page_sekianafraz #adminmenu{background:var(--sekianafraz-black);}
            body.toplevel_page_sekianafraz #adminmenu a{color:var(--sekianafraz-white);}
            body.toplevel_page_sekianafraz #adminmenu .wp-submenu{background:var(--sekianafraz-black);}
            body.toplevel_page_sekianafraz #adminmenu a:hover,
            body.toplevel_page_sekianafraz #adminmenu li.menu-top:hover,
            body.toplevel_page_sekianafraz #adminmenu li.opensub>a.menu-top,
            body.toplevel_page_sekianafraz #adminmenu li>a.menu-top:focus{background-color:var(--sekianafraz-primary)!important;color:var(--sekianafraz-white)!important;}
            body.toplevel_page_sekianafraz #adminmenu li.menu-top:hover div.wp-menu-image:before,
            body.toplevel_page_sekianafraz #adminmenu li.opensub>a.menu-top div.wp-menu-image:before,
            body.toplevel_page_sekianafraz #adminmenu li>a.menu-top:focus div.wp-menu-image:before{color:var(--sekianafraz-white)!important;}
            body.toplevel_page_sekianafraz #adminmenu .wp-submenu a:hover,
            body.toplevel_page_sekianafraz #adminmenu .wp-submenu a:focus,
            body.toplevel_page_sekianafraz #adminmenu .wp-submenu li.current a,
            body.toplevel_page_sekianafraz #adminmenu .wp-submenu li.current a:hover{background:var(--sekianafraz-primary);color:var(--sekianafraz-white);}
            body.toplevel_page_sekianafraz #adminmenu li.current a.menu-top,
            body.toplevel_page_sekianafraz #adminmenu li.wp-has-current-submenu a.wp-has-current-submenu,
            body.toplevel_page_sekianafraz #toplevel_page_sekianafraz>a{background:var(--sekianafraz-primary)!important;color:var(--sekianafraz-white)!important;}
            body.toplevel_page_sekianafraz #toplevel_page_sekianafraz .wp-menu-image:before{color:var(--sekianafraz-white)!important;}
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile) .ab-top-menu>li:hover>.ab-item,
            body.toplevel_page_sekianafraz #wpadminbar .ab-top-menu>li.menupop.hover>.ab-item,
            body.toplevel_page_sekianafraz #wpadminbar.nojq .quicklinks .ab-top-menu>li>.ab-item:focus,
            body.toplevel_page_sekianafraz #wpadminbar.nojs .ab-top-menu>li.menupop:hover>.ab-item,
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile) .ab-top-menu>li>.ab-item:focus,
            body.toplevel_page_sekianafraz #wpadminbar .menupop .ab-sub-wrapper .ab-item:hover,
            body.toplevel_page_sekianafraz #wpadminbar .menupop .ab-sub-wrapper .ab-item:focus{background:var(--sekianafraz-primary)!important;color:var(--sekianafraz-white)!important;}
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile)>#wp-toolbar a:focus span.ab-label,
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile)>#wp-toolbar li.hover span.ab-label,
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile)>#wp-toolbar li:hover span.ab-label,
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile)>#wp-toolbar li:hover span.noticon,
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile) li:hover .ab-icon:before,
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile) li:hover .ab-item:before,
            body.toplevel_page_sekianafraz #wpadminbar:not(.mobile) li:hover .ab-item:after,
            body.toplevel_page_sekianafraz #wpadminbar li.hover .ab-icon:before,
            body.toplevel_page_sekianafraz #wpadminbar li.hover .ab-item:before,
            body.toplevel_page_sekianafraz #wpadminbar li.hover .ab-item:after,
            body.toplevel_page_sekianafraz #wpadminbar .ab-item:focus .ab-icon:before,
            body.toplevel_page_sekianafraz #wpadminbar .ab-item:focus:before,
            body.toplevel_page_sekianafraz #wpadminbar .ab-item:focus:after,
            body.toplevel_page_sekianafraz #wpadminbar .ab-sub-wrapper .ab-item:hover,
            body.toplevel_page_sekianafraz #wpadminbar .ab-sub-wrapper .ab-item:hover strong,
            body.toplevel_page_sekianafraz #wpadminbar .ab-sub-wrapper .ab-item:focus,
            body.toplevel_page_sekianafraz #wpadminbar .ab-sub-wrapper .ab-item:focus strong{color:var(--sekianafraz-white)!important;}
            body.toplevel_page_sekianafraz #collapse-button:hover,
            body.toplevel_page_sekianafraz #collapse-button:focus{background:var(--sekianafraz-primary)!important;color:var(--sekianafraz-white)!important;}
            html[dir="rtl"] body.toplevel_page_sekianafraz ul#adminmenu a.wp-has-current-submenu:after,
            html[dir="rtl"] body.toplevel_page_sekianafraz ul#adminmenu>li.current>a.current:after{border-left-color:var(--sekianafraz-white);border-right-color:transparent;}
            html[dir="ltr"] body.toplevel_page_sekianafraz ul#adminmenu a.wp-has-current-submenu:after,
            html[dir="ltr"] body.toplevel_page_sekianafraz ul#adminmenu>li.current>a.current:after{border-right-color:var(--sekianafraz-white);border-left-color:transparent;}
            body.toplevel_page_sekianafraz #wpwrap,
            body.toplevel_page_sekianafraz #wpcontent,
            body.toplevel_page_sekianafraz #wpbody,
            body.toplevel_page_sekianafraz #wpbody-content,
            body.toplevel_page_sekianafraz .sekianafraz-admin,
            body.toplevel_page_sekianafraz #wpfooter{background:var(--sekianafraz-white);}
            body.toplevel_page_sekianafraz #wpfooter{color:var(--sekianafraz-black);}
            body.toplevel_page_sekianafraz #wpfooter a{color:var(--sekianafraz-primary);font-weight:700;}
        </style>';
    }
    public function adminFooterText($text): string
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->id !== 'toplevel_page_sekianafraz') return (string)$text;
        return '<span class="sekianafraz-footer-credit">طراحی و توسعه توسط <strong>تیم برنامه‌نویسی کیان‌افراز</strong></span>';
    }
    public function adminFooterVersion($text): string
    {
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->id !== 'toplevel_page_sekianafraz') return (string)$text;
        return 'سنسور — نسخه ' . esc_html(SEKIANAFRAZ_VERSION);
    }
    private function shouldEnqueueFrontend(): bool
    {
        if (is_admin()) return false;
        if (is_front_page() || is_home()) return true;
        if (function_exists('is_product') && is_product()) return true;
        if (function_exists('is_cart') && is_cart()) return true;
        if (function_exists('is_checkout') && is_checkout()) return true;
        if (is_singular('post')) return true;
        if (is_page()) return true;
        if (is_search()) return true;
        if (function_exists('is_product_category') && is_product_category()) return true;
        if (function_exists('is_product_tag') && is_product_tag()) return true;
        if (is_category() || is_tag()) return true;
        return false;
    }
    private function ensureSensorIndexReady(): void
    {
        if (get_option('sekianafraz_sensor_index_ready')) {
            return;
        }
        if (!class_exists('SeKianAfraz\VisitDiscount\\Database\\Schema')) {
            return;
        }
        if (\SeKianAfraz\VisitDiscount\Database\Schema::createSensorIndexTable()) {
            update_option('sekianafraz_sensor_index_ready', 1, true);
        }
    }
    private function ensureSensorCoverageReady(): void
    {
        if (get_option('sekianafraz_sensor_coverage_ready')) return;
        if (!class_exists('SeKianAfraz\VisitDiscount\\Database\\Schema')) return;
        if (\SeKianAfraz\VisitDiscount\Database\Schema::createSensorCoverageTables()) {
            update_option('sekianafraz_sensor_coverage_ready', 1, true);
        }
    }
    public function syncCoverageForPostTransition($postId, $post, $update, $postBefore): void
    {
        $postId = (int)$postId;
        if ($postId <= 0 || !class_exists('SeKianAfraz\VisitDiscount\\Sensors\\SensorCoverageService')) return;
        $relevantTypes = ['product', 'post', 'page'];
        $afterType = is_object($post) && isset($post->post_type) ? (string)$post->post_type : '';
        $beforeType = is_object($postBefore) && isset($postBefore->post_type) ? (string)$postBefore->post_type : '';
        $afterStatus = is_object($post) && isset($post->post_status) ? (string)$post->post_status : '';
        $beforeStatus = is_object($postBefore) && isset($postBefore->post_status) ? (string)$postBefore->post_status : '';
        if ($afterType === $beforeType && $afterStatus === $beforeStatus) return;
        if ($afterStatus !== 'publish' && $beforeStatus !== 'publish') return;
        $coverage = new Sensors\SensorCoverageService();
        if (in_array($beforeType, $relevantTypes, true) && $beforeType !== $afterType) {
            $coverage->syncPostObject($postId, $beforeType);
        }
        if (in_array($afterType, $relevantTypes, true)) {
            $coverage->syncPostObject($postId, $afterType);
        }
    }
    public function syncCoverageForDeletedPost(int $postId, $post): void
    {
        $postType = is_object($post) && isset($post->post_type) ? (string)$post->post_type : '';
        if (!in_array($postType, ['product', 'post', 'page'], true)) return;
        if (!class_exists('SeKianAfraz\VisitDiscount\\Sensors\\SensorCoverageService')) return;
        (new Sensors\SensorCoverageService())->syncPostObject($postId, $postType);
    }
    public function syncCoverageForTerms($objectId, $terms, $termTaxonomyIds, $taxonomy, $append, $oldTermTaxonomyIds): void
    {
        $postTypeByTaxonomy = [
            'product_cat' => 'product',
            'product_tag' => 'product',
            'category' => 'post',
            'post_tag' => 'post',
        ];
        $taxonomy = (string)$taxonomy;
        $objectId = (int)$objectId;
        if (!isset($postTypeByTaxonomy[$taxonomy]) || $objectId <= 0) return;
        $newIds = array_values(array_unique(array_filter(array_map('intval', (array)$termTaxonomyIds))));
        $oldIds = array_values(array_unique(array_filter(array_map('intval', (array)$oldTermTaxonomyIds))));
        sort($newIds, SORT_NUMERIC);
        sort($oldIds, SORT_NUMERIC);
        if ($newIds === $oldIds) return;
        if (get_post_type($objectId) !== $postTypeByTaxonomy[$taxonomy] || get_post_status($objectId) !== 'publish') return;
        if (!class_exists('SeKianAfraz\VisitDiscount\\Sensors\\SensorCoverageService')) return;
        (new Sensors\SensorCoverageService())->syncPostObject($objectId, $postTypeByTaxonomy[$taxonomy]);
    }
    public function syncCoverageForTaxonomy($termId, $termTaxonomyId = 0, $taxonomy = '', $deletedTerm = null, $objectIds = null): void
    {
        if (!class_exists('SeKianAfraz\VisitDiscount\\Sensors\\SensorCoverageService')) return;
        (new Sensors\SensorCoverageService())->syncTaxonomy((string)$taxonomy, (int)$termId, true, is_array($objectIds) ? $objectIds : null);
    }
    public function syncCoverageForNewTaxonomy($termId, $termTaxonomyId = 0, $taxonomy = ''): void
    {
        if (!class_exists('SeKianAfraz\VisitDiscount\\Sensors\\SensorCoverageService')) return;
        (new Sensors\SensorCoverageService())->syncTaxonomy((string)$taxonomy, (int)$termId, false);
    }
}
