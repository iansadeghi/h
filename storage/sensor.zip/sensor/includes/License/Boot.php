<?php
if (!defined('ABSPATH')) { exit; }
add_action('sekianafraz_apply_coupon_limits', static function (int $couponId, string $limitType, array $limitIds): void {
	$limitType = sanitize_key($limitType);
	$limitIds = array_values(array_filter(array_map('intval', $limitIds)));
	if ($couponId <= 0 || !class_exists('WC_Coupon')) return;
	$coupon = new \WC_Coupon($couponId);
	if ($coupon->get_id() <= 0) return;
	if ($limitType === 'product') {
		$coupon->set_product_ids($limitIds);
		$coupon->save();
	} elseif ($limitType === 'category') {
		$coupon->set_product_categories($limitIds);
		$coupon->save();
	}
}, 10, 3);
add_filter('sekianafraz_issue_virtual_coupon', static function ($handled, int $sensorId, int $userId, string $guestId, array $meta) {
	$issuer = new \SeKianAfraz\VisitDiscount\Coupons\VirtualCouponIssuer();
	return $issuer->issueForSensor($sensorId, $userId, $guestId, $meta);
}, 10, 5);
if (!class_exists('WooCommerce')) {
	add_action('admin_notices', static function (): void {
		echo '<div class="notice notice-error"><p>' . esc_html__('برای اجرای افزونه تخفیف براساس بازدید، ووکامرس باید نصب و فعال باشد.', 'sekianafraz-visit-discount') . '</p></div>';
	});
} else {
	require_once SEKIANAFRAZ_PATH . 'includes/Orders/OrderReferral.php';
	if (class_exists('SeKianAfraz\\VisitDiscount\\Plugin')) {
		\SeKianAfraz\VisitDiscount\Plugin::instance()->boot();
	}
}
