<?php
namespace SeKianAfraz\VisitDiscount\Frontend;
if (!defined('ABSPATH')) { exit; }
class ReminderBar
{
    public function register(): void
    {
        $tags = ['sekianafraz_reminder_bar', 'sekianafraz_reminderbar', 'sekianafraz_reminder'];
        foreach ($tags as $tag) {
            $tag = trim((string)$tag);
            if ($tag === '') continue;
            if (function_exists('shortcode_exists') && shortcode_exists($tag)) {
                continue;
            }
            add_shortcode($tag, [$this, 'render']);
        }
    }
    public function render(): string
    {
        if (!defined('SEKIANAFRAZ_URL') || !defined('SEKIANAFRAZ_VERSION')) {
            return '';
        }
        $this->enqueueAssets();
        return '<div id="sekianafraz-reminder-bar-root"></div>';
    }
    private function enqueueAssets(): void
    {
        wp_enqueue_style(
            'sekianafraz-reminder-bar',
            SEKIANAFRAZ_URL . 'assets/css/reminder-bar.css',
            [],
            SEKIANAFRAZ_VERSION
        );
        wp_enqueue_script('sekianafraz-reminder-style', SEKIANAFRAZ_URL . 'assets/js/reminder-style.js', [], (string)filemtime(SEKIANAFRAZ_PATH . 'assets/js/reminder-style.js'), true);
        wp_enqueue_script(
            'sekianafraz-reminder-bar',
            SEKIANAFRAZ_URL . 'assets/js/reminder-bar.js',
            ['sekianafraz-reminder-style'],
            SEKIANAFRAZ_VERSION,
            true
        );
        $font_url = SEKIANAFRAZ_URL . 'assets/fonts/AradFD-VF.woff2';
        wp_add_inline_style('sekianafraz-reminder-bar',
            "@font-face { font-family: 'Arad'; src: url('" . esc_url($font_url) . "') format('woff2-variations'); font-weight: 100 900; font-style: normal; }"
        );
    }
}
