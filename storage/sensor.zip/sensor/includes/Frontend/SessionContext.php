<?php
namespace SeKianAfraz\VisitDiscount\Frontend;
use SeKianAfraz\VisitDiscount\Sensors\SensorService;
if (!defined('ABSPATH')) { exit; }
class SessionContext
{
    public function bootstrap(): void
    {
        nocache_headers();
        $origin = (string)($_SERVER['HTTP_ORIGIN'] ?? '');
        $site = wp_parse_url(home_url('/'));
        $source = $origin !== '' ? wp_parse_url($origin) : [];
        if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST'
            || ($_SERVER['HTTP_X_SEKIANAFRAZ_REQUEST'] ?? '') !== 'context'
            || ($_SERVER['HTTP_SEC_FETCH_SITE'] ?? '') === 'cross-site'
            || ($origin !== '' && (!$source || strcasecmp((string)($source['host'] ?? ''), (string)($site['host'] ?? '')) !== 0
                || ($source['scheme'] ?? '') !== ($site['scheme'] ?? '')
                || ($source['port'] ?? null) !== ($site['port'] ?? null)))) {
            wp_send_json_error(['code' => 'INVALID_ORIGIN'], 403);
        }
        $raw = isset($_POST['context']) && is_string($_POST['context']) ? wp_unslash($_POST['context']) : '';
        if (strlen($raw) > 12000) wp_send_json_error(['code' => 'INVALID_CONTEXT'], 413);
        $input = json_decode($raw, true);
        if (!is_array($input)) wp_send_json_error(['code' => 'INVALID_CONTEXT'], 403);
        $context = (new Tracker())->signatureContext($input);
        $timestamp = (int)($input['ts'] ?? 0);
        $signature = is_string($input['sig'] ?? null) ? $input['sig'] : '';
        $expected = hash_hmac('sha256', $timestamp . '|' . wp_json_encode($context), wp_salt('auth'));
        if ($timestamp <= 0 || $timestamp > time() + 300 || !hash_equals($expected, $signature)) {
            wp_send_json_error(['code' => 'INVALID_CONTEXT'], 403);
        }
        $guest = (string)($_COOKIE['sekianafraz_guest_id'] ?? '');
        if (!preg_match('/^[a-f0-9-]{36}$/D', $guest)) $guest = wp_generate_uuid4();
        setcookie('sekianafraz_guest_id', $guest, [
            'expires' => time() + 7 * DAY_IN_SECONDS, 'path' => '/',
            'secure' => is_ssl(), 'httponly' => false, 'samesite' => 'Lax',
        ]);
        $_COOKIE['sekianafraz_guest_id'] = $guest;
        $sensors = (new SensorService())->findRelevantForPage($context);
        $timestamp = time();
        wp_send_json_success([
            'nonce' => is_user_logged_in() ? wp_create_nonce('wp_rest') : '',
            'user' => get_current_user_id(), 'guest_id' => $guest,
            'ts' => $timestamp,
            'sig' => hash_hmac('sha256', $timestamp . '|' . wp_json_encode($context), wp_salt('auth')),
            'sensors' => $sensors,
        ]);
    }
}
