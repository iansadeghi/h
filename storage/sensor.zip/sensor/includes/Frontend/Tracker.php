<?php
namespace SeKianAfraz\VisitDiscount\Frontend;
use SeKianAfraz\VisitDiscount\Helpers\Path;
if (!defined('ABSPATH')) { exit; }
class Tracker
{
    public function getPageContext(): array
    {
        $homePath = Path::homePath();
        $requestUri = $_SERVER['REQUEST_URI'] ?? '/';
        $stripped = Path::canonicalize($requestUri, $homePath);
        $ctx = [
            'rest' => esc_url_raw(rest_url('sekianafraz/v1/')),
            'bootstrap' => esc_url_raw(admin_url('admin-ajax.php')),
            'base_path' => $homePath,
            'path' => $stripped,
            'guest_cookie' => 'sekianafraz_guest_id',
            'user' => get_current_user_id(),
        ];
        if (function_exists('is_product') && is_product()) {
            $productId = function_exists('get_queried_object_id') ? (int)get_queried_object_id() : 0;
            if ($productId <= 0 && function_exists('get_the_ID')) $productId = (int)get_the_ID();
            if ($productId > 0) {
                $ctx['product_id'] = $productId;
            }
        }
        if (is_single() && get_post_type() === 'post') {
            $postId = function_exists('get_queried_object_id') ? (int)get_queried_object_id() : 0;
            if ($postId <= 0 && function_exists('get_the_ID')) $postId = (int)get_the_ID();
            if ($postId > 0) {
                $ctx['post_id'] = $postId;
            }
        }
        if (is_page()) $ctx['page_id'] = get_the_ID();
        if (is_product_category()) $ctx['product_cat_ids'] = [get_queried_object_id()];
        if (is_product_tag()) $ctx['product_tag_ids'] = [get_queried_object_id()];
        if (is_category()) $ctx['post_cat_ids'] = [get_queried_object_id()];
        if (is_tag()) $ctx['post_tag_ids'] = [get_queried_object_id()];
        if (is_search()) $ctx['search_term'] = get_search_query();
        $timestamp = time();
        $signatureContext = $this->signatureContext($ctx);
        $ctx['ts'] = $timestamp;
        $ctx['sig'] = hash_hmac(
            'sha256',
            $timestamp . '|' . wp_json_encode($signatureContext),
            wp_salt('auth')
        );
        return $ctx;
    }
    public function signatureContext(array $ctx): array
    {
        return [
            'path' => Path::canonicalize((string)($ctx['path'] ?? ''), Path::homePath()),
            'search_term' => sanitize_text_field((string)($ctx['search_term'] ?? '')),
            'product_id' => (int)($ctx['product_id'] ?? 0),
            'post_id' => (int)($ctx['post_id'] ?? 0),
            'page_id' => (int)($ctx['page_id'] ?? 0),
            'product_cat_ids' => $this->normalizeIds($ctx['product_cat_ids'] ?? []),
            'product_tag_ids' => $this->normalizeIds($ctx['product_tag_ids'] ?? []),
            'post_cat_ids' => $this->normalizeIds($ctx['post_cat_ids'] ?? []),
            'post_tag_ids' => $this->normalizeIds($ctx['post_tag_ids'] ?? []),
        ];
    }
    private function normalizeIds($ids): array
    {
        if (is_wp_error($ids)) return [];
        $ids = array_values(array_unique(array_filter(array_map('intval', (array)$ids))));
        sort($ids, SORT_NUMERIC);
        return $ids;
    }
}
