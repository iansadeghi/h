<?php
namespace SeKianAfraz\VisitDiscount\Reminder;
if (!defined('ABSPATH')) { exit; }
class ReminderBuilder
{
    public function build(int $sensorId, array $meta, string $couponCode, int $expiresAtMs, int $issuedAtMs): ?array
    {
        $reminderEnabled = (bool)($meta['reminder_enabled'] ?? false);
        $couponStrategy = (string)($meta['coupon_strategy'] ?? 'individual');
        if (($meta['banner_type'] ?? 'single') === 'multi' && (($meta['audience'] ?? '') !== 'logged'
            || !in_array($meta['logged_behavior'] ?? 'single_sms', ['single', 'single_sms'], true))) return null;
        if (!$reminderEnabled) return null;
        if (!in_array($couponStrategy, ['individual','virtual'], true)) return null;
        $serverNowMs = (int)(microtime(true) * 1000);
        $expiresInMs = 0;
        if ($expiresAtMs > 0) {
            $expiresInMs = max(0, $expiresAtMs - $serverNowMs);
        }
        return [
            'sensor_id' => $sensorId,
            'coupon_code' => $couponCode,
            'expires_at_ms' => $expiresAtMs,
            'expires_in_ms' => $expiresInMs,
            'server_now_ms' => $serverNowMs,
            'message_template' => (string)($meta['reminder_message_template'] ?? ''),
            'show_timer_panel' => (bool)($meta['reminder_show_timer_panel'] ?? false),
            'styles' => (array)($meta['reminder_styles'] ?? []),
            'colors' => (array)($meta['reminder_colors'] ?? []),
            'issued_at_ms' => $issuedAtMs,
        ];
    }
}
