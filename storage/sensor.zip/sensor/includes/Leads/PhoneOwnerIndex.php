<?php
namespace SeKianAfraz\VisitDiscount\Leads;
use SeKianAfraz\VisitDiscount\Helpers\PhoneNormalizer;
use SeKianAfraz\VisitDiscount\Helpers\PhoneResolver;
if (!defined('ABSPATH')) { exit; }
class PhoneOwnerIndex
{
    private const EVENT = 'sekianafraz_phone_index_batch';
    public function register(): void
    {
        add_action(self::EVENT, [$this, 'buildBatch']);
        foreach (['added_user_meta', 'updated_user_meta', 'deleted_user_meta'] as $hook) {
            add_action($hook, [$this, 'metaChanged'], 10, 4);
        }
        add_action('deleted_user', [$this, 'userDeleted']);
        add_action('update_option_sekianafraz_phone_compat_custom', [$this, 'keysChanged'], 10, 2);
        add_action('add_option_sekianafraz_phone_compat_custom', [$this, 'keysChanged'], 10, 2);
        add_action('init', [$this, 'schedule']);
    }
    public function schedule(): void
    {
        if (!get_option('sekianafraz_phone_index_complete') && !wp_next_scheduled(self::EVENT)) {
            wp_schedule_single_event(time() + 1, self::EVENT);
        }
    }
    private function ready(): bool
    {
        if (get_option('sekianafraz_phone_index_ready')) return true;
        if (!\SeKianAfraz\VisitDiscount\Database\Schema::createPhoneIndexTable()) return false;
        update_option('sekianafraz_phone_index_ready', 1, false);
        return true;
    }
    public function buildBatch(): void
    {
        if (get_option('sekianafraz_phone_index_complete') || !$this->ready()) return;
        $lock = (int)get_option('sekianafraz_phone_index_lock');
        if ($lock && $lock < time() - 120) delete_option('sekianafraz_phone_index_lock');
        if (!add_option('sekianafraz_phone_index_lock', time(), '', false)) return;
        try {
            global $wpdb;
            $generation = (int)get_option('sekianafraz_phone_index_generation', 0);
            if (get_option('sekianafraz_phone_index_reset')) {
                $ids = $wpdb->get_col("SELECT meta_id FROM {$wpdb->prefix}sekianafraz_phone_index ORDER BY meta_id LIMIT 1000");
                if ($wpdb->last_error) return;
                if ($ids) {
                    if ($wpdb->query("DELETE FROM {$wpdb->prefix}sekianafraz_phone_index WHERE meta_id IN (" . implode(',', array_map('absint', $ids)) . ')') === false) return;
                    return;
                }
                if ($generation !== (int)get_option('sekianafraz_phone_index_generation', 0)) return;
                delete_option('sekianafraz_phone_index_reset');
            }
            $after = (int)get_option('sekianafraz_phone_index_cursor', 0);
            $keys = (new PhoneResolver())->metaKeys();
            $keyHolders = implode(',', array_fill(0, count($keys), '%s'));
            $rows = $wpdb->get_results($wpdb->prepare(
                "SELECT umeta_id,user_id,meta_key,IF(meta_key IN ({$keyHolders}),meta_value,'') AS meta_value FROM {$wpdb->usermeta}
                 WHERE umeta_id > %d ORDER BY umeta_id ASC LIMIT 1000", array_merge($keys, [$after])), ARRAY_A) ?: [];
            if ($wpdb->last_error) { $this->schedule(); return; }
            $candidates = [];
            foreach ($rows as $row) {
                if (!in_array($row['meta_key'], $keys, true)) continue;
                $phone = PhoneNormalizer::mobile((string)$row['meta_value']);
                if ($phone !== '') $candidates[] = [$row, $phone];
            }
            foreach (array_chunk($candidates, 100) as $chunk) {
                $parts = [];
                foreach ($chunk as [$row, $phone]) {
                    $parts[] = $wpdb->prepare('SELECT %d AS meta_id, %s AS phone, %s AS raw_value',
                        (int)$row['umeta_id'], $phone, (string)$row['meta_value']);
                }
                $sql = "INSERT IGNORE INTO {$wpdb->prefix}sekianafraz_phone_index (meta_id,user_id,phone)
                    SELECT m.umeta_id,m.user_id,c.phone FROM (" . implode(' UNION ALL ', $parts) . ") c
                    INNER JOIN {$wpdb->usermeta} m ON m.umeta_id=c.meta_id AND BINARY m.meta_value=BINARY c.raw_value";
                if ($wpdb->query($sql) === false) { $this->schedule(); return; }
            }
            if ($generation !== (int)get_option('sekianafraz_phone_index_generation', 0)) return;
            if ($rows) update_option('sekianafraz_phone_index_cursor', (int)end($rows)['umeta_id'], false);
            if (count($rows) < 1000) update_option('sekianafraz_phone_index_complete', 1, true);
        } finally {
            delete_option('sekianafraz_phone_index_lock');
            $this->schedule();
            (new PhoneOwnerCache())->schedule();
        }
        $this->schedule();
    }
    private function syncMeta(int $metaId): void
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_phone_index';
        $oldPhone = (string)$wpdb->get_var($wpdb->prepare("SELECT phone FROM {$table} WHERE meta_id=%d", $metaId));
        $row = $wpdb->get_row($wpdb->prepare(
            "SELECT user_id,meta_key,meta_value FROM {$wpdb->usermeta} WHERE umeta_id=%d", $metaId), ARRAY_A);
        $phone = $row && in_array($row['meta_key'], (new PhoneResolver())->metaKeys(), true)
            ? PhoneNormalizer::mobile((string)$row['meta_value']) : '';
        if ($phone === '') $wpdb->delete($table, ['meta_id' => $metaId], ['%d']);
        else $wpdb->replace($table, ['meta_id' => $metaId, 'user_id' => (int)$row['user_id'], 'phone' => $phone], ['%d','%d','%s']);
        $cache = new PhoneOwnerCache();
        foreach (array_unique([$oldPhone, $phone]) as $changed) if ($changed !== '') $cache->enqueue($changed);
    }
    public function metaChanged($metaIds, $userId, $key, $value): void
    {
        if (!in_array($key, (new PhoneResolver())->metaKeys(), true)) return;
        if (!get_option('sekianafraz_phone_index_ready')) { $this->schedule(); return; }
        foreach ((array)$metaIds as $id) $this->syncMeta((int)$id);
    }
    public function keysChanged($oldValue, $newValue): void
    {
        if ($oldValue === $newValue) return;
        update_option('sekianafraz_phone_index_generation', (int)get_option('sekianafraz_phone_index_generation', 0) + 1, false);
        update_option('sekianafraz_phone_index_reset', 1, false);
        (new PhoneOwnerCache())->invalidateAll();
        update_option('sekianafraz_phone_index_cursor', 0, false);
        update_option('sekianafraz_phone_index_complete', 0, true);
        $this->schedule();
    }
    public function userDeleted($userId): void
    {
        if (!get_option('sekianafraz_phone_index_ready')) return;
        global $wpdb;
        $phones = $wpdb->get_col($wpdb->prepare("SELECT DISTINCT phone FROM {$wpdb->prefix}sekianafraz_phone_index WHERE user_id=%d", (int)$userId));
        $wpdb->delete($wpdb->prefix . 'sekianafraz_phone_index', ['user_id' => (int)$userId], ['%d']);
        foreach ($phones as $phone) (new PhoneOwnerCache())->enqueue($phone);
    }
    public function forLeadIds(array $ids): array
    {
        return (new PhoneOwnerCache())->forLeadIds($ids);
    }
}
