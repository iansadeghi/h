<?php
namespace SeKianAfraz\VisitDiscount\Leads;
if (!defined('ABSPATH')) { exit; }
class LeadsExporter
{
    private $selectedIds = [];
    public function download(): void
    {
        if (!current_user_can('manage_options')) wp_die('دسترسی مجاز نیست.', '', ['response' => 403]);
        check_admin_referer('sekianafraz_export_leads');
        $format = sanitize_key((string)($_GET['format'] ?? ''));
        if (!in_array($format, ['csv', 'xlsx'], true)) wp_die('فرمت خروجی نامعتبر است.', '', ['response' => 400]);
        if (!LeadsRepository::ensureReady()) wp_die('جدول شماره‌ها در دسترس نیست.', '', ['response' => 500]);
        if (isset($_GET['ids'])) {
            $this->selectedIds = array_values(array_unique(array_filter(array_map('absint', explode(',', wp_unslash((string)$_GET['ids']))))));
            if (!$this->selectedIds || count($this->selectedIds) > 500) wp_die('انتخاب شماره‌ها نامعتبر است.', '', ['response' => 400]);
        }
        $repository = new LeadsRepository();
        $maxId = $repository->maxId();
        $name = 'sekianafraz-collected-leads-' . gmdate('Y-m-d-His') . '.' . $format;
        if ($format === 'csv') {
            nocache_headers();
            header('Content-Type: text/csv; charset=UTF-8');
            header('Content-Disposition: attachment; filename="' . $name . '"');
            $out = fopen('php://output', 'wb');
            if (!$out) wp_die('ایجاد خروجی ممکن نیست.', '', ['response' => 500]);
            fwrite($out, "\xEF\xBB\xBF");
            fputcsv($out, $this->headings(), ',', '"', '');
            foreach ($this->batches($repository, $maxId) as $batch) {
                foreach ($batch as $row) {
                    fputcsv($out, array_map([$this, 'csvSafe'], $this->values($row)), ',', '"', '');
                }
            }
            fclose($out);
            exit;
        }
        if (!class_exists('ZipArchive')) wp_die('افزونهٔ ZIP برای خروجی اکسل روی سرور فعال نیست.', '', ['response' => 500]);
        $sheetPath = wp_tempnam('sekianafraz-leads-sheet.xml');
        $zipPath = wp_tempnam('sekianafraz-leads.xlsx');
        if (!$sheetPath || !$zipPath) wp_die('ایجاد خروجی ممکن نیست.', '', ['response' => 500]);
        try {
            $sheet = fopen($sheetPath, 'wb');
            if (!$sheet) wp_die('ایجاد خروجی ممکن نیست.', '', ['response' => 500]);
            fwrite($sheet, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>');
            $line = 1;
            $this->writeRow($sheet, $line++, $this->headings());
            foreach ($this->batches($repository, $maxId) as $batch) {
                foreach ($batch as $row) $this->writeRow($sheet, $line++, $this->values($row));
            }
            fwrite($sheet, '</sheetData></worksheet>');
            fclose($sheet);
            $zip = new \ZipArchive();
            if ($zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE) !== true) {
                wp_die('ایجاد خروجی اکسل ممکن نیست.', '', ['response' => 500]);
            }
            $zip->addFromString('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?>'
                . '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                . '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                . '<Default Extension="xml" ContentType="application/xml"/>'
                . '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                . '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                . '</Types>');
            $zip->addFromString('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?>'
                . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                . '</Relationships>');
            $zip->addFromString('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8"?>'
                . '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                . 'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                . '<sheets><sheet name="شماره‌های جمع‌آوری‌شده" sheetId="1" r:id="rId1"/></sheets></workbook>');
            $zip->addFromString('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8"?>'
                . '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                . '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                . 'Target="worksheets/sheet1.xml"/></Relationships>');
            if (!$zip->addFile($sheetPath, 'xl/worksheets/sheet1.xml')) {
                $zip->close();
                wp_die('ایجاد خروجی اکسل ممکن نیست.', '', ['response' => 500]);
            }
            if (!$zip->close()) wp_die('ایجاد خروجی اکسل ممکن نیست.', '', ['response' => 500]);
            nocache_headers();
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment; filename="' . $name . '"');
            header('Content-Length: ' . filesize($zipPath));
            readfile($zipPath);
        } finally {
            @unlink($sheetPath);
            @unlink($zipPath);
        }
        exit;
    }
    private function batches(LeadsRepository $repository, int $maxId): \Generator
    {
        $after = 0;
        do {
            $batch = $repository->batchAfter($after, $maxId, 500, $this->selectedIds);
            if (!$batch) break;
            yield $batch;
            $after = (int)end($batch)['id'];
        } while (count($batch) === 500);
    }
    private function headings(): array
    {
        return ['شناسه لید', 'شماره تلفن', 'شناسه سنسور', 'نام سنسور', 'وضعیت پیامک', 'زمان ثبت (UTC)', 'زمان ویرایش (UTC)'];
    }
    private function values(array $row): array
    {
        $status = ['sent' => 'ارسال‌شده', 'failed' => 'ناموفق', 'pending' => 'در انتظار'];
        return [(string)$row['id'], (string)$row['phone'], (string)$row['sensor_id'],
            (string)$row['sensor_name'], $status[$row['sms_status']] ?? 'در انتظار',
            (string)$row['created_at'], (string)$row['updated_at']];
    }
    private function csvSafe(string $value): string
    {
        if (preg_match('/^\s*[=+\-@]/u', $value) || preg_match('/^[\x00-\x1F]/', $value)) return "'" . $value;
        return $value;
    }
    private function writeRow($handle, int $line, array $values): void
    {
        fwrite($handle, '<row r="' . $line . '">');
        foreach ($values as $index => $value) {
            $column = chr(65 + $index);
            $escaped = htmlspecialchars((string)$value, ENT_XML1 | ENT_QUOTES, 'UTF-8');
            fwrite($handle, '<c r="' . $column . $line . '" t="inlineStr"><is><t xml:space="preserve">'
                . $escaped . '</t></is></c>');
        }
        fwrite($handle, '</row>');
    }
}
