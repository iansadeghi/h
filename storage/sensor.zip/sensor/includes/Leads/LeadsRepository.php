<?php
namespace SeKianAfraz\VisitDiscount\Leads;
use SeKianAfraz\VisitDiscount\Database\Schema;
if (!defined('ABSPATH')) { exit; }
class LeadsRepository
{
    public static function ensureReady(): bool
    {
        if (get_option('sekianafraz_collected_leads_ready')) return true;
        if (!Schema::createCollectedLeadsTable()) return false;
        update_option('sekianafraz_collected_leads_ready', 1, false);
        return true;
    }
    public function record(string $sessionHash, int $sensorId, string $phone): bool
    {
        $phone = \SeKianAfraz\VisitDiscount\Helpers\PhoneNormalizer::mobile($phone);
        if ($phone === '') return false;
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_collected_leads';
        $name = sanitize_text_field((string)get_the_title($sensorId));
        if ($name === '') $name = 'سنسور #' . $sensorId;
        $name = wp_html_excerpt($name, 191, '');
        $now = current_time('mysql', true);
        $result = $wpdb->query($wpdb->prepare(
            "INSERT INTO {$table} (session_hash, sensor_id, sensor_name, phone, sms_status, created_at, updated_at)
             VALUES (%s, %d, %s, %s, 'pending', %s, %s)
             ON DUPLICATE KEY UPDATE updated_at=IF(phone<>VALUES(phone), VALUES(updated_at), updated_at),
                 sms_status='pending', phone=VALUES(phone)",
            $sessionHash, $sensorId, $name, $phone, $now, $now
        ));
        if ($result !== false) (new PhoneOwnerCache())->enqueue($phone, false);
        return $result !== false;
    }
    public function markStatus(string $sessionHash, string $status): void
    {
        if (!in_array($status, ['sent', 'failed'], true)) return;
        global $wpdb;
        $wpdb->update($wpdb->prefix . 'sekianafraz_collected_leads', ['sms_status' => $status],
            ['session_hash' => $sessionHash], ['%s'], ['%s']);
    }
    public function page(int $before = 0): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_collected_leads';
        $cacheReady = (bool)get_option('sekianafraz_phone_owner_cache_ready');
        $ownerColumns = $cacheReady ? 'c.pending AS owner_pending,c.owners AS cached_owners' : 'NULL AS owner_pending,NULL AS cached_owners';
        $query = "SELECT l.id,l.phone,l.sensor_id,l.sensor_name,l.sms_status,l.created_at,l.updated_at,{$ownerColumns}
                  FROM {$table} l";
        if ($cacheReady) $query .= " LEFT JOIN {$wpdb->prefix}sekianafraz_phone_owner_cache c ON c.phone=l.phone";
        if ($before > 0) $query .= $wpdb->prepare(' WHERE l.id < %d', $before);
        $query .= ' ORDER BY l.id DESC LIMIT 51';
        $rows = $wpdb->get_results($query, ARRAY_A) ?: [];
        $hasMore = count($rows) > 50;
        $rows = array_slice($rows, 0, 50);
        foreach ($rows as &$row) {
            $pending = ($row['owner_pending'] ?? null) === null || (int)$row['owner_pending'] === 1;
            $row['owners'] = $pending ? [] : (json_decode((string)($row['cached_owners'] ?? '[]'), true) ?: []);
            $row['owner_status'] = $pending ? 'pending' : ($row['owners'] ? 'matched' : 'unmatched');
            unset($row['owner_pending'], $row['cached_owners']);
            $row['created_local'] = get_date_from_gmt((string)$row['created_at'], 'Y/m/d H:i');
            $row['updated_local'] = get_date_from_gmt((string)$row['updated_at'], 'Y/m/d H:i');
        }
        unset($row);
        return [
            'items' => $rows,
            'has_more' => $hasMore,
            'next_before' => $hasMore ? (int)end($rows)['id'] : 0,
        ];
    }
    public function deleteIds(array $ids): int
    {
        global $wpdb;
        $ids = array_slice(array_values(array_unique(array_filter(array_map('absint', $ids)))), 0, 500);
        if (!$ids) return 0;
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));
        $result = $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}sekianafraz_collected_leads WHERE id IN ({$placeholders})", $ids));
        return $result === false ? -1 : (int)$result;
    }
    public function maxId(): int
    {
        global $wpdb;
        return (int)$wpdb->get_var('SELECT MAX(id) FROM ' . $wpdb->prefix . 'sekianafraz_collected_leads');
    }
    public function batchAfter(int $after, int $maxId, int $limit = 500, array $ids = []): array
    {
        global $wpdb;
        $table = $wpdb->prefix . 'sekianafraz_collected_leads';
        $selection = $ids ? ' AND id IN (' . implode(',', array_map('absint', $ids)) . ')' : '';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT id, phone, sensor_id, sensor_name, sms_status, created_at, updated_at
             FROM {$table} WHERE id > %d AND id <= %d {$selection} ORDER BY id ASC LIMIT %d",
            $after, $maxId, min(500, max(1, $limit))
        ), ARRAY_A) ?: [];
    }
}
