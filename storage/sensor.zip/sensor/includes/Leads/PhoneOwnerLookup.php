<?php
namespace SeKianAfraz\VisitDiscount\Leads;
use SeKianAfraz\VisitDiscount\Helpers\PhoneNormalizer;
use SeKianAfraz\VisitDiscount\Helpers\PhoneResolver;
if (!defined('ABSPATH')) { exit; }
class PhoneOwnerLookup
{
    public function forRows(array $rows): array
    {
        if (!$rows) return [];
        $keys = (new PhoneResolver())->metaKeys();
        if (!$keys) return [];
        $wanted = [];
        $variants = [];
        $persian = ['0'=>'۰','1'=>'۱','2'=>'۲','3'=>'۳','4'=>'۴','5'=>'۵','6'=>'۶','7'=>'۷','8'=>'۸','9'=>'۹'];
        $arabic = ['0'=>'٠','1'=>'١','2'=>'٢','3'=>'٣','4'=>'٤','5'=>'٥','6'=>'٦','7'=>'٧','8'=>'٨','9'=>'٩'];
        foreach ($rows as $row) {
            $phone = PhoneNormalizer::mobile((string)$row['phone']);
            if ($phone === '') continue;
            $wanted[$phone] = [];
            $tail = substr($phone, 1);
            foreach ([$phone, $tail, '98' . $tail, '+98' . $tail, '0098' . $tail] as $variant) {
                $variants[$variant] = true;
                $variants[strtr($variant, $persian)] = true;
                $variants[strtr($variant, $arabic)] = true;
            }
        }
        if (!$variants) return $wanted;
        global $wpdb;
        $keysSql = implode(',', array_fill(0, count($keys), '%s'));
        $valuesSql = implode(',', array_fill(0, count($variants), '%s'));
        $sql = "SELECT m.user_id, m.meta_value, u.display_name, u.user_login
                FROM {$wpdb->usermeta} m INNER JOIN {$wpdb->users} u ON u.ID=m.user_id
                WHERE m.meta_key IN ({$keysSql}) AND m.meta_value IN ({$valuesSql})";
        $matches = $wpdb->get_results($wpdb->prepare($sql,
            array_merge($keys, array_keys($variants))), ARRAY_A) ?: [];
        foreach ($matches as $match) {
            $phone = PhoneNormalizer::mobile((string)$match['meta_value']);
            if ($phone === '' || !isset($wanted[$phone])) continue;
            $id = (int)$match['user_id'];
            $wanted[$phone][$id] = ['id' => $id,
                'name' => (string)($match['display_name'] ?: $match['user_login'])];
        }
        return array_map('array_values', $wanted);
    }
}
