<?php
namespace SeKianAfraz\VisitDiscount\Leads;
if (!defined('ABSPATH')) { exit; }
class PhoneOwnerCache
{
    private const EVENT = 'sekianafraz_phone_owner_cache_batch';
    public function register(): void
    {
        add_action(self::EVENT, [$this, 'runBatch']);
        add_action('init', function (): void {
            if (get_option('sekianafraz_phone_owner_work_pending')) $this->schedule();
        });
    }
    public function schedule(): void
    {
        update_option('sekianafraz_phone_owner_work_pending', '1', true);
        if (!wp_next_scheduled(self::EVENT)) wp_schedule_single_event(time() + 5, self::EVENT);
    }
    public function enqueue(string $phone, bool $invalidate = true): void
    {
        if ($phone === '') return;
        if ($this->ready()) {
            global $wpdb;
            if ($invalidate) {
                $changed = $wpdb->query($wpdb->prepare(
                    "UPDATE {$wpdb->prefix}sekianafraz_phone_owner_cache SET revision=revision+1,pending=1 WHERE phone=%s", $phone));
                if ($changed === 0) return;
            } else {
                $wpdb->query($wpdb->prepare(
                    "INSERT IGNORE INTO {$wpdb->prefix}sekianafraz_phone_owner_cache (phone,revision,pending,owners)
                     VALUES (%s,1,1,'[]')", $phone));
            }
        }
        $this->schedule();
    }
    public function invalidateAll(): void
    {
        update_option('sekianafraz_phone_owner_refresh_generation', (int)get_option('sekianafraz_phone_owner_refresh_generation', 0) + 1, false);
        update_option('sekianafraz_phone_owner_refresh_cursor', '', false);
        update_option('sekianafraz_phone_owner_refresh', 1, false);
        $this->schedule();
    }
    private function ready(): bool
    {
        if (get_option('sekianafraz_phone_owner_cache_ready')) return true;
        if (!\SeKianAfraz\VisitDiscount\Database\Schema::createPhoneOwnerCacheTable()) return false;
        update_option('sekianafraz_phone_owner_cache_ready', 1, false);
        return true;
    }
    public function runBatch(): void
    {
        $lock = (int)get_option('sekianafraz_phone_owner_cache_lock');
        if ($lock && $lock < time() - 120) delete_option('sekianafraz_phone_owner_cache_lock');
        if (!add_option('sekianafraz_phone_owner_cache_lock', time(), '', false)) return;
        $more = true;
        try {
            if (!$this->ready() || !LeadsRepository::ensureReady()) return;
            global $wpdb;
            $table = $wpdb->prefix . 'sekianafraz_phone_owner_cache';
            if (!get_option('sekianafraz_phone_index_complete')) { (new PhoneOwnerIndex())->schedule(); return; }
            $indexGeneration = (int)get_option('sekianafraz_phone_index_generation', 0);
            if (get_option('sekianafraz_phone_owner_refresh')) {
                $refreshGeneration = (int)get_option('sekianafraz_phone_owner_refresh_generation', 0);
                $cursor = (string)get_option('sekianafraz_phone_owner_refresh_cursor', '');
                $phones = $wpdb->get_col($wpdb->prepare("SELECT phone FROM {$table} WHERE phone>%s ORDER BY phone LIMIT 50", $cursor));
                if ($wpdb->last_error) return;
                if ($phones) {
                    $holders = implode(',', array_fill(0, count($phones), '%s'));
                    if ($wpdb->query($wpdb->prepare("UPDATE {$table} SET pending=1,revision=revision+1 WHERE phone IN ({$holders})", $phones)) === false) return;
                    if ($refreshGeneration !== (int)get_option('sekianafraz_phone_owner_refresh_generation', 0)) return;
                    update_option('sekianafraz_phone_owner_refresh_cursor', end($phones), false);
                }
                if ($refreshGeneration !== (int)get_option('sekianafraz_phone_owner_refresh_generation', 0)) return;
                if (count($phones) < 50) delete_option('sekianafraz_phone_owner_refresh');
            }
            $jobs = $wpdb->get_results("SELECT phone,revision FROM {$table} WHERE pending=1 ORDER BY phone LIMIT 50", ARRAY_A);
            if ($jobs === null || $wpdb->last_error) return;
            if ($jobs) {
                $phones = array_column($jobs, 'phone');
                $holders = implode(',', array_fill(0, count($phones), '%s'));
                $rows = $wpdb->get_results($wpdb->prepare(
                    "SELECT DISTINCT p.phone,u.ID,u.display_name,u.user_login
                     FROM {$wpdb->prefix}sekianafraz_phone_index p INNER JOIN {$wpdb->users} u ON u.ID=p.user_id
                     WHERE p.phone IN ({$holders})", $phones), ARRAY_A);
                if ($rows === null || $wpdb->last_error) return;
                $matches = [];
                foreach ($rows as $row) $matches[$row['phone']][(int)$row['ID']] = [
                    'id' => (int)$row['ID'], 'name' => $row['display_name'] ?: $row['user_login']];
                $results = [];
                foreach ($jobs as $job) {
                    $json = wp_json_encode(array_values($matches[$job['phone']] ?? []));
                    $results[] = $wpdb->prepare('SELECT %s AS phone,%d AS revision,%s AS owners',
                        $job['phone'], (int)$job['revision'], $json);
                }
                if ($indexGeneration !== (int)get_option('sekianafraz_phone_index_generation', 0)) return;
                if ($wpdb->query("UPDATE {$table} c INNER JOIN (" . implode(' UNION ALL ', $results) . ") r
                    ON r.phone=c.phone AND r.revision=c.revision
                    SET c.owners=r.owners,c.pending=0 WHERE c.pending=1") === false) return;
            }
            $more = count($jobs) === 50 || get_option('sekianafraz_phone_owner_refresh');
        } finally {
            delete_option('sekianafraz_phone_owner_cache_lock');
            if ($more) $this->schedule();
            else update_option('sekianafraz_phone_owner_work_pending', 0, true);
        }
    }
    public function forLeadIds(array $ids): array
    {
        $ids = array_slice(array_values(array_unique(array_filter(array_map('absint', $ids)))), 0, 50);
        if (!$ids) return ['pending' => false, 'items' => [], 'pending_ids' => []];
        if (!get_option('sekianafraz_phone_owner_cache_ready')) return ['pending' => true, 'items' => [], 'pending_ids' => $ids];
        global $wpdb;
        $holders = implode(',', array_fill(0, count($ids), '%d'));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT l.id,c.pending,c.owners FROM {$wpdb->prefix}sekianafraz_collected_leads l
             LEFT JOIN {$wpdb->prefix}sekianafraz_phone_owner_cache c ON c.phone=l.phone
             WHERE l.id IN ({$holders})", $ids), ARRAY_A) ?: [];
        if ($wpdb->last_error) return ['pending' => true, 'items' => [], 'pending_ids' => $ids];
        $items = []; $pending = [];
        foreach ($rows as $row) {
            $id = (int)$row['id'];
            if ($row['pending'] === null || (int)$row['pending'] === 1) $pending[] = $id;
            else $items[$id] = json_decode((string)$row['owners'], true) ?: [];
        }
        return ['pending' => (bool)$pending, 'pending_ids' => $pending, 'items' => $items,
            'missing_ids' => array_values(array_diff($ids, array_map('intval', array_column($rows, 'id'))))];
    }
}
