<?php
if (!defined('WP_UNINSTALL_PLUGIN')) { exit; }
function sekianafraz_uninstall_site(): void
{
    global $wpdb;
    foreach (['sekianafraz_phone_index', 'sekianafraz_phone_owner_cache', 'sekianafraz_collected_leads',
        'sekianafraz_banner_sessions', 'sekianafraz_sms_queue', 'sekianafraz_sensor_index',
        'sekianafraz_sensor_coverage', 'sekianafraz_sensor_exclusions', 'sekianafraz_action_log',
        'sekianafraz_coupon_registry', 'sekianafraz_coupon_redemptions', 'sekianafraz_dedup_claims'] as $suffix) {
        $table = $wpdb->prefix . $suffix;
        $wpdb->query("DROP TABLE IF EXISTS `{$table}`");
    }
    $sensorIds = get_posts([
        'post_type' => 'sekianafraz_sensor', 'post_status' => 'any', 'numberposts' => -1,
        'fields' => 'ids', 'no_found_rows' => true,
    ]);
    foreach ($sensorIds as $sensorId) wp_delete_post((int)$sensorId, true);
    $couponIds = $wpdb->get_col($wpdb->prepare(
        "SELECT p.ID FROM {$wpdb->posts} p
         INNER JOIN {$wpdb->postmeta} pm ON pm.post_id=p.ID
         WHERE p.post_type=%s AND pm.meta_key=%s AND pm.meta_value=%s",
        'shop_coupon', '_generated_by', 'sekianafraz'
    ));
    foreach ($couponIds as $couponId) {
        $couponId = (int)$couponId;
        if ($couponId <= 0) continue;
        if (class_exists('WC_Coupon')) {
            try {
                $coupon = new \WC_Coupon($couponId);
                if ($coupon->get_id() > 0 && $coupon->delete(true)) {
                    continue;
                }
            } catch (\Throwable $e) {
            }
        }
        wp_delete_post($couponId, true);
    }
    $optionNames = [
        'sekianafraz_sms_settings', 'sekianafraz_phone_strategy', 'sekianafraz_phone_compat_custom',
        'sekianafraz_sms_queue_ready', 'sekianafraz_sensor_index_ready', 'sekianafraz_sensor_coverage_ready',
        'sekianafraz_banner_sessions_ready', 'sekianafraz_collected_leads_ready',
        'sekianafraz_coupon_registry_ready', 'sekianafraz_coupon_redemptions_ready',
        'sekianafraz_phone_index_ready', 'sekianafraz_phone_owner_cache_ready',
        'sekianafraz_phone_index_complete', 'sekianafraz_phone_index_cursor',
        'sekianafraz_phone_index_generation', 'sekianafraz_phone_index_reset', 'sekianafraz_phone_index_lock',
        'sekianafraz_phone_compat_scan_lock',
        'sekianafraz_phone_owner_work_pending', 'sekianafraz_phone_owner_refresh_generation',
        'sekianafraz_phone_owner_refresh_cursor', 'sekianafraz_phone_owner_refresh',
        'sekianafraz_phone_owner_cache_lock', 'sekianafraz_retention_action_log_days',
        'sekianafraz_retention_coupon_registry_days', 'sekianafraz_retention_coupon_redemptions_days',
        'sekianafraz_retention_dedup_claims_minutes',
        'sekianafraz_cleanup_pending',
    ];
    foreach ($optionNames as $optionName) delete_option($optionName);
    foreach (['sekianafraz_coverage_retry', 'sekianafraz_phone_index_batch', 'sekianafraz_phone_owner_cache_batch',
        'sekianafraz_daily_cleanup_event', 'sekianafraz_cleanup_continue', 'sekianafraz_process_sms_queue',
        'sekianafraz_cleanup_sms_queue', 'sekianafraz_continue_sms_queue'] as $hook) {
        wp_clear_scheduled_hook($hook);
    }
    if (function_exists('as_unschedule_all_actions') && did_action('action_scheduler_init')) {
        as_unschedule_all_actions('sekianafraz_continue_sms_queue', [], 'sekianafraz');
    }
    if (function_exists('wc_get_orders')) {
        $metaKeys = ['_sekianafraz_attributed', '_sekianafraz_coupon_codes', '_sekianafraz_sensor_ids'];
        $page = 1;
        do {
            $result = wc_get_orders([
                'type' => 'shop_order',
                'limit' => 100,
                'page' => $page,
                'paginate' => true,
                'orderby' => 'ID',
                'order' => 'ASC',
            ]);
            if (!is_object($result) || !isset($result->orders) || !is_array($result->orders)) {
                break;
            }
            foreach ($result->orders as $order) {
                if (!$order instanceof \WC_Order) {
                    continue;
                }
                foreach ($metaKeys as $metaKey) {
                    $order->delete_meta_data($metaKey);
                }
                $order->save_meta_data();
            }
            $maxPages = isset($result->max_num_pages) ? (int)$result->max_num_pages : 0;
            $page++;
        } while ($page <= $maxPages);
    }
    $likeTransient = $wpdb->esc_like('_transient_sekianafraz_') . '%';
    $likeTimeout = $wpdb->esc_like('_transient_timeout_sekianafraz_') . '%';
    $wpdb->query($wpdb->prepare(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
        $likeTransient,
        $likeTimeout
    ));
}
if (is_multisite()) {
    $siteIds = get_sites(['fields' => 'ids', 'number' => 0]);
    foreach ($siteIds as $siteId) {
        switch_to_blog((int)$siteId);
        sekianafraz_uninstall_site();
        restore_current_blog();
    }
} else {
    sekianafraz_uninstall_site();
}
